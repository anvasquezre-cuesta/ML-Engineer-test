# 22 · Estado y siguiente paso (2026-10-29 tarde; tarea 05 lista para el plan)

Leer primero al retomar, junto con `CLAUDE.md`, `tasks/INDEX.md`, `tasks/05-rag-ingest/` y las últimas filas de `DECISIONS-LOG.md`. El 21 queda como historia: 01-04 están cerradas.

## Tarea activa: 05-rag-ingest (`POST /api/ingest`)
| Etapa | Estado | Dónde |
|---|---|---|
| Research | listo | `tasks/05-rag-ingest/research.md` |
| Auditoría de paquetes | listo | `reviews/2026-10-29-package-audit.md` |
| Literatura | listo (Chroma 2024 verificado por Claude) | `reviews/2026-10-29-literature.md` |
| NB05, parte de ingesta | listo: 96 celdas, 0 errores; falta que JM revise "Mis respuestas" | `ML-Engineer-test/notebooks/05_rag.ipynb`, `reviews/2026-10-29-nb05-review.md` |
| `eval/questions.json` | 22 con respuesta + 4 sin respuesta; `gold` es la lista de páginas válidas | revisado por Claude como experto, con el permiso de JM |
| Decisiones de diseño | aprobadas por JM | `reviews/2026-10-29-decisions-critic.md` |
| Evaluación | lista | `tasks/05-rag-ingest/evaluation.md` |
| Spec | redactada, crítico r1 aplicado (8 cambios); **falta la firma de JM** | `ML-Engineer-test/docs/specs/05-rag-ingest.md`, `reviews/2026-10-29-spec-critic-r1.md` |
| Plan | **siguiente paso** | `tasks/05-rag-ingest/plan.md` |

## Decidido en esta sesión (detalle en DECISIONS-LOG)
- **Chunking:** estrategia A, por página, 500 + overlap 60, por palabras enteras. En la comparación pareada (McNemar, bootstrap de ΔMRR) ninguna de las 6 estrategias se distingue; A se elige por robustez de los nombres en el borde del chunk ("Jennifer Liu"). MiniLM: bge-small empata. La normalización del OCR no cambia nada.
- **Chroma:**
  - un `PersistentClient` por proceso (`lru_cache`) y una colección `documents`;
  - coseno, `embedding_function=None` y nunca `query_texts`;
  - delete `$in` + add;
  - el modelo en la metadata de la colección, con comprobación;
  - `ChromaError` → `VectorStoreError` → 503;
  - **1 worker de uvicorn**. Medido: con varios procesos, el lector ve el `count` nuevo, pero su `query` devuelve el índice viejo.
- **Diseño:**
  - `doc_id` = sha256 completo;
  - `rag_service.ingest()` puro, a imagen de `extract()`;
  - Protocol `Embedder` vía `Depends`;
  - `read_pdf` en `dependencies.py`;
  - PDF en blanco → 200 con 0;
  - tests con `PersistentClient(tmp_path)`;
  - unas 104 líneas.
- **Bonus:** orden Docker > CI > visor. CPU por defecto; GPU como adaptador en 08. Registro vivo de Docker y entorno productivo: `tasks/08-bonus/research.md`.
- **Métricas del RAG para la 06:** `research/18-metricas.md` §8. Un `MIN_SCORE` fijo no separa: u01 y u02 sacan ≈ 0.48, por encima de 11 de las respondibles.
- **El plan de la 05 lo escribe un subagente Plan (Opus) en modo plan**, a pedido de JM. JM lo revisa y lo aprueba.

## Siguiente
1. JM firma la spec 05 (y, si quiere, `/commit-handoff` de `docs(spec): add RAG ingest spec`).
2. Subagente Plan (Opus) → `tasks/05-rag-ingest/plan.md`. Entradas:
   - la spec;
   - `evaluation.md`;
   - `reviews/`;
   - la plantilla de plan de las tareas 03 y 04 (`tasks/04-extract-api/plan.md`);
   - las reglas de `CLAUDE.md`.

   Commits previstos:
   - `feat(config): add RAG ingest settings`;
   - `feat(rag): chunk text without splitting words`;
   - `feat(rag): store chunks in Chroma with unique ids`;
   - `feat(api): add /api/ingest endpoint`;
   - `test(integration): ...`.
3. Al cerrar: `DECISIONS.md` desde `tasks/05-rag-ingest/decisions-draft.md` (cada decisión con su porqué; mostrar texto a JM).
4. Implementación: implementer (Sonnet) + code-critic (Opus) en paralelo, máximo 2 rondas. Después `verify.ps1`, el NB05 "Desde `app/`" (regresión pareada frente al proto A) y la Explicación en el NB05.

## Pendientes que cruzan tareas
- JM: "Mis respuestas" de 02a, 02c, 03 y 05 antes de la entrevista.
- `research/20-preguntas-entrevista.md`: añadir la sección de la 05 al cerrar (el NB05 ya trae 8 preguntas).
- Fecha de entrega (decide cuánto bonus entra).
