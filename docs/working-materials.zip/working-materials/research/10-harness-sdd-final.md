# 10 - Harness minimo y SDD ligero (final)

Fecha: 2026-10-27. CLI 2.1.310, node 24.16 [V]. [V] = probado hoy (docs descargadas en el scratchpad o experimento); [NV] = no verificado. Este documento manda sobre 08 y 09 donde difieran. No se toco el repo: los prototipos estan en el scratchpad.

## 1. Bugs verificados

| # | Bug de 08 | Veredicto | Evidencia |
|---|---|---|---|
| 1 | Ruta equivocada en `commit-handoff` y `delegate` | **Confirmado** | `...\jeikosd\ML-Engineer-test` no existe; la real es `...\parterns_test_ML\ML-Engineer-test` |
| 2 | Deny de git evadible | **Confirmado y peor** | Las docs dicen que `Bash(git push *)` "no casa `git -C . push`" ni `git -c ... push` y que "no es una frontera de seguridad" (permissions.md, "Bash rule limits"). Ademas `secret-guard.js` **no mira git**: devuelve 0 para `git -C . commit`, `git add -A` y `gh pr create` |
| 3 | `allowed-tools` separado por espacios rompe `Bash(git status*)` | **Refutado** | Las docs aceptan "un string separado por espacios o comas, o una lista YAML"; su propio ejemplo es `allowed-tools: Bash(git add *) Bash(git commit *) ...`. El problema real es otro: solo concede permisos durante el turno que invoca la skill, no restringe nada |
| 4 | `verify.ps1` trunca la salida | **Confirmado** | Prueba con un comando falso de 33 lineas: la primera linea de error se pierde (`-Last 15`) y el stderr aparece como ruido `NativeCommandError`. El codigo de salida si se propaga (1) |
| 5 | `commit-msg` demasiado amplio | **Confirmado** | `docs: explain Claude Code harness` sale con 1 (falso positivo). El regex corregido `^\s*(co-authored-by\|assisted-by\|generated-by):.*(claude\|anthropic)\|generated with .*claude` pasa las 5 pruebas. `pre-commit` falla abierto sin gitleaks (8.30.1 esta instalado) |
| 6 | `onFailure` | **Correcto** | Existe desde v2.1.295; estamos en 2.1.310 |

**Nuevos hallazgos**
- **N1.** Nada impide editar `app/models/schemas.py`: el guard devuelve 0 para un Edit sobre ese archivo.
- **N2.** El guard pide confirmacion en `git diff main...HEAD`, justo el comando de la revision.
- **N3.** `grill-me` trae preguntas de wizzatrip (backend/front, migraciones, despliegue) que aqui no aplican.
- **N4.** `CLAUDE.local.md` cita 07 como "cuando exista" (desactualizado). La seccion "Compact Instructions" no aparece en las docs actuales: es una instruccion comun, no un mecanismo [NV].
- **N5.** Resuelto: el clon duplicado `docintel-service` ya no se usa (se borra, ver `DECISIONS-LOG.md`). Repo unico: `ML-Engineer-test`.
- **N6.** Trampa del entorno: en esta maquina el tool Bash convirtio `\\` en `\` dentro de heredocs y `printf`. Los fixtures con rutas Windows deben escribirse con la herramienta Write o con `String.fromCharCode(92)`.
- **N7.** Un deny `Read(**/.env.*)` tambien bloquearia `.env.example`, porque deny gana sobre allow. Para las variantes de `.env` sirve el guard, con su excepcion.

## 2. Mantener / Cortar / Agregar

| Pieza | Decision | Por que |
|---|---|---|
| `attribution` (`""`, `""`, `false`) | Mantener | Valido [V]; red de seguridad aunque Claude no commitee |
| `.git/info/exclude` | Mantener | `.claude/` y `CLAUDE.local.md` no viajan al PR, y el `.gitignore` del upstream queda intacto |
| `upstream` con push `DISABLED` | Mantener | Unico freno no evadible por texto contra empujar al repo de Cuesta |
| `secret-guard.js` (244 lineas) | **Reemplazar** por `guard.js` (31 lineas) | No bloquea git (N1, bug 2), mete friccion (N2) y nadie puede explicarlo linea a linea. El prototipo pasa 18/18 casos [V] |
| 25 reglas deny | **Reducir a 9** | Las reglas de ruta (Read/Edit) son nativas y deterministas; las de texto de comandos quedan como primera capa visible en `/permissions` |
| `allow` | **Agregar** pocas | `Bash(uv run pytest *)`, `Bash(uv run ruff *)` y sus equivalentes PowerShell, mas `verify.ps1`. Evita prompts sin abrir `uv run *`, que permitiria Python arbitrario |
| `verify.ps1` | Arreglar | Capturar la salida, leer `$LASTEXITCODE` justo despues y, si falla, imprimir las primeras 25 lineas y las ultimas 5 |
| `commit-msg`, `pre-commit` | Arreglar | Regex anclado a trailers; `pre-commit` falla cerrado si falta gitleaks |
| `grill-me` | Mantener, reescrita | Preguntas de este proyecto: contrato, AC, fixtures, errores, config |
| `commit-handoff` | Mantener, corregida | Ruta real, `allowed-tools` en YAML solo con git de lectura, sin duplicar gitleaks |
| `py-verify` | **Cortar** | Duplica `verify.ps1`; su checklist manual pasa al agente `reviewer` |
| `delegate` | **Cortar** | Los subagentes custom y general-purpose ya cargan los `CLAUDE*.md`; solo Explore y Plan no (sub-agents.md [V]). Bastan 5 lineas en `CLAUDE.local.md` |
| `untrusted-content` | **Convertir** en `.claude/rules/rag.md` con `paths:` | Solo aplica a codigo RAG; carga bajo demanda |
| `scout` | Mantener, con `maxTurns: 15` | Barato, ya funciona |
| `reviewer` | **Agregar** | Solo `Read, Grep, Glob` (de solo lectura por herramientas). Recibe la ruta de un `.diff` y la spec, no las conclusiones del implementador |
| Hook `Stop` | Agregar tras la rebanada 1 | Corre `verify.ps1` solo si hay `.py` modificados; las docs fijan un tope de 8 bloqueos seguidos [V] |

**Que puede hacer una regla deny en lugar de codigo:**
- `Edit(/app/models/schemas.py)` cubre Edit, Write y NotebookEdit ("las reglas Edit aplican a todas las herramientas que editan" [V]).
- `Read(./.env)`, `Read(**/*.pem)`, `Read(**/*.key)` y `Read(**/GRADING.md)` cubren las lecturas por herramienta (en Grep y Glob es "best-effort").
- Lo que deny **no** puede hacer: reconocer el mismo programa escrito de otra forma (`git -C`, `& git`, `cmd /c git`, una redireccion `>` sobre `schemas.py`). Eso le toca al hook.

## 3. Archivos finales (todos excluidos del PR salvo `docs/specs/`)

```
CLAUDE.local.md            <=80 lineas
.claude/settings.json      attribution; deny(9); allow(5); hooks: PreToolUse->guard.js (onFailure block), Stop->stop-verify.ps1
.claude/hooks/guard.js     31 lineas (prototipo probado en el scratchpad: tl/guard.js + tl/guard_test.js)
.claude/hooks/stop-verify.ps1  ~12 lineas: si `git status --porcelain -- *.py` no esta vacio, corre verify; si falla, exit 2 con resumen
.claude/tools/verify.ps1   ~20 lineas
.claude/rules/tests.md     paths: tests/**  -> nombres test_ac_*, fakes, sin red ni LLM, skipif sin Tesseract, fixtures con Write
.claude/rules/rag.md       paths: app/services/{rag_service,llm_client,vector_service}.py -> OCR = dato no confiable, sources desde codigo, abstencion
.claude/templates/spec.md  plantilla de la seccion 4
.claude/skills/grill-me/SKILL.md, commit-handoff/SKILL.md
.claude/agents/scout.md, reviewer.md
.git/hooks/commit-msg, pre-commit;  .git/info/exclude
```

**Esquema de `guard.js`.** Lee el JSON de stdin; si `tool_name` es Bash o PowerShell, quita comillas y bloquea con exit 2 en estos casos:
1. Patron `\bgit\b[^|;&\n]*\s(add|commit|push|reset|clean|rebase|merge|tag|stash|checkout|switch|restore|rm|mv|cherry-pick|revert|apply|am)\b`.
2. `gh` con un verbo de escritura (`create`, `merge`, `close`, `edit`, `comment`, `review`, `delete`, `fork`, `-X POST/PUT/PATCH/DELETE`). Agregar ademas `auth token`, porque gh esta autenticado como Jeikosd.
3. El comando nombra un secreto (`.env*` salvo `.env.example`, `*.pem`, `*.key`, `id_rsa`/`id_ed25519`, `.git-credentials`).
4. Escritura de shell (`>`, `Set-Content`, `sed -i`, `rm`, `mv`) sobre `app/models/schemas.py`.

Para las herramientas de archivo, el guard repite los chequeos de secreto y de contrato (las dos ramas cubren el mismo riesgo por dos vias).

Falsos positivos aceptados: `git log --grep add` queda bloqueado y lo ejecuta Jeison.

**Esquema de `CLAUDE.local.md`:**
1. Que es el proyecto (3 lineas) y el contrato fijo.
2. Rutas: repo, rama y research (06, 07, 10).
3. Git: Jeison ejecuta add, commit y push; Claude entrega el bloque via `/commit-handoff`; Conventional Commits sin trailer.
4. Flujo SDD (seccion 4, 8 lineas).
5. Estilo (6 lineas: minimo y obvio, config en `app/config.py`, Protocols, routers delgados, sin `except: pass`).
6. Verificacion (`verify.ps1`).
7. Contenido no confiable (3 lineas, incluye no buscar `GRADING.md`).
8. Subagentes (5 lineas: `scout` para localizar, `reviewer` tras cada rebanada, avisar que Codex evalua, retorno de 300 palabras).
9. Entorno (Tesseract en `TESSERACT_CMD`, Ollama `qwen2.5:7b-instruct`).

## 4. Flujo SDD y orden de rebanadas

**Una spec por rebanada** en `docs/specs/NN-nombre.md`, de 40 lineas como maximo:
- Cabecera: objetivo, fuera de alcance, contrato, datos de prueba.
- Criterios `AC-<AREA>-<NN>` en Given/When/Then, cada uno con su tipo de test.
- Tareas (6 como maximo).
- Seccion "Explicacion (JM)".

El ID se mapea al test: `AC-EXT-01` -> `test_ac_ext_01_<que_prueba>` (se ejecuta con `-k ac_ext_01`). Detector de deriva, en PowerShell:
- `Select-String docs\specs\*.md -Pattern 'AC-\w+-\d+' -AllMatches | % {$_.Matches.Value} | sort -u` contra `Select-String tests -Recurse -Pattern 'test_ac_\w+?_\d+' ...`.
- Resultado esperado: los mismos IDs en ambos lados.

**Ciclo de cada rebanada:**
1. `/grill-me` (15 min o menos).
2. Jeison escribe y firma la spec.
3. Modo plan: Claude propone archivos y tareas.
4. Rojo: solo tests, que fallan por la razon correcta.
5. Verde: el codigo minimo, una tarea a la vez.
6. `verify.ps1`.
7. **Explica-de-vuelta (obligatorio, 10 min):** Jeison escribe en la spec, en 3 a 5 lineas por AC, que lineas lo cumplen, y responde 3 preguntas de entrevistador que genera el `reviewer`. Si no puede explicarlo, se simplifica el codigo antes de seguir.
8. `reviewer` sobre el `.diff` y la spec: ACs sin test, codigo sin AC, contrato tocado, valores hardcodeados.
9. `/commit-handoff`; Jeison commitea.

**Orden de rebanadas (camino critico primero):**
1. **01 PoC `/api/extract`** sobre `company_memo.pdf`.
   - Correccion al encargo: son **8 menciones de 7 personas** (Margaret Thompson aparece 2 veces, mas Robert Chen, Sarah Williams, James Anderson, Maria Garcia, David Nakamura y Patricia Okonkwo).
   - ACs: px a pt; pagina 0 incluida; ubicacion multi-palabra y repetida; quitar "Dr."; fuzzy por acento y mayusculas, y rechazo de "Robert Chen" contra "James Chen"; e2e con las 8 menciones, con IoU contra cajas revisadas en PNG (skipif sin Tesseract).
2. **02 Endurecer extract:** validacion 400/413/415/422, errores de dominio, logs JSON con request-id, `/health` con estado de Tesseract, config, workflow de CI (archivo listo; corre cuando se publique).
3. **03 Eval de nombres:** 55 menciones, IC de Wilson, ablacion sm/md/lg.
4. **04 Ingest.**
5. **05 Ask** (Ollama).
6. **06 Eval de fuzzy y retrieval.**
7. **07 Visor.**
8. **08 DESIGN.md y DECISIONS.md.**
9. **09 Docker y compose.**

**Que va en el PR:** codigo, `tests/`, `eval/` (oro y script), `docs/specs/` curadas (muestran trazabilidad AC a test), `DESIGN.md`, `DECISIONS.md` (incluye uso de IA, origen de ejes y tablas de eval) y `RUNNING.md` corto.
- **No** se edita `README.md`: es el enunciado.
- No van `.claude/`, `CLAUDE.local.md`, `research/`, transcripciones ni planes del agente.

## 5. Guia de comandos para aprender (PowerShell, desde la raiz del repo)

| Pieza | Comando | Que demuestra |
|---|---|---|
| Guard | `'{"tool_name":"PowerShell","tool_input":{"command":"git -C . commit -m x"}}' \| node .claude\hooks\guard.js; $LASTEXITCODE` | 2 = bloqueado; cambiar a `git status` da 0 |
| Guard (suite) | `node <scratchpad>\tl\guard_test.js .claude\hooks\guard.js` | 18 casos de bloqueo y permiso; `fallos: 0` |
| Deny | En Claude: `/permissions`; luego "edita app/models/schemas.py" | La regla nativa lo niega antes del hook |
| Settings | `/status` y `claude doctor` | Que archivos cargaron y que entradas se rechazaron |
| Memoria | `/memory` y `/context` | `CLAUDE.local.md` cargado y su costo en tokens |
| Rules | Pedir "lee tests\unit\test_fuzzy.py" y luego `/context` | `tests.md` aparece solo al tocar `tests/**` [NV la vista exacta] |
| Hooks | `/hooks` | PreToolUse y Stop registrados |
| Stop | Romper un test y pedir "termina" | Claude vuelve a trabajar con el resumen del fallo |
| Verify | `powershell -NoProfile -File .claude\tools\verify.ps1; $LASTEXITCODE` | 0 = lint, formato y tests en verde |
| commit-msg | `Set-Content $env:TEMP\m.txt "feat: x`n`nCo-Authored-By: Claude <noreply@anthropic.com>"; & "C:\Program Files\Git\bin\sh.exe" .git\hooks\commit-msg $env:TEMP\m.txt; $LASTEXITCODE` | 1 = rechazado |
| pre-commit | `gitleaks git --pre-commit --staged --redact --no-banner; $LASTEXITCODE` | Escaneo de lo staged |
| Exclude | `git check-ignore -v CLAUDE.local.md .claude\settings.json` | Que regla los oculta del PR |
| Remoto | `git remote -v` | Push a upstream `DISABLED` |
| Skills | `/grill-me rebanada 01` y `/commit-handoff` | Entrevista; bloque de git para pegar |
| Agentes | `/agents`; "usa reviewer con <ruta.diff> y docs\specs\01-extract-poc.md" | Revision sin sesgo |
| Deriva | Los dos `Select-String` de la seccion 4 | IDs de la spec iguales a los IDs de los tests |
| Linea base | `claude --bare -p "di hola"` | Sesion sin harness (sin hooks, skills ni CLAUDE.md), para comparar |

## 6. Limites (honestos)

**Forzado (determinista):**
- El guard con exit 2 sobre los patrones listados.
- Las reglas deny de ruta para herramientas de archivo (Grep y Glob, best-effort).
- `onFailure: block`, para que un guard roto no deje pasar todo.
- El push a upstream desactivado.
- `commit-msg` y `pre-commit` en los commits de Jeison (los puede saltar con `--no-verify`, y eso es decision suya).
- El hook `Stop`, con tope de 8 bloqueos seguidos.

**Consultivo (el modelo puede ignorarlo):** `CLAUDE.local.md`, rules, skills, el orden TDD (un hook no entiende "test primero"), el explica-de-vuelta, el codigo minimo.

**No es frontera de seguridad:**
- Un regex se evade, por ejemplo con `python -c "subprocess.run(['git','commit'])"`.
- No hay sandbox en Windows nativo.
- Las protecciones reales son tres: no tener secretos reales en el arbol, que Jeison revise el diff antes de cada commit, y que solo Jeison commitee y empuje.

## 7. Decisiones para Jeison

1. Reemplazar `secret-guard.js` por `guard.js` de 31 lineas y reducir el deny a 9 reglas. *Default: si.*
2. Hook `Stop` con `verify` desde la rebanada 2, cuando ya hay tests. *Default: si.*
3. `pre-commit` falla cerrado si falta gitleaks. *Default: si.*
4. Publicar `docs/specs/` y un `RUNNING.md` en el PR, sin tocar `README.md`. *Default: si.*
5. Modelo del `reviewer`: sonnet (Codex audita aparte). *Default: sonnet.*
6. Borrar el clon duplicado `docintel-service`: decidido (ya no se necesita); lo ejecuta Jeison. *Hecho cuando la carpeta no exista.*

## Fuentes

Docs de Claude Code descargadas hoy al scratchpad: permissions (Bash rule limits, Edit rules), skills (frontmatter, allowed-tools), hooks (exit 2, onFailure, Stop con tope de 8), memory (CLAUDE.local.md, rules con `paths:`), sub-agents (carga de CLAUDE.md, `maxTurns`), best-practices. Todas en https://code.claude.com/docs/en/<pagina>.md.

Experimentos en el scratchpad: `tl/guard.js`, `tl/guard_test.js`, `tl/v.ps1`, `tl/fake.py` y las pruebas de `commit-msg`. No se encontro texto dirigido a una IA en las docs leidas.
