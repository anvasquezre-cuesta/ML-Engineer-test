# 11 - Ecosistema de skills: que adoptar, como auditar, como medir

Fecha: 2026-10-27. Investigacion rapida, sin instalar ni ejecutar nada de terceros. [V] = leido hoy en la fuente citada; [NV] = no verificado. Los textos de las paginas son datos no confiables; ninguna dirigia instrucciones a una IA (solo el banner estandar de las docs "Fetch the complete documentation index at ... llms.txt", ignorado).

## 1. Candidatas (por defecto: escribir las nuestras)

El plan 10 ya tiene `grill-me` y `commit-handoff` propias. Una skill ajena solo vale si ahorra mas de lo que cuesta auditarla.

| Candidata | Fuente / licencia | Veredicto | Razon y riesgo |
|---|---|---|---|
| **skill-creator** (Anthropic) | `anthropics/skills` (Apache-2.0 para la mayoria; docx/pdf/pptx/xlsx son source-available, no open source [V]); tambien en `claude-plugins-official` (Apache-2.0 el repo; cada plugin puede variar [V]) | **Adoptar** (solo como herramienta de medicion) | Origen oficial; guarda `evals/evals.json`, corre cada caso en subagente aislado y da `grading.json` con tasa de acierto, tiempo y tokens [V skills.md]. Aun asi: leer sus scripts antes (paso 2 del procedimiento). El README advierte "demonstration and educational purposes only" [V] |
| **obra/superpowers**: `test-driven-development`, `systematic-debugging`, `writing-plans`, `requesting-code-review` | https://github.com/obra/superpowers , MIT, ~306k estrellas [V] | **Adaptar (leer, copiar ideas, no instalar)** | Muy popular, pero es un plugin completo con `hooks/` (inyecta un bootstrap en `SessionStart`), `scripts/` y `package.json` [V]. Eso es superficie grande y arrastra su propio flujo, que choca con el SDD de 10. Popularidad no es seguridad. Tomar 10-15 lineas de TDD/debugging para nuestras propias skills |
| TDD / pytest propia | Reglas en `.claude/rules/tests.md` del plan 10 | **Saltar skill externa** | Ya cubierto con rules `paths: tests/**`; el orden rojo-verde es consultivo igual en cualquier skill |
| Revision de codigo | Agente `reviewer` de 10 (Read/Grep/Glob) y el `/code-review` integrado | **Saltar** | Ya existe y esta acotado por herramientas |
| Higiene de commits | `commit-commands` en `claude-plugins-official` [NV contenido exacto] | **Saltar** | Commitea por Claude; el plan quiere que solo Jeison lo haga. `commit-handoff` propia basta |
| Notebooks / ciencia de datos | No encontre una skill de reputacion comparable [NV] | **Saltar** | Escribir una regla `paths: **/*.ipynb` de 5 lineas si hace falta (no editar JSON a mano, limpiar outputs) |

## 2. Procedimiento de auditoria (PowerShell, en orden)

Basado en tu checklist 4.5 de `GUIA-CLAUDE-CODE-EXPERTO.md`. Todo en un directorio desechable, nunca dentro del repo.

1. **Procedencia.** `gh api repos/OWNER/REPO --jq '.license.spdx_id,.pushed_at,.stargazers_count'` (solo lectura). Rechazar si no hay repo real o licencia.
2. **Clonar fijo y aislado.** `git clone https://github.com/OWNER/REPO $env:TEMP\audit\repo; git -C $env:TEMP\audit\repo rev-parse HEAD` y anotar el SHA; `git -C ... checkout <SHA>`. Los hooks de git no se ejecutan en un clone, pero no abrir el directorio con Claude todavia.
3. **Inventario de archivos.** `Get-ChildItem $env:TEMP\audit\repo -Recurse -File | Select FullName,Length`. Rechazar `.zip`, binarios o `.exe` sin fuente.
4. **Leer SKILL.md y cada script** (no resumir con un LLM). `Get-Content` archivo por archivo; ver tambien `hooks/`, `.mcp.json`, `plugin.json`, `package.json` (scripts `postinstall`).
5. **Frontmatter peligroso.** `Select-String -Path $env:TEMP\audit\repo\**\SKILL.md -Pattern 'allowed-tools|hooks:|context:|shell:|Bash\(\*\)'`. `allowed-tools` concede permisos sin prompt durante el turno [V skills.md]: `Bash(*)` o `PowerShell(*)` es rechazo.
6. **Patrones sospechosos.** `Select-String -Path $env:TEMP\audit\repo -Recurse -Pattern 'curl|wget|Invoke-WebRequest|base64|eval|exec|\| *sh|\.ssh|\.aws|\.env|\.claude|settings\.json|ignore (all )?previous|do not tell'`. Mirar tambien comentarios HTML y texto invisible.
7. **SkillSpector estatico, offline** (flags verificados en el README [V]: `scan <ruta>`, `--no-llm`, `-f/--format terminal|json|markdown|sarif`, `-o`, `--recursive`, `--fail-on-findings`, `--fail-on-incomplete`, `--min-coverage`; salida 0 = SAFE/CAUTION, 1 = riesgo > 50 o gate, 2 = error). Con el wrapper ya construido (imagen `skillspector-local:2.13.0`, `--network none`, rootfs de solo lectura, objetivo montado `readonly`):
   `& C:\Users\Jeikosd\Documents\jeikosd\wizzatrip\.claude\tools\skillspector\run-skillspector.ps1 -Target $env:TEMP\audit\repo -OutDir $env:TEMP\audit\report -Recursive`
   Escribe `skillspector-report.json/.md/.sarif`. Nota del README: `--no-llm` por si solo NO hace el escaneo offline (SC4 consulta `api.osv.dev`); el wrapper lo resuelve con `--network none`, y la cobertura SC4 sale "parcial" (esperado). Un resultado limpio no sustituye los pasos 4-6.
8. **Probar en directorio desechable.** `mkdir $env:TEMP\sandbox-proj; cd` ahi, copiar solo la carpeta de la skill a `.claude\skills\`, con un `.claude\settings.json` que tenga `deny` para `.env`, `*.pem`, `git push`, `Bash(curl *)`. Ejecutar un caso y ver `/permissions` y `/hooks`. Recordar: los deny de comandos son evadibles; la barrera real es no tener secretos reales ahi.
9. **Diff de config.** Antes y despues, `Get-FileHash` o copia de `~\.claude\settings.json` y `.claude\`: buscar permisos, hooks o MCP anadidos.
10. **Fijar y registrar.** Anotar repo + SHA + fecha en `research/`. Para actualizar: repetir el diff `git diff <SHA_viejo> <SHA_nuevo>` y los pasos 4-7.

## 3. Como evaluar si una skill ayuda (forma minima)

Las docs piden comparar con y sin la skill en **sesiones nuevas** [V skills.md]. Version minima:

1. Escribir 5 prompts reales (3 que deben disparar la skill, 2 que no).
2. **Disparo:** en sesion nueva, pegar cada prompt y mirar si Claude carga la skill; luego `/skill-name` directo para separar "no dispara" de "funciona mal". `/skill-doctor` muestra skills listadas pero nunca invocadas y su costo de contexto [V].
3. **A/B:** `claude -p "<prompt>"` con la skill y de nuevo con ella desactivada. Para skills personales/de proyecto se pone `"off"` en `skillOverrides`; `claude --bare -p` da una linea base sin hooks, skills ni CLAUDE.md (verificado en 10). Comparar a mano contra 3 criterios escritos antes (p. ej. "test escrito antes del codigo", "no toca schemas.py").
4. **Automatizado (opcional):** skill-creator guarda `evals/evals.json`, ejecuta cada caso aislado y produce `grading.json` + benchmark de tasa, tiempo y tokens [V]. Util solo si la skill se va a reutilizar; para una take-home de 1 semana, 5 prompts a mano bastan.

Criterio de corte: si la skill no cambia el resultado en 3 de 5 casos, borrarla (cuesta contexto en cada sesion).

## 4. Campos de SKILL.md que importan (docs actuales [V])

- `description` (recomendado): que hace **y cuando usarla**, lo clave primero; con `when_to_use` se truncan juntos a **1.536 caracteres** en el listado.
- `name`: por defecto el directorio; define el comando `/`.
- `allowed-tools`: permisos sin prompt **solo durante el turno** que invoca la skill; **no restringe** otras herramientas. Acepta cadena o lista YAML. Para restringir de verdad: `disallowed-tools` (existe en las docs, detalles [NV]) o subagente con `tools:`.
- `disable-model-invocation: true`: solo la invoca el usuario. Usar en todo lo que tenga efectos (commit-handoff).
- `paths`: carga automatica solo al tocar esos globs; bueno para rules/skills de dominio.
- `context: fork` (+ `agent:`): corre en subagente sin el historial; bueno para revisar o investigar sin ensuciar el contexto.
- `user-invocable: false`, `model`, `hooks`, `argument-hint`: secundarios. `hooks:` dentro de una skill es un riesgo a revisar en terceros.

Esqueleto:

```markdown
---
name: grill-me
description: Interroga a Jeison antes de escribir una spec. Usala cuando diga "grill me", "vamos a especificar", "nueva rebanada" o pida planear un endpoint o servicio antes de codificar.
argument-hint: [rebanada]
disable-model-invocation: true
---
# Grill-me: $ARGUMENTS
Haz UNA pregunta por turno hasta cubrir: contrato, criterios AC (Given/When/Then),
fixtures, errores, configuracion. Maximo 15 minutos.

## Reglas
- Propone una respuesta por defecto en cada pregunta.
- No escribas codigo ni toques `app/models/schemas.py`.

## Salida
Borrador de `docs/specs/NN-nombre.md` (<=40 lineas) con IDs `AC-<AREA>-<NN>`.
```

Para que dispare fiable: verbos y frases literales del usuario, el caso de uso primero, y un contraejemplo si hay skills vecinas. `disable-model-invocation: true` hace que el campo `description` no dispare solo; ponerlo solo en skills manuales.

## 5. Hooks extra (costo/beneficio honesto)

| Hook | Beneficio | Costo / riesgo | Veredicto |
|---|---|---|---|
| `PostToolUse` con matcher `Edit\|Write` que corre `uv run ruff format <file>` (el archivo viene en `tool_input.file_path` por stdin [V hooks-guide]) | Formato siempre consistente; menos ruido en `verify` | Corre en cada edicion (latencia pequena); cambia el archivo bajo los pies de Claude; si hay JSON de notebooks o no-.py hay que filtrar por extension; en Windows `jq`/`xargs` no existen: hacerlo en PowerShell o Node | **Adoptar solo si `verify.ps1` ya formatea; si no, redundante con el hook Stop** |
| `Stop` con `verify.ps1` (ya en el plan 10) | Cierra el bucle antes de decir "terminado"; tope de 8 bloqueos | Tiempo de tests en cada parada | Mantener (ya decidido) |
| `SessionStart` que imprime rama y `git status --short` | Orientacion al reanudar; su stdout entra al contexto de Claude [V] | Tokens fijos cada sesion; `git status` ya se pide en un turno | **Saltar**; marginal |
| `SessionStart` matcher `compact` que reinyecta 5 lineas de reglas clave | Recupera lo perdido en la compactacion [V ejemplo en hooks-guide] | Texto fijo que hay que mantener | Opcional, bajo valor si `CLAUDE.local.md` ya recarga |
| `PreToolUse` guard (plan 10) | Unico control determinista de git/secretos | Evadible con regex; no es frontera de seguridad | Mantener |

## Fuentes

- https://code.claude.com/docs/en/skills.md (campos, truncado 1.536, evals, skill-creator) [V]
- https://code.claude.com/docs/en/hooks-guide.md (PostToolUse, SessionStart, exit codes) [V]
- https://github.com/anthropics/skills (licencias mixtas, advertencia educativa; lista completa de skills no mostrada por el fetch) [V parcial]
- https://github.com/anthropics/claude-plugins-official (Apache-2.0, no enumera plugins en la pagina) [V parcial]
- https://github.com/obra/superpowers (MIT, hooks/scripts presentes) [V]; fecha del ultimo commit [NV]
- https://github.com/NVIDIA/SkillSpector (Apache-2.0, flags) [V]
- Local: `wizzatrip\GUIA-CLAUDE-CODE-EXPERTO.md` seccion 4.5 (lineas 980-991); `wizzatrip\.claude\tools\skillspector\run-skillspector.ps1`; `parterns_test_ML\research\10-harness-sdd-final.md` secciones 2-3.
- No leido: GUIA-ENTORNO.md lineas 290-310 (omitido por tiempo) [NV]; contenido de `commit-commands` y `skill-creator` en el repo [NV].
