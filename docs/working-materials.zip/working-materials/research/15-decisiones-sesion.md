# 15 - Decisiones buenas de la sesion 2026-10-27 (y por que)

Resumen para la entrevista: que se decidio, por que es bueno y como defenderlo en una frase. El detalle cronologico esta en `DECISIONS-LOG.md`; lo que viaja al PR esta en `ML-Engineer-test/DECISIONS.md`.

## 1. Repo y git

| Decision | Por que es buena | Frase para defenderla |
|---|---|---|
| Un solo repo (`ML-Engineer-test`), clon `docintel-service` descartado | Dos copias = riesgo de editar la equivocada | "Una fuente de verdad." |
| Rama `feat/jeison-mesa-document-intelligence` desde `main` @`7acb727` | Comparte historia con el upstream (el PR se puede abrir); el nombre identifica al autor en la pagina del PR, donde el login `Jeikosd` no lo dice | "Historia compartida y autoria visible." |
| Commits de una linea, Conventional Commits, sin trailer de IA; los ejecuta Jeison | Historial legible y propio; el uso de IA se declara en DECISIONS.md, no en cada commit | "El porque vive en DECISIONS.md, el commit dice el que." |
| Commits atomicos por idea (deps / config / carpetas) | Cada commit se revierte o explica solo | "Un commit, una idea." |

## 2. Entorno

| Decision | Por que es buena | Frase |
|---|---|---|
| Python 3.12 fijado (`.python-version`) y `uv.lock` commiteado | Reproducible; lo pide el README | "Mismo entorno en cualquier maquina." |
| Modelo spaCy por URL en `[tool.uv.sources]` | Queda en el lock; `spacy download` usa pip, que el venv de uv no trae; evita `allow-direct-references` en hatchling | "El modelo es una dependencia mas, versionada." |
| `dev` sigue como *extra* (no grupo) | El README del evaluador corre `uv sync --extra dev`; cambiarlo romperia su comando | "No romper el camino del evaluador." |
| rapidfuzz en vez de thefuzz + python-Levenshtein | `thefuzz` 0.22 es una envoltura de `rapidfuzz`; `python-Levenshtein` es GPL-2.0-or-later y sobra (verificado en PyPI) | "Uso la libreria de verdad, no su envoltura, y sin GPL." |
| torch CPU en todas las plataformas (indice oficial `whl/cpu`, `explicit = true`) | Con el wheel por defecto el lock traia 15 paquetes `nvidia-*`: en Linux (evaluador, Docker) bajaba CUDA, varios GB. MiniLM sobre pocos chunks no necesita GPU; la VRAM queda para Ollama | "La GPU la usa el LLM, no los embeddings; la instalacion pesa poco en cualquier maquina." |
| ruff con 88 columnas (default) | Con 100 reformateaba stubs del upstream: diff ajeno a la tarea | "No tocar lo que no es mio." |
| Tesseract por PATH, sin `TESSERACT_CMD` | Como cualquier herramienta de linea de comandos (git, docker): una setting menos. En Linux/Docker ya queda en el PATH; en Windows se agrega una vez | "El binario se instala en el PATH; la config es para parametros del modelo, no para rutas de programas." |
| `.gitignore`: `!.env.example` | `.env.*` del upstream ignoraba el ejemplo; el ejemplo documenta las claves sin secretos | "Se versiona el contrato de config, no los valores." |
| Config en `app/config.py` con pydantic-settings + `lru_cache` | Una sola fuente, sobreescribible por env, tipada; primer test (`test_ac_cfg_01`) | "Env > .env > default, con tipos." |

Leccion operativa: un programa hereda el PATH al arrancar. Una ventana nueva de VS Code reutiliza el proceso principal (y su PATH viejo), y el kernel lo hereda. Tras cambiar el PATH hay que cerrar **todos** los procesos `Code` (comprobar con `Get-Process Code`) y abrir de nuevo.

## 3. Plan

| Decision | Por que es buena |
|---|---|
| Revision del plan contra README + stubs (`14`, R1-R11) | Encontro huecos reales: firmas de stubs, reintentos en vector store, dedupe en fuzzy, `/health` liveness, PDF desde bytes, `MAX_PAGES` |
| Recorte: 11 -> 5 notebooks, camino critico 8-10 h, ablaciones solo si `sm` falla | El rubric premia core (70 %), no evaluacion |
| Origen de ejes arriba-izquierda con `BBOX_ORIGIN`, formula documentada | Convencion de PyMuPDF/pdf.js/APIs comerciales; reversible por config |

## 4. Notebooks (metodo de trabajo)

| Decision | Por que es buena |
|---|---|
| `.ipynb` fuera del PR (`.git/info/exclude`) | Exploracion local; el PR lleva solo codigo, tests y evidencia curada |
| Funciones en `notebooks/proto/`, notebook solo corre y mira; `%autoreload 2` | Patron cookiecutter-data-science: codigo reusable importable, sin copiar funciones entre notebooks |
| Cada funcion aparece primero como codigo suelto ("por que surge") y luego como funcion con chequeo de igualdad | Se entiende y se puede defender cada paso; el chequeo prueba que la funcion hace lo mismo |
| Estilo data scientist: celdas cortas, pandas, sin prints, empezar con una pagina | Legible como informe; escala despues de entender |
| `image_to_data` a `DICT` y luego DataFrame (no `Output.DATAFRAME`) | La opcion DataFrame pasa por `read_csv`, que convierte palabras como "NA"/"null" en vacios |
| Dibujar cajas en pt sobre el PDF (`draw_boxes`) en vez de convertir a pixeles | Una sola imagen prueba unidad (pt) y origen (arriba-izquierda) a la vez |
| El agente ejecuta el notebook completo antes de entregarlo (nbconvert, copia en `artifacts/`) | Nada se entrega sin correr; el notebook de Jeison no se sobrescribe |

**Resultados NB01 (ejecutado):** 5/5 paginas con palabras, escala 0.24 = 72/300, conf media 94.5-95.8, una palabra bajo 60 ('Atlas', comillas curvas), cajas exactas en memo p0 y minutes p1, offsets consistentes, 4/4 funciones iguales a su codigo suelto.

## 5. Papers

| Decision | Por que es buena |
|---|---|
| `papers/to_markdown.py` (script PEP 723: dependencias en la cabecera, `uv run` las aisla) | No ensucia el `pyproject` del repo; idempotente |
| Plan B por OCR si MarkItDown devuelve vacio | El PDF de Packer et al. era "Imprimir a PDF" (solo imagenes); MarkItDown no hace OCR |
| Analisis por paper en `papers/analysis/` con veredicto USAR/CITAR/DESCARTAR | Decidir que se usa y que solo se cita, con acciones y costo |
