# 13 - Etapas, tareas y notebooks (mapa maestro)

Fecha: 2026-10-27. Sintesis de 06, 07, 10 y 12 mas `papers/INDEX.md`. Nada de esto esta ejecutado: es el plan que Jeison aprueba antes de tocar codigo. Ante conflicto manda el numero de reporte mayor.

> **Actualizado por 14:** notebooks (ahora 5: 01_ocr, 02_ner_cajas, 03_fuzzy, 04_extract_e2e, 05_rag), horas del camino critico (8-10 h), ablaciones y correcciones tecnicas R1-R11: ver `14-revision-plan.md`. Las tareas por etapa de este documento siguen valiendo como checklist.

## 1. Principio rector: un notebook que sirva a todo el proyecto

Cada notebook es un script `notebooks/NN_nombre.py` con celdas `# %%` que Jeison corre en VS Code con "Run All". Para que sea entendible Y reutilizable:

| Regla | Para que |
|---|---|
| Estructura fija por notebook: **Pregunta -> Datos -> Experimento -> Resultado -> Para llevar a app/ -> Lo que debo poder explicar** | Se lee como un informe corto, no como un cuaderno de borrador |
| Primera celda comun: `from _common import *` (rutas, `SEED=42`, hash de PDFs, versiones, `draw_boxes`) | Procedencia y reproducibilidad; el helper de dibujo se reusa en eval y en el visor |
| Cada celda con un comentario de **que** hace y **por que** | Jeison la explica en la entrevista |
| Al estabilizarse una celda, se **mueve** a una funcion pura en `app/` y el notebook pasa a importarla | El notebook nunca diverge de la app; gana la app |
| Lo etiquetado a mano va a `eval/` (se commitea); lo explorado, a `notebooks/` (no se commitea) | PR pequeno, evidencia curada |
| Tope de horas por notebook; al cumplirse se decide y se sigue | Evita el sumidero de tiempo |

Los notebooks no los ejecuta el agente (OCR sobre PDFs y salidas son datos no confiables): los corre Jeison; el agente los escribe y explica.

## 2. Etapa 0 - Setup (antes de cualquier notebook) ~2 h

Lo que **aun falta** del entorno:
- [ ] `uv python install 3.12` y `.python-version`; `uv sync` (instala spaCy, rapidfuzz, pymupdf, chromadb, sentence-transformers...). Ojo: `torch` en Windows baja un wheel grande; decidir CPU-only.
- [ ] Modelo spaCy `en_core_web_sm` 3.8.0 (wheel por URL en `pyproject`).
- [ ] Grupo `notebooks` (`ipykernel`, `matplotlib`, `pandas`) y kernel en VS Code; probar que `# %%` corre.
- [ ] `TESSERACT_CMD` en `.env` (no se commitea) y `.env.example` con valor de ejemplo.
- [ ] `ruff` y `pytest` configurados; `tests/`, `docs/specs/`, `eval/` vacios.
- [ ] Ollama instalado y `qwen2.5:7b-instruct` descargado (solo se necesita desde la etapa 7).
- [ ] Ajustes de `pyproject` del reto: +rapidfuzz, +tenacity, -thefuzz, -python-Levenshtein, -pytest-asyncio (aprobar uno por uno).
**Hecho cuando:** `uv run python -c "import fitz, spacy, rapidfuzz"` y `tesseract` responden; un `# %%` imprime las versiones.

## 3. Etapas y tareas

Notacion: **AC** = prefijo de criterios de aceptacion; **NB** = notebook; **Reuso** = lo que sobrevive en el proyecto.

### Etapa 1 - OCR y geometria (NB 01, tope 1.5 h) | AC-OCR
Pregunta: que devuelve Tesseract a 300 DPI y como pasa a puntos PDF?
- [ ] Renderizar cada pagina con PyMuPDF a 300 DPI; confirmar `scale = page.rect.width / pix.width = 0.24`.
- [ ] `image_to_data` (eng): construir lista de palabras con caja, linea y confianza; descartar `conf<0` y vacios.
- [ ] Dibujar las cajas en pt sobre el PNG y comprobarlas a ojo (origen arriba-izquierda).
- [ ] Verificar que se procesan **todas** las paginas, incluida la 0.
- Reuso: `px_to_pt`, `ocr_page_words`, `draw_boxes` (en `_common`).
- Lectura: etapa OCR y geometria de `papers/INDEX.md`.

### Etapa 2 - NER de personas (NB 02, tope 1.5 h) | AC-NER
Pregunta: que spans PERSON salen y cuales son falsos positivos?
- [ ] **Jeison etiqueta a mano** las 55 menciones de los 3 PDFs en `eval/gold_names.json` (documento, pagina, nombre; quien reviso). Es la verdad de referencia: no se edita mirando al modelo.
- [ ] Correr `en_core_web_sm` sobre el texto OCR por pagina; comparar con el oro.
- [ ] Reglas minimas: quitar titulos (Dr., Prof.), descartar titulares en mayuscula, apostrofo curvo (O'Brien), `NER_MIN_TOKENS=2`.
- Reuso: `extract_person_names`, `eval/gold_names.json`.

### Etapa 3 - Ubicar nombres (NB 03, tope 2 h) | AC-BBX
Pregunta: los offsets de spaCy caen sobre las palabras OCR correctas?
- [ ] Construir el texto de pagina guardando `(inicio, fin)` de cada palabra OCR.
- [ ] Mapear cada span de spaCy a palabras y unir cajas **por linea** (un nombre que cruza linea da una caja por linea).
- [ ] Una caja por aparicion (Margaret Thompson aparece 2 veces en el memo).
- [ ] Dibujar y revisar contra el PNG; contar aciertos con IoU.
- Reuso: `locate_names` (funcion pura, testeable sin modelos).

### Etapa 4 - Fuzzy matching (NB 04, tope 1.5 h) | AC-FUZ
Pregunta: que umbral separa pares verdaderos de negativos duros?
- [ ] Normalizacion con `unicodedata` NFKD (no `unidecode`: es GPL), minusculas, sin puntuacion.
- [ ] **Jeison etiqueta ~40 pares** (`eval/gold_fuzzy_pairs.csv`): Maria Gonzalez~Maria Gonzalez con acento, Robert Chen vs James Chen, orden invertido, ruido OCR.
- [ ] Comparar `ratio`, `partial_ratio`, `token_set_ratio` y `token_sort_ratio`; mostrar por que los dos primeros inflan.
- [ ] Barrer umbral 0.80-0.95; tabla precision/recall con intervalo de Wilson; fijar `FUZZY_THRESHOLD`.
- Reuso: `normalize_name`, `fuzzy_match_names`, la tabla para `DECISIONS.md`.

### Etapa 5 - Ensamblar `/api/extract` (sin notebook; rebanada 01 y 02)
- [ ] Spec `docs/specs/01-extract-poc.md` con ACs de etapas 1-4; luego tests, codigo, `verify`.
- [ ] Rebanada 02: validacion (PDF por contenido, vacio, tamano), errores de dominio a HTTP, logs JSON con request-id, `/health` con estado de Tesseract, config, CI.
- **Camino critico completo = etapas 0-5 (~12-14 h incluyendo notebooks).**

### Etapa 6 - Evaluacion del NER (NB 05, tope 2 h) | AC-EVA
- [ ] Precision/recall/F1 en las 55 menciones con IC de Wilson; ablacion `sm` vs `md` vs `lg` y DPI 150 vs 300.
- [ ] Frase obligatoria: "n pequeno, resubstitucion: sirve para regresion, no estima produccion".
- Reuso: `eval/run_eval.py` (el notebook madurado), tabla para `DECISIONS.md`.

### Etapa 7 - Chunking y recuperacion (NB 06, tope 2 h) | AC-RAG
Pregunta: chunks de 500/60 y MiniLM recuperan la pagina correcta?
- [ ] Chunking por pagina sin cortar palabras; metadatos `doc_id`, `page`, `chunk`.
- [ ] Embeddings MiniLM normalizados; Chroma con metrica **coseno** explicita; IDs `doc_id:pagina:chunk`.
- [ ] **Jeison escribe 10 preguntas** (8 con respuesta, 2 sin) en `eval/questions.json`; medir hit@1, hit@3, MRR.
- [ ] Comprobar a mano la trampa de Chroma: un `add` con ID repetido no avisa y se descarta.
- Reuso: `chunk_text`, `VectorStore`, `eval/questions.json`.

### Etapa 8 - LLM y respuesta fundamentada (NB 07, tope 1.5 h) | AC-ASK
- [ ] Ollama `qwen2.5:7b-instruct` por API compatible con OpenAI; prompt en ingles, temperatura 0, contexto delimitado.
- [ ] Abstencion sin llamar al LLM si ningun chunk supera `MIN_SCORE`.
- [ ] `sources` construidas en codigo; probar un chunk con "ignora las instrucciones" (inyeccion).
- [ ] Reintentos solo en timeout/429/5xx.
- Reuso: `LLMClient`, `RagService.ask`.

### Etapa 9 - Consolidar evaluacion (NB 08, tope 0.5 h)
- [ ] Exportar todas las tablas a `notebooks/artifacts/results.md` y pasarlas a `DECISIONS.md`.

### Etapa 10 - Extras y documentos
Visor (pdf.js, un HTML) | CI (ruff + pytest) | `DESIGN.md` (<=3 pag.) | `DECISIONS.md` (incluye uso de IA y origen de ejes) | `RUNNING.md` | Docker con Chroma. Orden de valor por hora: CI, visor, Docker. Decidir tras el camino critico.

## 3b. Flujo de pruebas incremental con notebooks (reemplaza la numeracion NB de la seccion 3)

Carpeta: `ML-Engineer-test/notebooks/` (excluida del PR con `.git/info/exclude`; ya cubierta por la regla `rules/notebooks.md`).

```
ML-Engineer-test/notebooks/
  _common.py            rutas, SEED, hash de PDFs, versiones, draw_boxes, cargar/guardar artefactos
  artifacts/            salida congelada de cada etapa: ocr/ ner/ boxes/ chunks/ results.md  (no se commitea)
  00_entorno.py         ¿corren Tesseract, spaCy, Chroma, Ollama? (humo de 2 min)
  01_ocr.py             OCR + px->pt            -> artifacts/ocr/<pdf>.json  (palabras con caja)
  02_ner.py             NER sobre el OCR        -> artifacts/ner/<pdf>.json  (nombres) + P/R/F1
  03_cajas.py           ubicar nombres          -> artifacts/boxes/<pdf>.json + IoU
  04_fuzzy.py           umbral con pares        -> tabla P/R + FUZZY_THRESHOLD
  05_extract_e2e.py     las 4 etapas encadenadas sobre las 3 muestras (+ llamada real a la API)
  06_chunking.py        chunks sin cortar palabras -> artifacts/chunks/<pdf>.json
  07_recuperacion.py    embeddings + Chroma, hit@k y MRR (sin LLM)
  08_llm.py             Ollama: respuesta fundamentada, abstencion, inyeccion
  09_rag_eval.py        las 10 preguntas de punta a punta
  10_resultados.py      une todas las tablas -> artifacts/results.md -> DECISIONS.md
```

**Como funciona (la idea que lo hace manejable):**
1. **Artefactos congelados.** Cada notebook *lee* el artefacto de la etapa anterior y *escribe* el suyo (JSON pequeno). Asi puedes correr `04_fuzzy.py` sin rehacer el OCR y depurar una etapa aislada. Cuando se promueve a `app/`, el JSON pasa a ser un dataclass de `domain.py`.
2. **Construir y medir en el mismo notebook.** Cada uno termina con su metrica (CER en OCR, P/R/F1 en NER, IoU en cajas, P/R en fuzzy, hit@k en recuperacion). El 10 solo junta tablas.
3. **Entradas oraculo para aislar errores** (la tecnica estadistica util aqui): en `02_ner` corres el NER dos veces, sobre el texto OCR y sobre el texto perfecto construido desde tu oro. La diferencia de F1 es la parte del error que viene del OCR; el resto es del NER. Igual en `03_cajas` (cajas con OCR real vs. texto ideal).
4. **RAG por pasos, sin LLM hasta tarde.** Primero `06` (chunks) y `07` (recuperacion: ¿aparece la pagina correcta?). Solo con recuperacion buena entra el LLM en `08`. Si la respuesta falla, sabes que no fue la recuperacion.
5. **Humo antes de todo.** `00_entorno` evita perder una hora porque falte una dependencia.
6. **Ejecutar:** en VS Code, abrir el `.py` y "Run All" (o celda a celda con Shift+Enter). Si el resultado es bueno, se guarda el artefacto; si no, se ajusta y se repite sin tocar el resto.
7. **Cierre de cada notebook (checklist):** [ ] metrica anotada, [ ] funcion candidata para `app/` identificada, [ ] oro guardado en `eval/` si lo hubo, [ ] 3 preguntas de entrevistador respondidas por ti, [ ] fila agregada a `DECISIONS-LOG.md`.

**Orden y topes (camino critico en negrita; cuentan dentro de las horas ya estimadas, no se suman):**

| Fase | Notebooks | Tope | Antes de pasar a la siguiente |
|---|---|---|---|
| A. Entorno | 00 | 0.5 h | las 4 herramientas responden |
| **B. Extraccion** | **01 -> 02 -> 03 -> 04 -> 05** | **~8 h** | cajas correctas sobre `company_memo.pdf` (8 menciones) y spec 01 firmada |
| C. RAG | 06 -> 07 -> 08 -> 09 | ~7 h | hit@3 aceptable y 2 preguntas sin respuesta bien rechazadas |
| D. Cierre | 10 | 0.5 h | tablas listas para DESIGN y DECISIONS |

Punto de control entre B y C: no se empieza RAG hasta que `/api/extract` funcione de punta a punta en la PoC (es el 30 % de la nota).

## 4. Mapa de reuso

| Origen | Destino en el PR |
|---|---|
| Celdas estables | funciones puras en `app/services/` + test + AC |
| Etiquetas a mano | `eval/gold_*.json|csv` |
| Notebook madurado | `eval/run_eval.py` |
| Tablas y figuras finales | `DECISIONS.md` y `DESIGN.md` |
| Exploracion cruda | se queda en `notebooks/` (no va al PR) |

## 5. Lo que hace Jeison (no delegable, y es el aprendizaje)
Etiquetar el oro (55 menciones, ~40 pares, 10 preguntas); correr cada notebook con "Run All"; escribir la seccion "Explicacion (JM)" de cada spec; ejecutar `git`.

## 6. Pendientes de decision
1. Aprobar los cambios de `pyproject` (rapidfuzz, tenacity, quitar thefuzz).
2. torch CPU-only: aceptar el indice especial o dejar el wheel por defecto en local.
3. Orden: empezar por Etapa 0 + NB 01 como primera rebanada.
