# 17 · Investigacion para NB03 fuzzy (2026-10-28)

Fuentes: 3 subagentes (literatura opus, paquetes sonnet, requisitos sonnet). Cifras clave re-ejecutadas por Claude con rapidfuzz 3.14.6. [V] = fuente abierta hoy; [E] = ejecutado.

## Paquetes
| Paquete | Version | Licencia | Veredicto |
|---|---|---|---|
| rapidfuzz | 3.14.6 (ultima, 2026-08-30) | MIT | usar (ya en pyproject) |
| unidecode | 1.4.0 | GPL-2+ | descartar |
| text-unidecode | 1.3 (2019) | Artistic/GPL | descartar |
| anyascii | 0.3.3 | ISC | innecesaria |
| jellyfish | 1.3.0 | MIT | sobra: `rapidfuzz.distance.JaroWinkler` da lo mismo |
| scipy | 1.18.1 | BSD | transitiva (scikit-learn, sentence-transformers); solo para contrastar Wilson en notebooks |

## Comportamiento verificado [E]
- `processor=None` por defecto: `ratio("Maria","maria")` = 80. `utils.default_process` baja mayusculas y cambia no alfanumericos a espacio, pero **no quita acentos** ("maría").
- `ratio` = Indel normalizado `1 - indel/(len1+len2)` (Levenshtein con sustitucion de costo 2) [V rapidfuzz docs]. No afirmar relacion con Ratcliff-Obershelp.
- `token_set_ratio` y `partial_ratio` inflan: "maria" vs "maria gonzalez" = 100. `token_sort_ratio` = 52.6. WRatio = 90. Descartarlos.
- **Fallo de `token_sort` solo:** "katherine johnson" vs "catherine johnson": token_sort 47.1, ratio 94.1 (ordenar mueve el token con error OCR). "ana lopez garcia" vs "ana lopez-garcia": 62.5 vs 93.8 (el guion une tokens).
- Falso positivo a 0.90: "maria gonzalez" vs "mario gonzalez" = 92.9. "john a smith" vs "john smith" = 90.9 (Jeison decide etiqueta).
- Ruido OCR fuerte queda bajo 0.90: "Wi11iam" 71.4, "john srnith" 85.7.
- `process.cdist` 100x100 = 0.7 ms.

## Normalizacion propuesta
Unicode D146 (compatibility caseless matching) = NFKD(casefold(NFKD(casefold(NFD(x))))) [V Unicode 18 cap. 3]. UAX #15: NFKD no debe aplicarse a ciegas a texto mostrado [V]; aqui solo se usa para comparar, el nombre devuelto es el original.
Pasos: casefold + NFKD (dos veces, D146) -> quitar marcas `combining` -> apostrofos (', U+2019) se borran; guiones y demas puntuacion -> espacio -> tabla pequena {ø:o, ł:l, đ:d, ð:d} (NFKD no los descompone) -> colapsar espacios.
No resuelve ü -> ue ("Müller" vs "Mueller" = 92.3, pasa por poco).

## Scorer propuesto (a medir en NB03)
`score = max(ratio, token_sort_ratio) / 100`. Ambos son de cadena completa; el max es el "Permuted-Winkler" de Christen 2006 limitado a 2 ordenes [V Sec. 3.2]; no infla parciales.
Literatura: Christen 2006 no halla un comparador ganador; el umbral depende del dataset (rec. 8) [V]. Cohen et al. 2003: en Census (nombres) gana Levenshtein, TF-IDF falla [V Tabla 2]; SoftTFIDF exige corpus, no aplica a ~5 nombres.

## Umbral
Criterio: maximo recall con precision >= 0.95 (compliance: falso match cuesta mas), no max F1 (Hand & Christen 2018: F pondera P y R segun el metodo) [V]. IC de Wilson; con ~20 pares avisar resubstitucion. Negativos duros: mismo apellido, nombre a 1 edicion, parcial.

## No hacer
partial/token_set/WRatio; codigos foneticos + igualdad (Christen rec. 3); SoftTFIDF; mapa de confusiones OCR sin medirlo; P/R sin IC.

## ACs candidatos (AC-FUZ)
01 parcial "Maria" no matchea "Maria Gonzalez"; 02 "Robert Chen" vs "James Chen" < umbral; 03 mayusculas; 04 acentos (score 1.0); 05 1 caracter de ruido >= umbral; 06 orden invertido; 07 umbral desde config; 08 cambiar umbral cambia resultado; 09 score en [0,1]; 10 todos los pares >= umbral, orden desc; 11 dedupe R4; 12 firma del stub y claves; 13 `names` vacia -> []; 14 sin extraidos -> []. JSON invalido de `names` va a los AC del router. `app/config.py` aun no tiene clave de umbral.

## Datos
Oro: 29 nombres unicos, 55 menciones; solo Margaret Thompson se repite entre PDFs (memo y report). 26 pares candidatos sin etiquetar (lista del subagente de requisitos, en la conversacion del 2026-10-28; se pasan al NB03 para que Jeison etiquete).

## Decisiones abiertas para /grill-me
1. Uno-a-muchos: todos los pares >= umbral (plan 06) o solo el mejor por extraido.
2. Scorer: token_sort solo (plan 06) vs `max(ratio, token_sort)` (nuevo, por el fallo medido).
3. Normalizacion de puntuacion (apostrofo borrado, guion a espacio) y tabla ø/ł.
4. `>=` (docstring: "at or above") y redondeo del score.
5. Dedupe: por texto normalizado antes del fuzzy; `extracted_name` = primera aparicion original.
6. Iniciales ("J. Anderson") y "John A Smith": match o no; documentar.

## Para papers/INDEX.md (pendiente de aprobar)
- Christen 2006, *A Comparison of Personal Name Matching: Techniques and Practical Issues*, ANU TR-CS-06-02. http://users.cecs.anu.edu.au/~Peter.Christen/publications/tr-cs-06-02.pdf
- Hand & Christen 2018, *A note on using the F-measure for evaluating record linkage algorithms*, Statistics and Computing 28(3):539-547, doi 10.1007/s11222-017-9746-6 [titulo NV].
- UAX #15 y Unicode 18 cap. 3 §3.13 (D144-D146).
- Correccion: la URL `kdd03.pdf` de Cohen et al. 2003 es el paper del workshop KDD ("A Comparison of String Metrics for Matching Names and Records"), no el titulo IJCAI que figura en INDEX.

## Plan de ejecucion de la fase (2026-10-28, sesion 2)
Principios (Jeison): como desarrollo hacia produccion; minimo de lineas; cada notebook ejecutable y entendible por Jeison; papers siempre por MarkItDown (`papers/to_markdown.py`) con analisis en `papers/analysis/`; todo trazable desde los notebooks (entradas, salidas, decisiones D#, ACs); respetar el README y justificar cuando no; el grill lo decide un juez experto, no Jeison.

| Fase | Agente (rol, modelo) | Entrada | Salida |
|---|---|---|---|
| 1 | `paper-curator` (sonnet) | 6 papers: Christen 2006, Cohen 2003 KDD, Hand & Christen 2018 (fuzzy); Finkel 2005, Krishnan & Manning 2006, Ratinov & Roth 2009 (D4) | `papers/pdf`, `md`, `analysis`, INDEX corregido |
| 2 | grill ronda 1-2: minimalista (sonnet) + evaluador del rubric (sonnet), critica cruzada | este archivo, papers, notebooks | posiciones finales |
| 3 | juez experto (opus) | posiciones + papers | D4 y D-FUZ-1..6 decididas con cita y cumplimiento del README |
| 4 | Claude | todo | verifica hechos que deciden, log, sintesis |
| 5 | `notebook-builder` (sonnet) | decisiones | 02a/02c actualizados si D4 lo exige; 03 fuzzy nuevo |
| 6 | `notebook-reviewer` (opus) | ejecutado + proto | hallazgos -> ronda de arreglo del builder |

## Decisiones del grill (juez experto opus, ronda 3; verificadas por Claude)
| # | Decision | Fuente / medicion |
|---|---|---|
| D4 | Propagar nombres PERSON ya hallados (2+ tokens) a sus apariciones exactas con borde de palabra en **todo el documento** (PDF del request), nunca entre PDFs. Paso 1 NER en todas las paginas; paso 2 `propagate_names` por pagina; dedupe por `(start, end)`; cada aparicion con su caja | Krishnan & Manning 2006 Tabla 3 (documento +2.95 PER, corpus +0.09); Finkel 2005 Tabla 3 (PER casi nunca cambia de tipo en un documento); Gale 1992 como origen del principio (94 % medido, 51/54; el 98 % es extrapolacion). Medido 02c P4: R 0.945 -> 0.982, FP 0 |
| B | 02a aplica la propagacion y escribe `source` (`spacy`/`propagated`); 02c compara spaCy solo vs sistema | sistema y medicion = mismo artefacto, lineal |
| F1 | Todos los pares >= umbral; orden score desc, extraido, pedido | docstring fuzzy_service.py:5-6 |
| F2 | `max(ratio, token_sort_ratio) / 100` | Christen 2006 Sec. 3.2 (Permuted 0.883 vs Sorted 0.809, verificar en PDF); katherine 47.1 vs 94.1 |
| F3 | casefold, NFKD, quitar marcas, borrar apostrofos, resto no-\w a espacio, **quitar titulos {dr, mr, mrs, ms, miss, prof}**, colapsar | "Dr. Robert Chen" vs "Robert Chen" = 0.88 sin quitar (medido); Christen 2006 Sec. 2.1 |
| F4/C | `>=` sobre score crudo; salida `round(score, 4)`; `matched_name` = `f"{first} {last}"` del pedido | redondeo monotono; 0 discrepancias de borde |
| F5 | Dedupe de extraidos **y** de pedidos por clave normalizada; se devuelve la primera aparicion original | pedido duplicado duplicaria FuzzyMatch |
| F6 | Sin logica de iniciales ni segundo nombre; limite documentado | "j anderson" 0.87; "Maria Jose Gonzalez" 0.85 |
| D/F7 | ~24 pares (12 pos, 12 neg duros) etiquetados por regla escrita antes de puntuar; CSV sin score; Jeison firma `REVIEWED`. Reportar recall sobre positivos y FPR sobre negativos con Wilson, nombrando cada FP; **no** P>=0.95 (la precision depende de la prevalencia que fijamos nosotros: se deduce de su formula; Hand & Christen 2018 Sec. 2-3 solo respalda que el peso P/R lo fija el problema. Cita corregida por Claude). Default 0.90 no cambia; el notebook solo muestra la sensibilidad | |
| F8 | Un notebook `03_fuzzy`; `proto/fuzzy.py` (normalize_name, name_score, fuzzy_match_names); `fuzzy_threshold` en config en la fase TDD | |
| E | Logging sin PII (solo conteos y umbral); riesgo "Anna Kowalski" dentro de "Anna Kowalski-Smith" (guion no es \w) documentado | |

ACs: AC-NER-03 propagacion en el documento con caja por aparicion; AC-NER-04 borde de palabra y sin spans duplicados; AC-FUZ-01 acentos+mayusculas = 1.0; 02 parcial bajo umbral; 03 un caracter de ruido pasa; 04 orden invertido = 1.0; 05 Robert/James Chen no pasa; 06 umbral de config y cambiarlo cambia el resultado; 07 score en [0,1], 4 decimales, orden desc; 08 dedupe de extraidos y pedidos; 09 vacios -> []; 10 claves = FuzzyMatch; 11 "Dr. Robert Chen" = 1.0; 12 score igual al umbral se reporta.
Riesgos residuales: Mario/Maria Garcia 0.917 FP inevitable; segundos nombres e iniciales; OCR de 2+ caracteres (Wi11iam 0.85); resubstitucion con ~24 pares; la propagacion hereda los FN de spaCy (Zimmermann).
