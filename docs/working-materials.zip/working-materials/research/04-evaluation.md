# 04 - Evaluacion minima y creible por etapa

Fecha: 2026-10-27. Alcance: solo investigacion. Marcas: [V] = verificado en fuente web; [NV] = no verificado / conocimiento propio, citar con cuidado.

## 1. Recomendacion (plan minimo, ~12-16 h totales; recortable a ~6 h)

Principio: un script `eval/run_eval.py` + `eval/gold/*.json` versionados, que imprime una tabla (metrica, valor, IC 95 %, n). Se ejecuta con `uv run`, sin red salvo el paso opcional de juez-LLM. Las metricas deterministas tambien se vuelven tests `pytest` con umbral laxo (regresion).

| Etapa | Metrica | Dataset | Esfuerzo |
|---|---|---|---|
| OCR | CER (y WER) | 3 PDFs: transcribir a mano 5-10 lineas por PDF (~30 lineas, incl. las que contienen nombres) | 1.5 h |
| NER | P/R/F1 a nivel entidad, estricto y laxo | Mismas paginas: lista de nombres de persona reales (~20-40 entidades) | 1 h (comparte etiquetado) |
| Cajas | IoU, centro-en-caja, tolerancia en pt | (a) 10-15 cajas corregidas a mano; (b) fixture sintetico | 1 h (a); 2-3 h (b) |
| Fuzzy | Curva PR, umbral por restriccion de precision | 60-120 pares etiquetados (semi-sinteticos) | 2 h |
| Retrieval | hit@k, MRR (nDCG opcional) | 12-15 preguntas doradas + 3-4 sin respuesta | 2 h |
| Generacion | citation-correctness (determinista), groundedness (juez opcional) | mismas preguntas | 1 h det. + 2 h juez |

**OCR.** CER = (S + D + I) / N, con S, D, I sustituciones/borrados/inserciones de la alineacion de Levenshtein y N = caracteres de la referencia; puede superar 1. WER igual a nivel palabra. jiwer implementa WER/CER via distancia de edicion minima con RapidFuzz [V: https://jitsi.github.io/jiwer/reference/measures]. Usar `jiwer.cer/wer`. Decidir y documentar la normalizacion (minusculas, espacios, acentos): cambia el numero. Reportar CER por documento y tambien restringido a las lineas con nombres (lo que importa al producto). Con ~30 lineas se pueden comparar configuraciones (DPI 150/200/300, idioma de Tesseract): ese ablation barato es el diferenciador.

**NER.** Unidad = nombre extraido (string normalizado + pagina) emparejado contra el oro. Estricto: texto normalizado identico; laxo: solapamiento de tokens o fuzzy alto. P = TP/(TP+FP), R = TP/(TP+FN), F1 = 2PR/(P+R). seqeval en modo `strict` exige span+tipo exactos; el modo por defecto imita conlleval y puede contar aciertos con tags B/I erroneos [V: https://pypi.org/project/seqeval , https://github.com/chakki-works/seqeval]. Como el servicio devuelve nombres y no tags BIO, es mas simple y transparente implementar el emparejado (~10 lineas); seqeval queda como referencia conceptual.
IC con n pequeno: Wilson para P y R (son proporciones); Wald tiene cobertura erratica en n chico y se recomienda Wilson/Jeffreys [V: Brown, Cai, DasGupta 2001, https://projecteuclid.org/euclid.ss/1009213286]. Para F1 (no es proporcion) bootstrap percentil. Remuestrear por documento/pagina (cluster) porque las entidades de un documento no son independientes; con 3 PDFs ese bootstrap es casi degenerado: decirlo, y reportar bootstrap por pagina/entidad como cota optimista.
Por que n es pequeno (explicarlo asi): solo hay 3 PDFs, etiquetar es manual, y el objetivo es detectar regresiones y comparar configuraciones, no estimar rendimiento poblacional.

**Cajas.** IoU = area(A interseccion B) / area(A union B). Centro-en-caja: el centro de la caja predicha cae dentro de la caja oro (tolera diferencias de ajuste). Reportar tasa a IoU>=0.5, tasa centro-en-caja y error medio de bordes en puntos. Tolerancia en pt derivada de la resolucion: a 200 DPI 1 px = 72/200 = 0.36 pt; 2-3 pt por lado es razonable [NV: valor de diseno, justificarlo]. Verificar tambien pagina 0-based correcta y eje y (PDF origen abajo vs imagen arriba) [NV].
Oro barato: (a) renderizar las cajas devueltas y corregir a mano 10-15 (el visor de auditoria bonus sirve de herramienta). (b) Sintetico: con PyMuPDF `insert_text` en una pagina, extraer posiciones exactas con `page.get_text("words")`, rasterizar, aplicar skew/ruido/blur (Pillow/numpy) y empaquetar como PDF solo-imagen. Vale la pena: oro exacto en puntos, permite barrer nivel de ruido y sirve de fixture determinista para el test end-to-end. Limite: fuentes limpias, no es la distribucion real (circularidad); presentarlo como prueba de la geometria px->pt, no de la calidad de OCR real.

**Fuzzy.** Pares (extraido, lista) con etiqueta match/no-match. Positivos: variantes reales y sinteticas (acentos, mayusculas, orden apellido-nombre, ruido OCR l/1, rn/m). Negativos: los mas valiosos son los duros (mismo apellido distinto nombre). Barrer el umbral, curva PR, y elegir con criterio explicito: p. ej. maximo recall sujeto a precision>=0.95 (en compliance un falso match cuesta mas que uno perdido), o F-beta con beta<1. Con desbalance (muchos negativos) PR es mas informativa que ROC; ROC dominante <=> PR dominante, pero optimizar AUC-ROC no garantiza AUC-PR y no se interpola linealmente en PR [V: Davis & Goadrich 2006, https://mlanthology.org/icml/2006/davis2006icml-relationship]. Elegir umbral en un split y reportar en otro (o CV); IC Wilson sobre la precision. Comparar 2-3 scorers (ratio, token_sort, Jaro-Winkler tras normalizar acentos); referencia clasica: Cohen et al. 2003, mejor hibrido TF-IDF + Jaro-Winkler [V: https://www.cs.utexas.edu/~ai-lab/pubs/kdd03.pdf , solo vi el resumen en buscador].

**RAG - retrieval.** Oro: pregunta -> span de texto exacto que contiene la respuesta (NO id de chunk: el chunking cambia). Un chunk acierta si contiene el span. hit@k = fraccion de preguntas con algun relevante en top-k; MRR = media de 1/rank del primer relevante; nDCG@k = DCG/IDCG con DCG = sum rel_i/log2(i+1) [NV: definiciones estandar de IR]. Con 1 relevante por pregunta nDCG y MRR son casi redundantes: reportar hit@1/3/5 y MRR. Escribir las 12-15 preguntas a mano (no con el mismo LLM): literales, parafraseadas y 3-4 sin respuesta en el corpus.
**RAG - generacion.** (1) Citation correctness, determinista: `set(sources) <= set(retrieved_ids)` y la fuente correcta esta en `sources`; test pytest con LLM mockeado. (2) Abstencion correcta en preguntas sin respuesta. (3) Faithfulness: fraccion de afirmaciones de la respuesta soportadas por el contexto recuperado, y answer relevance (definidas en Ragas [V: https://arxiv.org/abs/2309.15217]). Opcional con juez-LLM a temperatura 0, rubrica binaria por afirmacion, validado contra ~10 etiquetas humanas propias.

**Framework recomendado: pytest puro + ~40 lineas de juez opcional.** Cero dependencias nuevas, reproducible, explicable linea a linea. Ragas/DeepEval/TruLens/promptfoo/ARES existen y son open-source segun mi conocimiento [NV: no verifique versiones ni APIs actuales]; arrastran dependencias y llamadas LLM por metrica, y n=15 no justifica la maquinaria. Mencionar Ragas como siguiente paso.

## 2. Alternativas descartadas
- Datasets publicos (FUNSD, SROIE [NV], BEIR, MTEB): dominio distinto; BEIR/MTEB sirven para justificar el modelo de embeddings, no para evaluar este sistema.
- Oro RAG generado por LLM: circularidad y fuga.
- Suite completa Ragas/DeepEval/ARES, MLflow/W&B, CI de evaluacion: infraestructura fuera de alcance.
- Etiquetar los 3 PDFs completos: poca ganancia marginal; las lineas con nombres concentran el valor.
- ROC/AUC como metrica principal del fuzzy.

## 3. Riesgos y trampas
- n minusculo: IC amplios (ej. 18/20 -> Wilson aprox. [0.70, 0.97], calculo propio a reverificar). No declarar "95 % de precision" sin IC.
- Fuga/resubstitucion: tunear umbral, DPI o prompts sobre el mismo set que se reporta. Separar dev/test o declarar que es resubstitucion.
- Datos sinteticos optimistas; el ruido simulado no es el de Tesseract real.
- Juez-LLM: sesgo de posicion, verbosidad y auto-preferencia; el acuerdo >80 % con humanos del paper es en preferencias, no en groundedness [V: https://arxiv.org/abs/2306.05685]. Circularidad si juez = generador. Costo y no determinismo.
- Contexto largo: el LLM usa peor la informacion del medio; afecta k y orden de chunks [V: https://arxiv.org/abs/2307.03172].
- Normalizacion no declarada; px vs pt; eje y; olvidar pagina 0.
- Convencion de caja oro (nombre solo vs linea completa): fijarla antes.

## 4. Que explicar en la entrevista
Distancia de edicion y por que CER puede ser >1; P/R/F1, estricto vs laxo, micro vs macro; IC de Wilson vs Wald (cobertura en n chico); bootstrap y remuestreo por cluster (dependencia intra-documento); fuga/resubstitucion en seleccion de umbral; PR vs ROC y prevalencia; costo asimetrico FP/FN y umbral por restriccion; IoU y tolerancia derivada de DPI; hit@k/MRR/nDCG; sesgos del juez y su calibracion contra humanos; potencia estadistica: con n=20 solo se detectan diferencias grandes.

## 5. Preguntas abiertas para el usuario
1. Idioma(s) de los 3 PDFs (spaCy, acentos, CER)? 2. Cuantos nombres hay en total (n real)? 3. Hay LLM/API disponible para juez o solo local (cuota)? 4. Caja oro: solo nombre o linea? 5. Recortar a ~6 h (sin sintetico ni juez) o incluir el fixture sintetico como test e2e? 6. Se pueden publicar las etiquetas oro en el repo (privacidad de nombres)?

## 6. Fuentes / papers (existencia verificada por busqueda salvo marca)
- RAG original, Lewis et al. 2020: https://arxiv.org/abs/2005.11401 - define RAG (memoria parametrica + indice denso).
- Ragas, Es et al. 2023: https://arxiv.org/abs/2309.15217 - metricas sin referencia (faithfulness, relevancia).
- BEIR, Thakur et al. 2021: https://arxiv.org/abs/2104.08663 - retrieval zero-shot; BM25 linea base fuerte.
- MTEB, Muennighoff et al. 2022: https://arxiv.org/abs/2210.07316 - elegir embeddings; ninguno gana en todo.
- Lost in the Middle, Liu et al. 2023: https://arxiv.org/abs/2307.03172 - sensibilidad a posicion en contexto.
- LLM-as-a-Judge, Zheng et al. 2023: https://arxiv.org/abs/2306.05685 - sesgos del juez.
- Cohen, Ravikumar, Fienberg 2003 (name matching): https://www.cs.utexas.edu/~ai-lab/pubs/kdd03.pdf
- Brown, Cai, DasGupta 2001 (IC binomial): https://projecteuclid.org/euclid.ss/1009213286
- Davis & Goadrich 2006 (PR vs ROC): https://mlanthology.org/icml/2006/davis2006icml-relationship
- Herramientas: https://github.com/jitsi/jiwer , https://github.com/chakki-works/seqeval
- Tesseract LSTM / Smith 2007: [NV] no verificado; citar solo tras comprobarlo.

## 7. Como presentarlo en DECISIONS.md / DESIGN.md
Tabla con metrica, valor, IC 95 %, n y como se obtuvo el oro; frase fija: "n=XX; sirve para regresion y comparar configuraciones, no estima rendimiento en produccion". Declarar si dev=test, que el sintetico prueba geometria, que el umbral se eligio por restriccion de precision y su costo en recall, y listar lo no medido (otros idiomas, escaneos peores). Cerrar con plan de escalado: ampliar oro y muestreo de produccion con revision humana.
