# 01 - OCR + bounding boxes + validacion de PDF

## Hallazgos de las muestras (inspeccionadas con PyMuPDF en entorno aislado)
- 3 PDFs: company_memo (1 pag), meeting_minutes (2), research_report (2). Todas 612x792 pt (Letter), rotacion 0, MediaBox == CropBox == (0,0,612,792), sin capa de texto (get_text() vacio), sin cifrar. Cada pagina es UNA imagen 1275x1650 px = 150 DPI nativos.
- Contenido: ingles, texto limpio sintetico (fuente sans, sin ruido ni inclinacion visible). Memo, actas de junta y reporte anual. Nombres: Margaret Thompson, Robert Chen, Sarah Williams, James Anderson, Maria Garcia, David Nakamura, Patricia Okonkwo; Richard Hernandez, Elizabeth Park, Thomas Muller, Aisha Patel, Kevin O'Brien, Jennifer Liu, Carlos Mendoza, Yuki Tanaka, Alexander Popov, Catherine Dubois; Olivia Chambers, Benjamin Foster, Priya Sharma, Lucas Zimmermann, Fatima Al-Rashidi, Christopher Wong, Anna Kowalski, Michael O'Sullivan, Elena Volkov, Raj Krishnamurthy, Hans Weber, James Chen. Trampas: titulos "Dr."/"Prof." antes del nombre, apostrofe (O'Brien), guion (Al-Rashidi), mismo nombre repetido varias veces (Richard Hernandez x4, Aisha Patel x3), nombres al final de linea con coma, ORG/lugares que NO son personas (NovaTech Solutions, ETH Zurich, Stanford, NeurIPS, ICML, NSF, DARPA, Atlas).
- Prompt injection: NINGUNO encontrado. No hay texto dirigido a una IA en ninguna pagina (las 5 paginas fueron vistas en imagen).

## Recomendacion
**Tesseract + pytesseract.image_to_data (Output.DICT, lang=eng) + PyMuPDF a 300 DPI**, con el DPI configurable por env (el README prohibe DPI hardcodeado).
Por que: es lo sugerido por el README (el evaluador lo espera), da cajas por palabra con `block_num/par_num/line_num/word_num/conf` listos para agrupar, es CPU-only, y los docs son limpios (la precision no es el cuello). 300 DPI es el punto dulce documentado de Tesseract (>=300 recomendado) [S1]; las imagenes nativas son 150 DPI, asi que renderizar a 300 sube pixeles (upsampling) y ayuda a Tesseract con texto pequeno; subir mas no aporta. Flujo por pagina: `page.get_pixmap(dpi=D)` -> `Image.frombytes("RGB",(w,h),pix.samples)` -> `image_to_data` -> convertir a puntos. Memoria: una pagina a la vez.

## Alternativas descartadas
- RapidOCR (ONNX): instalacion pip sin binario, buena CPU, pero salida por linea/caja (detector DBNet) y reconocimiento sin palabras individuales por defecto; se aleja de lo que el evaluador espera. Opcion B real si Tesseract fallara en Windows. (unverified en detalle)
- EasyOCR / docTR / PaddleOCR: requieren PyTorch/TF/Paddle (cientos de MB-GB), arranque lento, sin ganancia en texto limpio impreso. (unverified en benchmarks)
- OCRmyPDF: produce PDF con capa de texto; util, pero obliga a re-parsear y depende de Tesseract + Ghostscript; mas pesado y menos control de coordenadas [S6].

## Formula / pseudocodigo clave
```
scale = 72 / dpi                      # px -> pt
x_pt = left * scale ; y_pt = top * scale   # y origen ARRIBA-izquierda
w_pt = width * scale ; h_pt = height * scale
# page_number = indice 0-based (enumerate), NO page.number+1
```
- Origen: PyMuPDF usa top-left, y crece hacia abajo [S2]. schemas.py solo dice "PDF coordinate space (points, 72/inch)" y x,y,width,height: no define origen. SUPUESTO: top-left (coincide con pdf.js viewport/overlay del visor opcional y con PyMuPDF `Rect`). Si se quisiera el origen PDF nativo (bottom-left): `y_pdf = page_height_pt - (top+height)*scale`. Documentarlo en DECISIONS.md y confirmar con el usuario.
- Rotacion/CropBox: `page.rect` ya refleja la rotacion y el origen del CropBox (rect parte en 0,0 aunque el CropBox no) [S2]. Como el pixmap se renderiza con esa misma rotacion, px*scale queda en el espacio de `page.rect`. Para devolver coordenadas del espacio sin rotar: `Rect * page.derotation_matrix` [S2]. En las muestras rot=0 y offset=0, asi que es cuestion de robustez, no de resultado.
- Alternativa exacta sin DPI: `scale = page.rect.width / pix.width` (robusto a redondeos del pixmap).
- Agrupacion de nombres: filtrar `conf>=0` y texto no vacio; clave de linea = (page, block_num, par_num, line_num). Tokenizar el nombre NER (normalizar: minusculas, quitar acentos con unicodedata, quitar puntuacion final); buscar la secuencia de tokens consecutiva DENTRO de la misma linea (ventana deslizante) comparando token a token con similitud (ratio >= ~0.85) para tolerar ruido OCR; caja = union (min x/y, max x+w/y+h) solo de esas palabras. Si el nombre cruza salto de linea, emitir dos cajas o unir solo si lineas adyacentes (decision a documentar). Una caja por ocurrencia: iterar todas las coincidencias, no solo la primera. Excluir titulos (Dr., Prof.) de la caja salvo que NER los incluya. Evitar `str.find` sobre texto plano: desalinea con palabras.

## Riesgos y trampas
- Primera pagina omitida (bucle 1-based o `range(1,n)`), pagina 0-based en el contrato.
- Devolver pixeles o mezclar DPI render vs 72.
- Fugas: usar `with fitz.open(...) as doc` / `open(stream=bytes, filetype="pdf")`; sin archivos temporales si se puede (bytes en memoria). Si pytesseract/`Image` se usa, `with Image` o cerrar; pytesseract crea temporales internos y los borra [S3] (unverified detalle).
- pytesseract bloquea (sincrono): usar `run_in_threadpool`/`def` sync en FastAPI y `timeout=` en image_to_data.
- Tesseract no esta instalado aqui: la API debe fallar claro (503/log) si falta el binario; en tests mockear `image_to_data`.
- Bomba de descompresion: Pillow avisa al superar MAX_IMAGE_PIXELS y lanza error al doble [S4]; valor por defecto ~89M px (unverified aqui). Como el pixmap lo crea PyMuPDF, limitar tambien `page.rect` x DPI antes de renderizar (ej. rechazar paginas > N pt o bajar DPI).
- Fuzzy: "Margaret Thompson" puede fusionarse con "Thompson" aparte si no se limita a una linea.

## Validacion de upload (checklist)
1. Leer en streaming con tope (p.ej. MAX_UPLOAD_MB configurable; 413 si se excede; no confiar en Content-Length). 2. Vacio -> 400/422. 3. Magic bytes: `data[:5]==b"%PDF-"` (el estandar permite basura en los primeros 1024 bytes; estricto es aceptable) -> 415/422; no confiar en extension ni content-type. 4. Abrir con PyMuPDF dentro de try: error -> 422; `doc.needs_pass`/`is_encrypted` -> 422; `len(doc) > MAX_PAGES` -> 413/422; `len(doc)==0` -> 422. 5. Tope de pixeles por pagina. Mapear a HTTPException con mensajes distintos.

## Windows / Docker
- Instalador UB Mannheim (64-bit, 5.5.x) [S5]; ruta tipica `C:\Program Files\Tesseract-OCR\tesseract.exe` (convencion, unverified en la fuente). El instalador NO agrega al PATH por defecto [S5]: configurar `TESSERACT_CMD` (env) y `pytesseract.pytesseract.tesseract_cmd = settings.tesseract_cmd` [S3]. `eng.traineddata` viene incluido; `TESSDATA_PREFIX` solo si se mueve tessdata.
- Docker: `python:3.12-slim` + `apt-get install -y tesseract-ocr` (incluye eng) [S7 unverified]; evita todo el dolor de Windows; sera un extra positivo. PyMuPDF trae wheels binarios, sin dependencias de sistema (poppler no necesario).

## Que explicar en la entrevista
- Por que 300 DPI y `scale=72/dpi` (derivacion: 1 pt = 1/72 in; px = in*dpi). Por que page.rect y no MediaBox. Origen top-left y como convertir.
- Por que image_to_data y no image_to_string (necesitas cajas) y como se usa conf/line_num para agrupar.
- Match por tokens en una linea vs substring; tolerancia al ruido como umbral (analogia: prueba de hipotesis, tradeoff falsos positivos/negativos).
- Gestion de recursos (context managers, bytes en memoria), validacion por magic bytes, limites, y por que 3 limites distintos (bytes, paginas, pixeles).
- Por que Tesseract en vez de DL-OCR en estos docs limpios y como lo cambiarias tras un Protocol `OcrEngine`.

## Preguntas abiertas para el usuario
1. Origen de y: top-left (supuesto) o bottom-left? 2. Una caja por nombre que cruza lineas, o varias? 3. Incluir titulos (Dr.) en la caja? 4. Limites concretos (MB, paginas)? 5. Se instalara Tesseract en Windows o solo Docker?

## Fuentes
- S1 https://tesseract-ocr.github.io/tessdoc/ImproveQuality.html (300 DPI; unverified por fetch, conocido)
- S2 https://pymupdf.readthedocs.io/en/latest/page.html (rect, rotation, derotation_matrix; verificado parcial. Origen top-left: apendice "Coordinates", https://pymupdf.readthedocs.io/en/latest/app3.html, no leido)
- S3 https://github.com/madmaze/pytesseract (image_to_data, tesseract_cmd; unverified por fetch)
- S4 https://pillow.readthedocs.io/en/stable/reference/Image.html (MAX_IMAGE_PIXELS; verificado)
- S5 https://github.com/UB-Mannheim/tesseract/wiki (instalador 5.5.x, PATH off; verificado)
- S6 https://ocrmypdf.readthedocs.io/ (unverified)
- S7 https://tesseract-ocr.github.io/tessdoc/Installation.html (unverified)
- Muestras: inspeccion local con PyMuPDF (script en scratchpad, no en repo).
