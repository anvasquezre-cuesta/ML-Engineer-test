# 02 - NER + Fuzzy matching (investigacion)

Leyenda: [E] = medido por mi en esta sesion (scripts en el scratchpad, fuera del repo); [U] = no verificado, viene de memoria/documentacion sin abrir la fuente.

## Recomendacion

**NER: spaCy `en_core_web_sm` (el del README) + `es_core_news_sm` en cascada, con post-proceso propio; no cambiar de familia.**
- Ambos pesan ~12 MB [E: wheels 12.2 y 12.3 MiB], cargan en 0.3 s y tardan ~4 ms/doc de 1-2 frases en CPU [E]. Se instalan como wheel con pin de version (sin `spacy download` en runtime), lo que sirve para Docker/offline.
- Motivo de la cascada: el modelo EN dio PERSON con tildes y con ruido OCR leve, pero NO detecto "Ana Lopez-Garcia" (partida por salto de linea) y fallo con "Contract betw3en J0hn Sm1th" (entidad con basura). El ES (`PER`) fallo en ruido pesado y absorbio "Dr. Maria Gonzalez and". Se toma la union y se deduplica por forma normalizada.
- Post-proceso (lo que de verdad sube la precision): (1) unir lineas partidas por guion/`\n` antes del NER; (2) quitar titulos (Dr., Sr., Sra., Mr., Ing., Lic.) y sufijos; (3) colapsar espacios multiples ("Carlos  Ramirez Torres"); (4) descartar entidades de 1 token, con digitos, o con tokens en lista de palabras vacias/cargos ("Director", "Contrato"); (5) dedupe por normalizacion; (6) para lineas TODO EN MAYUSCULAS pasar a title-case antes del NER (el modelo EN las reconocio igual, BERT no [E]).
- Bounding box: guardar offsets de caracter -> palabras OCR (otro integrante lo cubre); el NER debe devolver span, no solo string.

**Fuzzy: `rapidfuzz` (no `thefuzz`) con normalizacion propia + `fuzz.token_sort_ratio` sobre el nombre completo normalizado, puntuando el par (first+last) como una unidad.** Score = valor/100, umbral configurable (default 0.90), `score_cutoff` para eficiencia.
- `token_sort_ratio` = `ratio` (Indel normalizado, 2*M/T, similitud de cadena completa) tras ordenar tokens: da 100 a "Gonzalez, Maria" ~ "Maria Gonzalez" sin inflar parciales [E].
- rapidfuzz: MIT, mantenido, C++, es el backend de thefuzz actual [E: `uv` instalo rapidfuzz 3.14.6 al pedir thefuzz 0.22.1]. thefuzz devuelve enteros (redondeo) y su `full_process` no es lo mismo que mi normalizacion; rapidfuzz permite `score_cutoff`, `process.extract`, float exacto. El README sugiere thefuzz; justificarlo: misma API, menos dependencias (no hace falta `python-Levenshtein`).

## Alternativas descartadas
- `en_core_web_md/lg`: mas pesados (~40/~560 MB [U]); mejora en PERSON modesta; sin ganancia en ES. `trf`: ~440 MB y requiere torch [U]; latencia alta en CPU. Sobredimensionado para un take-home.
- `xx_ent_wiki_sm` (multilingue): mas rapido (1.5 ms) pero malo en precision [E]: etiqueto "Acme Corp", "Contrato" y "Sr" como PER, y perdio "JOHN A. SMITH".
- HF `dslim/bert-base-NER` [E]: muy bueno en texto limpio (score ~1.0, tildes OK, "Carlos Ramirez Torres" OK), 31 ms/doc CPU (~8x spaCy), pero en MAYUSCULAS devolvio "A" y "SM" (fragmentos basura) y trae torch (~cientos de MB; peso del modelo ~430 MB [U]). Opcion "v2" detras de un Protocol `NerBackend`, no la base.
- Presidio [U]: es una capa de PII que usa spaCy/transformers por debajo; anade dependencias sin mejorar el reconocimiento de PERSON. GLiNER [U]: zero-shot, buen candidato multilingue pero requiere torch y descarga de pesos; no verificado aqui.
- Metricas: `partial_ratio`, `token_set_ratio`, `WRatio` (inflan, ver abajo); Jaro-Winkler (premia prefijo comun, no es distancia de edicion; "Mar1a G0nza1ez" vs "Maria Gonzalez" = 90.0 JW vs 78.6 ratio [E]); Levenshtein normalizado puro (penaliza duro el orden: 14.3 en "Gonzalez, Maria" [E]).

## Experimentos y resultados reales (normalizados con NFKD + casefold + quitar puntuacion; escala 0-100)

| a | b | ratio | partial | tsort | tset | WRatio | JW | Lev |
|---|---|---|---|---|---|---|---|---|
| Gonzalez, Maria | Maria Gonzalez | 57.1 | 72.7 | 100 | 100 | 95.0 | 70.6 | 14.3 |
| Maria Gonzalez | Maria Gonzalez Perez | 82.4 | **100** | 82.4 | **100** | 95.0 | 94.0 | 70.0 |
| Maria | Maria Gonzalez | 52.6 | **100** | 52.6 | **100** | 90.0 | 87.1 | 35.7 |
| Gonzalez | Maria Gonzalez | 72.7 | **100** | 72.7 | **100** | 90.0 | 77.4 | 57.1 |
| Juan Perez | Juan Perez Garcia | 74.1 | **100** | 74.1 | **100** | 90.0 | 91.8 | 58.8 |
| Maria Gonzalez | Mario Gonzales | 85.7 | 88.9 | 85.7 | 85.7 | 85.7 | 91.0 | 85.7 |
| Maria Gonzalez | Maria Rodriguez | 62.1 | 63.6 | 34.5 | 62.1 | 62.1 | 83.6 | 60.0 |

- **Por que inflan**: `partial_ratio` toma la mejor ventana de la cadena larga del tamano de la corta: "Maria" esta contenida en "Maria Gonzalez" -> 100. `token_set_ratio` compara interseccion de tokens: si un conjunto contiene al otro, 100 (aqui "Juan Perez" == "Juan Perez Garcia", dos personas distintas). `WRatio` es un heuristico que elige entre los anteriores con pesos (0.9/0.95): hereda el sesgo, "Maria" vs "Maria Gonzalez" = 90 pasaria el umbral por defecto [E].
- Sin normalizar, "Maria Gonzalez" vs "María González" da `ratio`=85.7 (bajo 90) [E]; con NFKD da 100. thefuzz `WRatio` sin normalizar mis tildes dio 92 [E]: la normalizacion propia es obligatoria. En rapidfuzz sin `processor`, "MARIA GONZALEZ" vs "maria gonzalez" da 7.1 [E] (no es case-insensitive por defecto).
- Normalizar: `norm("  María-GONZÁLEZ, Ñandú. ")` -> `maria gonzalez nandu`; ojo, NFKD tambien elimina la tilde de la `ñ` ("nandu"), aceptable y simetrico en ambos lados [E].
- **Par como unidad vs separado** [E]: unir `first+last` y puntuar token_sort en bloque da "Maria Rodriguez" 34.5 vs Maria Gonzalez; separado, el nombre perfecto aporta 100 y el apellido 35.3 -> promedio 67.6, y con un `max` o un umbral por campo entraria el falso positivo (mismo nombre de pila, muy comun). Separado ademas obliga a decidir que token es nombre/apellido (el "naive pos" fallo con "Gonzalez, Maria": 15/15). Unidad + token_sort resuelve orden sin adivinar.
- **Trampa de 90%**: en cadenas de ~14 caracteres, una sola edicion cuesta ~7 puntos, asi que "Maria Gonzalez" ~ "Mario Gonzalez" = 92.9 y pasa con 90 [E]; tambien lo hace "Maria Gonzales". Empate real: `process.extract` devolvio ambos con 92.86 [E]. Con `score_cutoff=93` rapidfuzz devuelve 0.0 (no None) para lo que queda bajo el corte [E].
- **Calibracion juguete (12 pares etiquetados a mano, solo para ilustrar)** [E]: con umbral 90, token_sort P=1.00 R=0.67; con 85, P=0.83 R=0.83; con 80, P=0.75 R=1.00. token_set a 90 solo P=0.67. Los falsos negativos a 90 son ruido OCR ("Mar1a Gonza1ez"=85.7, "Ana Lopez"~"Anna Lopes"=84.2).
- NER (5 textos de prueba sinteticos, no OCR real): latencias spaCy EN 4.2 ms, ES 3.8 ms, XX 1.5 ms, BERT 31 ms por doc, CPU Windows [E]. Muestra minima: no sacar conclusiones de accuracy general.

## Riesgos y trampas
- El umbral 90 es sobre cadena completa: 1 edicion pasa en nombres cortos, 2 ediciones fallan. Decidir si se confia en el 0.90 pedido o se anade verificacion extra (p. ej. exigir igualdad de iniciales / apellido exacto tras normalizar) y documentarlo.
- OCR confunde 0/O, 1/l/I, rn/m: se puede anadir un mapa de confusiones al normalizar ("0"->"o", "1"->"i") solo para el comparador; probar que no rompa nombres reales. Subir recall sin tocar el umbral.
- NER: falsos positivos (cargos, empresas con nombre propio -> PER en XX), entidades partidas por saltos de linea, nombres en MAYUSCULAS, tokens basura. Sin metrica de NER real: no hay PDFs etiquetados mas alla de `sample_pdfs/` (verificar manualmente).
- Descargar modelos: `spacy download` en runtime falla offline; usar wheel pinneado o `uv add` con URL. Python >=3.12 en `pyproject` y spaCy 3.8 compatibles en mi prueba [E].
- Uno-a-muchos: una extraccion puede superar el umbral con varias consultas, y una consulta con varias extracciones (duplicados en el documento). Definir politica: devolver todos los pares >= umbral ordenados por score desc, desempate determinista (score, luego orden en lista), o solo el mejor por consulta+extraccion. No esconder empates (ver Mario/Maria).

## Que explicar en la entrevista (en terminos estadisticos)
- `ratio` = 2*M/(|a|+|b|) sobre Indel: coeficiente tipo Dice entre cadenas; simetrico, 0..1. `partial/set` no son metricas de la cadena completa: dan 1.0 por contencion, es decir tasa alta de falsos positivos (precision baja) en nombres con 2 vs 3 tokens.
- Umbral = punto de operacion en la curva precision-recall: subirlo baja FP y sube FN. Calibracion: etiquetar (par, match si/no) con ruido OCR real (~100-200 pares incluyendo negativos duros: mismo nombre/otro apellido), barrer el umbral, elegir el que maximice F-beta (beta<1 si el costo de un falso match en compliance es mayor), y reportar intervalo de confianza (bootstrap) dado el N pequeno. El 0.90 pedido es un default, no un optimo.
- Normalizacion: NFKD + eliminar marcas combinantes + casefold = proyeccion a una clase de equivalencia; hace la distancia invariante a tildes/mayusculas.
- Por que par-unidad: un solo estadistico en vez de dos correlacionados cuya combinacion (promedio/min) introduce otro hiperparametro.
- Complejidad: Indel O(nm) por par; con N consultas x M extracciones pequeno, irrelevante; rapidfuzz en C++ y `score_cutoff` descarta pronto.

## Preguntas abiertas para el usuario
1. Hay textos OCR etiquetados o solo `sample_pdfs/`? Cuantos idiomas reales (ES/EN)?
2. Se acepta anadir una regla extra sobre el 0.90 (p. ej. apellido exacto) o el 90% debe ser puro?
3. Politica de salida: todos los pares sobre el umbral o solo el mejor por consulta? Como tratar empates?
4. Se permite subir dependencias pesadas (torch/HF) o se prioriza una imagen Docker ligera?
5. Como se maneja un nombre extraido con una sola palabra ("Garcia")? Descartar o permitir match parcial?

## Fuentes
- Experimentos: scripts f.py, n.py, h.py, u.py en el scratchpad de la sesion (salidas pegadas arriba).
- rapidfuzz docs/API (fuzz, distance, process, score_cutoff): https://rapidfuzz.github.io/RapidFuzz/ [U, no abierto]; licencia MIT: https://github.com/rapidfuzz/RapidFuzz [U].
- thefuzz: https://github.com/seatgeek/thefuzz [U]; dependencia en rapidfuzz observada [E].
- spaCy modelos: https://spacy.io/models/en , https://spacy.io/models/es , https://spacy.io/models/xx ; wheels: https://github.com/explosion/spacy-models/releases [descargados y probados, E].
- dslim/bert-base-NER: https://huggingface.co/dslim/bert-base-NER (probado, E; tamano [U]).
- Presidio: https://microsoft.github.io/presidio/ [U]; GLiNER: https://github.com/urchade/GLiNER [U].
- Docs de `uv run --with`: https://docs.astral.sh/uv/ [U].
