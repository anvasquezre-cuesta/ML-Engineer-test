# 09 - Spec-Driven Development (SDD) minimo para el take-home

Fecha: 2026-10-27. [V] = leido hoy en la fuente citada. [NV] = no verificado / criterio propio. Todo contenido web se trato como dato; no se encontro texto dirigido a una IA en las paginas leidas.

## 1. Que es y enfoques

SDD = escribir primero una especificacion revisable (que debe hacer el sistema) y usarla como fuente para que el agente planifique, implemente y verifique. Birgitta Boeckeler (Thoughtworks/Fowler) distingue 3 niveles: *spec-first* (la spec guia la tarea y luego se descarta), *spec-anchored* (se mantiene viva) y *spec-as-source* (el humano edita solo la spec); advierte que el termino es difuso y que algunos lo usan como sinonimo de "prompt detallado" [V][F1].

| Enfoque | Flujo y artefactos | Ceremonia | Fortaleza | Fallo / critica |
|---|---|---|---|---|
| GitHub Spec Kit | constitution -> specify -> plan -> tasks -> implement -> converge (`/speckit-*`); instalacion `uv tool install specify-cli` [V][F2] | Alta (muchos .md por feature) | Estructura clara, agnostico de agente | Fowler: "spec-first only", archivos repetitivos y tediosos de revisar; "preferiria revisar codigo que todos estos markdown"; el agente ignoro notas y duplico clases [V][F1] |
| AWS Kiro | requirements.md (historias + criterios, notacion EARS) -> design.md -> tasks.md, con aprobacion por fase; "Quick Spec" sin gates [V][F3]. EARS: "When [disparador], [sistema] shall [respuesta]" [V][F4] | Media-alta | Trazabilidad requisito->tarea | Para un bug pequeno genero 4 historias y 16 criterios (Fowler) [V][F1]; IDE propietario |
| OpenSpec | `/opsx:propose` crea proposal.md, specs/ (deltas con escenarios WHEN/THEN), design.md, tasks.md; `/opsx:apply`; `/opsx:archive` [V][F5] | Media (se autodefine "iterativo, no waterfall", ligero) | Pensado para cambios sobre codigo existente; deltas pequenos | Su propio README llama a Spec Kit "pesado"; es autopromocion [V][F5] |
| Tessl | Hoy se presenta como plataforma de contexto/skills/registro, no como spec-as-source [V][F6] | Alta/otra categoria | Skills versionados | Fowler vio no determinismo incluso por archivo (2025) [V][F1]; hoy mal ajuste para un take-home |
| BMAD | Personas (producto, arquitectura, UX, dev, QA), fases clarify/plan/build/learn; briefs, specs, arquitectura; `npx bmad-method install` [V][F7] | Alta (se declara "right-sized") | Cubre desde idea vaga | Excesivo para 1 servicio de 4 endpoints [NV, juicio] |
| Claude Code (guia propia) | Explorar -> planificar (plan mode) -> implementar -> verificar; "entrevistame hasta poder escribir la spec, escribela en SPEC.md"; dar al agente una verificacion (tests) y revisar con subagente contra SPEC.md [V][F8] | Minima | Cero herramientas extra | Sin gates propios; depende de tu disciplina |

**Relacion con TDD/BDD:** los criterios Given/When/Then (BDD) o EARS son la parte "ejecutable" de una spec: cada criterio puede ser un test pytest. "Tests como spec ejecutable" resuelve el drift (si el test pasa, la spec se cumple) pero solo cubre comportamiento verificable; decisiones de diseno y no funcionales siguen en prosa [NV, criterio].

## 2. Criticas y limites

- **Bloat y costo de revision:** mas markdown que codigo; revisar specs cuesta tanto como revisar codigo [V][F1].
- **Waterfall revival:** Boeckeler se declara "muy esceptica" de mucho diseno inicial; paquetes de trabajo pequenos "casi contradicen" SDD [V][F1]. Mitigacion: specs por rebanada, no una spec total.
- **Drift:** nadie mantiene spec-anchored salvo que algo lo fuerce (CI, tests con ID de spec) [V][F1].
- **El agente no obedece siempre:** ignora instrucciones o se excede [V][F1]; por eso la verificacion debe ser tests, no confianza.
- **Riesgo propio de Jeison:** una spec generada por IA y aprobada sin entender es codigo que no puede defender. La spec la debe escribir/editar el, con entrevista previa.

## 3. Recomendacion: flujo SDD minimo (rebanada = fase del plan 06, ~1-3 h)

Rechazo Spec Kit/Kiro/BMAD (ceremonia > beneficio en 25-30 h); adopto "OpenSpec-lite hecho a mano" + la guia de Claude Code. Cero herramientas nuevas.

1. **Entrevista (15 min):** `/grill-me` o prompt de la guia [F8]: "Entrevistame sobre la rebanada X hasta poder escribir la spec". Jeison responde con sus palabras.
2. **Spec de rebanada** `docs/specs/NN-nombre.md` (plantilla abajo): objetivo, fuera de alcance, 4-8 criterios con ID (`AC-EXT-1`...). Jeison la edita y firma.
3. **Plan (plan mode):** el agente propone archivos y lista de tareas (`- [ ]` al final de la spec, max 6 tareas). No escribe codigo hasta que Jeison aprueba.
4. **Rojo:** el agente escribe SOLO los tests, uno por criterio, con el ID en el nombre (`test_ac_ext_1_...`). Se ejecutan y deben fallar por la razon correcta.
5. **Verde:** minimo codigo para pasar. Una tarea a la vez.
6. **Explica-de-vuelta (checkpoint obligatorio, 5-10 min):** antes de commitear, Jeison explica en voz alta o en 5 lineas por que cada criterio pasa y que lineas lo logran; luego pide al agente 3 preguntas de entrevistador. Si no puede, se reescribe mas simple. Esto es el control de "defender cada linea".
7. **Revision independiente:** subagente de solo lectura recibe diff + spec (no las conclusiones del implementador) y reporta criterios sin test o codigo sin criterio [F8].
8. **Commit por Jeison.** Detector de drift: `grep -rn "AC-" docs/specs tests` -> todo ID de spec aparece en un test y viceversa (script de 10 lineas o paso manual).

**Donde viven y que se envia al PR [NV, criterio]:** `docs/specs/` en el repo SI conviene enviarlo, curado: demuestra tests trazables y juicio (el README premia decisiones y tests). Incluir specs finales y un enlace desde DECISIONS.md. NO enviar: transcripciones de entrevista, prompts/planes del agente, `.claude/`, borradores; viven en `research/` fuera del repo. DECISIONS.md debe declarar el uso de IA (el README lo exige) [V: README].

## 4. Plantilla de spec por rebanada (<=40 lineas), ejemplo /api/extract

```markdown
# SPEC-EXT: POST /api/extract (PoC)        Estado: aprobada por JM  Fecha: 2026-10-xx
Objetivo: dado un PDF escaneado y una lista de nombres, devolver personas con pagina y caja
          en puntos PDF, y los matches difusos contra la lista (para auditoria humana).
Fuera de alcance: /ingest, /ask, multi-idioma, UI.  Contrato: app/models/schemas.py (no tocar).
Datos de prueba: sample_pdfs/*, fixture sintetico (tests/fixtures).

## Criterios de aceptacion (ID -> test `test_ac_<id>_*`)
AC-EXT-1  Given un PDF de N paginas, When se hace OCR, Then se procesan las N paginas
          (incluida la pagina 0).                          [unit con fake de 2 paginas]
AC-EXT-2  Given texto con "Maria Gonzalez" en la pag. 1, When se extrae, Then
          page_number == 1 (0-based).                      [unit]
AC-EXT-3  Given una caja OCR en pixeles a 300 DPI, When se convierte, Then x_pt = x_px*72/300
          (no pixeles) y origen segun BBOX_ORIGIN.         [unit puro px_to_pt]
AC-EXT-4  Given "Dr. John Smith", When NER, Then el nombre no incluye "Dr." y se ignoran
          ORG/LOC/fechas.                                  [unit con fake NER]
AC-EXT-5  Given "Maria Gonzalez" extraido y "MARIA GONZALEZ"/"María González" en la lista,
          When fuzzy, Then hay match con score >= FUZZY_THRESHOLD (mayus/acento-insensible).
AC-EXT-6  Given "Maria" vs "Maria Gonzalez" o "Robert Chen" vs "James Chen",
          When fuzzy, Then NO hay match (cadena completa, sin subcadenas).
AC-EXT-7  Given archivo no-PDF (extension .pdf pero sin "%PDF-"), vacio, o sobre el limite,
          Then 415 / 400 / 413 y los servicios no se invocan.   [TestClient]
AC-EXT-8  Given `names` con JSON invalido, Then 422.          [TestClient]
AC-EXT-9  Given PDF sintetico con nombre en posicion conocida, When POST, Then IoU >= 0.5
          con la caja esperada.          [e2e, skipif sin Tesseract]

## Tareas (una por commit)
- [ ] T1 px_to_pt + tests AC-3   - [ ] T2 validacion AC-7/8   - [ ] T3 OCR AC-1/2
- [ ] T4 NER+cajas AC-4          - [ ] T5 fuzzy AC-5/6        - [ ] T6 router+e2e AC-9
## Explica-de-vuelta (JM, tras cada tarea): ___ (3 lineas) | Decisiones abiertas: ___
```

## 5. Integracion con el harness

- **Plan mode:** el agente solo lee y propone; es el paso 3. Recomendado por la guia oficial (explorar -> planificar -> implementar) [V][F8].
- **Entrevista / `/grill-me`:** la guia sugiere "interview me until you could write the spec, then write it to SPEC.md" [V][F8]. `/grill-me` es un skill de usuario [NV si existe en tu instalacion].
- **Subagentes:** `/code-review` revisa el diff en un subagente que no vio la conversacion; tambien se puede pedir "revisa el diff contra SPEC.md, verifica criterios y tests" [V][F8]. Cuestan tokens y a veces tiempo [V][F8].
- **Hooks (honesto):** los hooks `command` son deterministas; un `PreToolUse` con exit 2 bloquea una accion, un `Stop` con exit 2 impide terminar hasta que pasen los chequeos (tope: tras 8 bloqueos seguidos Claude Code lo anula) [V][F8]. Los hooks `prompt/agent` usan otro modelo y no son deterministas [V][F8].
  - SI se puede forzar: `pytest -q` y `ruff` verdes antes de terminar (Stop); bloquear edicion de `schemas.py` (PreToolUse); formatear tras Edit.
  - NO se puede forzar de forma fiable: "escribir primero un test que falle". Un hook no entiende semantica; solo heuristicas (p. ej. bloquear Edit en `app/` si ningun archivo de `tests/` cambio en el turno), facilmente esquivables y con falsos positivos [NV, razonamiento propio]. La guia advierte que cada hook falla a veces y que se mantenga pequeno el conjunto [V][F8]. Conclusion: el rojo se controla con el checkpoint 4 y la revision humana, no con hooks. Si se desea uno, solo el Stop de pytest/ruff.
- **CLAUDE.md:** poner 5 lineas: leer la spec de la rebanada, no escribir codigo sin aprobacion del plan, un test por ID, no hacer git, comandos de verificacion.

## 6. Evidencia (debil, dicha honestamente)

- No encontre ningun estudio controlado SDD vs vibe coding [V: busqueda de hoy, resultados secundarios]. Una revision multivocal (47 fuentes) reporta ganancias de velocidad inicial pero evidencia limitada sobre mantenibilidad [F9] (leida solo via resumen de buscador [NV]).
- Cifras como "3-10x de exito al primer intento" no citan fuente: ignorar. "Mercari +150%" es de segunda mano [F10] [NV, debil].
- Lo mas solido es cualitativo: la experiencia de Fowler/Thoughtworks (n=1 autora, 3 herramientas) y la guia oficial de Claude Code [F1][F8]. Para este caso, el valor real es el aprendizaje y la trazabilidad, no una ganancia de velocidad medida.

## 7. Comandos para aprender (PowerShell, desde la raiz del repo nuevo)

| Paso | Comando | Que hace |
|---|---|---|
| Plan | `claude --permission-mode plan` (o Shift+Tab hasta "plan") [NV exacto, ver `/help`] | Sesion solo-lectura para proponer plan |
| Entrevista | `/grill-me` o pegar: "Entrevistame sobre SPEC-EXT hasta poder escribir la spec" | Saca requisitos de tu cabeza |
| Editar spec | `code docs/specs/01-extract.md` | Tu editas y firmas |
| Rojo | `uv run pytest -q tests/unit -k ac_ext_3` | Debe FALLAR por la razon correcta |
| Verde | `uv run pytest -q` | Todo en verde |
| Estilo | `uv run ruff check . ; uv run ruff format --check .` | Lint y formato |
| Drift | `Select-String -Path docs\specs\*.md -Pattern 'AC-[A-Z]+-\d+' -AllMatches \| % { $_.Matches.Value } \| sort -Unique` y comparar con `Select-String -Path tests -Recurse -Pattern 'ac_[a-z]+_\d+'` | Lista IDs de spec vs IDs en tests |
| Revision | `/code-review` | Subagente revisa el diff sin sesgo |
| Cierre | `git status ; git diff --stat` | Tu revisas antes de commitear (tu eres quien commitea) |
| Opcional | `uv tool install specify-cli` [V][F2] | Probar Spec Kit fuera del repo, solo para aprender |

## Fuentes
- F1 Boeckeler/Fowler, "Understanding SDD: Kiro, spec-kit, Tessl": https://martinfowler.com/articles/exploring-gen-ai/sdd-3-tools.html
- F2 GitHub Spec Kit: https://github.com/github/spec-kit
- F3 Kiro specs: https://kiro.dev/docs/specs/
- F4 EARS (Mavin, Rolls-Royce): https://alistairmavin.com/ears/
- F5 OpenSpec: https://github.com/Fission-AI/OpenSpec
- F6 Tessl: https://tessl.io/
- F7 BMAD: https://github.com/bmad-code-org/BMAD-METHOD
- F8 Claude Code best practices: https://code.claude.com/docs/en/best-practices ; hooks: https://code.claude.com/docs/en/hooks-guide
- F9 Multivocal review (via buscador, no leido completo): https://arxiv.org/pdf/2607.21652
- F10 Resumen secundario Mercari: https://pasqualepillitteri.it/pt/news/3389/aidd-vs-vibe-coding-spec-driven-development-2026-pt
- Contexto local: ML-Engineer-test/README.md; research/06-tl-plan.md
