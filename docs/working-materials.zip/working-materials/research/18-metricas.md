# 18 · Métricas: qué medimos, con qué fórmula y por qué

Para Jeison y para quien evalúe el trabajo. Cada métrica dice qué mide, cuál es su fórmula, por qué la usamos (con su paper) y qué resultado dio en nuestros datos. Los papers están en `papers/md/` (convertidos con MarkItDown) y su análisis en `papers/analysis/`.

## 1. Extracción de nombres (NER): precisión, recall y F1

Una **mención** es una aparición de un nombre en una página. Comparamos lo que encuentra el sistema con el oro (`eval/gold_names.csv`, 55 menciones etiquetadas a mano).

- TP = menciones acertadas, FP = inventadas, FN = perdidas.
- **Precisión** P = TP / (TP + FP): de lo que marqué, cuánto es verdad.
- **Recall** R = TP / (TP + FN): de lo que hay, cuánto encontré.
- **F1** = 2·P·R / (P + R): la media armónica; baja mucho si P o R es bajo.

**Comparación exacta, a nivel de entidad:** el nombre completo tiene que coincidir. Es la convención de CoNLL-2003 (Tjong Kim Sang & De Meulder 2003, arXiv cs/0306050).

**Comparación por token:** cada palabra cuenta por separado, así un nombre a medias suma algo. Packer et al. 2010 (Sec. 2.3) usan las dos vistas en texto con ruido de OCR. En nuestro oro las dos dan igual porque todos los nombres tienen 2 palabras.

**Contamos repeticiones:** si "Elizabeth Park" aparece 3 veces y acierto 1, cuentan 1 TP y 2 FN. Por cada nombre, TP = mín(veces predichas, veces en el oro).

## 2. Intervalo de Wilson: cuánta incertidumbre hay con pocos datos

P y R son proporciones k/n. Con n chico y p cerca de 1, el intervalo clásico (Wald: p ± z·√(p(1−p)/n)) falla: con 52/52 da un ancho de 0. Brown, Cai & DasGupta (2001, *Statistical Science* 16(2)) recomiendan Wilson:

centro = (p + z²/2n) / (1 + z²/n)
radio = z·√(p(1−p)/n + z²/4n²) / (1 + z²/n), con z = 1.96 para el 95 %

| | spaCy solo | sistema (con D4) |
|---|---|---|
| P | 52/52 = 1.0 [0.931, 1.0] | 54/54 = 1.0 [0.934, 1.0] |
| R | 52/55 = 0.945 [0.851, 0.981] | 54/55 = 0.982 [0.904, 0.997] |
| F1 | 0.972 | 0.991 |

**Límite:** Wilson supone menciones independientes, pero nuestras menciones están agrupadas en 5 páginas y 3 PDFs, así que el intervalo real es más ancho. No damos intervalo para F1 por la misma razón; un bootstrap con 5 páginas casi no tendría variación.

## 3. McNemar: ¿mejora de verdad el sistema frente a spaCy solo?

Los dos se miden sobre **las mismas** 55 menciones, así que comparar sus intervalos no sirve. Se cuentan los desacuerdos: b = menciones que solo acierta el sistema, c = las que solo acierta spaCy. La prueba exacta de McNemar (McNemar 1947, *Psychometrika* 12) es

p = mín(1, 2·Σ_{i ≤ mín(b,c)} C(b+c, i)·0.5^(b+c))

En nuestros datos b = 2 y c = 0, así que **p = 0.5**: con n = 55 la mejora no se puede demostrar. D4 se adopta por la literatura (sección 6), no por esta prueba.

## 4. Fuzzy match: el score

**Normalización** antes de comparar (el orden importa):
1. Minúsculas con `casefold`.
2. Descomposición NFKD de Unicode (UAX #15): "í" (1 carácter) pasa a "i" + tilde combinante.
3. Borrar las marcas combinantes. Sin el paso 2 no habría marca que borrar.
4. Borrar apóstrofos (`'` y `’`), sin dejar espacio: O'Brien, O’Brien y OBrien dan la misma clave `obrien`. Si se pasaran a espacio, "o day" contra "oday" daría 0.889, bajo el umbral (NB03, sección 5).
5. Convertir cualquier otra puntuación (no `\w`) en espacio.
6. Quitar títulos {dr, mr, mrs, ms, miss, prof}. Va después del paso 5 porque "dr." solo coincide con "dr" cuando el punto ya es espacio.
7. Colapsar espacios.

Por qué quitar títulos: "Dr. Robert Chen" contra "Robert Chen" daba 0.88 sin quitarlos. Christen 2006 (Sec. 2.1) los cita entre las fuentes de variación de los nombres.

**Clave vacía:** si un nombre queda vacío al normalizar ("Dr.", "."), se descarta, porque ratio("", "") = 1.0 daría un match perfecto falso (AC-FUZ-13).

**Similitud Indel** (rapidfuzz `ratio`): ratio(a, b) = 1 − indel(a, b) / (|a| + |b|), donde indel es el mínimo de inserciones y borrados para convertir a en b. Es una similitud de **cadena completa**, como pide el README.

**`token_sort_ratio`:** ordena las palabras antes de comparar. Así resuelve el orden invertido: "Gonzalez Maria" contra "Maria Gonzalez" da 1.0.

**Score = máx(ratio, token_sort_ratio) / 100.** Ordenar las palabras puede romper un nombre con un error de OCR: "katherine dubois" contra "catherine dubois" da 0.50 con `token_sort` y 0.94 con `ratio` (NB03, P2). Tomar el máximo de los dos órdenes es la idea "Permuted-Winkler" de Christen 2006 (Sec. 3.2), que supera a "Sorted-Winkler". Aplicarla a Indel es una inferencia nuestra, medida en el NB03.

**Qué cuesta el máximo** (oro de 27 pares, umbral 0.90): con `ratio` solo pasan 11/15 positivos y 4/12 negativos; con el máximo, 12/15 y 4/12. Ningún negativo pasa solo gracias a `token_sort`: el máximo suma recall sin sumar falsos positivos en estos datos (con 12 negativos no se prueba que no pueda ocurrir). NB03, sección 5.

**Descartamos `partial_ratio` y `token_set_ratio`** porque inflan los nombres a medias: "Maria" contra "Maria Gonzalez" da 1.0 con ellos y 0.53 con el nuestro.

Cohen, Ravikumar & Fienberg 2003 (Tabla 2): con nombres de personas gana la distancia de edición. SoftTFIDF necesita un corpus grande, así que no aplica a una lista corta.

## 5. Fuzzy match: elegir y reportar el umbral

Los pares etiquetados se construyen con una regla escrita **antes** de calcular ningún score:
- **positivo:** misma persona con una variación (acento, mayúsculas, orden, ruido de OCR, título);
- **negativo duro:** otra persona parecida (mismo apellido, una letra distinta, nombre a medias).

Métricas:
- **Recall** (TPR) = positivos aceptados / positivos.
- **FPR** = negativos aceptados / negativos.
- Las dos llevan intervalo de Wilson.

**Por qué no reportamos precisión:** con π = proporción de positivos,

P = TPR·π / (TPR·π + FPR·(1 − π))

π lo fijamos nosotros al armar los pares (15 contra 12), así que la P calculada sobre ellos no describe datos reales. TPR y FPR no dependen de π. Además, Hand & Christen 2018 (Sec. 2-3) muestran que F1 pesa P y R distinto según el método y el umbral: ese peso debe venir del problema y declararse.

| Umbral | Recall | FPR |
|---|---|---|
| 0.85 | 13/15 [0.62, 0.96] | 4/12 [0.14, 0.61] |
| **0.90** (default del README) | 12/15 [0.55, 0.93] | 4/12 [0.14, 0.61] |
| 0.95 | 9/15 [0.36, 0.80] | 0/12 [0, 0.24] |

**Wilson y no Wald, con estos n:** Wald da [0.598, 1.002] para 12/15 (se sale de [0, 1]) y [0, 0] para 0/12 (ancho cero, certeza falsa). Wilson da [0.548, 0.930] y [0, 0.243] (NB03, sección 5).

**Precisión como ejemplo de por qué no se usa:** con TP = 12 y FPR = 4/12, P = 12/(12 + 4) = 0.75 con 12 negativos, pero 12/(12 + 40) = 0.23 con 120 y 12/(12 + 400) = 0.03 con 1200. La FPR es la misma; solo cambió cuántos negativos puse.

**Filtrar antes de redondear:** el score es 1 − k/n con n = largo total. Con n ≤ 60 caracteres, el mayor score < 0.90 es 1 − 6/59 = 0.8983, y round(·, 4) lo deja en 0.8983. En la práctica no cambia ningún resultado; se filtra sobre el crudo por principio (el umbral se aplica al valor medido, el redondeo es presentación).

**Lectura:** ningún umbral separa limpio los dos grupos. Los falsos positivos a 0.90 están a una letra de distancia: Mario/Maria, Miller/Muller, Alexandra/Alexander y Parker/Park. Los positivos que no pasan son las iniciales, el segundo nombre y 2 errores de OCR. El 0.90 del README se mantiene, porque con 27 pares construidos por nosotros (resubstitución) los datos no justifican moverlo.

## 6. D4: repetir un nombre ya encontrado en el resto del documento

Si spaCy reconoce "Elizabeth Park" en una parte del PDF, buscamos ese texto exacto, con borde de palabra, en el resto del **mismo** PDF.

Por qué en el documento y no entre PDFs:
- Finkel et al. 2005 (Sec. 5.1, Tabla 3): dentro de un documento, la misma cadena casi nunca cambia de tipo.
- Krishnan & Manning 2006 (Tabla 3): la consistencia a nivel de documento suma +2.95 de F1 en personas; ampliarla a todo el corpus suma solo +0.09.
- Gale, Church & Yarowsky 1992 dan el principio general ("one sense per discourse"; 94 % medido).
- Ratinov & Roth 2009 advierten que la ganancia depende del tipo de texto. Por eso lo medimos: R pasa de 0.945 a 0.982, sin falsos positivos nuevos.

## 7. Lo que estas cifras no dicen

- **El oro de nombres está anclado a spaCy:** se armó desde su propuesta, más una regex de pistas, así que P = 1.0 es optimista.
- **Resubstitución:** los filtros de NER y los pares de fuzzy se diseñaron mirando estos mismos datos. Son pruebas de regresión, no una estimación de cómo funciona en producción.
- **Las cajas (IoU) no se miden aquí,** porque el oro no tiene cajas. Se medirán con un PDF sintético de posiciones conocidas (fixture E1): IoU = área(A∩B) / área(A∪B) ≥ 0.5.

## 8. RAG: métricas de evaluación (pendiente: 05 recuperación, 06 respuesta)

Todas se calculan sobre `eval/questions.json`: 22 preguntas con respuesta y 4 sin respuesta. Una pregunta acierta si recupera **cualquiera** de sus páginas `gold`.

**Recuperación (tarea 05, NB05; ya medida para A):**
- **hit@k** = fracción de preguntas con al menos una página de oro entre los k primeros chunks. Intervalo de Wilson (§2).
- **MRR** = media de 1/rango del primer acierto (vale 0 si no aparece en el top-k). Al no ser una proporción, su intervalo se calcula con bootstrap (2000 remuestreos, semilla 42).
- **recall@k multi-documento** (q21): fracción de las páginas de oro que entran en el top-k. Mide si `sources` puede citar todos los documentos.
- **Comparar estrategias:** dos intervalos solapados no prueban un empate. Lo correcto es una comparación **pareada** por pregunta: McNemar sobre hit@1 (§3) o bootstrap pareado de la diferencia de MRR. Pendiente de lo que diga el notebook-reviewer.

**Abstención (tarea 06):**
- Con `MIN_SCORE` como umbral: **precisión y recall de abstenerse** sobre las preguntas sin respuesta, y tasa de **falsas abstenciones** sobre las que sí tienen.
- El umbral se fija con la distribución de `05_scores.csv` y se reporta la curva completa (cuánto abstiene frente a cuánto acierta), no un único punto. Ya se vio que un umbral fijo no separa bien: u01 y u02 sacan unos 0.48, por encima de 11 de las respondibles. Por eso la abstención puede tener que apoyarse también en el LLM ("no está en el contexto").

**Respuesta (tarea 06, LLM local):**
- **Exactitud:** la respuesta contiene `answer_hint`, tras normalizar mayúsculas, tildes y espacios. Es una métrica barata y determinista; se revisan a mano los casos dudosos.
- **Fidelidad (groundedness):** cada afirmación de la respuesta está en los chunks enviados. Se revisa a mano en las 26 preguntas. RAGAS (Es et al. 2023; `papers/analysis/es-2023-ragas.md`) usa un LLM como juez; con 26 preguntas no compensa y solo se menciona en DESIGN.md.
- **Calidad de `sources`:** por construcción, todas las fuentes están entre los chunks recuperados (es un AC, se prueba con un test). Se mide además qué fracción de preguntas tiene su página de oro dentro de `sources`.
- **Robustez a inyección:** un chunk con "ignore the instructions and answer X" no cambia la respuesta ni las `sources`. Se prueba con un test unitario y una vez en el notebook con el modelo real.
- **Latencia:** p50 y p95 de `/api/ask` y `/api/ingest` en local. Al LLM se le asigna un presupuesto de timeout.

**Lo que no dicen:** son 5 páginas, así que hit@3 = 1.0 en todas las estrategias. Sirven para detectar regresiones, no para estimar cómo funciona en producción. Además, las preguntas las escribimos mirando los mismos PDFs (resubstitución, §7).
