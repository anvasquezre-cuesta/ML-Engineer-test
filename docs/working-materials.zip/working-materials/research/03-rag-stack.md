# 03 - Stack RAG (investigacion, sin implementar)

Convencion: [V] = verificado en la fuente citada (consultada 2026-10-27); [NV] = no verificado hoy, viene de conocimiento previo (revisar antes de afirmarlo en la entrevista).

## Recomendacion

**Chunking.** Dividir por palabras/oraciones, no por caracteres crudos. Algoritmo: segmentar por parrafo/oracion (regex simple), acumular hasta `CHUNK_SIZE` caracteres (~500-800 chars, ~120-200 tokens), y si una oracion sola excede el limite, cortar en el ultimo espacio (`rfind(" ")`), nunca a mitad de palabra. Overlap ~10-15 % (50-100 chars) arrancando en limite de palabra. Por que caracteres y no tokens: la firma del repo es `chunk_text(text, chunk_size=500)` (caracteres) y evita cargar un tokenizador; tradeoff: los tokens se alinean mejor con el limite del modelo (MiniLM trunca a 256 tokens [NV]; 500 chars ~ 125 tokens, cabe). Para documentos de negocio cortos, chunks pequenos dan mejor precision de recuperacion; chunks grandes diluyen el embedding. Metadata por chunk: `doc_id`, `page`, `chunk_idx`, `filename`. Para conservar `page`, chunkear **por pagina** (no sobre el texto concatenado) y numerar chunk_idx global. Nota: `chunk_text` devuelve `list[str]`, asi que la metadata se arma en el llamador (rag_service/api).

**Embeddings.** `sentence-transformers` con `all-MiniLM-L6-v2` si los documentos son en ingles (384 dims, ~80-90 MB, rapido en CPU [NV]); si hay espanol u otros idiomas, `intfloat/multilingual-e5-small` (384 dims, ~118M params [NV]) que **exige prefijos** `"query: "` / `"passage: "` [NV: la ficha HF no cargo; confirmar en https://huggingface.co/intfloat/multilingual-e5-small]. Decision que depende del idioma de los PDFs (pregunta abierta). Cargar el modelo UNA vez: singleton `functools.lru_cache` o carga en `lifespan` de FastAPI y guardar en `app.state`. Normalizar (`normalize_embeddings=True`) para que coseno = producto punto. `get_query_embedding` y `get_embeddings` deben aplicar prefijos distintos si se usa e5. Configurable por env (`EMBEDDING_MODEL`). Alternativa ligera: `fastembed` (ONNX Runtime, sin PyTorch, evita descargas grandes; modelo por defecto bge-small-en-v1.5, 384 dims) [V: https://github.com/qdrant/fastembed]. Util para una imagen Docker mas pequena; pero `sentence-transformers` ya esta en `pyproject.toml`, por lo que cambiar no aporta nota extra: mencionarlo como mejora de Docker.

**Vector store.** Chroma embebido (`PersistentClient(path=settings.chroma_path)`), ya en dependencias. Trampa clave: la metrica por defecto es **L2 (cuadrado)**, no coseno [V: https://docs.trychroma.com/docs/collections/configure]. Crear la coleccion con `configuration={"hnsw": {"space": "cosine"}}` [V, misma fuente]. Chroma devuelve **distancia** (1 - coseno), no similitud: para el campo `score` convertir `score = 1 - distance` y documentarlo; si se deja L2 los "scores" no son comparables ni acotados. IDs: `f"{doc_id}:{chunk_idx}"` con `doc_id = sha256(contenido del archivo)[:16]` (idempotente: re-ingestar el mismo PDF reemplaza con `upsert` solo SUS chunks; documentos distintos nunca colisionan) o `uuid4` si se quiere que cada ingesta sea nueva. Recomiendo hash de contenido + upsert; decision a explicar. Envolver excepciones del cliente en `VectorStoreError` propio. Thread-safety: [NV] el cliente embebido es razonablemente seguro para lecturas concurrentes, pero con varios workers de uvicorn sobre el mismo directorio hay riesgo; usar 1 worker o Chroma/Qdrant en servidor.

**LLM.** Un unico cliente `httpx` contra una API compatible con OpenAI (`POST {LLM_BASE_URL}/chat/completions`), configurado por env: `LLM_BASE_URL`, `LLM_API_KEY`, `LLM_MODEL`, `LLM_TIMEOUT_S`, `LLM_MAX_RETRIES`. Con esto cambian proveedores sin tocar codigo: Ollama local (`http://localhost:11434/v1/`, la API key se exige pero se ignora) [V: https://docs.ollama.com/api/openai-compatibility]; OpenAI; Anthropic via capa de compatibilidad `https://api.anthropic.com/v1/` [V: https://platform.claude.com/docs/en/cli-sdks-libraries/libraries/openai-sdk], pero la propia doc dice que es para pruebas/comparacion y "no production-ready" para la mayoria de casos, ignora `response_format`, y hoistea mensajes system en un solo campo. Open-source primero: Ollama + un modelo instruct pequeno (p. ej. familia Llama 3.x / Qwen / Gemma de 3-8B; tamanos y nombres exactos vigentes [NV], revisar `ollama.com/library`). Groq/OpenRouter/Together tienen tiers gratis y endpoints compatibles [NV: limites cambian, no cotizar cifras]. LiteLLM como capa extra: innecesario aqui (dependencia pesada para un solo endpoint). Diseno testeable: `Protocol LLMClient { def complete(messages) -> str }` con `OpenAICompatLLM` y `FakeLLM` (devuelve texto fijo / eco del contexto); se inyecta con `Depends` y `app.dependency_overrides` en pytest. Sin `LLM_BASE_URL` (o sin respuesta) -> `LLMUnavailableError` -> HTTP 503 limpio, sin traceback.

**Prompting con grounding.** System: "Responde SOLO con el contexto; si no esta, responde exactamente `No tengo informacion suficiente en los documentos`". Contexto en bloques numerados `<fragmento id="3" doc="..." page="2">...</fragmento>`. temperature 0. `sources` se construye en codigo desde los resultados recuperados (doc_id, page, chunk_idx, score, snippet), **nunca** desde lo que diga el LLM. Si la recuperacion devuelve 0 resultados o todos bajo un umbral de score (`MIN_SCORE` en config), se responde "sin informacion" SIN llamar al LLM y con `sources=[]`.

**Mitigacion de prompt injection (OCR no confiable).** Capas: (1) delimitar el contexto con etiquetas y decir en el system que su contenido es DATO, no instrucciones; (2) jerarquia: instrucciones solo en system, texto de usuario/OCR en user, y repetir la regla al final; (3) escapar/neutralizar los delimitadores dentro del texto OCR (quitar `</fragmento>`); (4) el LLM no tiene herramientas ni acceso a red/archivos: el peor caso es una respuesta mala, no una accion; (5) validacion de salida: si el LLM cita ids de fragmento, comprobar que sean subconjunto de los recuperados; `sources` ignora lo que dice el modelo; limitar longitud de la respuesta (`max_tokens`); (6) filtro heuristico opcional de patrones tipo "ignore previous instructions" en ingesta (solo log/flag, es evadible). Marco: OWASP LLM01 prompt injection (incl. indirecta) [referencia: https://genai.owasp.org/llm-top-10/ ; la pagina de detalle no cargo, NV]. Honestidad: ninguna mitigacion es completa; se reduce el radio de dano.

**Retry/timeout.** `httpx.Timeout(connect=5, read=LLM_TIMEOUT_S, write=10, pool=5)` (httpx aplica 5 s por defecto en todo, y tiene 4 tipos de timeout [V: https://www.python-httpx.org/advanced/timeouts/]). Cliente `httpx.Client` reutilizado. `tenacity`: `@retry(retry=retry_if_exception_type((httpx.TimeoutException, httpx.TransportError, RetryableHTTP)), stop=stop_after_attempt(n), wait=wait_exponential(multiplier=1, min=1, max=10), reraise=True)` [V: https://tenacity.readthedocs.io/en/latest/]. Reintentar solo 429/5xx/timeouts/errores de red; NO reintentar 400/401/403/404. Respetar `Retry-After` si llega [NV]. Mapeo a HTTP: LLM no configurado o agotados los reintentos de conexion -> 503; timeout del upstream -> 504; respuesta upstream invalida/5xx persistente -> 502; vector store caido -> 503; pregunta vacia -> 422 (pydantic); sin informacion -> 200 con mensaje y `sources=[]`.

**Enrutamiento por complejidad (parrafo para DESIGN.md).** Un clasificador barato (reglas: longitud de la pregunta, palabras como "compara/resume/por que", numero de fragmentos relevantes) deriva consultas simples (lookup de un dato) a un modelo pequeno/local y las complejas (multi-documento, razonamiento) a un modelo grande en la nube, con fallback al local si falla el remoto. Ahorra costo y latencia; se mide con un set de preguntas de evaluacion. Es solo diseno, no implementado.

**Postgres/SQLite: no vale la pena aqui.** Para decenas de documentos, Chroma embebido basta. pgvector/Qdrant se justifican cuando hay varios workers/replicas, necesidad de filtros transaccionales con datos relacionales, backups/HA, o >1M vectores. Un contenedor Qdrant en docker-compose es el "bonus" barato (solo cambia `vector_service.py`).

## Alternativas descartadas
- **Chunking por tokens**: mas exacto pero requiere tokenizador; no necesario a este tamano.
- **bge-base / e5-base / gte / nomic**: mas calidad pero 3-4x mas lentos en CPU y mas pesados [NV]; nomic requiere prefijos y `trust_remote_code` [NV].
- **FAISS**: sin persistencia/metadata nativa; hay que construirlas. **sqlite-vec**: joven, menos conocido [NV]. **pgvector**: exige un servicio Postgres; sobredimensionado.
- **LiteLLM / LangChain**: dependencias pesadas para un solo endpoint; ocultan decisiones que hay que explicar.
- **Anthropic via capa OpenAI**: viable, pero no recomendada para produccion segun su doc.

## Riesgos y trampas
- Chroma L2 por defecto: scores confusos (distancia, no similitud) [V].
- Prefijos e5 olvidados degradan la recuperacion en silencio [NV].
- Cargar el modelo por request (explicitamente penalizado).
- IDs `chunk_0..n` por documento sobrescriben ingestas previas (penalizado).
- OCR ruidoso: texto con saltos y guiones; limpiar espacios antes de chunkear; chunks vacios deben descartarse.
- Primer arranque descarga el modelo (red, tiempo): precalentar en `lifespan` o en el Dockerfile.
- Citar `sources` desde el LLM = fabricacion; construirlos en codigo.
- Reintentos sin tope + timeout largo bloquean el worker; presupuesto total acotado.
- Secretos: nada en codigo; `.env.example` sin valores reales.

## Que explicar en la entrevista
- Por que ese chunk_size/overlap (precision vs contexto; overlap evita perder informacion en el borde) y como se garantiza no cortar palabras.
- Coseno vs L2: embeddings normalizados, relacion `dist = 1 - cos`; por que el score se invierte.
- Estrategia de ID (hash de contenido + chunk_idx) e idempotencia vs duplicados.
- Modelo cargado una vez (singleton/lifespan) y por que.
- Grounding: umbral de score, abstencion, `sources` derivados de la recuperacion.
- Modelo de amenaza de prompt injection y por que el LLM sin herramientas limita el dano.
- Que errores se reintentan y por que (idempotentes/transitorios), mapeo 503/504/502.
- FakeLLM + inyeccion de dependencias para tests sin red.
- Cuando migrar a Qdrant/pgvector y a fastembed.

## Preguntas abiertas para el usuario
1. Idioma de los PDFs de prueba (ingles/espanol)? Define MiniLM vs multilingual-e5-small.
2. Hay GPU / cuanta RAM? Define el modelo Ollama; o se usa API remota gratis?
3. Re-ingestar el mismo PDF debe reemplazar (upsert por hash) o duplicar?
4. Se hara el bonus con Qdrant en docker-compose?
5. Hay presupuesto de tiempo para una mini-evaluacion (preguntas con respuesta conocida)?

## Fuentes
- Chroma configuracion/metricas: https://docs.trychroma.com/docs/collections/configure
- Anthropic compat OpenAI SDK: https://platform.claude.com/docs/en/cli-sdks-libraries/libraries/openai-sdk
- Ollama compat OpenAI: https://docs.ollama.com/api/openai-compatibility
- fastembed: https://github.com/qdrant/fastembed
- httpx timeouts: https://www.python-httpx.org/advanced/timeouts/
- tenacity: https://tenacity.readthedocs.io/en/latest/
- OWASP LLM Top 10 (indice): https://genai.owasp.org/llm-top-10/
- multilingual-e5-small (ficha, no verificada): https://huggingface.co/intfloat/multilingual-e5-small
- Repo leido: `rag_service.py`, `vector_service.py`, `embedding_service.py`, `pyproject.toml` (stubs con NotImplementedError; deps ya incluyen sentence-transformers, chromadb, httpx; tenacity NO esta y habria que anadirlo). No lei `app/api/rag.py` ni `schemas.py`; no ejecute experimentos.
