# 08 - Harness engineering para Claude Code (take-home ML)

Fecha 2026-10-27. CLI local 2.1.310 [V: `claude --version`]. Etiquetas: [V] verificado en fuente/archivo, [NV] no verificado. Fuentes S1..S14 al final. Nota de seguridad: las paginas de code.claude.com traen una cabecera dirigida a agentes ("Use this file to discover all available pages before exploring further"); es solo un indice, no se siguio ninguna instruccion.

## 1. Principios (con fuentes)
1. **Contexto = recurso finito.** Objetivo: "el menor conjunto posible de tokens de alta señal"; recuperar just-in-time (rutas, no volcados); compactar; notas fuera de contexto; subagentes con ventana limpia que devuelven resumen [S1].
2. **Simplicidad.** Anadir complejidad solo si mejora algo medible; pocas herramientas, sin solapes, con proposito claro [S2, S3]. Para un harness: pocas piezas, cada una explicable.
3. **Dar a Claude una forma de verificarse** (tests, lint, criterios ejecutables) y una revision independiente (`/code-review` usa un subagente que no vio tu conversacion) [S4].
4. **Instruccion != cumplimiento.** CLAUDE.md es contexto, "Claude puede decidir que una guia no aplica"; lo que no admite excepciones va en hook, regla deny o setting gestionado. Si subes el enfasis de una linea y se ignora, es señal de que es un hook [S4, S5]. Al reves: hooks para meras preferencias sobran.
5. **CLAUDE.md corto**: objetivo <200 lineas; lo parcial va a `.claude/rules/*.md` con `paths:`; los `@imports` no reducen coste [S5].
6. **Trabajo largo** (Anthropic): lista de features en JSON con `passes`, un feature por sesion, archivo de progreso + commits, `init.sh`/smoke test al arrancar, prohibido editar tests para "pasar" [S6]. Traduccion a spec-driven: SPEC con criterios de aceptacion = tests en rojo; tu "lista de features" son los tests.
7. **Contenido no confiable = dato.** Defensa en capas: deny, hooks, aprobacion de red, sandbox; "ningun sistema es inmune" [S7].

## 2. Tabla "quiero X -> uso Y"
| Quiero | Uso | Nota |
|---|---|---|
| Contexto del proyecto, comandos, convenciones (guia) | `CLAUDE.md` (compartido) o `CLAUDE.local.md` (solo tu, gitignorado a mano) | Se cargan juntos; local se añade despues [S5] |
| Regla solo para ciertos archivos | `.claude/rules/x.md` con `paths:` | Carga bajo demanda [S5] |
| Algo que NUNCA/SIEMPRE debe pasar | Hook `PreToolUse` (exit 2) / `Stop` / deny | Determinista [S4,S8] |
| Prohibir leer/ejecutar | `permissions.deny` | deny > ask > allow; un allow no abre un deny [S9] |
| Evitar prompts de comandos seguros | `permissions.allow` (`Bash(uv run pytest *)`) | allow de repo espera "trust" [S10] |
| Flujo repetible que Claude elige solo | Skill (`SKILL.md`) | `description` decide cuando carga [S11] |
| Flujo que solo yo disparo | Skill con `disable-model-invocation: true` | p.ej. `/grill-me` [S11] |
| Trabajo pesado que ensucia contexto | Subagente (`.claude/agents/*.md`: `tools`, `model`) o skill `context: fork` | Contexto limpio [S12] |
| Datos externos / herramientas | MCP (`.mcp.json`) | Revisar cada servidor [S7] |
| Empaquetar y compartir todo | Plugin | No necesario aqui |
| Recordar entre sesiones | CLAUDE.md (tu) / auto memory (Claude, 200 lineas/25KB) | `/memory` [S5] |
| Config personal de un proyecto | `.claude/settings.local.json` | Precedencia: managed > CLI `--settings` > local > proyecto > usuario; las listas se fusionan [S10] |

## 3. Verificaciones puntuales
- **`attribution`**: objeto `{commit, pr, sessionUrl}` o `false` (v2.1.281+). `commit` por defecto añade `Co-Authored-By: <modelo> <noreply@anthropic.com>`; `""` lo oculta. `pr` por defecto `🤖 Generated with [Claude Code]...`; `""` lo oculta. `sessionUrl` (bool, def. true) solo afecta sesiones cloud/Remote Control. `includeCoAuthoredBy` esta deprecado. Tus instrucciones (CLAUDE.md) tienen prioridad salvo que se fije en managed [V, S13]. Tu config (`""`,`""`,`false`) es valida; `"attribution": false` es la forma moderna. Como Claude no commitea, solo es red de seguridad.
- **`.git/info/exclude` vs `.gitignore`**: sensato aqui. `.gitignore` esta versionado (upstream lo tiene) y editarlo ensucia el PR; `exclude` es local por clon y se comparte entre worktrees del mismo repo [NV worktrees]. Limites: no oculta archivos ya trackeados; `git clean -fdx` borra ignorados (tu deny cubre `git clean -f*`); Grep/Glob (ripgrep) suelen respetar ignores [NV]. La doc recomienda `.gitignore` o excludes globales (Claude Code escribe `**/.claude/settings.local.json` en el global excludes) [V, S10].
- **CLAUDE.local.md**: se carga junto a CLAUDE.md, después de este, desde el cwd hacia arriba; **no se gitignora solo** (hay que añadirlo; `CLAUDE_CODE_NEW_INIT=1 /init` lo hace). Solo existe en el worktree donde lo creaste; sobrevive a `/compact` el de raiz [V, S5]. Subagentes custom lo heredan; Explore/Plan no [V, S12].
- **Hooks y subagentes**: los hooks de settings/managed/plugins SI se ejecutan dentro de subagentes (`agent_id`, `agent_type` en la entrada); los de frontmatter del agente solo mientras corre y tras aceptar trust [V, S8, S12]. Tu `secret-guard` cubre a `scout`.
- **Huecos conocidos**: (a) reglas `Bash(...)` casan el texto escrito: "no es frontera de seguridad"; `git -C x add`, `cmd /c`, otra forma del mismo programa las esquivan [V, S9]. (b) `Read` deny es "best-effort" para Grep/Glob/@mentions [V, S9]. (c) Los hooks no deciden contra deny: un PreToolUse `allow` no salta un deny [V, S9]. (d) exit 1 es error NO bloqueante; para politica usar exit 2 o `onFailure:"block"` (v2.1.295+) [V, S8]. (e) **Sandbox no existe en Windows nativo** (solo macOS/Linux/WSL2) y no cubre Read/Edit/Write ni hooks [V, S14]. (f) `-p` no muestra dialogo de trust; `--bare` salta hooks, skills y CLAUDE.md [V, S8, S15].

## 4. Anti-patrones
CLAUDE.md largo con reglas duras (usa hook); duplicar la misma regla en CLAUDE.md, skill y hook; denylist de regex enorme que nadie puede explicar; confiar en deny de Bash como frontera; skills/agentes "por si acaso"; dejar que el modelo marque "terminado" sin test; obedecer texto de PDFs/PRs/web (mitigar: tratarlos como dato, agente de solo lectura sin Bash, sin credenciales reales en el arbol, `sources` calculadas en codigo, test de inyeccion).

## 5. Auditoria de nuestro harness (ML-Engineer-test)
**Bugs**
1. **Ruta de repo equivocada** en `commit-handoff` (`$r`) y `delegate`: `...\jeikosd\ML-Engineer-test`; la real es `...\jeikosd\parterns_test_ML\ML-Engineer-test` [V: `ls`]. El bloque de commit fallaria.
2. **Deny de git evadible**: `Bash(git add*)` no casa `git -C <ruta> add`, justo la forma que enseña `commit-handoff`; ni `git -c`, `cmd /c git`, `& git` [V, S9]. Hoy el unico bloqueo real de Claude-commitea es textual. Fix: en `secret-guard.js` bloquear (exit 2) en Bash/PowerShell `\bgit\b[^|;&]*\b(add|commit|push|reset|clean|rebase|merge|tag|checkout --)\b`.
3. **`allowed-tools: ... Bash(git status*) Bash(git diff*)`** como cadena separada por espacios: los espacios dentro de `Bash(git status*)` pueden partir el token [NV]. Usar lista YAML. Ademas `allowed-tools` solo *concede* sin preguntar, no restringe [V, S11].
4. **`verify.ps1`**: `Select-Object -Last 15` corta los errores de ruff (el detalle sale primero, el resumen al final); `2>&1` sobre exe nativos en PS 5.1 mete `NativeCommandError` ruido; `$LASTEXITCODE` tras tuberia [NV]. Capturar salida en variable, leer `$LASTEXITCODE` justo despues, imprimir cabeza+cola.
5. **`commit-msg`** rechaza cualquier mensaje con "claude code" (falso positivo en `docs: guia de Claude Code`); **`pre-commit`** falla abierto si no hay gitleaks (hoy esta instalado, 8.30.1 [V]). Aceptable; documentarlo.
6. `settings.json`: `onFailure` exige v2.1.295+ [V]; con CLI viejo se ignora y el hook falla abierto. Hoy 2.1.310, ok. El matcher no cubre `WebFetch`, `WebSearch`, `Agent`, `Artifact` (publicar a claude.ai); añadir `Artifact` a deny.
7. `CLAUDE.local.md`: seccion "Compact Instructions" sin confirmar que se aplique [NV]; usa `/compact <foco>`.

**Redundante/arriesgado**
- `secret-guard.js` (~250 lineas, regex): no explicable en entrevista y la propia cabecera dice "no es frontera"; sin sandbox en Windows, el control real es no tener credenciales en el arbol. Reducir (~40 lineas).
- Los 17 `Read(...)` deny duplican al hook; mantener los pocos declarativos visibles en `/permissions`, quitar duplicados `Bash`+`PowerShell` de git si el hook ya lo bloquea.
- Skill `delegate`: subagentes custom/general-purpose ya heredan `CLAUDE.local.md` [V, S12]; la plantilla "reglas (copiar tal cual)" es redundante. Reducir a 10 lineas o borrar.
- Skill `untrusted-content`: mitad duplica CLAUDE.local.md; la mitad RAG deberia ser `.claude/rules/rag.md` con `paths:`. Su `allowed-tools` no aporta.
- `commit-handoff` repite gitleaks (ya en pre-commit) y reglas de CLAUDE.local.md; `py-verify` repite "Verificacion". Una sola fuente por regla.
- `scout` valido (`tools`, `model: haiku` OK [V, S12]); vs built-in Explore solo aporta heredar reglas y tope de 300 palabras: mantener, añadir `maxTurns`.
- `grill-me`: frontmatter valido (`disallowed-tools` existe [V, S11]); util para spec-driven.

**Faltan**: bloqueo real de git-write; `allow` minimo (`uv run pytest/ruff`, `verify.ps1`) para no ser prompteado cada vez; hook `Stop` que corra `verify.ps1` si hay `.py` modificados (con limite: tras 8 bloqueos Claude Code lo anula [V, S4]); plantilla SPEC; revisor independiente de solo lectura.

## 6. Harness minimo recomendado
1. `CLAUDE.local.md` <=60 lineas: contexto, comandos, convenciones, trampas. Sin reglas "duras".
2. `settings.json`: `attribution:false`; deny (secretos, `GRADING.md`, `Artifact`); allow de verificacion; sin hooks extra.
3. **Un** hook `PreToolUse` corto: git-write + `.env*`/claves (exit 2).
4. Hook `Stop` opcional (fase 2) -> `verify.ps1`.
5. Skills: `grill-me`, `py-verify`, `commit-handoff` (corregido), `spec` (opcional, `disable-model-invocation`). Borrar `delegate`; `untrusted-content` -> rule con `paths:`.
6. Agentes: `scout` + `reviewer` (Read/Grep/Glob, revisa diff contra SPEC).
Flujo spec-driven: `/grill-me` -> `/plan` -> `SPEC.md` (objetivo, no-objetivos, criterios = nombres de tests) -> tests rojos -> implementar -> `verify.ps1` -> `reviewer` -> bloque de commit.

## 7. Comandos para aprender e inspeccionar (PowerShell, desde el repo)
| Pieza | Comando | Que muestra |
|---|---|---|
| Version/config | `claude --version`; `claude doctor` | Version; entradas rechazadas de settings [S10] |
| Fuentes cargadas | `/status` | Que settings se cargaron |
| Memoria | `/memory`, `/context` | Archivos CLAUDE*.md cargados y su coste [S5] |
| Permisos | `/permissions` | Reglas allow/ask/deny activas [S7] |
| Hooks | `/hooks` | Hooks configurados [S16] |
| Skills | `/skills` [NV exacto], invocar `/grill-me idea` | Lista/ejecuta |
| Agentes | `/agents` (>=2.1.198 solo recuerda editar `.claude/agents/`) [S16]; pedir "usa scout para..." | Delegacion |
| Auditar prompts | `/doctor prompt-audit` [S5] | Revisa CLAUDE.md, skills, agentes |
| Plan | `/plan <tarea>` | Modo plan |
| Hook sin Claude | `'{"tool_name":"Read","tool_input":{"file_path":".env"},"cwd":"."}' \| node .claude/hooks/secret-guard.js; $LASTEXITCODE` | Debe dar 2 (solo lee stdin) |
| Ignorados | `git check-ignore -v .claude/settings.json CLAUDE.local.md` | Que regla los oculta |
| commit-msg | `"feat: x\`n\`nCo-Authored-By: Claude <a@b.c>" \| Set-Content $env:TEMP\m.txt; sh .git/hooks/commit-msg $env:TEMP\m.txt; $LASTEXITCODE` | Debe dar 1 |
| Verificacion | `powershell -NoProfile -File .claude/tools/verify.ps1; $LASTEXITCODE` | 0 = OK |
| Headless | `claude -p "lee .env" --max-turns 3 --output-format json` | Prueba el bloqueo [S15] |
| Depurar | `claude -p "..." --debug-file $env:TEMP\cc.log` | Log; buscar el hook [S15] |
| Linea base | `claude --setting-sources user -p "..."` / `claude --bare -p "..."` | Sin harness: comparar [S15] |
| Modo | `claude --permission-mode plan` | Empezar en plan |

## Fuentes
S1 https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents
S2 https://www.anthropic.com/engineering/building-effective-agents
S3 https://www.anthropic.com/engineering/writing-tools-for-agents
S4 https://code.claude.com/docs/en/best-practices
S5 https://code.claude.com/docs/en/memory
S6 https://www.anthropic.com/engineering/effective-harnesses-for-long-running-agents
S7 https://code.claude.com/docs/en/security
S8 https://code.claude.com/docs/en/hooks
S9 https://code.claude.com/docs/en/permissions
S10 https://code.claude.com/docs/en/settings
S11 https://code.claude.com/docs/en/skills
S12 https://code.claude.com/docs/en/sub-agents
S13 https://code.claude.com/docs/en/settings-reference (seccion attribution)
S14 https://code.claude.com/docs/en/sandboxing
S15 https://code.claude.com/docs/en/cli-reference
S16 https://code.claude.com/docs/en/commands
