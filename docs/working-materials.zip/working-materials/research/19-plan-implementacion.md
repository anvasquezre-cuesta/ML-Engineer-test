# 19 · Plan de implementacion y arquitectura de agentes (2026-10-28, PROPUESTA)

Fuente del inventario: asistente Sonnet (2026-10-28), verificado por Claude en lo que decide. Manda sobre 13/14 en orden de trabajo.

## Estado
- Notebooks 01-03 y oros (`gold_names.csv`, `gold_fuzzy_pairs.csv`) commiteados. `app/` = stubs; 1 test (`test_config.py`); sin specs.
- Dependencias de runtime ya declaradas en `pyproject.toml` (spaCy, pytesseract, pymupdf, rapidfuzz, chromadb, sentence-transformers, httpx, tenacity). pandas solo en grupo `notebooks`: el servicio no lo usa.

## Decisiones abiertas (se resuelven en la spec, con el critico)
1. Firmas `pdf_path: str` de los stubs (R1) frente a `pymupdf.open(stream=bytes)` (R6): envoltorio que abre el path y delega a un nucleo con bytes.
2. Caja de nombre que cruza renglones: 06:23 dice una por linea; el proto hace caja union.
3. `BBOX_ORIGIN` top-left vs bottom-left (R10).
4. NB04 e2e: reemplazarlo por un test e2e (recomendado).

## Orden
| Fase | Que | Agentes | Sale |
|---|---|---|---|
| F0 | 02b sin `def` (`line_of` -> `merge_asof`; `occurrence` -> `cumcount` en linea; `show_page` -> una celda por pagina o `proto/common`) | notebook-builder; Claude verifica hash de `gold_names.csv` | 02b ejecutado, oro identico |
| F1 | Spec 01 `/api/extract` (ACs OCR/NER/BOX/FUZ + validacion, config, errores, logging) | Claude redacta; code-critic (opus) critica el diseno antes del codigo; Jeison firma | `docs/specs/01-extract.md` |
| F2 | Base: config, errores de dominio -> HTTP, Protocols, deps, logging, validacion de upload | implementer + code-critic | tests verdes |
| F3 | Rebanadas: 3a OCR+cajas, 3b NER+D4, 3c fuzzy, 3d router + e2e | implementer + code-critic por rebanada | tests verdes, verify.ps1, commit por rebanada |
| F4 | RAG: auditar Chroma/MiniLM/Ollama -> NB05 -> spec 02 -> implementar | package-auditor, notebook-builder, implementer + code-critic | `/api/ingest`, `/api/ask` |
| F5 | DESIGN.md + filas DECISIONS.md | Claude redacta; Jeison aprueba | entregables |
| F6 | Bonus segun fecha: CI > visor > Docker | implementer + code-critic | |
| F7 | Evaluacion final de la rama contra el rubric | final-evaluator (opus), sin conclusiones previas | hallazgos -> arreglos -> PR (Jeison) |

Ciclo por rebanada: spec -> tests rojo (implementer) -> codigo minimo -> verify.ps1 -> code-critic (max 2 rondas) -> Jeison explica cada AC -> /commit-handoff.

## Agentes
| Rol | Modelo | Herramientas | Cuando |
|---|---|---|---|
| assistant | sonnet | Read, Grep, Glob, Bash (solo lectura) | Lee y resume para Claude; corre verify y resume fallos |
| notebook-builder | sonnet | existente | F0, F4 |
| package-auditor | sonnet | existente | F4 |
| implementer (nuevo) | sonnet | Read, Edit, Write, Bash | F2-F4, F6 |
| code-critic (nuevo) | opus | Read, Grep, Glob, Bash (solo lectura) | Spec y cada diff: por que esta funcion, este nombre, esta linea; propone borrar; acepta mas lineas solo si ganan calidad |
| final-evaluator (nuevo) | opus | Read, Grep, Glob, Bash (solo lectura) | F7 |
`reviewer` (sonnet) queda sustituido por code-critic para no duplicar.

## Commits (Jeison, 2026-10-28)
Historia honesta y legible: refleja el orden real de trabajo. Sin cambiar fechas, sin juntar dias en commits falsos, uso de IA ya declarado en DECISIONS.md.
- Commit cuando una idea queda terminada, verde (`verify.ps1`) y **explicada por Jeison**. Nunca a mitad de rebanada ni un commit gigante final.
- Una idea por commit, una linea Conventional Commits. Test y codigo separados cuando el test tiene sentido solo; si no, un `feat` con ambos. Ningun commit deja la rama en rojo.
- Arreglos del critico sobre codigo ya commiteado: `refactor:`/`fix:` aparte; antes del commit, dentro del mismo.
- Ritmo esperado: 1-3 commits por sesion. Lo inacabado se queda en el working tree.
- Lista prevista por fase en la respuesta del 2026-10-28 (F1 spec; F2 config, errores, validacion, protocols, logging; F3 test/feat por etapa + e2e; F4 RAG igual; F5 docs; F6/F7 ci, viewer, fix).

## Revision (2026-10-28, aprobada: "hacer lo recomendado")
- NB04 se elimina: lo cubre un test e2e (AC-E2E). Fecha de entrega sin definir: bonus se decide al llegar a F6.
- **Una spec pequena por rebanada** (no una sola spec 01 grande). Orden por riesgo y dependencias, de logica pura a integracion:

| Spec | Rebanada | Por que en este orden |
|---|---|---|
| 01-fuzzy | `fuzzy_service` + `fuzzy_threshold` en config | logica pura, prototipo listo, sin modelos: estrena el ciclo con bajo riesgo |
| 02-ner | `ner_service` (spaCy + 3 filtros + D4) tras Protocol `NameRecognizer` | logica pura sobre texto; fake en tests |
| 03-ocr-boxes | `ocr_service` + `bbox_service` (bytes, px->pt, caja) tras Protocol `OcrEngine` | depende de Tesseract; resolver R1/R6, caja multi-renglon y BBOX_ORIGIN |
| 04-extract-api | router `/api/extract`, validacion de upload, errores -> HTTP, logging, DI, `/health`, e2e | integra 01-03 |
| 05-rag-ingest | chunking, embeddings, Chroma (IDs unicos) | tras NB05 |
| 06-rag-ask | cliente LLM (timeout, tenacity), prompt, abstencion, sources | tras 05 |

## Estrategia de evaluacion por paso (gates)
Ningun paso avanza sin pasar su gate. Quien evalua no es quien produjo.

| Paso | Produce | Evalua | Criterio para pasar |
|---|---|---|---|
| 1 Spec | Claude | code-critic (opus) -> Jeison firma | Cada AC observable y con fuente (linea README / decision D#-F# / valor del notebook); sin relleno; <= 6 tareas; contrato intacto; APPROVE |
| 2 Tests rojo | implementer | assistant (corre pytest) | Un test por AC con nombre `test_ac_<area>_<nn>_*`; fallan por `NotImplementedError`/assert, no por import o sintaxis |
| 3 Codigo verde | implementer | assistant (verify.ps1) | ruff, formato y pytest verdes; valores esperados = los del notebook |
| 4 Critica | implementer | code-critic (opus), max 2 rondas | APPROVE: cada funcion/nombre/linea justificada; lineas minimas sin perder calidad |
| 5 Explicacion | Jeison | Claude pregunta | Jeison explica cada AC y responde 3 preguntas de entrevistador sin mirar; se firma la seccion "Explicacion (JM)" |
| 6 Commit | Jeison (`/commit-handoff`) | hooks (gitleaks, commit-msg) | rama verde, una idea por commit |
| Fin de 04 | - | assistant | e2e sobre `company_memo.pdf` reproduce el notebook: 8 menciones, 7 nombres, 3 matches (03_matches.csv) |
| F7 | - | final-evaluator (opus) | tabla del rubric; arreglos top-5 aplicados con el mismo ciclo |
| 1b Plan de implementacion | **Jeison** (`tasks/NN-slug/plan.md`, fuera del PR) | Claude lo revisa contra la spec | Antes de cualquier test o codigo; Claude avisa y espera, nunca lanza implementer sin el plan |

## Carpetas de tarea (Jeison, 2026-10-28)
Flujo por tarea: research -> evaluacion -> spec -> plan (JM) -> implementacion -> reviews -> explicacion -> commit. Todas las tareas se piensan antes de implementar la primera. Cada tarea tiene `tasks/NN-slug/` (fuera del PR) con README, research, evaluation, plan y reviews/; indice en `tasks/INDEX.md`; plantilla en `.claude/templates/task/`. La spec sigue en `ML-Engineer-test/docs/specs/` (va al PR) y no enlaza a `tasks/` (no llega al evaluador). Tareas: 01-fuzzy, 02-ner, 03-ocr-boxes, 04-extract-api, 05-rag-ingest, 06-rag-ask, 07-docs, 08-bonus, 09-final-eval.
