# 23 · Estado y siguiente paso (2026-10-29 noche; 05 implementada, cierre en curso)

Leer primero al retomar, con `CLAUDE.md`, `tasks/INDEX.md`, `tasks/05-rag-ingest/` y las últimas filas de `DECISIONS-LOG.md`. El 22 queda como historia.

## Tarea 05-rag-ingest: hecho
| Commit | Qué |
|---|---|
| 1e8876b | `docs(spec)`: spec 05 (con spec:13 corregida por amend) |
| 379e411 | config RAG (+ `/data/` en `.gitignore`) |
| 380de61 | `eval/questions.json` |
| c7256ce | `chunk_text` (CHK-01..03; CHK-02 con overlap 17 y 20) |
| af0759c | Chroma (VEC-01..04 + store/search con dimensión errónea) |
| dda3a0c | refactor `read_pdf` compartido |
| 40bd28a | `/api/ingest` (ING-01..03; fixture `chroma` en `tests/unit/conftest.py`) |
| 7fe35d8 | integración MiniLM real (INT-01 con A más corto, EMB-01) |

- `app/` = 120 líneas (techo del gate 88-120; 69 sentencias). Unitarios 70 en ~5.5 s; integración 8 en ~18 s.
- Mutaciones que sobreviven y se aceptan: `>=` en la 2.ª condición del overlap (borde exacto); "embeber después del delete" (ningún AC; revisado leyendo el código).
- Plan: `tasks/05-rag-ingest/plan.md` (con "Respuestas de JM").

## Cierre (en curso)
1. Spec alineada: ebcfddc.
2. NB05 "Desde `app/`": hecho y revisado (12/12 chunks idénticos, 0 rangos distintos; 113 celdas, 0 errores).
3. Explicación de los 12 AC en el NB05: borrador de Claude listo; falta que JM la estudie y la firme.
4. `research/20-preguntas-entrevista.md`: sección 05 escrita (preguntas 28-42).
5. `DECISIONS.md` escrito (texto aprobado por JM); falta el commit `docs: record RAG ingest decisions`.
6. Documentos desactualizados: corregidos `research.md:42` y el README de la tarea; `proto/rag.py` se queda con `[:16]` (el NB05 lo explica).

## Siguiente tarea
06-rag-ask (`/api/ask`): métricas en `research/18-metricas.md` §8; `MIN_SCORE` fijo no separa (u01 y u02 ≈ 0.48). Para la 06: `top_k` necesita `gt=0` en la config (`top_k=0` da `TypeError` → 500, visto por el crítico). `schemas.py` no se toca (contrato de la prueba; solo campos opcionales justificados).

## Pendientes que cruzan tareas
- JM: "Mis respuestas" de 02a, 02c, 03 y 05 antes de la entrevista.
- Fecha de entrega (decide cuánto bonus entra).
