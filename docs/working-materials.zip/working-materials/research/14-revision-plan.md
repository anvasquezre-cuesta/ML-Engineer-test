# 14 - Revision del plan (correcciones a 06, 07 y 13)

Fecha: 2026-10-27. Revision de 06, 07, 13 y DECISIONS-LOG contra README, `schemas.py` y stubs. Veredicto: el plan tecnico es solido; se corrigen huecos puntuales y se recorta proceso. Ante conflicto, este documento manda sobre 06, 07 y 13.

## 1. Repo

- Repo unico: `C:\Users\Jeikosd\Documents\jeikosd\parterns_test_ML\ML-Engineer-test`. El clon `docintel-service` queda descartado (lo borra Jeison). Referencias corregidas en 06, 10 y CLAUDE.md.

## 2. Correcciones tecnicas

| # | Tema | Antes | Ahora | Por que |
|---|---|---|---|---|
| R1 | Firmas de los stubs | 06: "los stubs se reemplazan" | Se conservan las funciones publicas con su nombre y firma (`extract_text_from_pdf`, `get_word_bounding_boxes`, `extract_names`, `find_name_bounding_boxes`, `fuzzy_match_names`, `chunk_text(text, chunk_size=500)`, `get_embeddings`, `get_query_embedding`, `init_collection`, `store_document_chunks`, `search_similar`, `generate_answer`) como envoltorios delgados sobre las clases/funciones nuevas | Puede haber tests ocultos que importen esas funciones; el seguro cuesta pocas lineas |
| R2 | Reintentos en vector store | Solo en el LLM | Chroma embebido: sin reintento (fallo no transitorio), error de dominio -> 503. Chroma `HttpClient` (compose): timeout + `tenacity` con la misma politica que el LLM | El README pide timeouts y reintentos en LLM **y** vector store; en compose Chroma es externo. Justificar en DECISIONS.md |
| R3 | Filtro de entidades en MAYUSCULAS | Regla fija | Regla configurable (`NER_DROP_ALL_CAPS=true`), medida con el oro de 55; documentada como limitacion (pierde nombres reales en mayusculas, p. ej. "FROM: JOHN SMITH") | Evita sobreajuste a 3 muestras |
| R4 | Duplicados en fuzzy | Todos los pares >= umbral | Deduplicar nombres extraidos (normalizados) antes del fuzzy; las cajas siguen siendo una por ocurrencia | Margaret Thompson aparece 2 veces; `fuzzy_matches` no debe repetirse |
| R5 | Puntuacion en cajas | Palabra OCR completa | Al construir el texto con offsets, recortar puntuacion de borde (`,.;:()"`) de la palabra antes de mapear el span; la caja usa la palabra recortada solo si el ancho por caracter lo permite; si no, se acepta y documenta | "Thompson," ensancha la caja |
| R6 | Archivos temporales | `with` sobre archivo | `fitz.open(stream=bytes, filetype="pdf")`: sin archivo temporal | Cubre "no leaked file handles or temp files" sin codigo |
| R7 | Limite de paginas | Solo tamano y DPI | `MAX_PAGES` en config -> 413/422 | Un PDF pequeno puede tener cientos de paginas |
| R8 | `/health` | Con dependencias | `status: "ok"` siempre que el proceso viva (liveness); estado de Tesseract/LLM/Chroma como campos informativos. HEALTHCHECK y `depends_on` dependen solo de liveness | Que la falta de Ollama no marque el contenedor como unhealthy |
| R9 | LLM para el evaluador | Ollama del host via `host.docker.internal` | Ademas `extra_hosts: ["host.docker.internal:host-gateway"]` en compose; `.env.example` con bloque comentado para OpenAI listo para usar | En Linux `host.docker.internal` no resuelve sin eso |
| R10 | Origen de ejes | Top-left + `BBOX_ORIGIN` | Igual, pero reconocer que "PDF coordinate space" literal es bottom-left: formula `y_pdf = page_height - y - height` visible en DECISIONS.md, DESIGN.md y OpenAPI | Riesgo real; la apuesta se sostiene y es reversible por config |

## 3. Recorte de proceso

El rubric da 70 % a correctness, arquitectura y practicas; la evaluacion estadistica no tiene peso propio. Cambios:

**Notebooks: de 11 a 5** (reemplaza la tabla de 13 seccion 3b).

| NB | Contenido | Tope |
|---|---|---|
| 01_ocr | celda 0 de humo (versiones, Tesseract, hashes; reemplaza a `00_entorno`) + OCR 300 DPI, px -> pt, todas las paginas, texto con offsets, cajas dibujadas | 1.5 h |
| 02_ner_cajas | NER + filtros + `locate_names` + P/R contra oro de 55 + IoU | 2.5 h |
| 03_fuzzy | normalizacion, comparacion de scorers, barrido de umbral | 1 h |
| 04_extract_e2e | las 4 etapas sobre las 3 muestras + llamada a la API | 0.5 h |
| 05_rag | chunks, recuperacion hit@k/MRR, LLM, abstencion, inyeccion (Chroma y Ollama se prueban aqui) | 2.5 h |

- Se eliminan `00_entorno` (va en la celda 0 de 01) y `10_resultados` (cada NB escribe su tabla directo en `notebooks/artifacts/results.md`).
- Oro a etiquetar: 55 menciones y 10 preguntas se mantienen; pares fuzzy bajan de ~40 a ~20 (con negativos duros).
- Ablaciones (sm/md/lg, DPI 150/300) solo si `sm` con filtros no logra P=R=1, o despues de terminar el core.
- Wilson IC se mantiene (barato); "n pequeno, resubstitucion" sigue obligatorio.

**Horas.** El camino critico (etapas 0-5) tiene presupuesto de **8-10 h**, no 12-14 h. El PoC de `/api/extract` va antes de cualquier ablacion.

## 4. Rama y entorno (decidido)

- **Rama:** `feat/jeison-mesa-document-intelligence` (renombrada desde `feat/document-intelligence-service` con 0 commits), desde `main` @`7acb727`; una rama = un PR; un commit por rebanada, mensaje de **una sola linea**. El nombre va en la rama (la pagina del PR muestra `Jeikosd:<rama>` y el login no dice el nombre real) y en el titulo del PR (`Document Intelligence Service — Jeison Mesa`).
- **Publicar (Jeison):** fork -> `git remote add origin <fork>` -> `git push -u origin feat/jeison-mesa-document-intelligence` -> PR hacia `anvasquezre-cuesta:main`. `upstream` sigue con push DISABLED.
- **Dependencias aprobadas:** +rapidfuzz, +tenacity, +en-core-web-sm (wheel 3.8.0 via `[tool.uv.sources]`); extra `dev` = pytest, pytest-cov, ruff (se mantiene como extra porque el README usa `uv sync --extra dev`); grupo `notebooks` = ipykernel, matplotlib, pandas; fuera thefuzz, python-Levenshtein, pytest-asyncio.
- **torch CPU desde el indice oficial `download.pytorch.org/whl/cpu` en todas las plataformas** (el wheel por defecto traia CUDA en Linux): RTX 4060 Laptop 8 GB (driver 610.78) queda para Ollama (`qwen2.5:7b` Q4 ~5 GB); MiniLM en CPU sobra. `EMBEDDING_DEVICE=cpu` en config; `cuda` exigiria indice cu12x (extension documentada).
- **Kernel de VS Code:** `cuesta`.
- **Formato de notebooks:** `.ipynb` (reemplaza la recomendacion `.py` `# %%` del 12). Como `notebooks/` no va al PR, el argumento de diff limpio no aplica; los outputs con texto OCR quedan solo en local.

## 5. Pendientes de decision (Jeison)

1. Fecha limite de entrega: define cuanto bonus entra (orden sigue: CI > visor > Docker).
2. Borrar la carpeta `C:\Users\Jeikosd\Documents\jeikosd\docintel-service`.
