import sys

import nbformat as nbf

cells = []


def md(s):
    cells.append(nbf.v4.new_markdown_cell(s.strip("\n")))


def code(s):
    cells.append(nbf.v4.new_code_cell(s.strip("\n")))


md(r"""
# 05 · RAG, parte de ingesta: chunking, IDs, Chroma y recuperación

## Por qué este notebook importa
El README pide `POST /api/ingest` (OCR → chunk → embed → store) y dice qué revisará: el *chunking* **no debe cortar palabras**, los IDs del vector store deben ser **únicos entre documentos** (una segunda ingesta no pisa la primera) y la recuperación debe estar **fundamentada** (sin `sources` inventadas). Es la base de `/api/ask`: si aquí parto mal los textos o pierdo la página, la respuesta de la tarea 06 no se puede arreglar después.

## Dónde estoy en el pipeline
```
PDF -> 1 OCR (01) -> [2 CHUNK -> 3 EMBED -> 4 STORE (Chroma) -> 5 RECUPERAR top-k (este)] -> 6 LLM con contexto (tarea 06, no está aquí)
```

## Trazabilidad
| Qué | Dónde |
|---|---|
| Entrada | `artifacts/01_ocr_words.csv` (palabras OCR de los 3 PDFs) |
| Salidas | `artifacts/05_chunks.csv`, `05_strategies.csv`, `05_models.csv`, `05_scores.csv`; `eval/questions.json` (22 con respuesta + 4 sin respuesta, aprobado por Jeison) |
| Código | `notebooks/proto/rag.py`: `pages_from_words`, `chunk_text`, `chunk_sentences`, `chunk_recursive`, `doc_records`, `normalize_ocr`, `ingest`, `search`, `evaluate`, `retrieval_metrics` |
| Decisiones | `research/06-tl-plan.md:26-30`; `tasks/05-rag-ingest/research.md` y `reviews/2026-10-29-package-audit.md` |

## Preguntas que tengo que tener claras al terminar
- **P1.** ¿Qué texto entra al RAG y cómo lo reconstruyo del OCR?
- **P2.** ¿Cómo parto una página sin cortar palabras y con qué solape? ¿Qué pasa con una palabra gigante?
- **P3.** ¿Cómo hago IDs únicos entre documentos y una re-ingesta que no duplica ni pisa a otros?
- **P4.** ¿Con qué preguntas mido? (borrador que Jeison revisa)
- **P5.** ¿Recupera la página correcta, con qué incertidumbre, y cuánto cambia con el tamaño del chunk?
- **P6.** ¿Qué estrategia de chunking (A-F) me quedo?
- **P7.** ¿Qué modelo de embeddings y qué métrica (coseno o L2)? ¿Cuántos chunks pido (`top_k`)?

## Regla de decisión (la escribo ANTES de ver los números de la comparación)
Cambio **A** (500 caracteres, overlap 60, corte en espacio) por otra estrategia solo si, comparando **pregunta por pregunta** contra A: (a) McNemar exacto sobre `hit@1` da p < 0.05 a favor de la otra, o (b) el IC bootstrap pareado de ΔMRR excluye el 0 a favor de la otra. Con un empate gana la más simple. Exigir que los IC de dos estrategias no se solapen no sirve: con n = 22 casi nada lo cumple, y que se solapen no prueba que sean iguales. Poco código manda. Con 22 preguntas y 5 páginas espero no poder separar nada; lo diré. (Jeison decidió A por robustez de los nombres en el borde del chunk: criterio de **diseño**, no de métrica; la §6 lo explica.)

Orden: **01 -> 02a -> 02b -> 02c -> 03 -> 04 -> 05 (este)**. Las páginas se numeran desde 0, como en el resto del proyecto.
""")

md(r"""
## 0. Preparación
""")

code(r"""
# Empiezo importando librerías y `app`; las funciones propias las traigo solo cuando las uso.
%load_ext autoreload
%autoreload 2

import hashlib
import json
import os
import re
import sys
import tempfile
from math import comb
from pathlib import Path
from unittest.mock import patch

import chromadb
import numpy as np
import pandas as pd
from chromadb.config import Settings
from sentence_transformers import SentenceTransformer

ROOT = Path.cwd().parent  # el notebook corre desde notebooks/
sys.path.insert(0, str(ROOT))  # para importar `app`
ARTIFACTS = ROOT / "notebooks" / "artifacts"

from app.config import get_settings
from app.services import vector_service
from app.services.embedding_service import get_embeddings
from app.services.ocr_service import page_text
from app.services.rag_service import chunk_text as app_chunk_text
""")

code(r"""
# Compruebo las entradas: los 3 PDFs en el CSV del NB01 y las columnas que `page_text` necesita.
PDF_BYTES = {p.name: p.read_bytes() for p in sorted((ROOT / "sample_pdfs").glob("*.pdf"))}
words = pd.read_csv(ARTIFACTS / "01_ocr_words.csv", keep_default_na=False)
need = {"text", "block", "par", "line", "page", "pdf"}
assert need <= set(words.columns), f"Faltan columnas: {need - set(words.columns)}"
assert set(PDF_BYTES) == set(words.pdf), "El CSV del NB01 no tiene los 3 PDFs: corre el 01."
words.groupby(["pdf", "page"]).size().rename("palabras").to_frame()
""")

md(r"""
## 1. P1 · ¿Qué texto entra al RAG?
**Por qué surge.** La ingesta no necesita cajas ni NER, solo el texto de cada página. `page_text` (de `app`) une las palabras con espacio dentro de una línea y `\n` entre líneas. Empiezo sin función: un bucle sobre las filas del CSV, que ya tiene `block, par, line` para identificar la línea.
""")

code(r"""
# Reconstruyo el texto de cada página con `page_text`, igual que en los notebooks 02.
pages = {}
for pdf, group in words.groupby("pdf"):
    pages[pdf] = []
    for _, page_words in group.groupby("page"):
        rows = [{"word": str(r.text), "line": (r.block, r.par, r.line)} for r in page_words.itertuples()]
        pages[pdf].append(page_text(rows)[0])
pd.DataFrame([(pdf, i, len(t), t[:50]) for pdf, ts in pages.items() for i, t in enumerate(ts)],
             columns=["pdf", "page", "chars", "empieza_con"])
""")

md(r"""
**Como función.** Lo mismo con `pages_from_words` (un PDF a la vez).
""")

code(r"""
# Mismo resultado con la función de proto.
from proto.rag import pages_from_words

for pdf, group in words.groupby("pdf"):
    assert pages_from_words(group) == pages[pdf]
"5 páginas iguales con la función"
""")

md(r"""
**Lo que veo:** 5 páginas (memo 1, minutes 2, report 2) de 858 a 1006 caracteres cada una. Son pocas: la recuperación será fácil y los números de abajo serán ruidosos; lo tendré presente. Una página es corta: 2-3 chunks de 500 caracteres.

Leo el texto de una página a ojo, porque es **dato** y el error de OCR (`| am writing` por `I am writing`) llega a los embeddings tal cual.
""")

code(r"""
# Leo la página 0 del memo completa; busco instrucciones dirigidas a una IA (no debería haber).
pages["company_memo.pdf"][0]
""")

md(r"""
## 2. P2 · Partir una página sin cortar palabras
**Por qué surge.** Cortar cada 500 caracteres exactos parte palabras (`Engine|ering`) y el embedding de un fragmento roto no representa nada. Necesito ventanas de ~500 caracteres que terminen en espacio, y un solape de ~60 para que una frase entre dos ventanas aparezca entera en alguna. Empiezo con una sola página y un bucle: avanzo `chunk_size`, retrocedo hasta el último espacio, y empiezo la ventana siguiente `overlap` antes, **al comienzo de una palabra**. El mismo bucle con `overlap = 0` da la estrategia **B** (sin solape).
""")

code(r"""
# Bucle suelto sobre la página 0 del memo: A (overlap 60) y B (overlap 0) salen del mismo código.
text, chunk_size, loose = pages["company_memo.pdf"][0], 500, {}
for overlap in (60, 0):
    start, pieces = 0, []
    while start < len(text):
        end = min(start + chunk_size, len(text))
        if end < len(text) and not text[end].isspace():  # cortaría una palabra: retrocedo al espacio
            end = max(text.rfind(" ", start, end), text.rfind("\n", start, end))
        pieces.append(text[start:end].strip())
        if end >= len(text):
            break
        start = max(end - overlap, start + 1)
        while start < end and not text[start - 1].isspace():  # no empezar a media palabra
            start += 1
        while start < len(text) and text[start].isspace():
            start += 1
    loose[overlap] = pieces
pd.DataFrame({"chars": [len(p) for p in loose[60]], "empieza": [p[:25] for p in loose[60]], "termina": [p[-25:] for p in loose[60]]})
""")

md(r"""
**Lo que veo:** 2 chunks; el primero termina en una palabra completa y el segundo empieza unas palabras antes de ese final (el solape). Ahora lo comparo con la función y reviso el solape real y el tamaño a mano.
""")

code(r"""
# Como función: `chunk_text` debe dar lo mismo que el bucle, con overlap 60 (A) y con 0 (B).
from proto.rag import chunk_text

assert chunk_text(text, 500, 60) == loose[60]
assert chunk_text(text, 500, 0) == loose[0]
len(loose[60]), len(loose[0])
""")

md(r"""
Escalo a los 3 PDFs con la función y guardo la tabla de chunks (estrategia A). Reviso con `assert`s: ninguna palabra cortada, ningún chunk pasa de 500 (salvo palabra gigante) y el solape existe y es de ≤ 60 caracteres.
""")

code(r"""
# Parto todas las páginas con A y armo una fila por chunk.
chunks_df = pd.DataFrame(
    [(pdf, i, k, c) for pdf, ts in pages.items() for i, t in enumerate(ts) for k, c in enumerate(chunk_text(t))],
    columns=["pdf", "page", "chunk", "text"],
)
chunks_df["chars"] = chunks_df.text.str.len()
chunks_df.to_csv(ARTIFACTS / "05_chunks.csv", index=False)
display(chunks_df.groupby(["pdf", "page"]).size().rename("chunks").to_frame().T)
chunks_df.chars.describe().round(0).to_frame().T
""")

code(r"""
# Palabras de cada chunk ⊂ palabras de su página, y el chunk es un trozo literal de la página.
for r in chunks_df.itertuples():
    page = pages[r.pdf][r.page]
    assert set(r.text.split()) <= set(page.split()), (r.pdf, r.page, r.chunk)
    assert r.text in page
assert chunks_df.chars.max() <= 500
f"{len(chunks_df)} chunks: ninguna palabra cortada, ninguno pasa de 500 caracteres"
""")

code(r"""
# Solape real de un par (memo, página 0): el final más largo del chunk 0 que es el comienzo del chunk 1.
first_chunk, second_chunk = loose[60]
k_loose = next((k for k in range(min(len(first_chunk), len(second_chunk)), 0, -1) if first_chunk.endswith(second_chunk[:k])), 0)
k_loose, first_chunk[-k_loose:]
""")

code(r"""
# Como función: `overlap_chars` da lo mismo en ese par; luego lo mido en todos los pares consecutivos de la misma página.
from proto.rag import overlap_chars

assert overlap_chars(first_chunk, second_chunk) == k_loose
pairs = [(c0.pdf, c0.page, overlap_chars(c0.text, c1.text)) for c0, c1 in zip(chunks_df.itertuples(), chunks_df.iloc[1:].itertuples()) if (c0.pdf, c0.page) == (c1.pdf, c1.page)]
overlaps = pd.DataFrame(pairs, columns=["pdf", "page", "overlap"])
assert overlaps.overlap.between(1, 60).all()
overlaps.overlap.describe().round(0).to_frame().T
""")

md(r"""
**Lo que veo:** las 5 páginas dan 12 chunks (memo 2, acta 3 + 2, informe 3 + 2) de entre 120 y 500 caracteres (mediana 496); todas las palabras de cada chunk están en su página y los 7 pares consecutivos comparten entre 52 y 60 caracteres (media 57, palabras enteras). El último chunk de cada página es el resto y puede ser corto.

**Caso borde: palabra más larga que `chunk_size`.** Un token OCR de 700 caracteres (una URL, un código) no cabe. Cortarlo sería partir una palabra; la dejo entera en su propio chunk, aunque pase de 500.
""")

code(r"""
# Texto sintético con una "palabra" de 700 caracteres en medio.
giant = "aa " + "x" * 700 + " bb cc"
pd.DataFrame({"chars": [len(c) for c in chunk_text(giant, 500)], "empieza": [c[:10] for c in chunk_text(giant, 500)]})
""")

md(r"""
**Lo que veo:** tres chunks: `aa`, la palabra entera (700 > 500) y `bb cc`. No se parte ninguna palabra; el costo es un chunk más largo que `chunk_size`. Con MiniLM (256 tokens) un chunk así se **trunca**, pero un token de 700 caracteres ya es OCR roto: lo documento y no lo trato aparte.
""")

md(r"""
## 3. P3 · IDs únicos y re-ingesta idempotente
**Por qué surge.** Si el ID fuera `"{página}:{chunk}"`, dos PDFs distintos chocarían en `0:0`. El README lo dice: una segunda ingesta no debe pisar la primera. Uso `doc_id = sha256(bytes)[:16]` y el ID `"{doc_id}:{page}:{chunk}"`; el mismo contenido da el mismo `doc_id` aunque cambie el nombre. Cargo el modelo una sola vez (es lento) y mido.
""")

code(r"""
%%time
# Cargo MiniLM en CPU una vez; lo reuso en todo el notebook.
model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2", device="cpu")
model.max_seq_length, model.get_embedding_dimension()
""")

code(r"""
%%time
# Embebo los chunks de 2 PDFs con vectores normalizados (norma 1) para que coseno = producto punto.
DOC_ID = {pdf: hashlib.sha256(b).hexdigest()[:16] for pdf, b in PDF_BYTES.items()}
two = chunks_df[chunks_df.pdf.isin(["company_memo.pdf", "meeting_minutes.pdf"])].copy()
two["id"] = [f"{DOC_ID[r.pdf]}:{r.page}:{r.chunk}" for r in two.itertuples()]
emb = model.encode(two.text.tolist(), normalize_embeddings=True)
emb.shape, np.linalg.norm(emb, axis=1).round(3).min()
""")

code(r"""
# Chroma en memoria, coseno explícito y SIN función de embedding propia (le paso yo los vectores).
# Ojo: con muchas colecciones vivas a la vez, chromadb 1.5.9 falló en ~1 de cada 3 ejecuciones (consultas con 0 resultados o "Error finding id" en la colección más antigua). Por eso borro cada colección en cuanto ya no la uso.
client = chromadb.EphemeralClient(Settings(anonymized_telemetry=False, allow_reset=True))
if "nb05_demo" in {getattr(c, "name", c) for c in client.list_collections()}:
    client.delete_collection("nb05_demo")  # así la celda se puede repetir sin choques
demo = client.create_collection("nb05_demo", configuration={"hnsw": {"space": "cosine"}}, embedding_function=None)
metas = [{"doc_id": DOC_ID[r.pdf], "filename": r.pdf, "page": r.page, "chunk": r.chunk} for r in two.itertuples()]
demo.add(ids=two.id.tolist(), documents=two.text.tolist(), embeddings=emb.tolist(), metadatas=metas)
no_doc = two.page.astype(str) + ":" + two.chunk.astype(str)  # el ID sin doc_id
{"count": demo.count(), "ids_unicos": two.id.is_unique, "ids_sin_doc_id_repetidos": int(no_doc.duplicated().sum())}
""")

md(r"""
**Lo que veo:** 7 chunks de 2 documentos conviven (`count` = filas añadidas) y sus IDs son únicos; sin el `doc_id` en el ID, `ids_sin_doc_id_repetidos = 2`: el `0:0` y el `0:1` del memo chocarían con los del acta.

Ahora el hecho que obliga a borrar antes de volver a ingerir: `add` con un ID que ya existe **no lanza error y descarta el nuevo en silencio**.
""")

code(r"""
# Intento "actualizar" el primer chunk con `add`: mismo ID, texto distinto. ¿Cambia algo?
first = two.iloc[0]
demo.add(ids=[first.id], documents=["TEXTO NUEVO"], embeddings=[emb[0].tolist()], metadatas=[metas[0]])
{"count": demo.count(), "texto_guardado": demo.get(ids=[first.id])["documents"][0][:30]}
""")

md(r"""
**Lo que veo:** el `count` no cambió y el texto guardado sigue siendo el viejo: `add` ignoró mi texto nuevo sin avisar. Si re-ingiero un PDF corregido solo con `add`, quedaría el texto viejo. `upsert` sobrescribe, pero no borraría chunks sobrantes si la versión nueva tiene menos. Por eso: `delete(where={"doc_id": ...})` y luego `add`.
""")

code(r"""
# Re-ingesta de verdad para el memo: borro por doc_id y añado de nuevo; el otro documento no se toca.
demo.delete(where={"doc_id": DOC_ID["company_memo.pdf"]})
after_delete = demo.count()
is_memo = (two.pdf == "company_memo.pdf").to_numpy()
demo.add(ids=two.id[is_memo].tolist(), documents=["NUEVO"] * is_memo.sum(), embeddings=emb[is_memo].tolist(), metadatas=[m for m, f in zip(metas, is_memo) if f])
minutes_left = demo.get(where={"filename": "meeting_minutes.pdf"})["ids"]
{"tras_delete": after_delete, "count_final": demo.count(), "minutes_intactas": len(minutes_left), "memo_ahora": demo.get(ids=[first.id])["documents"][0]}
""")

md(r"""
**Lo que veo:** tras el `delete` solo quedan los chunks del acta; después del `add` vuelve al total, el memo tiene el texto nuevo y el acta no se tocó. Ahora la función y su prueba de idempotencia con los 3 PDFs.
""")

code(r"""
# Como función: `fresh_collection` (borra y crea) y `ingest` (delete + add). Con los 3 PDFs, y el memo dos veces: el count no cambia.
from proto.rag import doc_id, embedder, fresh_collection, ingest, page_records

embed = embedder(model)
assert fresh_collection(client, "nb05_demo").count() == 0  # la de antes se borró y esta es nueva y vacía
client.delete_collection("nb05_demo")  # ya no la uso
col_a = fresh_collection(client, "nb05_A")
counts = {pdf: ingest(col_a, embed, pdf, PDF_BYTES[pdf], page_records(pages[pdf], chunk_text)) for pdf in PDF_BYTES}
before = col_a.count()
ingest(col_a, embed, "company_memo.pdf", PDF_BYTES["company_memo.pdf"], page_records(pages["company_memo.pdf"], chunk_text))
assert doc_id(PDF_BYTES["company_memo.pdf"]) == DOC_ID["company_memo.pdf"]
assert col_a.count() == before == len(chunks_df)
assert set(col_a.get(where={"filename": {"$in": ["company_memo.pdf", "meeting_minutes.pdf"]}})["ids"]) == set(two.id)
counts, before
""")

md(r"""
**Lo que veo:** 2 chunks (memo), 5 (acta) y 5 (informe) = 12. Ingerir el memo otra vez dejó el mismo `count` y los IDs son los mismos que armé a mano (`assert`). Un mismo PDF con otro nombre tendría el mismo `doc_id`: la re-ingesta se queda con el último nombre.
""")

md(r"""
## 4. P4 · Preguntas de oro (aprobadas por Jeison)
**Por qué surge.** Para medir si recupero la página correcta necesito preguntas con respuesta conocida. Son **22 preguntas con respuesta** en inglés (los PDFs están en inglés): 10 *literales* (repiten palabras del texto), 10 *parafraseadas*, 1 *multi_doc* (q21: la respuesta está en dos PDFs) y 1 *disambiguation* (q22: Dr. James Chen frente a Robert Chen), más **4 sin respuesta** (`gold` vacío) que no entran en hit@k y sirven en la tarea 06 para fijar `MIN_SCORE`; u05 es una trampa del dominio (Carlos Mendoza estuvo ausente). Cada pregunta trae `gold`: una **lista de páginas `[filename, page]` que valen** (q17 acepta dos, q21 dos de PDFs distintos). `answer_hint` es una cadena que **tiene que aparecer** en alguna página de `gold`; lo compruebo. Claude revisó el archivo como experto y Jeison lo aprobó.
""")

code(r"""
# Cargo las preguntas aprobadas; `gold` vacío = sin respuesta. Compruebo que el hint está en alguna página de oro.
ALL_QUESTIONS = json.loads((ROOT / "eval" / "questions.json").read_text(encoding="utf-8"))
QUESTIONS = [q for q in ALL_QUESTIONS if q["gold"]]  # con respuesta en los PDFs
UNANSWERABLE = [q for q in ALL_QUESTIONS if not q["gold"]]  # sin respuesta: para MIN_SCORE (tarea 06)
for q in ALL_QUESTIONS:
    assert {"id", "question", "kind", "answer_hint", "gold"} <= set(q)
for q in QUESTIONS:
    assert all(any(part in pages[f][pg] for f, pg in q["gold"]) for part in q["answer_hint"].split("; ")), q["id"]
assert all(q["kind"] == "unanswerable" for q in UNANSWERABLE)
questions = pd.DataFrame(QUESTIONS)
questions["paginas_oro"] = [[f"{f.split('_')[0]}:p{pg}" for f, pg in q["gold"]] for q in QUESTIONS]
display(questions.kind.value_counts().to_frame().T)
display(questions[["id", "kind", "question", "paginas_oro", "answer_hint"]])
pd.DataFrame(UNANSWERABLE)[["id", "question"]]
""")

md(r"""
**Lo que veo:** 22 preguntas con respuesta (10 literales, 10 parafraseadas, 1 multi_doc, 1 disambiguation) y 4 sin respuesta (`UNANSWERABLE`); los 22 `answer_hint` aparecen en alguna página de `gold`. Casos con oro múltiple: q17 (dos páginas del informe) y q21 (memo p0 e informe p1). Casos difíciles que conviene mirar: q09 ("Prof. Michael O'Sullivan" también se nombra en la página 1 del informe, pero la división solo está en la 0) y q22 (James Chen frente a Robert Chen).
""")

md(r"""
## 5. P5 · ¿Recupera la página correcta?
**Por qué surge.** Una pregunta es un vector; Chroma devuelve los chunks más cercanos y yo lo evalúo **a nivel de página**: ¿la página de oro está entre las primeras páginas distintas? Una pregunta puede tener varias páginas de oro (`gold`): cuenta la **primera** que aparezca. Uso `hit@k` (¿está entre las k primeras?) y `MRR` (media de 1/posición; 1 = siempre primera). Pido 10 chunks y ordeno las páginas por su primer chunk. No reporto `hit@5`: con **5 páginas en total** siempre vale 1. Empiezo con una pregunta, siempre con `query_embeddings` (con `query_texts` Chroma descargaría su propio modelo ONNX).
""")

code(r"""
# Una pregunta: embebo, consulto con vectores y calculo score = 1 - distancia coseno.
q = QUESTIONS[2]
res = col_a.query(query_embeddings=model.encode([q["question"]], normalize_embeddings=True).tolist(), n_results=5, include=["documents", "metadatas", "distances"])
hits = pd.DataFrame(res["metadatas"][0]).assign(score=1 - np.array(res["distances"][0]), text=[d[:60] for d in res["documents"][0]])
display(q["question"], q["gold"])
hits[["filename", "page", "chunk", "score", "text"]].round(3)
""")

md(r"""
**Lo que veo:** el primer chunk (score 0.384) es el chunk 1 de la página de oro del memo, que contiene `London`; los demás están entre 0.275 y 0.286. La misma consulta con la función:
""")

code(r"""
# Como función: `search` debe devolver los mismos chunks y scores.
from proto.rag import search

got = pd.DataFrame(search(col_a, embed, q["question"], 5))
pd.testing.assert_frame_equal(got[["filename", "page", "chunk"]], hits[["filename", "page", "chunk"]])
assert np.allclose(got.score, hits.score)
"search == suelto"
""")

code(r"""
# Todas las preguntas: posición de la primera página de oro entre las páginas distintas de los 10 primeros chunks, y cuántas páginas de oro entran en los 5 primeros chunks.
rows = []
for q in QUESTIONS:
    res = col_a.query(query_embeddings=model.encode([q["question"]], normalize_embeddings=True).tolist(), n_results=10, include=["metadatas", "distances"])
    found = list(dict.fromkeys((m["filename"], m["page"]) for m in res["metadatas"][0]))
    gold = {tuple(g) for g in q["gold"]}
    rank = next((i + 1 for i, page in enumerate(found) if page in gold), None)  # primera página que vale
    top5 = {(m["filename"], m["page"]) for m in res["metadatas"][0][:5]}
    rows.append({"id": q["id"], "kind": q["kind"], "rank": rank, "top1": f"{found[0][0]}:p{found[0][1]}",
                 "score1": round(1 - res["distances"][0][0], 3), "gold_top5": len(gold & top5), "n_gold": len(gold)})
ranks_loose = pd.DataFrame(rows)
ranks_loose.T
""")

code(r"""
# Como función: `evaluate` da la misma tabla.
from proto.rag import evaluate

ranks_a = evaluate(col_a, embed, QUESTIONS)
pd.testing.assert_frame_equal(ranks_a, ranks_loose)
ranks_a.query("rank != 1")
""")

md(r"""
**Lo que veo:** 15 de 22 preguntas tienen la primera página de oro en la posición 1. Cinco (q06, q09, q10, q12, q20) la tienen en la 2. En cuatro de ellas (q06, q09, q10, q12) el top-1 es otra página del mismo PDF; en q20 el top-1 es **otro PDF** (el acta p0, no el memo). q09 es la que anticipé: el top-1 es la página 1 del informe (DARPA, también nombra a O'Sullivan), con el score más bajo de las respondibles (0.256). q12 es difícil a propósito: la p0 del acta trae el horario previsto (`12:30 PM`, la agenda) y no el cierre real (`12:25 PM`, en p1), así que es un distractor legítimo. Las dos últimas son las difíciles de verdad: q22 (Dr. James Chen) tiene el oro en la posición 3, porque el top-1 es el memo (Robert Chen), y q21 (multi_doc) en la 4. Convierto las posiciones en métricas. Primero el intervalo de **Wilson** de `hit@1` a mano, para entenderlo:
""")

code(r"""
# hit@1 con Wilson 95 %: k aciertos de n preguntas.
k, n, z = int((ranks_a["rank"] == 1).sum()), len(ranks_a), 1.96
p = k / n
centro = (p + z**2 / (2 * n)) / (1 + z**2 / n)
mitad = z * np.sqrt(p * (1 - p) / n + z**2 / (4 * n**2)) / (1 + z**2 / n)
(k, n, round(centro - mitad, 3), round(centro + mitad, 3))
""")

code(r"""
# Como función: `wilson` y `retrieval_metrics` (hit@1/3 con Wilson, MRR con bootstrap, semilla 42).
from proto.rag import retrieval_metrics, wilson

assert np.allclose(wilson(k, n), (centro - mitad, centro + mitad))
metrics_a = retrieval_metrics(ranks_a["rank"])
metrics_a
""")

code(r"""
# Para las tablas siguientes: cada métrica como texto "valor [IC]". Suelto, con hit@1 de A.
m = metrics_a.set_index("metrica")
hit1_loose = f"{m.loc['hit@1', 'valor']:.2f} [{m.loc['hit@1', 'ic_lo']:.2f}-{m.loc['hit@1', 'ic_hi']:.2f}]"
hit1_loose
""")

code(r"""
# Como función: `metric_strings` da el mismo texto.
from proto.rag import metric_strings

assert metric_strings(ranks_a["rank"])["hit@1"] == hit1_loose
metric_strings(ranks_a["rank"])
""")

code(r"""
# Una fila por tipo de pregunta (n pequeño: los intervalos serán muy anchos).
by_kind = {kind: {"n": len(g), **retrieval_metrics(g["rank"]).set_index("metrica").valor.to_dict()} for kind, g in ranks_a.groupby("kind")}
pd.DataFrame(by_kind).T.round(2)
""")

code(r"""
# multi_doc (q21): además del rango, ¿entran las DOS páginas de oro en los 5 primeros chunks? (lo necesita `sources` en la 06)
multi = ranks_a.query("kind == 'multi_doc'")[["id", "rank", "top1", "gold_top5", "n_gold"]].copy()
multi["ambas_en_top5"] = multi.gold_top5 == multi.n_gold
multi
""")

md(r"""
**Lo que veo:** A da `hit@1` 0.68 [0.47-0.84], `hit@3` 0.95 [0.78-0.99] y MRR 0.82 [0.71-0.93]. Por tipo: literales `hit@1` 0.80 y MRR 0.90; parafraseadas 0.70 y 0.85; la única `multi_doc` (q21) `hit@1` 0 y MRR 0.25, y la única `disambiguation` (q22) 0 y 0.33. Con n = 10 los intervalos de literales y parafraseadas se solapan casi del todo, y con n = 1 las dos últimas filas son anécdotas, no estimaciones. **multi_doc:** las **dos** páginas de oro de q21 (memo p0 e informe p1) están en los 5 primeros chunks (`ambas_en_top5 = True`): para `sources` en la 06 importa más esto que el rango. **`hit@5` no se reporta:** con 5 páginas en total siempre vale 1, y `hit@3` ya está casi saturado.

### Sensibilidad al tamaño del chunk
Repito la ingesta con `chunk_size` 300 / 500 / 800 y **overlap fijo en 60** (no proporcional, para variar una sola cosa). Una colección nueva por tamaño. `size_builder(size)` es A con otro `chunk_size` (`page_records` + `chunk_text`, ya validados); `run_strategy` ingesta los 3 PDFs y evalúa. Primero compruebo que con 500 da lo mismo que A.
""")

code(r"""
# Como función: `size_builder` + `run_strategy` con chunk_size=500 deben reproducir la tabla de A.
from proto.rag import run_strategy, size_builder

by_size = {}
for size in (300, 500, 800):
    by_size[size] = run_strategy(fresh_collection(client, f"nb05_size{size}"), embed, size_builder(size), pages, PDF_BYTES, QUESTIONS)
pd.testing.assert_frame_equal(by_size[500][0], ranks_a)
"500 == A"
""")

code(r"""
# Tabla: chunks, hit@1, hit@3 y MRR con su IC, y segundos de ingesta.
size_table = pd.DataFrame({size: {"chunks": client.get_collection(f"nb05_size{size}").count(), **metric_strings(r["rank"]), "seg_ingesta": round(s, 2)} for size, (r, s) in by_size.items()}).T
for size in by_size:
    client.delete_collection(f"nb05_size{size}")  # ya no las uso
size_table
""")

md(r"""
**Lo que veo:** 300 / 500 / 800 dan 20 / 12 / 10 chunks, `hit@1` 0.73 / 0.68 / 0.77 y MRR 0.86 / 0.82 / 0.86: no es monótono y los IC se solapan casi por completo. No busco cambiar el tamaño, así que no hago la prueba pareada: simplemente **no elijo `chunk_size` por estas mismas 22 preguntas** y 500 queda por el plan. La ingesta tarda del orden de 0.1-0.3 s (columna `seg_ingesta`).

## 6. P6 · Otras estrategias de chunking
**Por qué surge.** Jeison quiere ver, no suponer, por qué corto en espacios con solape. Pruebo cinco alternativas, todas a mano, sin librerías: **B** (sin solape), **C** (agrupar oraciones), **D** (recursivo por estructura), **E** (página entera) y **F** (documento entero). Para cada una: cuántos chunks, cuántos tokens (MiniLM trunca en 256), cuántos se truncan y la recuperación. La regla de decisión está arriba.

### B · sin solape
Es el mismo bucle de la sección 2 con `overlap = 0` y ya lo validé (`chunk_text(text, 500, 0) == loose[0]`). Mido en qué se diferencia de A en toda la colección:
""")

code(r"""
# B sobre todo el corpus: chunks y cuántos pares consecutivos tendrían solape (ninguno por construcción).
chunks_b = pd.DataFrame([(pdf, i, c) for pdf, ts in pages.items() for i, t in enumerate(ts) for c in chunk_text(t, 500, 0)], columns=["pdf", "page", "text"])
{"chunks_A": len(chunks_df), "chunks_B": len(chunks_b)}
""")

md(r"""
**Dónde se ve la diferencia.** Sin overlap, un nombre puede quedar partido entre dos chunks. Miro el acta, página 0, que es donde está "Jennifer Liu confirmed quorum" (q11).
""")

code(r"""
# Los chunks del acta p0 con overlap 60 (A) y 0 (B): cómo termina/empieza cada uno y si la frase de q11 queda entera.
minutes0 = pages["meeting_minutes.pdf"][0]
pd.DataFrame([
    {"overlap": ov, "chunk": i, "termina": c[-12:], "empieza": c[:12], "frase_q11_entera": "Jennifer Liu confirmed quorum" in c}
    for ov in (60, 0) for i, c in enumerate(chunk_text(minutes0, 500, ov))
])
""")

md(r"""
**Lo que veo:** con overlap 0 (B) el chunk 0 termina en `Jennifer` y el chunk 1 empieza en `Liu confirmed...`: **ningún chunk trae la frase** `Jennifer Liu confirmed quorum` (el nombre solo sobrevive en la lista de asistentes). Con overlap 60 (A) el chunk 1 la trae entera. **Pero esto no se ve en las métricas:** q11 sale en rango 1 también con B (primera fila de `ranks_wide`, más abajo), porque el chunk 1 de B aún habla de `quorum`. Elijo A por **robustez de los nombres en el borde del chunk** (lo que se cita y se pasa al LLM), un criterio de **diseño**, no de métrica.
""")

md(r"""
### C · agrupar oraciones
**Por qué surge.** Una oración es una unidad de significado; agrupo oraciones enteras hasta 500 caracteres. Las separo con una regex de fin de oración (`.`, `!`, `?` seguidos de espacio). Sospecho que este OCR tiene muchas líneas sin punto (títulos, listas), que quedarán pegadas a la oración siguiente.
""")

code(r"""
# Oraciones de la página 0 del memo y agrupación voraz hasta 500 caracteres.
parts = re.split(r"(?<=[.!?])\s+", text)
cur, sent_chunks = "", []
for sentence in parts:
    if cur and len(cur) + 1 + len(sentence) > 500:
        sent_chunks.append(cur)
        cur = ""
    cur = f"{cur} {sentence}" if cur else sentence
sent_chunks.append(cur)
pd.DataFrame({"oracion_chars": [len(s) for s in parts]}).T, [len(c) for c in sent_chunks]
""")

code(r"""
# Como función: `chunk_sentences` debe dar los mismos trozos.
from proto.rag import chunk_sentences

assert chunk_sentences(text) == sent_chunks
"chunk_sentences == suelto"
""")

md(r"""
**Lo que veo:** 14 "oraciones" de 2 a 234 caracteres: lo que no termina en `.` (cabecera, título) se une con lo que sigue. Dos trozos de 457 y 464 caracteres. La regex también parte la numeración de las listas (`1.`, `2.` quedan como "oraciones" de 2-3 caracteres) y une líneas sin punto con la siguiente.

### D · recursivo por estructura
**Por qué surge.** Es lo que hace `RecursiveCharacterTextSplitter`: intento partir por el separador más grande (`\n\n`, luego `\n`, luego `. `, luego espacio) y solo bajo de nivel en lo que sigue sin caber. Lo escribo a mano. En este OCR no hay `\n\n`, así que parte por líneas y agrupa líneas completas hasta 500.
""")

code(r"""
# Un nivel suelto: parto por "\n" y agrupo líneas hasta 500 caracteres.
cur, rec_chunks = "", []
for linea in text.split("\n"):
    if cur and len(cur) + 1 + len(linea) <= 500:
        cur += "\n" + linea
        continue
    if cur:
        rec_chunks.append(cur)
    cur = linea
rec_chunks.append(cur)
[len(c) for c in rec_chunks], rec_chunks[0].splitlines()[-1]
""")

code(r"""
# Como función: igual en esta página; y un texto de una sola línea de 1200 caracteres baja de nivel (oración, luego palabra).
from proto.rag import chunk_recursive

assert chunk_recursive(text) == rec_chunks
one_line = "This is a sentence about nothing. " * 35
sizes = [len(c) for c in chunk_recursive(one_line)]
sizes, max(sizes) <= 500
""")

md(r"""
**Lo que veo:** en la página real coincide con el bucle (dos trozos de 450 y 471 caracteres, que terminan en línea completa). En el texto de una sola línea cae a `". "` y los tres trozos (474, 474 y 237) caben en 500. Costo: no hay solape y se pierde el `.` al partir por `". "`.

### E · la página entera como chunk
**Por qué surge.** Es lo más simple: un chunk por página, sin lógica. Pero MiniLM tiene `max_seq_length = 256` tokens y **trunca en silencio** lo que sobra; una página de ~1000 caracteres puede acercarse a ese tope. Mido los tokens antes de dudar.
""")

code(r"""
# Tokens por página con el tokenizer del modelo (incluye [CLS] y [SEP]).
enc = model.tokenizer([t for ts in pages.values() for t in ts])
tok_pages = pd.DataFrame({"pdf": [p for p, ts in pages.items() for _ in ts], "page": [i for ts in pages.values() for i, _ in enumerate(ts)],
                          "chars": [len(t) for ts in pages.values() for t in ts], "tokens": [len(x) for x in enc["input_ids"]]})
tok_pages["trunca"] = tok_pages.tokens > model.max_seq_length
tok_pages
""")

code(r"""
# Como función: `token_counts` da lo mismo.
from proto.rag import token_counts

assert token_counts(model, [t for ts in pages.values() for t in ts]).tolist() == tok_pages.tokens.tolist()
f"{tok_pages.trunca.sum()} de {len(tok_pages)} páginas pasan de {model.max_seq_length} tokens"
""")

md(r"""
**Lo que veo:** mi sospecha era demasiado pesimista: las 5 páginas miden entre 177 y 204 tokens, **ninguna** pasa de 256, aunque llegan al 80 % del tope. E no trunca aquí; con una página más densa (tabla, letra pequeña) sí lo haría, y en silencio. Los tokens de los chunks de 500 caracteres los mido en la tabla de la comparación.

### F · el documento entero cruzando páginas (D-RAG-1)
**Por qué surge.** Si junto todas las páginas y parto como en A, un chunk puede empezar al final de una página y terminar en la siguiente. El contrato guarda **una** `page` por chunk. Asigno la página donde **empieza** el chunk (y anoto si cruza), porque la cita `archivo:pN:cK` debe apuntar a algún sitio.
""")

code(r"""
# Uno las páginas del acta con "\n\n", parto como A y busco en qué página empieza y termina cada chunk.
doc = "\n\n".join(pages["meeting_minutes.pdf"])
page_start = np.cumsum([0] + [len(p) + 2 for p in pages["meeting_minutes.pdf"]])
rows = []
for c in chunk_text(doc):
    pos = doc.find(c)
    rows.append({"empieza_en": int(np.searchsorted(page_start, pos, side="right")) - 1,
                 "termina_en": int(np.searchsorted(page_start, pos + len(c) - 1, side="right")) - 1, "chars": len(c)})
doc_loose = pd.DataFrame(rows)
doc_loose["cruza"] = doc_loose.empieza_en != doc_loose.termina_en
doc_loose
""")

code(r"""
# Como función: `doc_records` da las mismas páginas de inicio y fin.
from proto.rag import doc_records

got = pd.DataFrame(doc_records(pages["meeting_minutes.pdf"]))
assert got.page.tolist() == doc_loose.empieza_en.tolist() and got.page_end.tolist() == doc_loose.termina_en.tolist()
f"{doc_loose.cruza.sum()} chunk(s) cruzan de {len(doc_loose)}"
""")

md(r"""
**Lo que veo:** 1 de los 5 chunks del acta (el tercero, 499 caracteres) empieza en la página 0 y termina en la 1. Se guarda con la página 0; una pregunta cuya respuesta está en la parte de la página 1 se cuenta como fallo aunque el chunk la contenga.

### Comparación de las 6 estrategias
Misma ingesta, mismo modelo, mismas 22 preguntas. Una colección nueva por estrategia (`fresh_collection`: borra la que exista y crea otra vacía). Los tokens vienen de los chunks guardados.
""")

code(r"""
# Ingesto y evalúo cada estrategia; guardo ranks, segundos y tokens de cada una.
from proto.rag import STRATEGIES

results = {}
for name, builder in STRATEGIES.items():
    col = fresh_collection(client, f"nb05_{name[0]}_cmp")
    ranks, seconds = run_strategy(col, embed, builder, pages, PDF_BYTES, QUESTIONS)
    results[name] = (ranks, seconds, token_counts(model, col.get()["documents"]))
    client.delete_collection(col.name)  # ya tengo sus rangos y tokens
assert results["A 500+60"][0].equals(ranks_a)
list(results)
""")

code(r"""
# Tabla resumen: chunks, tokens, % truncados, hit@1/3 y MRR (con IC) y segundos de ingesta (el encode domina).
metrics = {n: retrieval_metrics(r["rank"]).set_index("metrica") for n, (r, _, _) in results.items()}
summary = pd.DataFrame({
    n: {"chunks": len(t), "tok_med": int(t.median()), "tok_max": int(t.max()), "truncados_%": round(100 * (t > model.max_seq_length).mean()),
        **metric_strings(r["rank"]), "seg_ingesta": round(s, 2)}
    for n, (r, s, t) in results.items()
}).T
summary.to_csv(ARTIFACTS / "05_strategies.csv")
summary
""")

code(r"""
# Por tipo de pregunta (n por tipo: 10 literales, 10 parafraseadas, 1 multi_doc, 1 disambiguation): hit@1 y MRR puntuales.
by_type = pd.concat({n: r.assign(hit1=r["rank"].eq(1), rr=(1 / r["rank"]).fillna(0)).groupby("kind")[["hit1", "rr"]].mean() for n, (r, _, _) in results.items()}).unstack().round(2)
by_type
""")

md(r"""
Aplico la regla escrita arriba, **pregunta por pregunta contra A**. Pongo en una tabla el rango de cada pregunta con cada estrategia y, a mano, comparo B con A (¿ayuda el overlap?): discordantes de `hit@1`, McNemar exacto (binomial 0.5 de dos colas sobre los discordantes) y bootstrap pareado de ΔMRR.
""")

code(r"""
# Una columna por estrategia con el rango de cada pregunta (mismas 22, mismo orden).
ranks_wide = pd.DataFrame({n: r.set_index("id")["rank"] for n, (r, _, _) in results.items()})
display(ranks_wide.loc[["q11"]])  # la pregunta de "Jennifer Liu"
ranks_wide[ranks_wide.nunique(axis=1) > 1]
""")

code(r"""
# Suelto, B frente a A: discordantes de hit@1, McNemar exacto y bootstrap pareado de ΔMRR (semilla 42).
rank_a, rank_b = ranks_wide["A 500+60"], ranks_wide["B 500 sin overlap"]
only_a, only_b = int(((rank_a == 1) & (rank_b != 1)).sum()), int(((rank_a != 1) & (rank_b == 1)).sum())
n_disc = only_a + only_b
p_loose = min(1.0, 2 * sum(comb(n_disc, i) for i in range(min(only_a, only_b) + 1)) / 2**n_disc)
delta = (1 / rank_b - 1 / rank_a).to_numpy()
boot = delta[np.random.default_rng(42).integers(0, len(delta), (5000, len(delta)))].mean(axis=1)
only_a, only_b, round(p_loose, 3), round(delta.mean(), 3), np.percentile(boot, [2.5, 97.5]).round(3)
""")

code(r"""
# Como función: `paired_vs_base` repite la cuenta para B y la hace para las cinco estrategias.
from proto.rag import paired_vs_base

paired = paired_vs_base(ranks_wide, "A 500+60")
row = paired.loc["B 500 sin overlap"]
assert (row.solo_base, row.solo_otra, row.p_mcnemar, row.dMRR) == (only_a, only_b, round(p_loose, 3), round(delta.mean(), 3))
assert (row.ic_lo, row.ic_hi) == tuple(np.percentile(boot, [2.5, 97.5]).round(3))
paired
""")

code(r"""
# Regla: ¿alguna supera a A (p < 0.05 a favor, o IC de ΔMRR que excluye 0 a favor)? Si ninguna, se queda A.
supera = paired.index[paired.supera_a_base].tolist()
supera or "ninguna: se queda A"
""")

md(r"""
**Lo que veo (6 estrategias, 22 preguntas, cada una contra A pregunta por pregunta):**
| Estrategia | chunks | tokens (mediana) | `hit@1`: solo A / solo la otra | McNemar p | ΔMRR [IC pareado 95 %] | preguntas con rango distinto |
|---|---|---|---|---|---|---|
| B sin overlap | 11 | 91 | 1 / 1 | 1.0 | 0.000 [-0.068, 0.068] | 4 |
| C oraciones | 12 | 87 | 0 / 1 | 1.0 | 0.030 [0.000, 0.083] | 2 |
| D recursivo | 12 | 86 | 0 / 0 | 1.0 | 0.000 [0.000, 0.000] | 0 |
| E página entera | 5 | 181 | 1 / 1 | 1.0 | 0.004 [-0.068, 0.076] | 6 |
| F documento | 12 | 98 | 5 / 2 | 0.453 | -0.078 [-0.209, 0.057] | 8 |

(A: 12 chunks, mediana de 94 tokens; ninguna estrategia trunca a 256 tokens.)

- **Ninguna supera a A** con la regla pareada (`supera_a_base` es `False` en las cinco). Con 22 preguntas no distingo nada de A; F es la única con el signo claro en contra (MRR -0.08), pero su IC pareado incluye el 0 y su McNemar da p = 0.45.
- **D** da exactamente los mismos rangos que A (0 preguntas distintas): en estos PDFs, sin `\n\n`, parte por líneas y cae en los mismos cortes. **C** va 0 / 1 en `hit@1` y su IC de ΔMRR empieza justo en 0.000: no excluye el 0.
- **B frente a A (¿ayuda el overlap?)**: coinciden **en el agregado** (MRR 0.822 los dos, `hit@1` igual) pero **no pregunta por pregunta**: B gana en q09 y q22 y pierde en q15 y q20 (4 preguntas con rango distinto, ver `ranks_wide`). El overlap no mejora el recall medio, como encontró el informe de Chroma (2024); solo cambia qué preguntas aciertan.
- **Por qué A y no B (criterio de diseño, no de métrica):** la regla dice que con un empate gana la más simple (B, o incluso E), y la elección de A es una **excepción consciente** de Jeison. La razón no está en las métricas: sin overlap, "Jennifer Liu" queda partido entre el chunk 0 y el 1 y ninguna cita contiene la frase entera, pero q11 acierta igual (rango 1 con A y con B). A cuesta 1 chunk más de 12 y protege los nombres en el borde, que es lo que se cita en `sources` y se pasa al LLM.
- **F (documento entero)** es la peor en `hit@1` (0.55) y MRR (0.74): 1 de 5 chunks del acta cruza de página y se etiqueta con la de inicio. En q21 (multi_doc, n = 1) saca rango 1, anécdota.
- **Por tipo de pregunta** (n = 10, 10, 1, 1): literales `hit@1` 0.8-0.9 en todas salvo F (0.5); parafraseadas 0.7 (F 0.6); multi_doc y disambiguation tienen una pregunta cada una.

### Normalizar el texto OCR antes de partir
**Por qué surge.** OHRBench (arXiv 2412.02592) mostró que el ruido de OCR degrada el RAG. Dos arreglos baratos: unir las palabras partidas con guion al final de línea (`exam-\nple` → `example`) y colapsar espacios repetidos. Sospecho que en estos 3 PDFs casi no cambia nada (`page_text` ya une con un solo espacio); lo mido en vez de suponerlo.
""")

code(r"""
# Suelto: las dos regex sobre un texto sintético sucio, y cuántas páginas reales cambian.
dirty = "An exam-\nple   of  OCR\tnoise and year-over-year."
clean = re.sub(r"[ \t]+", " ", re.sub(r"(\w)-\n(?=[a-z])", r"\1", dirty))
changed = [(pdf, i) for pdf, ts in pages.items() for i, t in enumerate(ts) if re.sub(r"[ \t]+", " ", re.sub(r"(\w)-\n(?=[a-z])", r"\1", t)) != t]
clean, changed
""")

code(r"""
# Como función: `normalize_ocr` da lo mismo; evalúo A con y sin normalizar.
from proto.rag import normalize_ocr

assert normalize_ocr(dirty) == clean
pages_norm = {pdf: [normalize_ocr(t) for t in ts] for pdf, ts in pages.items()}
ranks_norm, _ = run_strategy(fresh_collection(client, "nb05_A_norm"), embed, STRATEGIES["A 500+60"], pages_norm, PDF_BYTES, QUESTIONS)
client.delete_collection("nb05_A_norm")
pd.DataFrame({"A sin normalizar": metric_strings(ranks_a["rank"]), "A normalizado": metric_strings(ranks_norm["rank"])}).T
""")

md(r"""
**Lo que veo:** `changed = []`: ninguna página de los 3 PDFs cambia (no hay palabras partidas por guion de fin de línea ni espacios repetidos), así que A normalizado da exactamente los mismos números. En estos datos la normalización no aporta evidencia; la función solo se justificaría con PDFs que sí tengan esos defectos. No la llevo a `app/` por esta evidencia.
""")

md(r"""
## 7. P7 · Métrica y modelo de embeddings
### Coseno frente a L2 con vectores normalizados
**Por qué surge.** Chroma usa L2 por defecto; yo fijo coseno. Con vectores de norma 1, `‖a-b‖² = 2 - 2·cos(a,b)`: L2 al cuadrado y coseno son una función decreciente del mismo número y dan **el mismo ranking**. Lo compruebo con los mismos vectores en dos colecciones.
""")

code(r"""
# Reconstruyo la colección de A (la ingesta es idempotente y tarda ~0.15 s): chromadb 1.5.9 a veces dejaba vacía una colección vieja.
col_a = fresh_collection(client, "nb05_A")
for pdf in PDF_BYTES:
    ingest(col_a, embed, pdf, PDF_BYTES[pdf], page_records(pages[pdf], chunk_text))
assert col_a.count() == len(chunks_df)
col_a.count()
""")

code(r"""
# Primero consulto A con las 22 preguntas; luego copio sus chunks a una colección L2 (mismos vectores) y consulto igual.
# Uso `search` (con su reintento): en chromadb 1.5.9 una colección a veces devolvía 0 resultados de forma pasajera.
cos = {q["id"]: search(col_a, embed, q["question"], 10) for q in QUESTIONS}
stored = col_a.get(include=["documents", "metadatas"])
col_l2 = fresh_collection(client, "nb05_l2", space="l2")
col_l2.add(ids=stored["ids"], documents=stored["documents"], embeddings=embed(stored["documents"]), metadatas=stored["metadatas"])
same_order, gaps = [], []
for q in QUESTIONS:
    l2 = search(col_l2, embed, q["question"], 10)
    same_order.append([(h["filename"], h["page"], h["chunk"]) for h in cos[q["id"]]] == [(h["filename"], h["page"], h["chunk"]) for h in l2])
    gaps.append(np.abs(np.array([1 - h["score"] for h in l2]) - 2 * np.array([1 - h["score"] for h in cos[q["id"]]])).max())
client.delete_collection("nb05_l2")
all(same_order), max(gaps)
""")

md(r"""
**Lo que veo:** los 22 rankings de 10 chunks son idénticos y `l2 = 2·(1-cos)` con diferencia máxima ≈ 6e-7. Elijo coseno explícito igual: si algún día los vectores no se normalizaran, L2 sí cambiaría el ranking, y `score = 1 - distancia` solo tiene sentido con coseno.

### `all-MiniLM-L6-v2` frente a `BAAI/bge-small-en-v1.5`
**Por qué surge.** Misma talla (384 dimensiones), pero `bge-small` rinde más en la recuperación de MTEB (51.7 frente a 42.0 de MiniLM, según el literature research). Son pesos de Hugging Face (MIT), no una dependencia nueva (sin `revision` fija: en `app/` va en config). Lo uso **sin instrucción de consulta** para no cambiar la interfaz `embed(texts)`. No pruebo e5 porque exige prefijos `query:`/`passage:`. Regla pareada: solo cambio de modelo si McNemar sobre `hit@1` da p < 0.05 a favor, o el IC de ΔMRR excluye el 0 a favor. Lo comparo en A y en la estrategia de mayor MRR puntual.
""")

code(r"""
%%time
# Cargo el segundo modelo (descarga una vez si no está en caché).
model2 = SentenceTransformer("BAAI/bge-small-en-v1.5", device="cpu")
model2.max_seq_length, model2.get_embedding_dimension()
""")

code(r"""
# Evalúo cada modelo en A y en la estrategia de mayor MRR puntual; guardo el rango de cada pregunta.
top_mrr = pd.Series({n: m.loc["MRR", "valor"] for n, m in metrics.items()}).idxmax()
picks = list(dict.fromkeys(["A 500+60", top_mrr]))
models = {"MiniLM": model, "bge-small": model2}
mr, ms = {}, {}
for mname, m in models.items():
    for sname in picks:
        col = fresh_collection(client, f"nb05_{mname}_{sname[0]}")
        mr[(mname, sname)], ms[(mname, sname)] = run_strategy(col, embedder(m), STRATEGIES[sname], pages, PDF_BYTES, QUESTIONS)
        client.delete_collection(col.name)
model_table = pd.DataFrame({k: {**metric_strings(r["rank"]), "seg_ingesta": round(ms[k], 2)} for k, r in mr.items()}).T
model_table.to_csv(ARTIFACTS / "05_models.csv")
model_table
""")

code(r"""
# Regla pareada: bge frente a MiniLM, en cada estrategia elegida (misma función que para las estrategias).
paired_models = pd.concat({s: paired_vs_base(pd.DataFrame({m: mr[(m, s)].set_index("id")["rank"] for m in models}), "MiniLM") for s in picks})
paired_models
""")

md(r"""
**Lo que veo:** `bge-small-en-v1.5` (sin instrucción) sale algo mejor en las cifras puntuales (A: `hit@1` 0.73 frente a 0.68, MRR 0.85 frente a 0.82; en C pasa lo mismo), pero la prueba pareada no lo respalda: en A solo gana 2 preguntas y pierde 1 (McNemar p = 1.0, ΔMRR +0.027 [-0.061, 0.125], 4 preguntas con rango distinto); en C, 2 contra 1 (p = 1.0, ΔMRR +0.034 [-0.045, 0.125]). **No cambio de modelo.** La ingesta tarda casi el doble (`seg_ingesta`, del orden de 0.1-0.3 s) y `max_seq_length` es 512. Con 22 preguntas esta prueba tiene poco poder; si la 06 muestra fallos de recuperación, bge es el primer candidato.

## 8. P7 · ¿Cuántos chunks pido (`top_k`)?
**Por qué surge.** `/api/ask` pasará al LLM los `top_k` primeros chunks. Con muy pocos puedo perder la respuesta; con muchos meto ruido y tokens. Miro en qué posición (de chunks, no de páginas) aparece el **primer chunk de la página de oro**.
""")

code(r"""
# Otra vez reconstruyo la colección de A antes de usarla (mismo motivo).
col_a = fresh_collection(client, "nb05_A")
for pdf in PDF_BYTES:
    ingest(col_a, embed, pdf, PDF_BYTES[pdf], page_records(pages[pdf], chunk_text))
assert col_a.count() == len(chunks_df)
col_a.count()
""")

code(r"""
# Para cada pregunta, posición del primer chunk de la página de oro entre los 10 mejores de A.
pos = []
for q in QUESTIONS:
    flags = [[h["filename"], h["page"]] in q["gold"] for h in search(col_a, embed, q["question"], 10)]
    pos.append(flags.index(True) + 1 if True in flags else None)
pos = pd.Series(pos, dtype=float)
pd.DataFrame({"top_k": range(1, 11), "preguntas_con_oro_en_top_k": [round((pos <= k).mean(), 2) for k in range(1, 11)]}).set_index("top_k").T
""")

md(r"""
**Lo que veo:** el primer chunk de una página de oro está en el puesto 1 en el 68 % de las preguntas, en el 2 en el 77 %, en el 3 en el 95 % y en el 4 en el 100 %. Candidato para la 06: `top_k = 5` (cubre el 4 y deja ambas páginas de q21). Con solo 12 chunks en total, esta conclusión es débil: un corpus mayor puede pedir más.

### Scores del top-1: con respuesta frente a sin respuesta (para `MIN_SCORE`, tarea 06)
**Por qué surge.** Si ningún chunk se parece a la pregunta, el RAG debe abstenerse en vez de inventar. Para fijar `MIN_SCORE` en la tarea 06 necesito ver cómo se reparten los scores del mejor chunk con y sin respuesta. **Aquí no decido el umbral**: guardo los números en `05_scores.csv` y los dibujo.
""")

code(r"""
# Score del mejor chunk (1 - distancia coseno) de las 26 preguntas, con A y MiniLM.
rows = []
for q in ALL_QUESTIONS:
    top = search(col_a, embed, q["question"], 1)[0]
    rows.append({"id": q["id"], "kind": q["kind"], "answerable": bool(q["gold"]), "score1": round(top["score"], 4),
                 "top1": f"{top['filename']}:p{top['page']}", "question": q["question"]})
scores = pd.DataFrame(rows)
scores.to_csv(ARTIFACTS / "05_scores.csv", index=False)
scores.groupby("kind").score1.agg(["count", "min", "median", "max"]).round(3)
""")

code(r"""
# Histograma: con respuesta frente a sin respuesta (mismas barras para comparar).
bins = np.linspace(0, 0.8, 17)
ax = scores.query("answerable").score1.plot.hist(bins=bins, alpha=0.6, label="con respuesta", figsize=(6, 3))
scores.query("not answerable").score1.plot.hist(bins=bins, alpha=0.6, label="sin respuesta", ax=ax)
ax.set_xlabel("score del mejor chunk (1 - distancia coseno)")
ax.legend()
""")

md(r"""
**Lo que veo:** los scores top-1 de las 22 con respuesta van de 0.256 a 0.722 (mediana 0.43). De las 4 sin respuesta, la ajena (Mundial) saca 0.106, por debajo de todas; pero las 3 del dominio sacan 0.424 (u05, Carlos Mendoza ausente), 0.478 (u01, salario) y 0.482 (u02, presupuesto de la migración), **por encima de 11, 13 y 13 de las 22 respondibles**. Una sola cifra de `MIN_SCORE` por encima de ~0.26 pierde preguntas contestables; por debajo solo corta lo ajeno. Que las preguntas del dominio sin respuesta no se separen por score es la pista para la tarea 06: `MIN_SCORE` no basta, hace falta que el prompt obligue a abstenerse. No fijo el umbral aquí.

## Decisiones del RAG de ingesta
| Decisión | Opciones | Evidencia (celda) | Elegida | Por qué |
|---|---|---|---|---|
| Estrategia de chunking | A caracteres 500+60 · B sin overlap · C oraciones · D recursivo · E página entera · F documento | §6: tabla de comparación y prueba pareada contra A (`paired`) | **A** (decisión de Jeison) | Ninguna supera a A (todas p ≥ 0.45; C +0.03 con IC que empieza en 0.000). Con un empate la regla elegiría la más simple; A es una excepción por diseño, no por métrica |
| Tamaño | 300 · 500 · 800 | §5 sensibilidad (MRR 0.86 / 0.82 / 0.86) | **500** | Sin separación; no se elige por estas preguntas |
| Overlap | 60 · 0 | §6B: sin overlap "Jennifer Liu" queda partido, pero q11 acierta igual; A y B coinciden en el agregado (MRR 0.822) y no pregunta por pregunta (q09/q22 frente a q15/q20) | **60** | Robustez de los nombres en el borde del chunk (criterio de diseño). Cuesta 1 chunk más de 12 |
| Por página o por documento | página · documento | §6 F (`hit@1` 0.55, MRR 0.74, 1 de 5 chunks cruza) | **por página** | F es la peor y la cita queda ambigua |
| Normalización OCR | sin · con (`normalize_ocr`) | §6, `changed = []` | **sin** | 0 páginas cambian; sin evidencia |
| Modelo | all-MiniLM-L6-v2 · bge-small-en-v1.5 | §7, `paired_models` (p = 1.0 en A y en C) | **MiniLM** | bge no se separa de MiniLM y tarda casi 2× en ingesta; primer candidato si la 06 falla |
| Métrica | coseno · L2 | §7, mismos rankings | **coseno** | Mismo ranking con vectores normalizados; `score = 1 - distancia` |
| IDs | `{página}:{chunk}` · `{doc_id}:{página}:{chunk}` | §3, 2 IDs repetidos sin `doc_id` | **con `doc_id` (sha256[:16])** | Únicos entre documentos |
| Re-ingesta | `add` · `upsert` · `delete` + `add` | §3, `add` descarta en silencio | **`delete(where doc_id)` + `add`** | `upsert` deja chunks sobrantes si la versión nueva es más corta |
| `top_k` (candidato 06) | 1 a 10 | §8, oro en top-4 = 100 %; q21 con las 2 páginas en top-5 | **5** | Cubre el puesto 4 y las dos páginas de multi_doc. Conclusión débil: solo 12 chunks |
| `MIN_SCORE` (06) | — | §8, histograma | **no se decide aquí** | Las preguntas sin respuesta del dominio (0.42-0.48) se mezclan con las respondibles |

## Mis respuestas (borrador de Claude, JM las reescribe)
1. **P1.** El texto por página sale de `01_ocr_words.csv` con `page_text`: palabras unidas por espacio y `\n` entre líneas (5 páginas, 858-1006 caracteres).
2. **P2.** Ventanas de 500 caracteres cortadas en el último espacio, con solape de 60 que empieza en comienzo de palabra. Una palabra mayor que `chunk_size` queda entera en su chunk. Asserts: palabras ⊂ página, ≤ 500, solape 52-60.
3. **P3.** ID `{doc_id}:{page}:{chunk}` con `doc_id = sha256(bytes)[:16]`; re-ingesta = `delete(where doc_id)` + `add`, porque `add` con ID repetido se descarta sin avisar.
4. **P4.** 22 preguntas con respuesta (10 literales, 10 parafraseadas, 1 multi_doc, 1 disambiguation) + 4 sin respuesta; `gold` es una lista de páginas `[filename, page]` y su `answer_hint` está en alguna de ellas. Aprobadas por Jeison.
5. **P5.** A: `hit@1` 0.68 [0.47-0.84], `hit@3` 0.95, MRR 0.82 [0.71-0.93]. Los casos difíciles son multi_doc (q21) y disambiguation (q22), con oro en las posiciones 4 y 3. Con n = 22 y 5 páginas, 300/500/800 no se distinguen.
6. **P6.** Ninguna estrategia supera a A en la prueba pareada. B coincide en el agregado pero no pregunta por pregunta; el nombre partido no se ve en las métricas. Elijo A por robustez en el borde del chunk (diseño, no métrica).
7. **P7.** MiniLM + coseno (L2 da el mismo ranking); bge no se separa. `top_k` candidato 5. Los scores top-1 de preguntas sin respuesta del dominio (0.42-0.48) se mezclan con las respondibles.

## Qué me llevo a `app/`
- `chunk_text(text, chunk_size, overlap)` en `rag_service`, con `chunk_size` y `chunk_overlap` de `app/config.py` y `assert 0 <= overlap < chunk_size`. ACs candidatos: **AC-CHK-01** ninguna palabra cortada; **AC-CHK-02** overlap real y ≤ `overlap`; **AC-CHK-03** palabra gigante queda entera.
- `doc_id(bytes)` y el ID `{doc_id}:{page}:{chunk}`. **AC-VEC-01** IDs únicos entre dos documentos; **AC-VEC-02** la segunda ingesta no pisa la primera.
- `ingest` = `delete(where doc_id)` + `add`. **AC-VEC-03** re-ingesta idempotente (mismo `count`); **AC-VEC-04** `add` con ID repetido se descarta, por eso el `delete`.
- `search` con `query_embeddings`, `score = 1 - distancia`, coseno explícito, `embedding_function=None`; una colección nueva por prueba (`delete_collection` + `create_collection`, sin `client.reset()`); `assert hits` en la evaluación.
- Embeddings: modelo cargado una vez (`lru_cache`), `normalize_embeddings=True`, CPU. **Fijar `revision` (commit) del modelo de Hugging Face en `app/config.py`**: hoy los notebooks bajan lo último.
- `eval/questions.json` (aprobado por Jeison; formato con `gold`, lista de páginas) lo comparte la tarea 06. `page_rank` y `evaluate` aceptan `gold` con varias páginas.

## Lo que tengo que poder explicar
1. El algoritmo de `chunk_text` línea a línea (ventana, retroceso al espacio, inicio al comienzo de palabra, palabra gigante).
2. Por qué el ID lleva `doc_id` y qué hace Chroma con un ID repetido.
3. Qué miden hit@k, MRR, Wilson y la prueba pareada (McNemar y bootstrap de ΔMRR), y por qué n = 22 no basta para elegir.
4. Qué pasa con una página de ~1000 caracteres y MiniLM (256 tokens): aquí no trunca, pero llega al 80 %.
5. Por qué coseno y L2 dan lo mismo con vectores normalizados.
6. Que `query_texts` descargaría un modelo ONNX y por eso paso `query_embeddings`.

## Preguntas que me pueden hacer
1. **¿Por qué cortas en espacio y no a los 500 exactos?** Cortar a los 500 parte palabras y el embedding de un fragmento roto no sirve. Respaldo: §2, asserts de palabras ⊂ página y el caso de la palabra gigante.
2. **¿Por qué `delete` + `add` y no solo `add` o `upsert`?** `add` con un ID repetido se descarta en silencio y `upsert` no borra los chunks sobrantes de una versión más corta. Respaldo: §3, celdas del "TEXTO NUEVO" y del `delete`. Y con `doc_id` en el ID, dos PDFs no chocan (`ids_sin_doc_id_repetidos = 2`).
3. **¿Cómo sabes que tu chunking no es peor que otro?** Comparo cada estrategia con A pregunta por pregunta (McNemar sobre `hit@1` y bootstrap pareado de ΔMRR): ninguna se separa. Respaldo: §6, tabla `paired`.
4. **¿Por qué no basta con que los IC no se solapen?** Es una prueba demasiado exigente (con n = 22 casi nada la pasa) y que se solapen tampoco prueba que sean iguales; además ignora que las dos estrategias se miden sobre las mismas preguntas. La prueba pareada usa esa información. Respaldo: §6, `ranks_wide` (B coincide en el agregado pero cambia 4 preguntas).
5. **¿Con 22 preguntas puedes elegir el tamaño del chunk?** No: 300/500/800 dan MRR 0.86/0.82/0.86 sin separación; 500 queda por el plan. Respaldo: §5, tabla de sensibilidad.
6. **¿Por qué `hit@5` vale siempre 1?** El corpus tiene 5 páginas y se piden 10 chunks, así que todas las páginas aparecen: no informa. Por eso solo reporto `hit@1`, `hit@3` y MRR. Respaldo: §5, `retrieval_metrics` sin `hit@5`.
7. **¿Qué página guardas si un chunk cruza dos?** La de inicio; la estrategia F lo hace y sale peor. Respaldo: §6 F, tabla de `cruza` y su fila en la comparación.
8. **¿Coseno o L2?** Con vectores normalizados dan el mismo ranking; fijo coseno para que `score = 1 - distancia` tenga sentido. Respaldo: §7, `same_order` y la diferencia máxima ≈ 6e-7.
""")

md(r"""
## Desde `app/`
**Por qué surge.** La 05 ya está implementada en `app/`. Quiero comprobar que el código final da lo mismo que el prototipo A y no suponerlo. Sospecho una diferencia: `app.services.rag_service.chunk_text` trabaja sobre `text.split()` y une con un espacio, así que **colapsa los `\n`** que el proto conserva. Lo comparo primero chunk a chunk (con espacios colapsados) y luego en recuperación, con la misma prueba pareada de la §6. Tamaño y solape salen de la configuración de `app/`, no de números sueltos.
""")

code(r"""
# Empiezo pequeño: la configuración de `app` debe ser la que probé (500, 60, MiniLM); con ella comparo los chunks de `app` y los de A en todas las páginas.
cfg = get_settings()
assert (cfg.chunk_size, cfg.chunk_overlap) == (500, 60)
assert cfg.embedding_model == "sentence-transformers/all-MiniLM-L6-v2"
SIZE, OVERLAP = cfg.chunk_size, cfg.chunk_overlap
app_chunks = lambda t: app_chunk_text(t, SIZE, OVERLAP)

rows = []
for pdf, ts in pages.items():
    for i, t in enumerate(ts):
        a = [" ".join(c.split()) for c in chunk_text(t, SIZE, OVERLAP)]
        b = app_chunks(t)
        rows.append({"pdf": pdf, "page": i, "chunks_proto": len(a), "chunks_app": len(b),
                     "identicos": sum(x == y for x, y in zip(a, b)), "chars_app_max": max(map(len, b))})
cmp_chunks = pd.DataFrame(rows)
cmp_chunks
""")

code(r"""
# Porcentaje de chunks idénticos (por posición, tras colapsar espacios) y, si hay diferencias, cuáles son.
total_app, total_proto = cmp_chunks.chunks_app.sum(), cmp_chunks.chunks_proto.sum()
pct_identicos = round(100 * cmp_chunks.identicos.sum() / max(total_app, total_proto), 1)
diffs = [(pdf, i, k, x[-30:], y[-30:]) for pdf, ts in pages.items() for i, t in enumerate(ts)
         for k, (x, y) in enumerate(zip([" ".join(c.split()) for c in chunk_text(t, SIZE, OVERLAP)], app_chunks(t))) if x != y]
{"chunks_proto": int(total_proto), "chunks_app": int(total_app), "identicos_%": pct_identicos}, diffs
""")

md(r"""
**Lo que veo:** los 12 chunks de `app` (los mismos 12 del proto: 2, 3, 2, 3 y 2 por página) son idénticos a los de A tras colapsar espacios (`identicos_%` = 100.0, `diffs` = []). Colapsar los `\n` no movió ningún corte en estos 5 textos.

Ahora lo que importa: ¿cambia la recuperación? Colección nueva con los chunks de `app` (mismo MiniLM, mismas 22 preguntas) y prueba pareada contra A.
""")

code(r"""
# Ingesto con los chunks de `app` en una colección nueva y evalúo las 22 preguntas, igual que con las estrategias.
app_builder = lambda pgs: page_records(pgs, app_chunks)
ranks_app, _ = run_strategy(fresh_collection(client, "app_A"), embed, app_builder, pages, PDF_BYTES, QUESTIONS)
n_app_chunks = client.get_collection("app_A").count()
client.delete_collection("app_A")
ranks_cmp = pd.DataFrame({"A 500+60": ranks_a.set_index("id")["rank"], "app": ranks_app.set_index("id")["rank"]})
n_app_chunks, ranks_cmp[ranks_cmp.nunique(axis=1) > 1]
""")

md(r"""
**Lo que veo:** la colección de `app` tiene 12 chunks y la tabla de preguntas con rango distinto entre A y `app` está vacía: las 22 preguntas tienen el mismo rango.
""")

code(r"""
# McNemar exacto sobre hit@1 y bootstrap pareado de ΔMRR: `app` frente a A (misma función que la §6).
paired_app = paired_vs_base(ranks_cmp, "A 500+60")
paired_app
""")

code(r"""
# Criterio: no puedo separar `app` de A (p >= 0.05 y el IC de ΔMRR contiene el 0). Si falla, lo reporto, no lo maquillo.
row = paired_app.loc["app"]
assert row.p_mcnemar >= 0.05, f"McNemar separa app de A: p = {row.p_mcnemar}"
assert row.ic_lo <= 0 <= row.ic_hi, f"IC de ΔMRR sin el 0: [{row.ic_lo}, {row.ic_hi}]"
f"app no se separa de A: p = {row.p_mcnemar}, ΔMRR = {row.dMRR} [{row.ic_lo}, {row.ic_hi}]"
""")

md(r"""
**Lo que veo:** `solo_base = 0`, `solo_otra = 0`, `p_mcnemar = 1.0`, `dMRR = 0.0` con IC [0.0, 0.0] y `rangos_distintos = 0`. El IC es [0, 0] porque las 22 diferencias pareadas valen 0, así que el criterio del `assert` se cumple de forma trivial: la evidencia real es que los chunks y los rangos son idénticos, no la prueba estadística.
""")

code(r"""
# Métricas de `app` frente a la referencia de A (hit@1 0.68 [0.47-0.84], hit@3 0.95, MRR 0.82 [0.71-0.93]).
assert metric_strings(ranks_a["rank"])["hit@1"] == "0.68 [0.47-0.84]"
pd.DataFrame({"A (proto)": metric_strings(ranks_a["rank"]), "app": metric_strings(ranks_app["rank"])}).T
""")

md(r"""
**Lo que veo:** las tres métricas de `app` son iguales a las de A (`hit@1` 0.68 [0.47-0.84], `hit@3` 0.95 [0.78-0.99], MRR 0.82 [0.71-0.93]).

### Con el almacén real de `app/`
**Por qué surge.** Hasta aquí usé mi `ingest`/`search` del proto. Falta pasar por `vector_service`: `store_document_chunks` y `search_similar`, con el embedder de `app` (`get_embeddings`) y `CHROMA_PATH` en una carpeta temporal para no tocar `data/chroma`. Los metadatos los armo a mano, así que **no ejercito `rag_service.ingest`** (lo cubren AC-ING-01 y AC-INT-01). Como `get_settings` y `_collection` están cacheados, los limpio antes y después. El ID de `app` usa el sha256 completo (el proto usaba 16 caracteres): no cambia el ranking.
""")

code(r"""
# Ingesta con `store_document_chunks` y recuperación con `search_similar` (embedder de `app`) en un Chroma temporal.
from proto.rag import page_rank

with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp, patch.dict(os.environ, {"CHROMA_PATH": tmp, "CHROMA_COLLECTION": "nb05_app"}):
    get_settings.cache_clear()
    vector_service._collection.cache_clear()
    for pdf, pgs in pages.items():
        recs = [(p, k, c) for p, t in enumerate(pgs) for k, c in enumerate(app_chunks(t))]
        meta = [{"doc_id": hashlib.sha256(PDF_BYTES[pdf]).hexdigest(), "filename": pdf, "page": p, "chunk": k} for p, k, _ in recs]
        vector_service.store_document_chunks([c for *_, c in recs], meta, get_embeddings)
    ranks_store = [page_rank(vector_service.search_similar(get_embeddings([q["question"]])[0], 10), q["gold"]) for q in QUESTIONS]
    n_store = vector_service._collection().count()
get_settings.cache_clear()
vector_service._collection.cache_clear()
same = pd.Series(ranks_store).fillna(-1).tolist() == ranks_app["rank"].fillna(-1).tolist()
assert same and n_store == n_app_chunks
{"chunks_en_el_almacen": n_store, "rangos_iguales_a_app_chunk_text": same}
""")

md(r"""
**Lo que veo:** el almacén real guarda 12 chunks y los rangos de las 22 preguntas con `store_document_chunks` + `search_similar` coinciden con los de la colección de `app_A` (`rangos_iguales_a_app_chunk_text = True`).

**Conclusión.** En estas celdas: 12 de 12 chunks de `app` idénticos a A (`identicos_%` = 100.0), 0 preguntas con rango distinto, `p_mcnemar` = 1.0 y ΔMRR = 0.0 [0.0, 0.0]. Ese IC es [0, 0] porque las 22 diferencias pareadas valen 0: el `assert` se cumple de forma trivial y la evidencia real es la identidad de chunks y rangos. La ingesta por `vector_service` da los mismos rangos. Con 22 preguntas y 5 páginas esto muestra que `app` reproduce el prototipo en estos datos, nada más.

## Explicación de los AC de la spec 05
_Borrador de Claude (líneas del commit 7fe35d8). Jeison lo reescribe con sus palabras y lo firma cuando puede explicarlo sin mirar._
""")

md(r"""
**AC-CHK-01 (palabras enteras, en orden, ≤ chunk_size).** `app/services/rag_service.py:46-56`: se recorre `text.split()` y una palabra solo entra entera en `current`; el chunk se cierra (`:47`) cuando la siguiente lo haría pasar de `chunk_size`. La cola de overlap (`:50-54`) tiene **dos** condiciones: medir como mucho `overlap` y caber con la palabra siguiente (`:52`). Sin la segunda, una cola de 20 más una palabra de 60 pasa de 50 (1638 casos en el esbozo del crítico). El test genera 200 textos aleatorios y comprueba que cada chunk es un trozo contiguo del texto, sin huecos.

**AC-CHK-02 (overlap que salva "Jennifer Liu").** Con 50/20, el primer chunk termina en "order." y el segundo empieza con "meeting to order." (17 caracteres; "the meeting to order." serían 21 > 20). Se prueba con overlap 17 y 20: con 17 el borde es exacto y mata la mutación `>=` en `:52`.

**AC-CHK-03 (bordes).** Texto vacío o solo espacios: `split()` da `[]` y no se crea chunk (`:57`). Una palabra de 600 queda entera y sola: ninguna cola cabe con ella. `overlap >= chunk_size` o negativo: `ValueError` en `:43-44`, antes de hacer nada.
""")

md(r"""
**AC-VEC-01 (dos documentos no chocan).** `app/services/vector_service.py:62`: el ID es `doc_id:page:chunk`, con `doc_id` = sha256 de los bytes (`rag_service.py:24`). `a:0:0` y `b:0:0` conviven.

**AC-VEC-02 (re-ingesta reemplaza solo ese documento).** `vector_service.py:61-69`: primero se embebe (si el modelo falla, lo viejo sigue), luego `delete(where={"doc_id": {"$in": ...}})` y `add`. Chroma descarta en silencio un `add` con ID repetido, por eso el test compara los **textos** y no solo el `count`; y `upsert` dejaría chunks sobrantes si la nueva versión tiene menos.

**AC-VEC-03 (score coseno y metadata).** `vector_service.py:34`: la colección se crea con `space: cosine` (Chroma usa L2² por defecto) y `embedding_function=None`; `search_similar` (`:74-96`) consulta solo con vectores y devuelve `score = 1 - distancia` (`:87`) con `filename`, `page` y `chunk`. El test exige que el segundo score sea el producto punto de los dos vectores.

**AC-VEC-04 (almacén inutilizable → VectorStoreError).** `vector_service.py:38-39`: cualquier `ChromaError` al abrir pasa a `VectorStoreError` con `from err` (ruta que es un archivo). `:40-44`: el modelo guardado en la metadata se compara **después** de `get_or_create`, que conserva la metadata original; si no coincide, error (MiniLM y bge-small tienen 384 dimensiones: sin esto se mezclarían). `:70-71` y `:82-83`: lo mismo al guardar y al buscar (vectores de 3 dimensiones en una colección de 384).
""")

md(r"""
**AC-ING-01 (200 con chunks e IDs sha256).** `app/api/rag.py:20-27`: router delgado; `read_pdf` (`app/dependencies.py:23-29`) aplica el tope y `get_embedder` permite el fake. `ingest` (`rag_service.py:19-38`): sha256, OCR, `page_text` y `chunk_text` por página con `chunk_size`/`chunk_overlap` de la config (`:30`), metadata por chunk, `store_document_chunks` y `log_event` con conteos (`:37`). El test comprueba IDs, textos, `filename` y que el nombre del archivo no aparece en el log.

**AC-ING-02 (PDF en blanco → 200 con 0).** `vector_service.py:59-60`: si no hay chunks se vuelve sin tocar Chroma, porque `add([])` lanza `ValueError` (no es `ChromaError`: daría 500). El test comprueba que no se llamó al embedder y que el `count` no cambió.

**AC-ING-03 (422, 413, 503).** 422: `ocr_pages` lanza `InvalidPdfError`. 413: `read_pdf` lee `limit + 1` bytes (`dependencies.py:26-28`). 503: `VectorStoreError` está en `ERROR_STATUS` (`app/main.py:27`). En los dos primeros el embedder no se llama.

**AC-INT-01 (A, B, A más corto con MiniLM real).** `tests/integration/test_rag_ingest.py`: la tercera ingesta usa los mismos bytes de A con menos chunks. Con el texto idéntico, un `add` sin `delete` pasaría (IDs repetidos descartados en silencio); con menos chunks, los sobrantes lo delatan. Una pregunta sobre satélites devuelve `b.pdf`.

**AC-EMB-01 (vectores normalizados).** `app/services/embedding_service.py:24-28`: `encode(..., normalize_embeddings=True)`, 384 dimensiones y norma 1, que hace equivalentes coseno y producto punto. `_load_model` (`:16-21`) carga el modelo una vez con `lru_cache` e importa sentence-transformers dentro (medido: 6 s → 13 s de arranque de los tests si va arriba).
""")

md(r"""
### Tres preguntas de entrevistador
1. **¿Por qué delete + add y no `upsert`?** `add` descarta en silencio los IDs repetidos y `upsert` deja chunks sobrantes cuando la nueva versión tiene menos; delete por `doc_id` y luego add deja exactamente la versión nueva (AC-VEC-02, AC-INT-01).
2. **¿Qué pasa si cambias `EMBEDDING_MODEL` sin re-ingestar?** `_collection` compara el modelo guardado en la metadata y lanza `VectorStoreError` → 503, en lugar de mezclar vectores de dos modelos sin avisar (AC-VEC-04).
3. **¿Por qué un solo worker de uvicorn?** Medido: con dos procesos sobre la misma ruta, el lector ve el `count` nuevo pero su `query` usa el índice viejo y devuelve el chunk equivocado, sin error. Varios workers exigen Chroma como servicio (bonus 08).
""")
nb = nbf.v4.new_notebook(cells=cells)
nb.metadata = {
    "kernelspec": {"display_name": "cuesta (uv 3.12)", "language": "python", "name": "cuesta"},
    "language_info": {"name": "python", "version": "3.12"},
}
nbf.write(nb, sys.argv[1])
print(len(cells))
