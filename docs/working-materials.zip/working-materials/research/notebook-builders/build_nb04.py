import sys

import nbformat as nbf

cells = []


def md(s):
    cells.append(nbf.v4.new_markdown_cell(s.strip("\n")))


def code(s):
    cells.append(nbf.v4.new_code_cell(s.strip("\n")))


md(r"""
# 04 · `POST /api/extract` de punta a punta

## Qué pruebo y cómo
El README pide un endpoint `POST /api/extract` que reciba el PDF y la lista `names`, y devuelva los nombres con su caja y los matches. Aquí no reimplemento nada: importo `app` y le hablo con `fastapi.testclient.TestClient`, como lo haría un cliente HTTP.

```
PDF -> 1 OCR (01) -> 2 NER (02a) -> 3 cajas (02a) -> 4 fuzzy (03) -> [5 ENDPOINT Y ERRORES (este)] -> respuesta
```

## Preguntas que tengo que tener claras
- **P1.** ¿El endpoint da lo mismo que mis notebooks 02a y 03?
- **P2.** ¿Cada entrada mala termina en el status HTTP correcto, sin un 500?
- **P3.** ¿Qué queda en el log y cómo sé que no hay nombres?

Orden: **01 -> 02a -> 02b -> 02c -> 03 -> 04 (este)**.
""")

md(r"""
## 0. Preparación
""")

code(r"""
# Empiezo importando librerías y `app`; el notebook solo la usa, no la reimplementa.
%load_ext autoreload
%autoreload 2

import json
import logging
import os
import sys
import time
from contextlib import contextmanager
from pathlib import Path

import pandas as pd
import pymupdf
from fastapi.testclient import TestClient

ROOT = Path.cwd().parent  # el notebook corre desde notebooks/
sys.path.insert(0, str(ROOT))  # para importar `app`

from app.config import get_settings
from app.dependencies import get_ocr_engine
from app.main import app
from app.services.ocr_service import OcrEngineError
""")

code(r"""
# Compruebo que existen las entradas que leo de los notebooks anteriores y los PDFs.
ARTIFACTS = ROOT / "notebooks" / "artifacts"
PDFS = sorted((ROOT / "sample_pdfs").glob("*.pdf"))
for path in [ARTIFACTS / "02a_name_boxes.csv", ARTIFACTS / "03_matches.csv"]:
    assert path.exists(), f"Falta {path.name}: corre primero el notebook que lo crea."
[p.name for p in PDFS]
""")

md(r"""
## 1. P1 · ¿Da lo mismo que el 02a y el 03?
**Por qué surge.** Si el endpoint cambia una caja o un score respecto a lo que revisé a ojo, mis notebooks no sirven de evidencia. Uso la lista de nombres del 03 (con el duplicado, el acento, el falso positivo Mario y el ausente Juan) y `FUZZY_THRESHOLD=0.90`. Mido el tiempo de cada PDF.
""")

code(r"""
# Uso la misma lista del NB03 y fijo el umbral por entorno, guardando el valor previo para devolverlo al final.
NAMES = [
    {"first_name": "Robert", "last_name": "Chen"},
    {"first_name": "María", "last_name": "García"},
    {"first_name": "Mario", "last_name": "Garcia"},
    {"first_name": "Robert", "last_name": "Chen"},
    {"first_name": "Juan", "last_name": "Pérez"},
]
prev_fuzzy = os.environ.get("FUZZY_THRESHOLD")
os.environ["FUZZY_THRESHOLD"] = "0.90"
get_settings.cache_clear()
assert get_settings().fuzzy_threshold == 0.90
client = TestClient(app)


@contextmanager
def env(**values):
    # Cambia variables de entorno y devuelve cada una a su valor previo (o la borra si no existía).
    old = {k: os.environ.get(k) for k in values}
    os.environ.update(values)
    get_settings.cache_clear()
    try:
        yield
    finally:
        for k, v in old.items():
            os.environ.pop(k, None) if v is None else os.environ.__setitem__(k, v)
        get_settings.cache_clear()


def post(pdf_bytes, names=json.dumps(NAMES), headers=None):
    files = {"pdf_file": ("doc.pdf", pdf_bytes, "application/pdf")}
    return client.post("/api/extract", files=files, data={"names": names}, headers=headers)
""")

code(r"""
# Mando los tres PDFs uno a uno y guardo respuesta y segundos.
responses, seconds = {}, {}
for pdf in PDFS:
    start = time.perf_counter()
    responses[pdf.name] = post(pdf.read_bytes())
    seconds[pdf.name] = round(time.perf_counter() - start, 1)
pd.DataFrame({"status": {k: r.status_code for k, r in responses.items()}, "segundos": seconds})
""")

code(r"""
# Aplano extracted_names a la misma forma del CSV del 02a para poder compararlos.
api = pd.DataFrame(
    [
        {"pdf": pdf, "page": n["bounding_box"]["page_number"], "name": n["name"],
         **{k: n["bounding_box"][k] for k in ["x", "y", "width", "height"]}}
        for pdf, r in responses.items()
        for n in r.json()["extracted_names"]
    ]
)
display(api.head(8).round(2))
api.groupby("pdf").size()
""")

md(r"""
Comparo con `02a_name_boxes.csv`. La clave es `(pdf, page, name)`; como un nombre puede repetirse en la misma página (Margaret Thompson), añado el orden de aparición.
""")

code(r"""
# Uno por (pdf, page, name, orden de aparición) y mido la diferencia máxima de cada caja en pt.
ref = pd.read_csv(ARTIFACTS / "02a_name_boxes.csv", keep_default_na=False)
cols = ["pdf", "page", "name"]
for df in (api, ref):
    df["k"] = df.groupby(cols).cumcount()
both = api.merge(ref, on=cols + ["k"], how="outer", suffixes=("_api", "_02a"), indicator=True)
box = ["x", "y", "width", "height"]
both["max_diff_pt"] = pd.concat([(both[f"{c}_api"] - both[f"{c}_02a"]).abs() for c in box], axis=1).max(axis=1)
display(both["_merge"].value_counts())
both.groupby("pdf")["max_diff_pt"].max()
""")

code(r"""
# Lo exijo con asserts: ninguna fila suelta y cajas idénticas.
assert (both["_merge"] == "both").all(), "hay filas que están en uno solo"
assert both["max_diff_pt"].max() == 0.0
f"{len(both)} filas iguales a las del 02a; diferencia máxima {both['max_diff_pt'].max()} pt"
""")

md(r"""
**Lo que veo:** las filas coinciden una a una con el 02a en los tres PDFs y las cajas son idénticas (0 pt de diferencia). Ahora los matches del memo contra `03_matches.csv`.
""")

code(r"""
# Comparo los matches del memo con el CSV del 03, igualdad exacta.
memo_matches = pd.DataFrame(responses["company_memo.pdf"].json()["fuzzy_matches"])
expected = pd.read_csv(ARTIFACTS / "03_matches.csv")
pd.testing.assert_frame_equal(memo_matches, expected)
memo_matches
""")

md(r"""
**Lo que veo:** los mismos 3 pares del 03, con el mismo orden y score. `Juan Pérez` no aparece, como en el 03. **P1:** sí, el endpoint da lo mismo que mis notebooks.

## 2. P2 · Errores y su status HTTP
**Por qué surge.** Un cliente que manda basura debe recibir un 4xx claro, no un 500. Empiezo con casos que no necesitan OCR (PDFs en blanco hechos con pymupdf) y luego fuerzo los límites y la caída de Tesseract.
""")

code(r"""
# Fabrico los PDFs de prueba: en blanco: 1 página, 2 páginas y 1 página cifrada (AES-256, contraseña de usuario "u").
def blank_pdf(pages=1, **save):
    doc = pymupdf.open()
    for _ in range(pages):
        doc.new_page()
    return doc.tobytes(**save)


one_page, two_pages = blank_pdf(), blank_pdf(2)
encrypted = blank_pdf(encryption=pymupdf.PDF_ENCRYPT_AES_256, user_pw="u", owner_pw="o")
png = pymupdf.Pixmap(pymupdf.csGRAY, pymupdf.IRect(0, 0, 8, 8), False).tobytes("png")
rows = []


def record(case, response):
    rows.append({"caso": case, "status": response.status_code, "detail": str(response.json()["detail"])[:80]})
""")

code(r"""
# Primero los cinco casos que se rechazan sin hacer OCR.
record("archivo vacío", post(b""))
record("texto", post(b"esto no es un pdf"))
record("PNG", post(png))
record("PDF cifrado", post(encrypted))
record("names = 'not json'", post(one_page, names="not json"))
pd.DataFrame(rows)
""")

md(r"""
Los dos límites configurables van por variable de entorno. Pongo `MAX_PAGES=1`, mando 2 páginas y **restauro** la configuración, aunque falle algo.
""")

code(r"""
# Bajo MAX_PAGES a 1 y mando 2 páginas; `env` restaura el valor previo al salir.
with env(MAX_PAGES="1"):
    record("2 páginas con MAX_PAGES=1", post(two_pages))
get_settings().max_pages
""")

md(r"""
Lo mismo con el tamaño: `MAX_UPLOAD_MB=1` y 1 MB + 1 byte.
""")

code(r"""
# Mando un byte más que el tope; el endpoint lo corta antes de abrir el PDF.
with env(MAX_UPLOAD_MB="1"):
    record("1 MB + 1 byte con MAX_UPLOAD_MB=1", post(b"x" * (2**20 + 1)))
get_settings().max_upload_mb
""")

md(r"""
Para el 503 reemplazo el engine de OCR por uno que lanza `OcrEngineError` (así simulo Tesseract caído sin tocarlo) y limpio el override.
""")

code(r"""
# Simulo Tesseract caído con un engine que lanza el error de dominio.
def broken_engine(image):
    raise OcrEngineError("Tesseract failed or is not installed")


app.dependency_overrides[get_ocr_engine] = lambda: broken_engine
try:
    record("engine falla (OcrEngineError)", post(one_page))
finally:
    app.dependency_overrides.clear()
pd.DataFrame(rows)
""")

code(r"""
# Fijo la tabla: status esperados, y el override y la configuración quedan limpios.
expected_status = [422, 422, 422, 422, 422, 413, 413, 503]
assert [r["status"] for r in rows] == expected_status
assert not app.dependency_overrides and get_settings().max_pages == 50
"8 casos, ninguno 500; configuración restaurada"
""")

md(r"""
**AC-API-02.** Un `names` inválido debe rechazarse **antes** de hacer OCR. Cuento las llamadas del engine con un override.
""")

code(r"""
# Engine falso que solo cuenta; si `names` es inválido no debería llamarse nunca.
calls = []
app.dependency_overrides[get_ocr_engine] = lambda: lambda image: calls.append(1)
try:
    bad = {"nombre vacío": '[{"first_name": "", "last_name": "Lee"}]', "objeto en vez de lista": "{}"}
    statuses = {k: post(one_page, names=v).status_code for k, v in bad.items()}
finally:
    app.dependency_overrides.clear()
statuses, len(calls)
""")

code(r"""
# Lo fijo: los dos dan 422 y el engine nunca se llamó.
assert set(statuses.values()) == {422} and len(calls) == 0
"422 sin llamar al engine (calls == 0)"
""")

md(r"""
**AC-OCR-07 y AC-API-03.** Dos hechos de pymupdf que justifican el código: un PDF con contraseña de usuario *abre* y solo falla al renderizar; y unos bytes de basura antes de la cabecera no impiden abrirlo, por eso no chequeo `%PDF-`.
""")

code(r"""
# Miro `needs_pass` con contraseña de usuario y solo de dueño, el error al renderizar, y el PDF con basura delante.
owner_only = blank_pdf(encryption=pymupdf.PDF_ENCRYPT_AES_256, owner_pw="o")
try:
    pymupdf.open(stream=encrypted, filetype="pdf")[0].get_pixmap()
except ValueError as err:
    render_error = f"{type(err).__name__}: {err}"
{
    "needs_pass con user_pw": pymupdf.open(stream=encrypted, filetype="pdf").needs_pass,
    "needs_pass solo owner_pw": pymupdf.open(stream=owner_only, filetype="pdf").needs_pass,
    "al renderizar el cifrado": render_error,
    "is_pdf con basura delante": pymupdf.open(stream=b"junk\n" + one_page, filetype="pdf").is_pdf,
}
""")

md(r"""
**Lo que veo:** vacío, texto, PNG, cifrado y `names` inválido dan **422**; el exceso de páginas y el exceso de bytes dan **413**; el engine caído da **503**. Ninguno es un 500. El `detail` del `names` inválido es el de FastAPI (lista de errores de validación); los demás son el mensaje de mi excepción. **P2:** cada entrada mala llega a su status.

## 3. P3 · ¿Qué queda en el log?
**Por qué surge.** Los nombres son datos personales: el log nunca debe llevarlos. Cuelgo un `Handler` del logger `"app"`, mando el memo con `X-Request-ID: nb04` y miro las líneas.
""")

code(r"""
# Cuelgo un handler del logger "app" y mando el memo con mi propio request id.
class Capture(logging.Handler):
    def __init__(self):
        super().__init__()
        self.lines = []

    def emit(self, record):
        self.lines.append(record.getMessage())


capture = Capture()
logging.getLogger("app").addHandler(capture)
try:
    memo = next(p for p in PDFS if p.name == "company_memo.pdf")
    response = post(memo.read_bytes(), headers={"X-Request-ID": "nb04"})
finally:
    logging.getLogger("app").removeHandler(capture)
display(capture.lines)
response.headers["X-Request-ID"]
""")

code(r"""
# Busco cada nombre (extraído y pedido) dentro de las líneas capturadas.
# Ningún nombre extraído ni pedido aparece en el log.
secrets = {n["name"] for n in response.json()["extracted_names"]}
secrets |= {q["first_name"] for q in NAMES} | {q["last_name"] for q in NAMES}
assert len(capture.lines) == 2
assert all(json.loads(line)["request_id"] == "nb04" for line in capture.lines)
assert not [s for s in secrets if any(s in line for line in capture.lines)]
f"{len(secrets)} cadenas buscadas, 0 en el log"
""")

md(r"""
**Lo que veo:** 2 líneas JSON con `request_id: nb04` (la primera del servicio con conteos, la segunda del middleware con método, ruta, status y ms) y la cabecera de respuesta devuelve el mismo id. Ninguna cadena de nombre aparece. **P3:** solo conteos y tiempos.

**¿Y el 422?** FastAPI devuelve en el `detail` el `input` que falló. Mando una pareja sin `last_name` y miro dónde aparece el nombre.
""")

code(r"""
# Mando {"first_name": "Zoe"} sin apellido: busco "Zoe" en la respuesta 422 y en el log.
zoe = Capture()
logging.getLogger("app").addHandler(zoe)
try:
    bad = post(one_page, names='[{"first_name": "Zoe"}]')
finally:
    logging.getLogger("app").removeHandler(zoe)
bad.status_code, "Zoe" in bad.text, any("Zoe" in line for line in zoe.lines)
""")

md(r"""
**Lo que veo:** 422, el nombre **sí** está en la respuesta (va de vuelta al mismo cliente que lo envió) y **no** está en el log.

Devuelvo el umbral al valor que tenía el entorno antes de empezar.
""")

code(r"""
# Restauro FUZZY_THRESHOLD como estaba antes del notebook.
if prev_fuzzy is None:
    os.environ.pop("FUZZY_THRESHOLD", None)
else:
    os.environ["FUZZY_THRESHOLD"] = prev_fuzzy
get_settings.cache_clear()
get_settings().fuzzy_threshold
""")

md(r"""
## Preguntas que me pueden hacer
1. ¿Por qué una función y no una clase `ExtractionService`? (celda de `post`: el notebook solo usa `app`; el servicio es `extract`).
2. ¿Cómo garantizas que los unitarios no cargan spaCy? (celda `AC-API-02`: el override de `get_ocr_engine` y `calls == 0`).
3. ¿Qué pasa con un PDF de 500 MB? (celda `MAX_UPLOAD_MB=1`: 413).
4. ¿Por qué la clave de unión con 02a añade `cumcount`? (celda de comparación: Margaret Thompson aparece 2 veces en la misma página y la respuesta no trae `line`).
5. ¿Puede filtrarse PII en un 422? (celda `Zoe`: sí, el `detail` devuelve el `input`; va a quien lo envió, no al log).

## Mis respuestas (borrador de Claude, JM las reescribe)
1. No guarda estado; sus dependencias llegan como argumentos, así se prueba sin HTTP y sin mocks de atributos.
2. `dependency_overrides` reemplaza el recognizer y la fixture fija `NER_MODEL=no-such-model`: si algo lo cargara, el test fallaría.
3. Hoy Starlette lo recibe entero antes del endpoint, que lo rechaza con 413. En producción el límite va también en el proxy (nginx `client_max_body_size`) para no recibirlo.
4. Sin `cumcount` la clave `(pdf, page, name)` repetiría filas en el `merge` (producto cruzado) y las cuadraría mal. El orden de aparición las distingue.
5. Sí: el `input` del error de validación va en el cuerpo del 422, solo para quien envió la petición. El log no lo recibe porque `log_event` registra conteos.

## Qué me llevo a `app/`
Ya está en `app/`; este notebook quedó como tests:
- Tabla de errores -> `test_ac_api_02..05` y `test_ac_ocr_07..09` (unitarios con fakes, sin Tesseract ni spaCy).
- Comparación con 02a y 03 -> `tests/integration/test_extract_e2e.py` (AC-API-06).
- Log sin PII -> AC-LOG-01.
- Quedan solo aquí: tiempos por PDF y el hecho de que el 422 devuelve el `input`.

## Lo que tengo que poder explicar
1. Qué cadena recorre una petición: `extract_names` -> `extract` -> `ocr_pages` -> `locate_names` -> `fuzzy_match_names`.
2. Qué excepción de dominio da cada status (422, 413, 503) y dónde se mapea.
3. Por qué cifrado y basura delante se tratan distinto (celda de pymupdf).
4. Por qué restauro entorno y overrides tras cada caso.
5. Qué se loguea y qué no.

## Explicación de los AC de la spec 04
""")

md(r"""
**AC-OCR-07 (cifrado → InvalidPdfError).** `app/services/ocr_service.py:73`: tras abrir, `doc.needs_pass` lanza `InvalidPdfError`. pymupdf abre un PDF con contraseña de usuario sin error y solo falla al renderizar con un `ValueError` genérico, que sería un 500. Un PDF con solo contraseña de dueño se lee normal y pasa.

**AC-OCR-08 (max_pages).** `ocr_service.py:75`: `doc.page_count > max_pages` lanza `DocumentTooLargeError` antes de renderizar, en la misma apertura (la tarea 03 descartó abrir dos veces). El test cuenta `fake.calls == 0`.

**AC-OCR-09 (engine → OcrEngineError).** `ocr_service.py:42-43`: el timeout de pytesseract es un `RuntimeError` genérico y el binario ausente un `TesseractNotFoundError` (de `OSError`); ambos se envuelven con `from err` para conservar la causa. Un handler global de `RuntimeError` convertiría cualquier fallo en 503.

**AC-API-01 (caso feliz).** `app/api/extract.py:18-29` delega en `extract` (`app/services/extraction_service.py:11`), que encadena `ocr_pages` → `locate_names` → `fuzzy_match_names`. El test usa 72 DPI (escala 1) para que la caja sea literal. Pydantic convierte los dicts en `ExtractedName`/`BoundingBox` e ignora las claves sobrantes.
""")

md(r"""
**AC-API-02 (names inválido → 422 sin OCR).** `extract.py:21`: `Json[list[NamePair]]` en un `Form` hace que FastAPI parsee y valide antes de llamar al endpoint; por eso el fake no se llama. `NamePair` exige `min_length=1`.

**AC-API-03 (vacío / no PDF → 422).** `app/main.py:22,31-36`: un dict excepción → status y una función `domain_error` registrada para cada excepción. No hay chequeo de `%PDF-`: el parser ya rechaza por contenido y la spec PDF permite bytes antes de la cabecera.

**AC-API-04 (tamaño → 413).** `extract.py:25-28`: se leen `limit + 1` bytes; si hay más de `limit`, `DocumentTooLargeError`. Starlette ya recibió el archivo (spool a disco > 1 MB) y lo cierra al terminar: el tope rechaza, no ahorra la descarga.

**AC-API-05 (engine falla → 503).** El override inyecta un engine que lanza `OcrEngineError`; `ERROR_STATUS` lo mapea a 503 ("servicio no disponible"; 504 es para pasarelas).
""")

md(r"""
**AC-LOG-01 (request id, sin PII).** `app/log.py:21-24`: el middleware toma `X-Request-ID` o crea un uuid, lo guarda en una `ContextVar` y lo devuelve en la cabecera. `log_event` (`log.py:15-16`) añade el id a cada línea JSON; la `ContextVar` llega al endpoint `def` aunque corra en el threadpool. `extract` registra solo conteos (`extraction_service.py:28`).

**AC-API-06 (e2e).** `tests/integration/test_extract_e2e.py`: el memo da los 8 nombres de `02a_name_boxes.csv` en la página 0 y los 3 matches del NB03 (`Maria Garcia`~`María García` 1.0, `Robert Chen` 1.0, `Maria Garcia`~`Mario Garcia` 0.9167). Se salta sin Tesseract o sin `en_core_web_sm`.
""")

nb = nbf.v4.new_notebook(cells=cells)
nb.metadata = {
    "kernelspec": {"display_name": "cuesta (uv 3.12)", "language": "python", "name": "cuesta"},
    "language_info": {"name": "python", "version": "3.12"},
}
nbf.write(nb, sys.argv[1])
print(len(cells))
