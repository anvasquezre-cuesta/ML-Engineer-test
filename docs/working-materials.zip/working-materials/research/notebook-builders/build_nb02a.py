import json
import sys
import uuid

cells = []


def md(s):
    cells.append(("markdown", s.strip("\n")))


def code(s):
    cells.append(("code", s.strip("\n")))


md(r"""
# 02a · Nombres de persona y sus cajas

## Por qué este notebook importa
Este es el corazón de la prueba: **devolver cada nombre de persona con su página y su caja**, para que un revisor de compliance pueda ir al documento y verificarlo. El README pide:
- **solo personas** (no organizaciones, lugares ni fechas);
- **una caja por ocurrencia real** del nombre;
- unir las palabras de un nombre con sentido, **sin juntar palabras sueltas de toda la página**;
- cajas en **puntos PDF** y página **0-based** (eso ya lo resolví en el 01).

Correctness pesa 30 % y aquí es donde más se puede perder: un nombre falso, uno que falta o una caja corrida se ven en cuanto el evaluador dibuja el resultado.

## El pipeline que propone la prueba (`POST /api/extract`)
1. **OCR** del PDF escaneado. ← NB 01 (aquí reuso su salida, no lo repito)
2. **NER**: solo nombres de persona. ← *este notebook*
3. **Cajas**: ubicar cada nombre y devolver su caja en puntos, página 0-based. ← *este notebook*
4. **Fuzzy match** contra la lista de nombres recibida. ← NB 03

La medición (precisión y recall) la hago aparte: oro en el `02b_gold_review` y evaluación en el `02c_evaluacion`.

## Preguntas que tengo que tener claras al terminar
- **P1.** ¿Puedo reconstruir el texto del 01 desde su CSV, sin repetir el OCR?
- **P2.** ¿Qué personas encuentra spaCy?
- **P3.** ¿Cuáles son falsas y cuál es la regla mínima que las quita?
- **P4.** Si spaCy halló un nombre en una página, ¿lo encuentro también donde se repite en el mismo PDF?
- **P5.** ¿Cómo paso de un nombre en el texto a su caja en puntos?
- **P6.** ¿Las cajas son justas y hay una por cada vez que aparece el nombre?

## Trazabilidad
- **Entradas:** `artifacts/01_ocr_words.csv` (NB 01) y los PDFs de `sample_pdfs/`.
- **Salidas:** `artifacts/02a_name_boxes.csv` con `name, x, y, width, height, start, end, pdf, page, source` (`source` = `spacy` o `propagated`). Lo leen 02b y 02c.
- **Decisión que aplico:** **D4**, propagar los nombres ya hallados a sus otras apariciones dentro del mismo PDF (`research/DECISIONS-LOG.md`, `research/17-nb03-fuzzy-research.md`).
- **ACs que produce:** AC-NER-01..04 y AC-BOX-01..03 (están al final).

**Cómo lo trabajo:** igual que en el 01, primero código suelto y después la función en `proto/ner.py` con un chequeo de que da lo mismo. Pocas reglas, porque con 3 muestras es fácil sobreajustar (Packer et al. 2010). Tope: 2 h.
""")

md(r"""
## 0. Preparación
Librerías y el modelo de spaCy. Las rutas y `draw_boxes` ya las construí y probé en el 01.
""")

code(r"""
# Solo librerías. Lo mío de proto/ lo importo cuando lo uso.
%load_ext autoreload
%autoreload 2

import re
from collections import Counter

import pandas as pd
import spacy
""")

code(r"""
# Rutas y dibujo de cajas: los hice y comprobé en el 01, aquí solo los reuso.
from proto.common import ARTIFACTS, PDFS, draw_boxes, versions

versions()
""")

code(r"""
# Antes de empezar compruebo que existe la salida del 01.
assert (ARTIFACTS / "01_ocr_words.csv").exists(), "Falta artifacts/01_ocr_words.csv: corre el 01"
""")

code(r"""
# El modelo pequeño de inglés, el que sugiere el README. En app/ el nombre irá
# en config, no fijo en el código.
nlp = spacy.load("en_core_web_sm")
nlp.pipe_names
""")

md(r"""
## 1. P1 · ¿Puedo reconstruir el texto desde el CSV del 01?
El 01 guardó una fila por palabra con su caja en puntos. Si rearmo el texto desde ahí con `add_offsets` (que ya probé en el 01), no tengo que volver a correr Tesseract, y cada carácter del texto sigue apuntando a una palabra con caja.
""")

code(r"""
# keep_default_na=False: si no, pandas convierte palabras como "NA" o "null" en
# vacíos (la misma trampa que evité en el 01).
words = pd.read_csv(ARTIFACTS / "01_ocr_words.csv", keep_default_na=False)
words.head()
""")

code(r"""
words.groupby(["pdf", "page"]).size()
""")

code(r"""
# add_offsets trabaja un PDF a la vez, así que la aplico por PDF y guardo el texto
# de cada página con la clave (pdf, página).
from proto.ocr import add_offsets

frames, texts = [], {}
for pdf, pdf_words in words.groupby("pdf", sort=False):
    pdf_words, page_texts = add_offsets(pdf_words)
    frames.append(pdf_words)
    texts.update({(pdf, page): text for page, text in page_texts.items()})

words = pd.concat(frames)
list(texts)
""")

code(r"""
# Como función: add_offsets_all() hace este mismo recorrido (los siguientes notebooks
# la reusan). Compruebo que da lo mismo.
from proto.ocr import add_offsets_all

words_fn, texts_fn = add_offsets_all(pd.read_csv(ARTIFACTS / "01_ocr_words.csv", keep_default_na=False))
pd.testing.assert_frame_equal(words_fn, words)
assert texts_fn == texts
""")

code(r"""
# Chequeo: para cada palabra, texto[start:end] tiene que ser exactamente la palabra.
words.apply(lambda w: texts[(w.pdf, w.page)][w.start : w.end] == w.text, axis=1).all()
""")

code(r"""
# Así se ve lo que va a leer spaCy (con saltos de línea, por eso uso print).
print(texts[("company_memo.pdf", 0)][:500])
""")

md(r"""
## 2. P2 · ¿Qué personas encuentra spaCy?
Empiezo pequeño: solo la página 0 del memo. Quiero ver **todas** las entidades, no solo las personas, para entender qué confunde el modelo.
""")

code(r"""
# Paso el texto por spaCy y miro cada entidad con su etiqueta y su posición.
memo_text = texts[("company_memo.pdf", 0)]
doc = nlp(memo_text)

ents = pd.DataFrame(
    [
        {"name": e.text, "label": e.label_, "start": e.start_char, "end": e.end_char}
        for e in doc.ents
    ]
)
ents
""")

code(r"""
# ¿Qué etiquetas salen? Solo me sirven las PERSON.
ents["label"].value_counts()
""")

code(r"""
# Me quedo con las PERSON y con lo que necesito para ubicarlas: nombre y posición.
persons_inline = ents.query("label == 'PERSON'")[["name", "start", "end"]].reset_index(
    drop=True
)
persons_inline
""")

code(r"""
# Lo paso a person_spans() y compruebo que da la misma tabla.
from proto.ner import person_spans

memo_spans = person_spans(nlp, memo_text)
pd.testing.assert_frame_equal(memo_spans, persons_inline)
""")

code(r"""
# Ahora todas las páginas de las 3 muestras.
spans = pd.concat(
    [
        person_spans(nlp, text).assign(pdf=pdf, page=page)
        for (pdf, page), text in texts.items()
    ],
    ignore_index=True,
)
spans.groupby(["pdf", "page"]).size()
""")

code(r"""
spans
""")

md(r"""
## 3. P3 · ¿Cuáles son falsas y qué regla mínima las quita?
Reviso la tabla de arriba a ojo. Sospecho tres patrones de error, y en vez de borrar casos uno por uno pruebo una regla general para cada uno:
- **cruza líneas** (`\n` dentro del nombre): un nombre real no se parte en dos renglones; esto suele ser una cabecera;
- **todo en mayúsculas**: títulos de sección como "RESEARCH DEPARTMENT";
- **una sola palabra**: sin nombre y apellido no tengo cómo verificar a la persona.
""")

code(r"""
# Marco cada regla en una columna y miro qué spans caerían.
flags = spans.assign(
    crosses_line=spans["name"].str.contains("\n"),
    all_caps=spans["name"].str.isupper(),
    one_word=~spans["name"].str.contains(" "),
)
flags.query("crosses_line or all_caps or one_word")
""")

md(r"""
**Lo que veo:** las reglas solo atrapan basura (cabeceras y palabras sueltas como `Atlas`, `Breakthrough` o `Forbes`), ningún nombre real. El costo que acepto: si un documento menciona a alguien solo por el apellido, o en mayúsculas ("FROM: JOHN SMITH"), lo pierdo. Lo dejo escrito como limitación y en `app/` la regla de mayúsculas será configurable.
""")

code(r"""
# Lo paso a filter_persons() y compruebo que deja exactamente las filas sin marca.
from proto.ner import filter_persons

persons = filter_persons(spans)
expected = flags.query("not (crosses_line or all_caps or one_word)")[spans.columns]
pd.testing.assert_frame_equal(persons, expected.reset_index(drop=True))
len(spans), len(persons)
""")

md(r"""
## 4. P4 · ¿Encuentro los nombres que spaCy dejó pasar en otra página?
**Por qué surge:** un nombre que spaCy reconoció una vez suele ser la misma persona cada vez que aparece en el documento. Krishnan y Manning (2006, Tabla 3) ganan +2.95 puntos de F1 en PER usando el documento entero y solo +0.09 usando el corpus; Finkel et al. (2005, Tabla 3) muestran que una persona casi nunca cambia de tipo dentro de un documento; el principio viene de Gale et al. (1992): 94 % medido. Esto es la decisión **D4** (`research/DECISIONS-LOG.md`).

La regla: por cada PDF, junto los nombres ya filtrados de **todas** sus páginas y los busco con borde de palabra (`(?<!\w)nombre(?!\w)`) en el texto de **cada página del mismo PDF**, nunca entre PDFs. Lo nuevo lo marco `source = "propagated"`; lo de spaCy, `"spacy"`. Si una aparición ya la halló spaCy (mismo `pdf, page, start, end`) no se duplica.

**Riesgo conocido:** el guion no es `\w`, así que "Anna Kowalski" también calzaría dentro de "Anna Kowalski-Smith". No aparece en estas 3 muestras; lo dejo escrito como límite.
""")

code(r"""
# Código suelto: para cada página de cada PDF busco todos los nombres del PDF.
rows = []
for (pdf, page), text in texts.items():
    for name in persons.query("pdf == @pdf")["name"].unique():
        for m in re.finditer(rf"(?<!\w){re.escape(name)}(?!\w)", text):
            rows.append(
                {"pdf": pdf, "page": page, "name": name, "start": m.start(), "end": m.end()}
            )
found_inline = pd.DataFrame(rows)
found_inline.shape
""")

code(r"""
# Quito lo que spaCy ya había hallado (mismo pdf, página, start y end): lo que queda
# es lo nuevo.
keys_spacy = pd.MultiIndex.from_frame(persons[["pdf", "page", "start", "end"]])
is_new = ~pd.MultiIndex.from_frame(found_inline[["pdf", "page", "start", "end"]]).isin(keys_spacy)
propagated_inline = found_inline[is_new].reset_index(drop=True)
propagated_inline
""")

code(r"""
# Como función: propagate_names() trabaja una página; la aplico página por página,
# y compruebo que lo nuevo es lo mismo que arriba.
from proto.ner import propagate_names

named = pd.concat(
    [
        propagate_names(text, persons.query("pdf == @pdf")["name"].unique(),
                        persons.query("pdf == @pdf and page == @page"))
        .assign(pdf=pdf, page=page)
        for (pdf, page), text in texts.items()
    ],
    ignore_index=True,
)
propagated = named.query("source == 'propagated'")[propagated_inline.columns].reset_index(drop=True)
cols = ["name", "start", "end", "pdf", "page"]
spacy_rows = named.query("source == 'spacy'")[cols].reset_index(drop=True)
pd.testing.assert_frame_equal(spacy_rows, persons[cols])
order = ["pdf", "page", "start"]
pd.testing.assert_frame_equal(
    propagated.sort_values(order, ignore_index=True),
    propagated_inline.sort_values(order, ignore_index=True),
)
named.groupby(["pdf", "source"]).size()
""")

md(r"""
`propagate_names` solo quita duplicados **idénticos** `(start, end)`. Si una aparición propagada se solapara a medias con un span más largo de spaCy, habría dos cajas. Lo cuento: debe ser 0.
""")

code(r"""
# Solapes parciales entre una propagada y un span de spaCy de la misma página.
sp = named.query("source == 'spacy'")
pr = named.query("source == 'propagated'")
pairs = pr.merge(sp, on=["pdf", "page"], suffixes=("", "_sp"))
overlaps = pairs.query("start < end_sp and start_sp < end")
assert len(overlaps) == 0, "una propagada se solapa con un span de spaCy"
len(overlaps)
""")

md(r"""
## 5. P5 · ¿Cómo paso de un nombre a su caja?
spaCy me da el nombre como posiciones de caracteres (`start`, `end`). Las palabras del OCR también tienen `start` y `end` en el mismo texto. Entonces las palabras del nombre son las que **se solapan** con ese rango, y la caja del nombre es la **unión** de sus cajas.

Empiezo con "James Anderson", porque en el OCR la palabra viene como `Anderson.` (con el punto pegado).
""")

code(r"""
# Las palabras del memo cuyo rango se cruza con el del nombre.
memo_words = words.query("pdf == 'company_memo.pdf' and page == 0")
span = memo_spans.query("name == 'James Anderson'").iloc[0]

hit = memo_words[(memo_words["start"] < span.end) & (memo_words["end"] > span.start)]
hit[["text", "start", "end", "x", "y", "width", "height"]]
""")

code(r"""
# Caja unión: lo más a la izquierda, lo más arriba, lo más a la derecha y lo más abajo.
x0, y0 = hit["x"].min(), hit["y"].min()
x1, y1 = (hit["x"] + hit["width"]).max(), (hit["y"] + hit["height"]).max()
box_inline = {"x": x0, "y": y0, "width": x1 - x0, "height": y1 - y0}
box_inline
""")

md(r"""
Problema: `Anderson.` incluye el punto, así que la caja queda un poco más ancha que el nombre. Tesseract no me da la caja de cada letra, pero sí sé cuántos caracteres sobran. Idea: recortar la caja de esa palabra **en proporción**; si sobra 1 de 9 caracteres, le quito 1/9 del ancho.
""")

code(r"""
# La palabra "Anderson." tiene 9 caracteres y el nombre usa 8: le quito 1/9.
last = hit.iloc[-1]
kept_chars = span.end - last["start"]
trimmed = box_inline | {
    "width": last["x"] + last["width"] * kept_chars / len(last["text"]) - x0
}
trimmed
""")

code(r"""
# Comparo las dos cajas con zoom sobre "James Anderson": arriba la unión,
# abajo la recortada.
memo_pdf = PDFS["company_memo.pdf"]
zoom = 200 / 72  # píxeles por punto a 200 DPI
area = tuple(v * zoom for v in (175, 326, 265, 348))
display(
    draw_boxes(memo_pdf, 0, pd.DataFrame([box_inline]), dpi=200).crop(area),
    draw_boxes(memo_pdf, 0, pd.DataFrame([trimmed]), dpi=200).crop(area),
)
""")

md(r"""
**Lo que veo:** la recortada se come parte de la "n". El punto es mucho más angosto que una letra, así que quitar 1/9 del ancho quita de más. Prefiero que la caja traiga el punto (unos 3 pt de más) a que corte el nombre: el revisor necesita ver el nombre completo. Me quedo con la **unión simple**, que además es menos código.
""")

code(r"""
# Lo paso a name_box() (la unión simple) y compruebo que da la misma caja.
from proto.ner import name_box

name_box(memo_words, span.start, span.end) == box_inline
""")

code(r"""
# locate_names() aplica name_box() a cada nombre de la página: una fila por
# ocurrencia. Compruebo contra el mismo cálculo hecho a mano.
from proto.ner import locate_names

memo_persons = filter_persons(memo_spans)
memo_boxes = locate_names(memo_words, memo_persons)
by_hand = pd.DataFrame(
    [
        {"name": s.name, **name_box(memo_words, s.start, s.end)}
        for s in memo_persons.itertuples()
    ]
)
pd.testing.assert_frame_equal(memo_boxes, by_hand)
memo_boxes
""")

code(r"""
# La prueba de verdad: dibujar las cajas en puntos sobre el PDF.
draw_boxes(memo_pdf, 0, memo_boxes)
""")

md(r"""
## 6. P6 · ¿Cajas justas y una por ocurrencia?
Lo corro en todas las páginas. Lo que reviso:
- **una caja por cada mención**, no por nombre distinto, sea de spaCy o propagada (Margaret Thompson aparece 2 veces en el memo);
- cada caja ocupa **un solo renglón** (no junto palabras de toda la página);
- todas caen dentro de la página.
""")

code(r"""
# Página por página: las palabras de esa página y sus nombres (spaCy y propagados).
# Guardo también start, end y source (los necesita el 02c).
frames = []
for (pdf, page), page_named in named.groupby(["pdf", "page"]):
    page_words = words[(words["pdf"] == pdf) & (words["page"] == page)]
    located = locate_names(page_words, page_named)
    extra = page_named[["start", "end", "source"]].reset_index(drop=True)
    frames.append(pd.concat([located, extra], axis=1).assign(pdf=pdf, page=page))

boxes = pd.concat(frames, ignore_index=True)
boxes.round(1)
""")

code(r"""
# ¿Cuántas veces sale cada nombre? Las repeticiones deben tener cajas distintas.
boxes.groupby(["pdf", "name"]).size().sort_values(ascending=False).head(8)
""")

code(r"""
# Un renglón mide lo que mide una palabra; si una caja es mucho más alta, uní
# palabras de renglones distintos.
boxes["height"].describe()
""")

code(r"""
# Otra página para descartar que sea casualidad del memo.
minutes_p0 = boxes.query("pdf == 'meeting_minutes.pdf' and page == 0")
draw_boxes(PDFS["meeting_minutes.pdf"], 0, minutes_p0)
""")

code(r"""
# Las filas que agregó la propagación (D4), con su caja. Solo hay una página afectada.
propagated_boxes = boxes.query("source == 'propagated'")
propagated_boxes.round(1)
""")

code(r"""
# La prueba de D4: dibujo solo las cajas propagadas de esa página. Deben caer sobre
# "Elizabeth Park".
draw_boxes(PDFS["meeting_minutes.pdf"], 0, propagated_boxes)
""")

md(r"""
**Lo que veo:** la propagación agrega 2 menciones de "Elizabeth Park" en la página 0 del acta (`start` 184 y 564), que spaCy no había marcado como persona (en el 02c P3 veo qué etiqueta les daba). Las cajas de arriba caen sobre el nombre (la del primer renglón incluye la coma pegada). La tercera mención (`start` 723) la había hallado spaCy y no se duplicó. En el memo y el reporte no cambia nada.
""")

code(r"""
report_p0 = boxes.query("pdf == 'research_report.pdf' and page == 0")
draw_boxes(PDFS["research_report.pdf"], 0, report_p0)
""")

code(r"""
# Lo que el README revisa, como asserts. Ninguna caja más alta que 1.5 renglones.
line_height = words["height"].max()
assert len(boxes) == len(named), "falta una caja por mención"
assert (boxes["height"] <= 1.5 * line_height).all(), "una caja junta renglones"
assert ((boxes["x"] >= 0) & (boxes["y"] >= 0)).all()
from proto.common import inspect_pdfs

pages = inspect_pdfs().set_index(["pdf", "page"])[["width_pt", "height_pt"]]
inside = boxes.join(pages, on=["pdf", "page"])
assert (inside["x"] + inside["width"] <= inside["width_pt"]).all(), "caja fuera por la derecha"
assert (inside["y"] + inside["height"] <= inside["height_pt"]).all(), "caja fuera por abajo"
""")

md(r"""
## 7. Guardo lo que necesitan los siguientes notebooks
El 02b (oro) necesita mi propuesta con sus cajas, y el 02c (evaluación) también las posiciones `start` y `end` de cada nombre en el texto y su `source` (`spacy` o `propagated`). El 03 (fuzzy) usará los nombres; el 04, las cajas.
""")

code(r"""
boxes.to_csv(ARTIFACTS / "02a_name_boxes.csv", index=False)
boxes.shape
""")

md(r"""
## Mis respuestas
*Borrador de Claude para que JM revise: cada cifra sale de una celda de este notebook.*
- **P1** ¿Reconstruyo el texto desde el CSV? **Sí**, sin repetir el OCR: las 5 páginas tienen 143, 149, 134, 129 y 134 palabras, y `texto[start:end] == palabra` se cumple para todas (`True`). `add_offsets_all` da lo mismo que mi recorrido suelto.
- **P2** ¿Qué personas encuentra spaCy? **57 menciones PERSON** en las 5 páginas (9, 13, 10, 13 y 12). En la página 0 del memo son 9 PERSON entre 16 entidades (también 4 CARDINAL, DATE, ORG y GPE).
- **P3** ¿Cuáles son falsas y qué regla las quita? **5 de 57**: `Atlas`, `Breakthrough`, `Forbes` y dos cabeceras (`DIRECTORS - MEETING MINUTES\nDate`, `RESEARCH DEPARTMENT - ANNUAL`). Tres reglas generales (cruza renglón, todo en mayúsculas, una palabra) dejan 52 y no quitan ningún nombre real. Costo: apellidos sueltos y nombres en mayúsculas.
- **P4** ¿Encuentro los nombres que spaCy dejó pasar en otra página? **Sí, 2**: la propagación (D4) pasa de 52 a 54 menciones, las dos de `Elizabeth Park` en `meeting_minutes.pdf` página 0 (`start` 184 y 564). Solapes parciales con un span de spaCy: 0.
- **P5** ¿Cómo paso de un nombre a su caja? Las palabras OCR que se cruzan con `[start, end)` y la unión de sus cajas. "James Anderson" da `x` 183.84, `y` 334.08, ancho 73.92 y alto 7.2 pt. Recortar el punto de "Anderson." en proporción se comía parte de la "n", así que me quedo con la unión simple.
- **P6** ¿Cajas justas y una por ocurrencia? **54 cajas para 54 menciones** (`assert len(boxes) == len(named)`), altura máxima 9.12 pt (menos de 1.5 renglones) y todas dentro de la página. "Richard Hernandez" sale 5 veces, cada una con su caja.

## Qué me llevo a `app/`
- `person_spans` + `filter_persons` → `app/services/ner_service.py` (`extract_names` del stub las envuelve; el modelo y la regla de mayúsculas, en config).
- `propagate_names` → `app/services/ner_service.py`, después de `filter_persons` y por PDF (D4).
- `name_box` + `locate_names` → `app/services/bbox_service.py` (`find_name_bounding_boxes` del stub las envuelve).

Criterios de aceptación candidatos:
- **AC-NER-01** solo devuelve entidades PERSON.
- **AC-NER-02** descarta spans que cruzan línea, en mayúsculas o de una sola palabra.
- **AC-NER-03** los nombres PERSON hallados en un PDF se buscan, con borde de palabra, en todas las páginas de ese PDF (nunca entre PDFs); cada aparición nueva lleva `source = "propagated"` y su propia caja.
- **AC-NER-04** el borde de palabra evita calzar dentro de otra palabra y no hay spans duplicados: solo se deduplican spans idénticos `(start, end)`, así que una aparición ya hallada por spaCy no se repite. Límites: un solape parcial con un span más largo de spaCy daría dos cajas (0 casos en estas muestras, lo cuento en P4); el guion no es `\w` ("Anna Kowalski" calzaría dentro de "Anna Kowalski-Smith").
- **AC-BOX-01** la caja de un nombre es la unión de sus palabras, en puntos, en un solo renglón.
- **AC-BOX-02** la caja contiene el nombre completo; si la palabra OCR trae puntuación pegada ("Anderson."), la caja la incluye.
- **AC-BOX-03** una caja por ocurrencia (Margaret Thompson: 2 en el memo).

## Lo que tengo que poder explicar
1. Por qué ubico nombres por offsets y no buscando el texto en la página.
2. Por qué 3 reglas generales y no una lista de casos (sobreajuste), y qué pierdo con ellas (apellidos sueltos, nombres en mayúsculas).
3. Por qué la caja incluye la puntuación pegada en vez de recortarla.
4. Qué hace D4, qué papers la respaldan y por qué solo dentro del mismo PDF (y que hereda los falsos negativos de spaCy).
5. Qué mide el `02c` y por qué el oro (`02b`) no sale de spaCy.
""")

md(r"""
## Desde `app/`
*Borrador de Claude para que JM revise.* Ya pasé la lógica a `app/services/ner_service.py` (esta comprobación cubre solo los spans; las cajas desde `app/` están en la sección siguiente). Antes de darla por buena compruebo que **da lo mismo que mi prototipo**: le paso el texto de cada página de cada PDF a `find_person_spans` (spaCy real, con propagación) y comparo `(pdf, página, nombre, start, end)` con las cajas que acabo de calcular. Ignoro `source`, porque `app/` no distingue entre spaCy y propagado.
""")

code(r"""
# Solo los spans de NER; las cajas no se comprueban aquí. El servicio recibe las páginas de un PDF como lista de textos y devuelve los spans de cada una.
from app.services.ner_service import find_person_spans

cols = ["pdf", "page", "name", "start", "end"]
rows = []
for pdf, pdf_words in words.groupby("pdf", sort=False):
    pages = [texts.get((pdf, p), "") for p in range(pdf_words["page"].max() + 1)]
    for page, page_spans in enumerate(find_person_spans(pages)):
        rows += [(pdf, page, name, s, e) for name, s, e in page_spans]
from_app = pd.DataFrame(rows, columns=cols)
from_app.groupby("pdf").size()
""")

code(r"""
# Igual al prototipo con propagación, solo spans (mismas filas, sin importar el orden ni `source`).
order = ["pdf", "page", "start", "end"]
proto_rows = boxes[cols].sort_values(order, ignore_index=True)
pd.testing.assert_frame_equal(from_app.sort_values(order, ignore_index=True), proto_rows)
pd.DataFrame({"proto": proto_rows.groupby("pdf").size(), "app": from_app.groupby("pdf").size()})
""")

code(r"""
# Los dos bordes de la regex y la distinción de mayúsculas, sobre un texto literal.
text = "Ann Lee, Ann Leeds, LeeAnn Lee, ROBERT CHEN y Robert Chen."
find = lambda name: [m.group() for m in re.finditer(rf"(?<!\w){re.escape(name)}(?!\w)", text)]
find("Ann Lee"), find("Robert Chen")
""")

md(r"""
## Preguntas que me pueden hacer
*Borrador de Claude para que JM revise.* Lista completa en `research/20-preguntas-entrevista.md` (Tarea 02).

| Pregunta | Respuesta corta | Celda que la respalda |
|---|---|---|
| ¿Por qué ubicas el nombre por offsets y no buscando su texto en la página? | Cada palabra OCR guarda `start` y `end` en el texto de su página: el offset de spaCy apunta a palabras con caja y una mención repetida tiene su propia caja. | §1 `texto[start:end] == palabra` (`True`) y §5 caja de "James Anderson" |
| ¿Qué es la propagación y por qué la haces? | Un nombre que spaCy halló una vez se busca como texto exacto en todas las páginas del mismo PDF (Gale 1992, Finkel 2005, Krishnan y Manning 2006). | §4 "Quito lo que spaCy ya había hallado": 2 menciones nuevas de Elizabeth Park |
| ¿Por qué `(?<!\w)` y `(?!\w)` en la regex? | Son bordes de palabra: "Ann Lee" no cuenta dentro de "Ann Leeds" ni de "LeeAnn Lee". | celda de `re.finditer` sobre texto literal, antes de esta tabla |
| ¿Por qué solo dentro del mismo PDF? | Entre PDFs dos personas distintas pueden compartir texto; dentro de un documento la etiqueta casi no cambia. | §4 "Por qué surge" y el filtro `pdf == @pdf` |
| ¿Por qué la caja incluye la puntuación pegada? | El recorte proporcional se comía parte de la "n" de "Anderson."; prefiero 3 pt de más a cortar el nombre. | §5 comparación de las dos cajas con zoom |
| ¿Por qué solo 3 reglas generales? | Con 3 muestras una lista de casos sobreajusta; las 3 quitan 5 falsas y ningún nombre real. | §3 tabla `flags` y celda de `filter_persons` (57 a 52) |
| ¿Cómo sabes que `app/` hace lo mismo que el notebook? | Con spaCy real, el multiconjunto `(pdf, page, name, start, end)` desde `app/` es idéntico al de mis cajas (54 filas). | "Desde `app/`": `assert_frame_equal` y tabla proto contra app |
| ¿Qué falla? | La propagación distingue mayúsculas, no cubre "Anna Kowalski-Smith" y hereda los falsos negativos de spaCy; los nombres de una palabra se pierden a propósito. | celda `re.finditer` ("ROBERT CHEN" no calza con "Robert Chen"), §4 solapes (0) y el 02c P3 |
""")

md(r"""
## Desde `app/`: OCR y cajas
*Borrador de Claude para que JM revise.* La sección anterior solo cubría los spans de NER; ahora `app/` ya tiene también el OCR (`ocr_pages`, `page_text`) y las cajas (`locate_names`). Compruebo que **dan lo mismo que mis CSV** del 01 y del 02a y que, contra el oro, la precisión es 1.000 y el recall 54/55 = 0.982. Esta celda vuelve a correr el OCR de los 3 PDFs.
""")

code(r"""
# Las palabras de ocr_pages contra 01_ocr_words.csv, por PDF y página: cuántas son, si el texto va en el mismo orden y cuánto difieren x/y/ancho/alto en pt.
from app.services import bbox_service, ocr_service

proto_words = pd.read_csv(ARTIFACTS / "01_ocr_words.csv")
app_pages = {pdf: ocr_service.ocr_pages(path.read_bytes()) for pdf, path in PDFS.items()}
geo = ["x", "y", "width", "height"]
rows = []
for pdf, pages in app_pages.items():
    for page, ws in enumerate(pages):
        p = proto_words.query("pdf == @pdf and page == @page")
        a = pd.DataFrame(ws)
        same_n = len(a) == len(p)
        same_text = same_n and a["word"].tolist() == p["text"].astype(str).str.strip().tolist()
        dmax = abs(a[geo].to_numpy() - p[geo].to_numpy()).max() if same_n else None
        rows.append((pdf, page, len(a), len(p), same_text, dmax))
words_check = pd.DataFrame(rows, columns=["pdf", "page", "app", "proto", "mismo_texto", "dmax_pt"])
words_check
""")

code(r"""
# Lo que sale de page_text es el texto que se le da a spaCy, una vez por página.
text0, placed0 = ocr_service.page_text(app_pages["company_memo.pdf"][0])
assert words_check["mismo_texto"].all() and words_check["dmax_pt"].max() == 0
len(placed0), text0[:70]
""")

code(r"""
# Las cajas de locate_names contra 02a_name_boxes.csv, emparejadas por (pdf, page, name, nº de ocurrencia).
keys = ["pdf", "page", "name"]
app_boxes = pd.DataFrame(
    [{"pdf": pdf, **b} for pdf, pages in app_pages.items() for b in bbox_service.locate_names(pages)]
)
app_boxes["occ"] = app_boxes.groupby(keys).cumcount()
proto_boxes = pd.read_csv(ARTIFACTS / "02a_name_boxes.csv")
proto_boxes["occ"] = proto_boxes.groupby(keys).cumcount()
m = app_boxes.merge(proto_boxes, on=keys + ["occ"], how="outer", suffixes=("_app", "_proto"), indicator=True)
both = m.query("_merge == 'both'")
dmax_box = max((both[f"{k}_app"] - both[f"{k}_proto"]).abs().max() for k in geo)
pd.Series({"pareadas": len(both), "solo_app": (m["_merge"] == "left_only").sum(), "solo_proto": (m["_merge"] == "right_only").sum(), "dmax_pt": dmax_box}).to_frame("valor")
""")

code(r"""
# Precisión y recall contra el oro, como multiconjunto de (pdf, page, name).
# Cuenta nombres por página; no valida la caja, eso lo hace la celda de cajas contra el proto.
gold = pd.read_csv(ARTIFACTS.parents[1] / "eval" / "gold_names.csv")
g = Counter(map(tuple, gold[keys].to_numpy()))
a = Counter(map(tuple, app_boxes[keys].to_numpy()))
tp = sum((g & a).values())
pd.DataFrame(
    {"P": [tp / sum(a.values())], "R": [tp / sum(g.values())], "tp": [tp], "gold": [sum(g.values())], "falta": [list((g - a).keys())]}
)
""")

md(r"""
Lo que veo: las palabras y las cajas de `app/` coinciden con mis CSV (diferencia máxima 0.0 pt, sin filas sobrantes ni faltantes) y la única mención del oro que no sale es "Lucas Zimmermann" en `research_report.pdf` página 0: un falso negativo de spaCy (lo analiza el 02c), no un error de `app/`. P = 1.000, R = 54/55 = 0.982; una sola corrida con n = 55, sin IC.
""")

md(r"""
## Preguntas
1. ¿Por qué las cajas están en puntos PDF y cómo pasas de píxeles a puntos?
2. ¿Por qué abres cada PDF una sola vez?
3. ¿Qué es la caja unión y qué pasa si el nombre queda partido en dos renglones?
4. ¿Por qué corres el NER una sola vez por documento y no por página o por mención?
""")

md(r"""
## Mis respuestas (borrador, Jeison las reescribe)
1. Tesseract mide en píxeles de la imagen que renderizo; el PDF mide en puntos (1/72 pulgada). Renderizo a un dpi de config y multiplico por `scale = ancho de la página en pt / ancho del pixmap en px`. Δ 0.0 contra el CSV prueba que app coincide con el proto; que la conversión es correcta lo muestra el dibujo de cajas del 01. Con `BBOX_ORIGIN=bottom-left` se voltea `y = H - y - h`.
2. Una sola apertura con `with`; las páginas se recorren dentro (lo caro es renderizar y hacer el OCR, no abrir). `ocr_pages` recibe los bytes y devuelve todas las páginas.
3. Es el rectángulo mínimo que contiene las palabras OCR que cruzan `[start, end)` del nombre. Si el nombre se parte en dos renglones la unión sería un rectángulo enorme; por eso el filtro de renglón, `_is_name` en `app/services/ner_service.py`, exige `"\n" not in name`.
4. El NER es la parte lenta. Un nombre hallado en cualquier página se propaga a las demás (`find_person_spans` → `_propagate`), por eso el NER corre una vez por documento y no por página; sus spans sirven luego para las cajas y la evaluación sin repetir el modelo.
""")


md(r"""
## Explicación de los AC de la spec 03

*Redactada por Claude para que JM la estudie.* Las líneas son de `app/services/ocr_service.py` (commit edade67, 89 líneas) y de `app/services/bbox_service.py` (commit 3bb169a, 42 líneas). Pendiente la firma de JM.

- **AC-OCR-01** (px→pt):
  - la línea 38 renderiza la página a `ocr_dpi`, y la 39 calcula `scale = page.rect.width / pix.width`; a 150 DPI, una página Letter de 612 pt mide 1275 px, así que la escala es 0.48;
  - la línea 47 multiplica las 4 medidas por esa escala: `left=100` px da `x=48.0` pt;
  - el test usa 150 DPI para que un `300` escrito a mano en el código falle.
- **AC-OCR-02** (todas las páginas): la línea 62 recorre `for page in doc` sin saltar ninguna, y `page.number` (línea 52) arranca en 0. El fake cuenta 2 llamadas para 2 páginas, así que `range(1, n)` haría fallar el test.
- **AC-OCR-03** (filtro): la línea 45 descarta la palabra si `float(conf) < 0` (Tesseract pone -1 a los bloques sin texto) o si el texto queda vacío tras `strip()`. La 52 guarda el texto ya limpio.
- **AC-OCR-04** (texto y offsets):
  - la línea 51 arma `line = (block, par, line_num)`;
  - `page_text`, en las líneas 69-77, agrega `" "` si la palabra sigue en el mismo renglón y `"\n"` si cambia;
  - cada palabra se copia con `start = len(text)` antes de sumarla, así que `text[start:end] == word`;
  - "Bob" está en otro bloque con el mismo `line_num`, así que agrupar solo por `line_num` lo pegaría con un espacio y el test fallaría.
- **AC-OCR-05** (bytes inválidos):
  - `pymupdf.open(..., filetype="pdf")` (línea 59) lanza `FileDataError` con bytes vacíos, texto o `%PDF` corrupto; la línea 63 lo convierte en `InvalidPdfError`, con `from err`;
  - un PNG sí abre, como documento de imagen, así que la línea 60 comprueba `doc.is_pdf`.
  - `InvalidPdfError` es un `ValueError`, así que el `except` no lo vuelve a capturar.
- **AC-OCR-06** (origen): con `bbox_origin == "bottom-left"`, las líneas 48-49 voltean cada palabra: `y = page.rect.height - y - h`, que da 792 - 96 - 12 = 684. El volteo es por palabra y es monótono, así que la caja unión sigue siendo correcta.
- **AC-BOX-01** (unión): en `bbox_service.py`, la línea 17 toma las palabras cuyo `(start, end)` toca el span. Las líneas 18-20 calculan el mínimo de `x` e `y` y el máximo de `x + width` y de `y + height`, y la 21 resta. Con "Ann" (y=5, h=10) y "Lee" (y=7, h=10), la altura es 17 - 5 = 12. Si se tomara la altura de la última palabra, daría 10.
- **AC-BOX-02** (coma de borde): "Thompson," toca el span aunque este termine antes de la coma (`start < end and end > start`), y entra entera, porque Tesseract da una caja por palabra. La coma suma unos 5 pt de ancho (D-OCR-4).
- **AC-BOX-03** (una por ocurrencia): el `for` de la línea 16 hace una caja por span. Las palabras de la otra ocurrencia tienen otros offsets, así que no tocan este span y no se mezclan.
- **AC-BOX-04** (E1 sintético): el PDF solo-imagen se genera en el test con un texto conocido, y su caja de referencia es `search_for` sobre el original. La caja OCR queda dentro de esa referencia con ±1 pt y cubre ≥ 0.95 de su ancho, en las fuentes 11, 14 y 24. No se usa IoU, porque la referencia es la caja del renglón y Tesseract encierra la tinta.
- **AC-BOX-05** (e2e): `locate_names(ocr_pages(bytes))` sobre las 3 muestras da P 1.0 y R 54/55 contra `gold_names.csv`, y cada caja queda a ±2 pt de una fila de `gold_boxes.csv`. El que falta, Lucas Zimmermann, es un FN del NER: el OCR lee bien sus 2 palabras. Tarda unos 4 s.
- **AC-BOX-06** (NER una vez): la línea 29 llama a `find_person_spans` una sola vez, con los textos de todas las páginas, para que `_propagate` lleve un nombre hallado en una página a las demás. El fake registra las llamadas y exige `[["Ann Lee", "Ann Lee"]]`.
- **AC-CFG-04**: `app/config.py:18`, `bbox_origin: Literal["top-left", "bottom-left"] = "top-left"`. Con `Literal`, pydantic rechaza cualquier otro valor de `BBOX_ORIGIN`.

**Preguntas de entrevistador**
1. *¿Por qué `ocr_pages` recibe bytes y no una ruta?* El upload llega en memoria, así que no hacen falta archivos temporales y el PDF se abre una sola vez (línea 59). Los stubs `extract_text_from_pdf` y `get_word_bounding_boxes` (líneas 81-89) leen la ruta y delegan (R1).
2. *¿Cómo pruebas sin Tesseract?* `OcrEngine` es un Protocol (líneas 15-16): cualquier función que reciba una imagen y devuelva las columnas de `image_to_data` sirve. Los unitarios pasan un fake, y solo los de integración usan Tesseract, con `skipif` si no está instalado.
3. *¿Cómo sabes que `app/` hace lo mismo que el notebook?* NB02a, en la sección "Desde `app/`", compara palabras y cajas con `01_ocr_words.csv` y `02a_name_boxes.csv`: la diferencia máxima es 0.0 pt, con 0 sobrantes y 0 faltantes.
""")


def to_cell(kind, src):
    cell = {"cell_type": kind, "id": uuid.uuid4().hex[:8], "metadata": {}, "source": src}
    if kind == "code":
        cell.update(execution_count=None, outputs=[])
    return cell


nb = {
    "cells": [to_cell(kind, src) for kind, src in cells],
    "metadata": {
        "kernelspec": {
            "display_name": "cuesta (uv 3.12)",
            "language": "python",
            "name": "cuesta",
        },
        "language_info": {"name": "python", "version": "3.12"},
    },
    "nbformat": 4,
    "nbformat_minor": 5,
}
with open(sys.argv[1], "w", encoding="utf-8") as f:
    json.dump(nb, f, ensure_ascii=False, indent=1)
print(len(cells))
