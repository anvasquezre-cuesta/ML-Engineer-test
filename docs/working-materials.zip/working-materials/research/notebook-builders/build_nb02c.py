import json
import sys
import uuid

cells = []


def md(s):
    cells.append(("markdown", s.strip("\n")))


def code(s):
    cells.append(("code", s.strip("\n")))


md(r"""
# 02c · Evaluación de nombres y cajas

## Por qué este notebook importa
Un sistema sin medir es una opinión. La prueba califica correctness (30 %) y el evaluador va a comparar mis nombres contra una verdad: si no sé cuántos nombres pierdo ni cuáles, no puedo defender el sistema ni decidir qué mejorar. Aquí comparo la salida del `02a` (spaCy + propagación de nombres, D4) con el oro que firmé en el `02b`.

## Dónde estoy en el pipeline (`POST /api/extract`)
1. **OCR** ← NB 01
2. **NER** y 3. **cajas** ← NB 02a (sistema), NB 02b (oro), **este notebook (medición)**
4. **Fuzzy match** ← NB 03

Orden: **01 → 02a → 02b (con `REVIEWED = True`) → 02c**. Este notebook solo lee `artifacts/02a_name_boxes.csv`, `artifacts/01_ocr_words.csv` y `eval/gold_names.csv`.

## Preguntas que tengo que tener claras al terminar
- **P1.** ¿Cuánta precisión, recall y F1 tiene el sistema completo (spaCy + propagación), exacta y por token, con qué margen de error y cómo se compara con spaCy solo?
- **P2.** ¿Qué menciones pierdo (falsos negativos) y cuáles invento (falsos positivos)?
- **P3.** ¿Por qué falla spaCy en las que pierde (y en las que recupera la propagación)?
- **P4.** ¿Qué ganó la propagación (D4) frente a spaCy solo, y a qué costo en falsos positivos?

## Trazabilidad
- **Entradas:** `artifacts/02a_name_boxes.csv` (NB 02a, con `source`), `artifacts/01_ocr_words.csv` (NB 01) y `eval/gold_names.csv` (NB 02b).
- **Salidas:** `artifacts/02c_errors.csv` (`pdf, page, line, name, start, type`).
- **Decisión que mido:** **D4**, propagar nombres dentro del mismo PDF (`research/DECISIONS-LOG.md`; Krishnan y Manning 2006 Tabla 3, Finkel et al. 2005 Tabla 3, Gale et al. 1992 con 94 % medido; ver `papers/analysis/`). La decisión ya está tomada; aquí la medición.
- **ACs que produce:** AC-EVAL-01..06 (al final).

Tope: 1.5 h.
""")

md(r"""
## 0. Preparación
""")

code(r"""
# Solo librerías. Lo mío de proto/ lo importo cuando lo uso.
%load_ext autoreload
%autoreload 2

import math
import re

import numpy as np
import pandas as pd
import spacy
from scipy.stats import binomtest
""")

code(r"""
# Rutas y draw_boxes, que ya conozco del 01.
from proto.common import ARTIFACTS, PDFS, ROOT, draw_boxes, versions

COLS = ["pdf", "page", "name"]
""")

code(r"""
# Versiones con las que salen estos números (procedencia).
versions()
""")

code(r"""
# Antes de medir, compruebo que existen mi sistema (02a) y mi oro (02b).
pred_path = ARTIFACTS / "02a_name_boxes.csv"
gold_path = ROOT / "eval" / "gold_names.csv"
assert pred_path.exists(), "Falta artifacts/02a_name_boxes.csv: corre el 02a"
assert gold_path.exists(), "Falta eval/gold_names.csv: corre 02b con REVIEWED = True"
""")

code(r"""
# Lo que predice mi sistema y lo que dice mi oro: una fila por mención.
pred = pd.read_csv(pred_path, keep_default_na=False)
gold = pd.read_csv(gold_path, keep_default_na=False)
by_page = ["pdf", "page"]
sizes = {"sistema": pred, "oro": gold}
pd.DataFrame({k: df.groupby(by_page).size() for k, df in sizes.items()})
""")

code(r"""
# El texto de cada página, igual que en el 02a (función ya probada allí).
from proto.ocr import add_offsets_all

words = pd.read_csv(ARTIFACTS / "01_ocr_words.csv", keep_default_na=False)
words, texts = add_offsets_all(words)
list(texts)
""")

md(r"""
## 1. P1 · ¿Cuánta precisión, recall y F1 tengo?
- **Precisión:** de lo que predije, cuánto es cierto.
- **Recall:** de lo que hay en el oro, cuánto encontré.
- **F1:** la media armónica de las dos, `2PR / (P + R)`. Es la medida a nivel de entidad de CoNLL-2003 (Tjong Kim Sang y De Meulder, 2003): una sola cifra que baja si cualquiera de las dos baja.

Cuento **repeticiones**: si "Elizabeth Park" está 3 veces en el oro y yo la marco 1, acierto 1 y fallo 2. Empiezo con un ejemplo de juguete que sé resolver a mano: predigo `[a, a, b]` y el oro es `[a, b, c]`. Aciertos: una `a` y la `b`, o sea 2 de 3 en cada lado, así que P = R = F1 = 2/3.
""")

code(r"""
# Cuántas veces sale cada elemento en cada lado; aciertos = el mínimo de los dos.
pred_toy, gold_toy = pd.Series(["a", "a", "b"]), pd.Series(["a", "b", "c"])
p, g = pred_toy.value_counts(), gold_toy.value_counts()
hits = p.combine(g, min, fill_value=0)
pd.DataFrame({"predicho": p, "oro": g, "aciertos": hits})
""")

code(r"""
# Precisión = aciertos / predichos; recall = aciertos / oro; F1 = 2PR / (P + R). Debe dar 2/3 las tres.
tp = hits.sum()
precision, recall = tp / p.sum(), tp / g.sum()
f1 = 2 * precision * recall / (precision + recall)
toy_inline = pd.Series({"precision": precision, "recall": recall, "f1": f1})
toy_inline
""")

code(r"""
# Lo paso a precision_recall() (y los aciertos a count_hits()) y compruebo que da lo mismo.
from proto.ner import count_hits, precision_recall

pd.testing.assert_series_equal(toy_inline, precision_recall(pred_toy, gold_toy))
assert count_hits(pred_toy, gold_toy) == tp
""")

md(r"""
Ahora con mis datos. Cada mención se identifica por `pdf | página | nombre`. Mido de dos formas (Packer et al., 2010):
- **exacta**: el nombre completo tiene que coincidir;
- **por token**: cada palabra del nombre cuenta por separado, así un nombre a medias suma algo.
""")

code(r"""
# La clave de cada mención y la versión por token (una fila por palabra), sueltas sobre pred.
pred_key = pred["pdf"] + "|" + pred["page"].astype(str) + "|" + pred["name"]
pred_tok = pred.assign(name=pred["name"].str.split()).explode("name")
pred_key.head(3), pred_tok.head(4)
""")

code(r"""
# Lo paso a keys() y tokens() y compruebo que dan lo mismo.
from proto.ner import keys, tokens

assert (keys(pred) == pred_key).all()
pd.testing.assert_frame_equal(tokens(pred), pred_tok)
""")

code(r"""
# Las dos medidas: exacta (nombre completo) y por token.
result = pd.DataFrame(
    {
        "exacta": precision_recall(keys(pred), keys(gold)),
        "por token": precision_recall(keys(tokens(pred)), keys(tokens(gold))),
    }
)
result
""")

code(r"""
# ¿Cuántas palabras tiene cada nombre del oro? Si todos tienen 2, exacta y por token coinciden.
gold["name"].str.split().str.len().value_counts()
""")

code(r"""
# Mi sistema es todo el CSV del 02a. "Solo spaCy" son las filas con source == "spacy":
# lo que habría salido sin propagar. Mido las dos contra el mismo oro (exacta).
variants = {"solo spaCy": pred.query("source == 'spacy'"), "sistema": pred}
pd.DataFrame(
    {k: precision_recall(keys(v), keys(gold)) for k, v in variants.items()}
).T
""")

md(r"""
**Lo que veo:** el sistema tiene precisión 1.0 (54 de 54) y recall 0.982 (54 de 55), con F1 de 0.991; spaCy solo tenía precisión 1.0 (52 de 52) y recall 0.945 (52 de 55), F1 de 0.972. La propagación sube el recall sin perder precisión. Exacta y por token dan lo mismo porque todos los nombres del oro tienen dos palabras (conteo de arriba) y el fallo que queda pierde las dos, así que aquí la medida por token no aporta información extra.
""")

md(r"""
### ¿Con cuánto margen de error?
Con 55 menciones, un 0.95 no es un número exacto: con otro oro de 55 habría salido distinto. Precisión y recall son **proporciones** (`k` aciertos de `n`), y para proporciones con `n` pequeño el intervalo de Wilson al 95 % cubre mejor que el normal simple (Brown, Cai y DasGupta, 2001, *Statistical Science* 16(2)):

`centro = (p + z²/2n) / (1 + z²/n)` y `mitad = z · √(p(1-p)/n + z²/4n²) / (1 + z²/n)`, con `z = 1.96`.

Lo calculo solo para la medida **exacta**. Con la de tokens no: las palabras de un mismo nombre no son independientes (si fallo "Elizabeth" casi seguro fallo "Park"), y contarlas como `n` independientes daría un intervalo más estrecho de lo que es. Empiezo a mano con el juguete, `k = 2` de `n = 3`.
""")

code(r"""
# La fórmula paso a paso para k = 2, n = 3.
k, n, z = 2, 3, 1.96
p = k / n
center = (p + z**2 / (2 * n)) / (1 + z**2 / n)
half = z * (p * (1 - p) / n + z**2 / (4 * n**2)) ** 0.5 / (1 + z**2 / n)
wilson_inline = (center - half, center + half)
wilson_inline
""")

code(r"""
# Lo paso a wilson() y compruebo que da lo mismo.
from proto.ner import wilson

assert np.allclose(wilson(k, n), wilson_inline)
""")

code(r"""
# Tabla con mis datos (medida exacta), para spaCy solo y para el sistema: k aciertos
# de n, el valor y su intervalo.
rows = []
for label, v in variants.items():
    k = count_hits(keys(v), keys(gold))
    for name, n in {"precision": len(v), "recall": len(gold)}.items():
        low, high = wilson(k, n)
        rows.append(
            {"variante": label, "medida": name, "k": k, "n": n, "valor": k / n, "ic_bajo": low, "ic_alto": high}
        )
interval = pd.DataFrame(rows).set_index(["variante", "medida"])
interval
""")

code(r"""
# Lo contrasto con scipy. Llega por sentence-transformers → scikit-learn; no está declarada en el proyecto ni la agrego. Usa z = 1.95996 en vez de 1.96, por eso comparo con una tolerancia pequeña.
for name, row in interval.iterrows():
    ci = binomtest(int(row["k"]), int(row["n"])).proportion_ci(method="wilson")
    assert np.allclose([row["ic_bajo"], row["ic_alto"]], [ci.low, ci.high], atol=1e-3)
assert np.isclose(interval.loc["sistema", "valor"], result.loc[["precision", "recall"], "exacta"]).all()
""")

md(r"""
**Lo que veo:** para spaCy solo, la precisión 52/52 tiene un intervalo de 0.931 a 1.0 y el recall 52/55 va de 0.851 a 0.981. Para el sistema, la precisión 54/54 va de 0.934 a 1.0 y el recall 54/55 de 0.904 a 0.997. Un 100 % con tan pocas menciones no prueba que la precisión real sea 1, spaCy y sistema se miden sobre las **mismas** 55 menciones (datos pareados), así que comparar sus intervalos no sirve; la comparación va con McNemar en P4. Los intervalos sirven para detectar regresiones y comparar configuraciones, no para estimar el rendimiento en producción.
""")

code(r"""
# El intervalo normal (Wald) para 54/54: p = 1 hace que el error estándar sea 0 y el ancho también.
p_hat, n_obs = 54 / 54, 54
wald_half = 1.96 * (p_hat * (1 - p_hat) / n_obs) ** 0.5
(p_hat - wald_half, p_hat + wald_half), 2 * wald_half
""")

md(r"""
### Lo que estas cifras no dicen
- **El oro está anclado a mi anotación.** Lo armé partiendo de la propuesta de spaCy y de pistas con regex (2 o más palabras capitalizadas, en el 02b). Lo que ninguna de las dos mostró no lo busqué: nombres de una sola palabra, en mayúsculas o partidos en dos renglones. Por eso P = 1.0 y el recall son **optimistas**.
- **Es resubstitución.** Los 3 filtros de `filter_persons` los diseñé mirando estas mismas 5 páginas. Es una medida dentro de la muestra: sirve para detectar regresiones, no estima producción.
- **Wilson supone menciones independientes** y no lo son: están agrupadas en 5 páginas de 3 PDFs y los nombres se repiten. El intervalo real es más ancho que el de la tabla.
- **No hay intervalo para F1** (no es una proporción) y no hago bootstrap: con 5 páginas sería casi degenerado (decisión en `research/06-tl-plan.md`).
""")

md(r"""
## 2. P2 · ¿Qué pierdo y qué invento?
Quiero ver **cuáles** menciones fallan, no solo cuántas. El oro que firmé trae `pdf, página, nombre` y **no** trae renglón ni posición: apunté qué nombres hay en cada página, no en qué lugar del texto. Por eso a este nivel una mención es un **multiconjunto** por `(pdf, página, nombre)`: lo que cuenta es cuántas veces sale cada clave en cada lado. Así la segunda "Elizabeth Park" no se da por encontrada solo porque vi la primera. Comparo sistema contra oro con la diferencia de conteos:
- el oro tiene más que el sistema → **falsos negativos** (FN, los perdí);
- el sistema tiene más que el oro → **falsos positivos** (FP, los inventé).
""")

code(r"""
# Cuántas veces sale cada clave en cada lado, y la diferencia en cada sentido (nunca negativa).
counts = pd.DataFrame(
    {"sistema": pred.groupby(COLS).size(), "oro": gold.groupby(COLS).size()}
).fillna(0).astype(int)
counts["fn"] = (counts["oro"] - counts["sistema"]).clip(lower=0)
counts["fp"] = (counts["sistema"] - counts["oro"]).clip(lower=0)
counts.query("fn > 0 or fp > 0")
""")

code(r"""
# Una fila por error: repito cada clave tantas veces como diga su diferencia.
tp = count_hits(keys(pred), keys(gold))
fn = counts.index.repeat(counts["fn"]).to_frame(index=False)
fp = counts.index.repeat(counts["fp"]).to_frame(index=False)
assert len(fn) == len(gold) - tp and len(fp) == len(pred) - tp
len(fn), len(fp)
""")

code(r"""
# Falsos negativos: están en el oro y mi sistema no los marcó.
fn
""")

code(r"""
# Falsos positivos: los marcó mi sistema y no están en el oro.
fp
""")

md(r"""
Con el conteo sé **cuántas** veces falla cada nombre, pero no **cuál** aparición. Esa se identifica por su posición en el texto OCR (`start`), que es lo que ya tiene el CSV del 02a. Busco todas las veces que ese nombre está escrito igual en la página y me quedo con las que mi sistema **no** marcó (su `start` no está en el CSV del 02a).
""")

code(r"""
# Todas las apariciones exactas de los nombres que perdí (con bordes de palabra: "Park" no cuenta dentro de "Parker").
found = pd.DataFrame(
    [
        {**r._asdict(), "start": m.start(), "end": m.end()}
        for r in fn.drop_duplicates().itertuples(index=False)
        for m in re.finditer(rf"(?<!\w){re.escape(r.name)}(?!\w)", texts[(r.pdf, r.page)])
    ],
    columns=COLS + ["start", "end"],
)
found
""")

md(r"""
Para decir en qué **renglón** está cada una uso `add_lines` del 02b: numera de arriba abajo, por su `y`, los renglones `(block, par, line)` de Tesseract. Luego, de la posición `start` busco la palabra que la contiene (`start <= pos < end`) y tomo su renglón.
""")

code(r"""
# Renglón de cada palabra, numerado por y dentro de la página: add_lines() del 02b.
from proto.ocr import add_lines

words, _ = add_lines(words)
words.query("pdf == 'meeting_minutes.pdf' and page == 0")[["line", "text"]].head(8)
""")

code(r"""
# El renglón de cada aparición: el de la palabra que contiene su start.
cand = found.reset_index().merge(
    words[["pdf", "page", "start", "end", "line"]], on=["pdf", "page"], suffixes=("", "_w")
)
cand = cand[(cand["start_w"] <= cand["start"]) & (cand["start"] < cand["end_w"])]
found["line"] = cand.set_index("index")["line"]
found[COLS + ["line", "start"]]
""")

code(r"""
# Cuáles ya marcó mi sistema (mismo pdf, página y start en el CSV del 02a) y cuáles perdí.
sys_marks = pd.MultiIndex.from_frame(pred[COLS + ["start"]])
found["marked"] = pd.MultiIndex.from_frame(found[COLS + ["start"]]).isin(sys_marks)
missed = found.query("not marked").reset_index(drop=True)
missed[COLS + ["line", "start"]]
""")

code(r"""
# Chequeo: encontré en el texto tantas apariciones perdidas como falsos negativos.
assert len(missed) == len(fn), "una mención perdida no está escrita igual"
""")

code(r"""
# La caja de cada una: la unión de sus palabras OCR (name_box, del 02a).
from proto.ner import name_box

page_words = {key: group for key, group in words.groupby(["pdf", "page"])}
rows = [
    name_box(page_words[(r.pdf, r.page)], r.start, r.end) for r in missed.itertuples()
]
missed = missed.join(pd.DataFrame(rows))
missed.round(1)
""")

code(r"""
# La prueba: las dibujo en su página. Cada caja debe caer sobre el nombre.
for (pdf, page), boxes in missed.groupby(["pdf", "page"]):
    display(f"{pdf} · página {page}", draw_boxes(PDFS[pdf], page, boxes, dpi=110))
""")

md(r"""
**Lo que veo:** la tabla de conteos dice que solo queda un error: "Lucas Zimmermann" está 1 vez en el oro y 0 en el sistema (1 FN, página 0 del reporte, renglón 11, `start` 434). No hay falsos positivos (FP = 0). Las 2 menciones de "Elizabeth Park" que spaCy perdía ya no son error: las recuperó la propagación (D4). La caja de arriba cae sobre el nombre.
""")

md(r"""
## 3. P3 · ¿Por qué falla spaCy en esas menciones?
No quiero adivinar: corro spaCy sobre cada página y miro qué entidad cae sobre cada mención que spaCy no marcó como persona (su etiqueta y su texto completo), o si no cae ninguna. Son las que el sistema sigue perdiendo y las que recuperó la propagación (`source == "propagated"`).
""")

code(r"""
# Para cada mención que spaCy no marcó (perdida o propagada) la entidad de spaCy que se le cruza: etiqueta y texto (repr muestra los saltos de línea).
nlp = spacy.load("en_core_web_sm")
docs = {key: nlp(text) for key, text in texts.items()}
cols = COLS + ["start", "end"]
lost = pd.concat(
    [
        missed[cols].assign(estado="perdida"),
        pred.query("source == 'propagated'")[cols].assign(estado="propagada"),
    ],
    ignore_index=True,
)
ents = []
for r in lost.itertuples():
    hit = [
        e
        for e in docs[(r.pdf, r.page)].ents
        if e.start_char < r.end and e.end_char > r.start
    ]
    ents.append((hit[0].label_, repr(hit[0].text)) if hit else ("sin entidad", ""))
lost[["spacy_label", "spacy_text"]] = ents
lost
""")

code(r"""
# Las 3 menciones de Elizabeth Park en el CSV del 02a: la de start 723 la halló spaCy.
pred.query("name == 'Elizabeth Park'")[COLS + ["start", "source"]]
""")

md(r"""
**Lo que veo:** a "Lucas Zimmermann" spaCy lo etiqueta completo como lugar (GPE) y nadie más lo menciona en su PDF, así que la propagación no tiene de dónde recuperarlo: hereda los falsos negativos de spaCy. "Elizabeth Park" la falla de dos formas distintas: en `start` 184 la mete dentro de una entidad ORG más grande, `'the Board
- Elizabeth Park'` (el final de "Chairman of the Board" y el guion de la lista), y en `start` 564 la toma por instalación (FAC), sospecho que porque "Park" suena a parque. Como spaCy sí la etiquetó PERSON en otra aparición del mismo PDF (`start` 723, fila `spacy` en el 02a), la propagación las recupera. No lo arreglo con una regla a la medida de 3 muestras (sería sobreajustar); queda medido como límite de `en_core_web_sm`.
""")

md(r"""
## 4. P4 · ¿Qué ganó la propagación (D4) frente a spaCy solo?
La decisión **ya está tomada** (D4, `research/DECISIONS-LOG.md`): el 02a busca, dentro de cada PDF, los nombres que spaCy ya halló en todas sus páginas y marca esas apariciones como `propagated`. Se apoya en Krishnan y Manning (2006, Tabla 3: usar el documento mejora PER en 2.95 puntos y el corpus solo 0.09), Finkel et al. (2005, Tabla 3: PER casi nunca cambia de tipo dentro de un documento) y Gale et al. (1992: 94 % medido, 51 de 54). Aquí solo la **mido**: spaCy solo contra el sistema, con falsos negativos y positivos.
""")

code(r"""
# Con cada variante: P, R, F1 y cuántos FN y FP quedan (con count_hits).
rows = {}
for label, v in variants.items():
    k = count_hits(keys(v), keys(gold))
    errs = pd.Series({"FN": len(gold) - k, "FP": len(v) - k})
    rows[label] = pd.concat([precision_recall(keys(v), keys(gold)), errs])
comparison = pd.DataFrame(rows).T
comparison
""")

code(r"""
# Las apariciones que aportó la propagación (mismas que dibujé en el 02a).
pred.query("source == 'propagated'")[COLS + ["start"]]
""")

md(r"""
¿Es real la mejora? Las dos variantes se miden sobre **las mismas menciones del oro**, así que los datos son pareados y lo que compara McNemar son solo los **discordantes**: `b` = menciones que acierta el sistema y spaCy no, `c` = al revés. Bajo "no hay diferencia", cada discordante es cara o cruz, así que `p = min(1, 2 · P(X ≤ min(b, c)))` con `X ~ Binomial(b + c, 0.5)` (exacto).
""")

code(r"""
# Aciertos por clave del oro (con repeticiones) de cada variante; b y c son las
# diferencias a favor de cada lado.
gold_n = keys(gold).value_counts()
hits = pd.DataFrame({k: keys(v).value_counts() for k, v in variants.items()})
hits = hits.reindex(gold_n.index).fillna(0).clip(upper=gold_n, axis=0)
diff = hits["sistema"] - hits["solo spaCy"]
b, c = int(diff.clip(lower=0).sum()), int((-diff).clip(lower=0).sum())

# Cola exacta de la binomial(b + c, 0.5), sin scipy.
n = b + c
tail = sum(math.comb(n, i) for i in range(min(b, c) + 1)) / 2**n
p_value = min(1, 2 * tail)
pd.Series({"b (solo sistema)": b, "c (solo spaCy)": c, "p (McNemar exacto)": p_value})
""")

code(r"""
# Lo contrasto con scipy.
assert np.isclose(p_value, binomtest(min(b, c), n, 0.5).pvalue)
""")

md(r"""
**Lo que veo:** la propagación recupera las 2 menciones de Elizabeth Park: los FN bajan de 3 a 1, el recall sube de 0.945 a 0.982 y el F1 de 0.972 a 0.991, sin ningún falso positivo (FP = 0 en ambas filas). Con b = 2 y c = 0, McNemar exacto da p = 0.5: la mejora **no es estadísticamente demostrable** con 55 menciones. Adopto D4 por la literatura (Krishnan y Manning 2006, Finkel 2005, Gale 1992), no por esta prueba; la medición solo muestra que aquí no aparece ningún FP nuevo. Queda el FN de Lucas Zimmermann (spaCy nunca lo reconoció como persona, no hay nada que propagar). **Límites:** con 5 páginas el efecto es de 2 menciones, demasiado pequeño para concluir (McNemar); y el riesgo de la propagación (dos personas distintas con el mismo texto, o un nombre que dentro del PDF ya no es persona) no aparece en estas muestras. El guion tampoco es `\w`: "Anna Kowalski" calzaría dentro de "Anna Kowalski-Smith".
""")

md(r"""
## Límite: las cajas no se miden aquí
El oro (`eval/gold_names.csv`) tiene nombres, no cajas, así que el IoU de las cajas **no** se mide en este notebook. Lo mido con el fixture sintético E1 (nombres insertados en posiciones conocidas, `research/06-tl-plan.md`), que da el oro exacto en puntos, y va en los tests.
""")

md(r"""
## 5. Guardo los errores
""")

code(r"""
# La mención completa (pdf, página, renglón, nombre, start) y el tipo de error.
# Los FN salen de la tabla de posiciones; si hubiera FP, el conteo no dice cuál aparición es.
cols = COLS[:2] + ["line", "name", "start"]
errors = pd.concat(
    [missed[cols].assign(type="FN"), fp.reindex(columns=cols).assign(type="FP")]
)
errors = errors.astype({"line": "Int64", "start": "Int64"})
errors.to_csv(ARTIFACTS / "02c_errors.csv", index=False)
errors
""")

md(r"""
## Mis respuestas
*Borrador de Claude para que JM revise: cada cifra sale de una celda de este notebook.*
- **P1** ¿Cuánta precisión, recall y F1 tengo, y con qué margen? Sistema (spaCy + propagación), medida exacta: **P 1.0 (54/54), R 0.982 (54/55), F1 0.991**; por token da lo mismo porque los 55 nombres del oro tienen 2 palabras. Solo spaCy: P 1.0 (52/52), R 0.945 (52/55), F1 0.972. Wilson al 95 %: precisión del sistema de 0.934 a 1.0 y recall de 0.904 a 0.997; las menciones están agrupadas en 5 páginas, así que el intervalo real es más ancho.
- **P2** ¿Qué pierdo y qué invento? **1 FN y 0 FP**: "Lucas Zimmermann" (`research_report.pdf`, página 0, renglón 11, `start` 434). Las 2 menciones de "Elizabeth Park" que spaCy perdía ya no son error.
- **P3** ¿Por qué falla spaCy? A "Lucas Zimmermann" lo etiqueta completo como GPE y nadie más lo menciona en su PDF, así que no hay qué propagar. "Elizabeth Park" cae en `start` 184 dentro de una entidad ORG (`'the Board\n- Elizabeth Park'`) y en `start` 564 como FAC; la propagación las recupera porque en otra aparición sí era PERSON.
- **P4** ¿Qué ganó la propagación? Los FN bajan de 3 a 1, el recall sube de 0.945 a 0.982 y el F1 de 0.972 a 0.991, con FP = 0 en ambas. Pero McNemar exacto con b = 2 y c = 0 da **p = 0.5**: con 55 menciones no es demostrable. Adopto D4 por la literatura, no por esta prueba.

## Qué me llevo a `app/`
`precision_recall`, `count_hits` y `wilson` no van al servicio: es de evaluación (un script o los tests). Lo que sí llevo son los criterios de aceptación:
- **AC-EVAL-01** `precision_recall` cuenta repeticiones: predicho `[a, a, b]` contra oro `[a, b, c]` da precisión, recall y F1 de 2/3 (F1 = 2PR / (P + R), a nivel de entidad como en CoNLL-2003).
- **AC-EVAL-02** la precisión, el recall y el F1 se calculan por `(pdf, página, nombre)` y por token.
- **AC-EVAL-03** la evaluación falla con un mensaje claro si falta el oro (`eval/gold_names.csv`) o la salida del sistema.
- **AC-EVAL-04** cada error queda como una fila `(pdf, página, renglón, nombre, start, tipo)`, contando repeticiones: es la diferencia de conteos por `(pdf, página, nombre)`.
- **AC-EVAL-05** (candidato) `wilson(k, n)` da el intervalo de Wilson al 95 %: para `k = 2, n = 3` da (0.208, 0.939), y coincide con `scipy.stats.binomtest(...).proportion_ci(method="wilson")` con tolerancia 1e-3.
- **AC-EVAL-06** la evaluación reporta spaCy solo (`source == "spacy"`) y el sistema completo (spaCy + propagación) contra el mismo oro, con precisión, recall, F1, FN, FP y Wilson para ambos.

## Lo que tengo que poder explicar
1. Por qué cuento repeticiones (multiconjunto por `(pdf, página, nombre)`): una segunda mención perdida no se tapa con la primera encontrada. Y por qué el oro no trae renglón: la mención concreta se identifica por `start` en el texto OCR.
2. Exacta frente a por token, y por qué el oro lo firmo yo y no sale de spaCy.
3. Por qué falla spaCy en cada falso negativo, y por qué no lo arreglé con una regla a la medida de pocas muestras (sobreajuste).
4. Qué es F1 (media armónica de P y R, a nivel de entidad como en CoNLL-2003) y por qué doy un intervalo de Wilson a la medida exacta y no a la de tokens (los tokens de un nombre no son independientes).
5. Qué es D4, qué recupera (Elizabeth Park) y qué no (Zimmermann), qué papers la respaldan y por qué una mejora de 2 menciones no es concluyente.
""")

md(r"""
## Desde `app/`
*Borrador de Claude para que JM revise.* La lógica ya está en `app/services/ner_service.py`. Compruebo que **medida contra el mismo oro da la misma cifra** que mi prototipo: genero los spans con `find_person_spans` (spaCy real, con propagación) y los paso por `precision_recall`. Si coincide con la columna "exacta" de la sección 1, `app/` no perdió nada por el camino.
""")

code(r"""
# Los spans desde app/, uno por mención, en el formato (pdf, page, name) que usa keys().
from app.services.ner_service import find_person_spans

rows = []
for pdf, pdf_words in words.groupby("pdf", sort=False):
    pages = [texts.get((pdf, p), "") for p in range(pdf_words["page"].max() + 1)]
    for page, page_spans in enumerate(find_person_spans(pages)):
        rows += [(pdf, page, name) for name, _, _ in page_spans]
from_app = pd.DataFrame(rows, columns=COLS)
len(from_app), count_hits(keys(from_app), keys(gold))
""")

code(r"""
# P, R y F1 desde app/ contra el oro: tienen que ser las de la medida exacta del sistema.
app_pr = precision_recall(keys(from_app), keys(gold))
pd.testing.assert_series_equal(app_pr, result["exacta"], check_names=False)
# Y no solo las cifras: es el mismo multiconjunto de menciones (sin `source`).
pd.testing.assert_series_equal(
    keys(from_app).value_counts().sort_index(), keys(pred).value_counts().sort_index(), check_names=False
)
app_pr
""")

md(r"""
## Preguntas que me pueden hacer
*Borrador de Claude para que JM revise.* Lista completa en `research/20-preguntas-entrevista.md` (Tarea 02).

| Pregunta | Respuesta corta | Celda que la respalda |
|---|---|---|
| ¿Cómo sabes que `app/` hace lo mismo que el notebook? | Con spaCy real, `find_person_spans` medido contra el mismo oro da P 1.0 y R 54/55 = 0.982, igual que la medida exacta del sistema. | "Desde `app/`": `assert_series_equal` con `result["exacta"]` |
| ¿Qué falla? | Falta 1 mención del oro (54/55): "Lucas Zimmermann", que spaCy etiqueta como GPE. Los nombres de una palabra se pierden a propósito. | §2 tabla de conteos y §3 etiquetas de spaCy |
| ¿Qué ganó la propagación y es significativo? | Recall de 0.945 a 0.982 con FP = 0, pero McNemar exacto da p = 0.5 (b = 2, c = 0): no es demostrable con 55 menciones. | §4 tabla `comparison` y celda de McNemar |
| ¿Por qué cuentas repeticiones? | Una segunda mención perdida no se tapa con la primera encontrada; el juguete `[a, a, b]` contra `[a, b, c]` da 2/3. | §1 celda del juguete y `precision_recall` |
| ¿Por qué un intervalo de Wilson y no el normal? | Con `n` pequeño y valores cerca de 1, el normal es poco fiable (con 54/54 da ancho cero); Wilson cubre mejor (Brown, Cai y DasGupta 2001). | §1 celda de Wald (ancho 0) y tabla `interval` con contraste scipy |
| ¿Por qué no intervalo para la medida por token? | Las palabras de un mismo nombre no son independientes. | §1 "¿Con cuánto margen de error?" |
| ¿Por qué el oro no sale de spaCy? | Si saliera de spaCy, sus errores serían invisibles; aun así es optimista porque partí de su propuesta. | §1 "Lo que estas cifras no dicen" |
| ¿Mides las cajas? | No aquí: el oro tiene nombres, no cajas; el IoU va con el fixture sintético E1 en los tests. | Sección "Límite: las cajas no se miden aquí" |
""")


def to_cell(kind, src):
    cell = {"cell_type": kind, "id": uuid.uuid4().hex[:8], "metadata": {}, "source": src}
    if kind == "code":
        cell.update(execution_count=None, outputs=[])
    return cell


nb = {
    "cells": [to_cell(kind, src) for kind, src in cells],
    "metadata": {
        "kernelspec": {
            "display_name": "cuesta (uv 3.12)",
            "language": "python",
            "name": "cuesta",
        },
        "language_info": {"name": "python", "version": "3.12"},
    },
    "nbformat": 4,
    "nbformat_minor": 5,
}
with open(sys.argv[1], "w", encoding="utf-8") as f:
    json.dump(nb, f, ensure_ascii=False, indent=1)
print(len(cells))
