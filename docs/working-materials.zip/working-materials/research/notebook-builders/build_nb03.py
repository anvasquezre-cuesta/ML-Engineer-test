import sys

import nbformat as nbf

cells = []


def md(s):
    cells.append(nbf.v4.new_markdown_cell(s.strip("\n")))


def code(s):
    cells.append(nbf.v4.new_code_cell(s.strip("\n")))


md(r"""
# 03 · Fuzzy match de nombres

## Por qué este notebook importa
El README pide comparar los nombres extraídos con la lista que llega en `names` (paso 4 de `/api/extract`) y dice qué revisará: **similitud de cadena completa** (no una razón parcial que infle coincidencias), **sin distinguir mayúsculas ni acentos**, y solo pares **en o sobre un umbral configurable (0.90 por defecto)**, con score entre 0 y 1. Entra en *Correctness* (30 %). Un falso match cuesta más que perder uno: alguien podría revisar a la persona equivocada.

## Dónde estoy en el pipeline
```
PDF -> 1 OCR (01) -> 2 NER de personas (02a) -> 3 cajas en puntos PDF (02a) -> [4 FUZZY MATCH (este)] -> respuesta
```

## Trazabilidad
| Qué | Dónde |
|---|---|
| Entrada | `artifacts/02a_name_boxes.csv` (columnas `pdf` y `name`) |
| Salidas | `artifacts/03_matches.csv`; `eval/gold_fuzzy_pairs.csv` **solo si** `REVIEWED = True` |
| Código | `notebooks/proto/fuzzy.py`: `normalize_name`, `name_score`, `fuzzy_match_names` |
| Decisiones | F1-F7 (juez experto): `research/17-nb03-fuzzy-research.md`; cada sección dice cuál aplica |
| Métricas y papers | `research/18-metricas.md` |
| Criterios | AC-FUZ-01..12 (celda de asserts, al final) |

## Preguntas que tengo que tener claras al terminar
- **P1.** ¿Cómo dejo dos nombres "iguales" antes de compararlos (acentos, mayúsculas, apóstrofos, títulos)?
- **P2.** ¿Qué puntaje uso y por qué no `partial_ratio` ni `token_set_ratio`?
- **P3.** ¿Sirve el umbral 0.90, con qué incertidumbre y qué falla?
- **P4.** ¿Qué devuelve el match cuando un nombre se parece a varios y cuando hay duplicados?

Orden: **01 -> 02a -> 02b -> 02c -> 03 (este)**.
""")

md(r"""
## 0. Preparación
""")

code(r"""
%load_ext autoreload
%autoreload 2

import unicodedata
from pathlib import Path

import numpy as np
import pandas as pd
import rapidfuzz
from rapidfuzz import fuzz
""")

code(r"""
# Compruebo que existe lo que leo del 02a y anoto la versión de rapidfuzz (sus puntajes cambian entre versiones).
ROOT = Path.cwd().parent  # el notebook corre desde notebooks/
ARTIFACTS = ROOT / "notebooks" / "artifacts"
boxes_path = ARTIFACTS / "02a_name_boxes.csv"
assert boxes_path.exists(), f"Falta {boxes_path.name}: corre primero el 02a."
rapidfuzz.__version__
""")

code(r"""
# Solo necesito de qué PDF viene cada nombre y el nombre.
boxes = pd.read_csv(boxes_path, usecols=["pdf", "name"], keep_default_na=False)
names = boxes["name"].drop_duplicates().tolist()
len(boxes), len(names)
""")

md(r"""
**Lo que veo:** 54 menciones y 28 nombres distintos. Con esos nombres reales construyo los casos de prueba.

**De dónde sale cada dato escrito a mano.** Todo caso de prueba de este notebook viene de una de cuatro fuentes y la celda lo dice:
- **02a:** un nombre de la lista `names` de arriba (los 28 nombres que el NER leyó de los PDFs).
- **README:** el ejemplo `María González` ~ `Maria Gonzalez` (`README.md`, línea 93).
- **Variación:** un nombre de las fuentes anteriores al que le aplico un cambio descrito (un acento, una letra cambiada, un título).
- **Sintético:** un texto inventado solo para fijar un comportamiento en un test.

## 1. P1 · ¿Cómo normalizo un nombre? (decisión F3)
**Por qué surge.** El README pide ignorar mayúsculas y acentos. En mis datos hay `O'Brien` y `Al-Rashidi`, y en los PDFs un nombre podría llegar con título ("Dr."): sin normalizar, el puntaje castiga diferencias que no cambian a la persona. Hago un paso por columna para ver qué hace cada uno. Incluyo `Søren` y `Łukasz` para ver el límite.
""")

code(r"""
# Mis casos de prueba. Origen: "María González" = README; "Müller" = Thomas Muller (02a) con ü;
# "O'Brien" = Kevin O'Brien (02a) y "O’Brien" es el mismo con apóstrofo tipográfico (variación);
# "Al-Rashidi" = Fatima Al-Rashidi (02a); "Dr. Robert Chen" = Robert Chen (02a) con título (variación);
# "Søren" y "Łukasz" son sintéticos (no están en mis datos; solo muestran el límite).
TITLES = {"dr", "mr", "mrs", "ms", "miss", "prof"}
steps = pd.DataFrame(
    {"original": ["María González", "Müller", "O'Brien", "O’Brien", "Al-Rashidi", "Dr. Robert Chen", "Søren", "Łukasz"]}
)
""")

code(r"""
# Un paso por columna, cada uno sobre el anterior.
steps["1_casefold"] = steps["original"].str.casefold()
steps["2_sin_acentos"] = steps["1_casefold"].str.normalize("NFKD").map(
    lambda x: "".join(c for c in x if not unicodedata.combining(c))
)  # NFKD separa letra y acento; borro el acento
steps["3_sin_apostrofo"] = steps["2_sin_acentos"].str.replace(r"['’]", "", regex=True)
steps["4_puntuacion_a_espacio"] = steps["3_sin_apostrofo"].str.replace(r"\W+", " ", regex=True)
steps["5_sin_titulos"] = steps["4_puntuacion_a_espacio"].map(lambda x: " ".join(w for w in x.split() if w not in TITLES))
steps
""")

md(r"""
**Lo que veo:**
- `María González` queda `maria gonzalez` y `Müller` queda `muller`.
- `O'Brien` y `O’Brien` (apóstrofo tipográfico) quedan los dos `obrien`.
- `Al-Rashidi` queda `al rashidi`: el guion pasa a espacio.
- "Dr. Robert Chen" queda `robert chen`.
- **Límite:** NFKD no descompone `ø` ni `ł` (`søren`, `łukasz`), y `ü` no se convierte en `ue` ("Müller" frente a "Mueller"). No aparecen en mis datos; lo dejo documentado.

**Por qué quito el título:** lo compruebo con el puntaje base sobre los dos textos ya normalizados, con y sin "dr".
""")

code(r"""
fuzz.ratio("dr robert chen", "robert chen") / 100
""")

md(r"""
**Lo que veo:** 0.88, bajo el umbral: sin quitar el título, "Dr. Robert Chen" no encontraría a "Robert Chen".

**Como función.** Paso los 5 pasos a `normalize_name` en `proto/fuzzy.py` y compruebo que da lo mismo que la última columna.
""")

code(r"""
from proto.fuzzy import normalize_name

assert steps["original"].map(normalize_name).tolist() == steps["5_sin_titulos"].tolist()
steps["original"].map(normalize_name).tolist()
""")

md(r"""
## 2. P2 · ¿Qué puntaje uso? (decisión F2)
**Por qué surge.** El README prohíbe una razón parcial que infle coincidencias. `fuzz.ratio` es una similitud de cadena **completa**: `1 - indel / (len_a + len_b)`, donde `indel` cuenta inserciones y borrados (una sustitución cuesta 2). Sospecho que `token_sort_ratio` (ordena las palabras antes de comparar) arregla "Gonzalez Maria", pero que ordenar mueve una palabra con error de OCR y la rompe ("Katherine" frente a "Catherine"). Comparo 4 puntajes en 7 casos; `partial` y `token_set` solo para ver cuánto inflan.
""")

code(r"""
# Mis 7 casos. `origen` dice de dónde sale cada uno: README (ejemplo del enunciado, línea 93)
# o 02a + variación (nombre real de mi lista al que le cambio algo). Los normalizo en a y b.
cases = pd.DataFrame(
    [
        ("Maria", "Maria Gonzalez", "README + solo el nombre"),
        ("Gonzalez Maria", "Maria Gonzalez", "README + orden invertido"),
        ("Katherine Dubois", "Catherine Dubois", "02a + variación C/K"),
        ("Fatima AlRashidi", "Fatima Al-Rashidi", "02a + variación sin guion"),
        ("Maria Gonzalez", "Mario Gonzalez", "README + variación a/o"),
        ("Sarah Wi11iams", "Sarah Williams", "02a + variación OCR (l por 1)"),
        ("Dr. Robert Chen", "Robert Chen", "02a + variación con título"),
    ],
    columns=["a", "b", "origen"],
)
a, b = cases["a"].map(normalize_name), cases["b"].map(normalize_name)
""")

code(r"""
# Cuatro puntajes de rapidfuzz (0-100) y el máximo de los dos de cadena completa.
for col, scorer in [
    ("ratio", fuzz.ratio),
    ("token_sort", fuzz.token_sort_ratio),
    ("partial", fuzz.partial_ratio),
    ("token_set", fuzz.token_set_ratio),
]:
    cases[col] = [scorer(x, y) for x, y in zip(a, b)]
cases["max_ratio_sort"] = cases[["ratio", "token_sort"]].max(axis=1)
cases.round(1)
""")

md(r"""
**Lo que veo:**
- `Maria` frente a `Maria Gonzalez`: `partial` y `token_set` dan **100** (un nombre suelto "es" el completo); `ratio` y `token_sort` dan 52.6. Descarto los dos primeros.
- `Gonzalez Maria`: `ratio` da 57.1 y `token_sort` 100. Necesito ignorar el orden.
- `Katherine Dubois` frente a `Catherine Dubois`: `token_sort` da 50.0 (ordenar movió la palabra con el error) y `ratio` 93.8. Por eso tomo el **máximo** de los dos, no `token_sort` solo (Christen 2006, Sec. 3.2: "Permuted-Winkler").
- `Fatima AlRashidi`: `token_sort` cae a 54.5 porque el guion separa palabras; `ratio` da 97.0. Mismo caso.
- `Mario Gonzalez` da 92.9: un falso positivo que ningún puntaje de edición evita. Lo mido en P3.
- `Sarah Wi11iams`, con dos caracteres de ruido OCR, queda en 85.7, bajo 0.90. Límite que acepto.

**Como función.** `name_score(a, b)` = `max(ratio, token_sort_ratio) / 100` sobre nombres normalizados. Compruebo que da la última columna.
""")

code(r"""
from proto.fuzzy import name_score

by_function = [name_score(x, y) for x, y in zip(cases["a"], cases["b"])]
assert by_function == (cases["max_ratio_sort"] / 100).tolist()
by_function
""")

md(r"""
## 3. P3 · ¿Sirve el umbral 0.90? (decisión F7)
**Por qué surge.** El 0.90 viene del README. No quiero cambiarlo a ciegas, sino ver qué pasa alrededor. No tengo etiquetas de la prueba, así que construyo pares con **nombres reales de mi lista** y les aplico variaciones.

**Regla de etiquetado (escrita antes de puntuar):**
- **Positivo** (`match = True`): *la misma persona* con una variación: acento, mayúsculas, orden, un carácter de ruido OCR u ortografía, guion, apóstrofo o título.
- **Negativo duro** (`match = False`): *otra persona* parecida: mismo apellido con otro nombre, mismo nombre con otro apellido, un nombre a una letra del otro (Mario/Maria), un apellido de más o un apellido vecino.

El extraído es siempre un nombre real; la variación va en lo pedido (`query_first`, `query_last`). La tabla va **sin puntaje** para que la etiqueta no dependa del modelo.
""")

code(r"""
# 27 pares: 15 positivos y 12 negativos duros, según la regla de etiquetado de arriba.
# `extracted` es siempre un nombre real del 02a (lo compruebo abajo); la variación va en `query_*`.
# Los 3 últimos positivos (Wi11iams, "J.", "Maria Jose") los incluyo a propósito: sospecho que fallarán.
# El ruido OCR doble ya lo vi en P2; la inicial y el segundo nombre son el límite que
# research/17-nb03-fuzzy-research.md deja documentado en la decisión F6 (línea 81).
# "Dr. Priya" es el nombre real "Priya Sharma" del 02a con el título añadido en lo pedido.
pairs = pd.DataFrame(
    [
        ("Maria Garcia", "María", "García", True, "acento"),
        ("Kevin O'Brien", "Kevin", "O’Brien", True, "apóstrofo tipográfico"),
        ("James Anderson", "JAMES", "ANDERSON", True, "mayúsculas"),
        ("Robert Chen", "Chen", "Robert", True, "orden invertido"),
        ("Fatima Al-Rashidi", "Fatima", "AlRashidi", True, "guion"),
        ("Priya Sharma", "Dr. Priya", "Sharma", True, "título añadido en lo pedido"),
        ("Catherine Dubois", "Katherine", "Dubois", True, "ortografía C/K"),
        ("Thomas Muller", "Thomas", "Müller", True, "acento (ü)"),
        ("Michael O'Sullivan", "Michael", "OSullivan", True, "apóstrofo borrado"),
        ("Margaret Thompson", "Margaret", "Thomson", True, "una letra menos"),
        ("Benjamin Foster", "Benjamln", "Foster", True, "OCR: i leída como l"),
        ("Hans Weber", "Hans", "Webr", True, "OCR: letra perdida"),
        ("Sarah Williams", "Sarah", "Wi11iams", True, "OCR: dos caracteres"),
        ("James Anderson", "J.", "Anderson", True, "inicial"),
        ("Maria Garcia", "Maria Jose", "Garcia", True, "segundo nombre"),
        ("Maria Garcia", "Mario", "Garcia", False, "nombre a 1 edición"),
        ("Robert Chen", "James", "Chen", False, "mismo apellido"),
        ("James Anderson", "James", "Chen", False, "mismo nombre"),
        ("Priya Sharma", "Priya", "Sharma Patel", False, "apellido de más"),
        ("Anna Kowalski", "Anna", "Kowalski-Smith", False, "apellido compuesto"),
        ("Alexander Popov", "Alexandra", "Popov", False, "nombre vecino"),
        ("Thomas Muller", "Thomas", "Miller", False, "apellido vecino"),
        ("Catherine Dubois", "Catherine", "Dupont", False, "apellido distinto"),
        ("David Nakamura", "Daniel", "Nakamura", False, "nombre vecino"),
        ("Hans Weber", "Hans", "Wagner", False, "apellido vecino"),
        ("Sarah Williams", "Sarah", "Wilson", False, "apellido vecino"),
        ("Elizabeth Park", "Elizabeth", "Parker", False, "apellido a 2 ediciones"),
    ],
    columns=["extracted", "query_first", "query_last", "match", "why"],
)
assert pairs["extracted"].isin(names).all(), "un extraído no está en mi lista"
pairs["match"].value_counts()
""")

md(r"""
**Lo que veo:** 15 positivos y 12 negativos, todos con un nombre extraído de mi lista. Reviso cada etiqueta contra la regla en la tabla de abajo, todavía sin puntaje.
""")

code(r"""
pairs
""")

md(r"""
Revisé las etiquetas contra la regla y pongo `REVIEWED = True`: se escribe `eval/gold_fuzzy_pairs.csv` (columnas `extracted`, `query_first`, `query_last`, `match`, `why`; sin puntaje, que se calcula después). Con `False` el notebook usa la tabla en memoria y corre igual.
""")

code(r"""
REVIEWED = True

gold_path = ROOT / "eval" / "gold_fuzzy_pairs.csv"
if REVIEWED:
    pairs.to_csv(gold_path, index=False)
gold_path.exists()
""")

md(r"""
Ahora sí puntúo cada par con `name_score` y lo ordeno de mayor a menor, con la etiqueta al lado.
""")

code(r"""
pairs["query"] = pairs["query_first"] + " " + pairs["query_last"]
pairs["score"] = [name_score(e, q) for e, q in zip(pairs["extracted"], pairs["query"])]
pairs.sort_values("score", ascending=False)[["extracted", "query", "match", "score", "why"]].round(4)
""")

md(r"""
**Lo que veo:**
- Los positivos fáciles (acento, mayúsculas, orden, título, apóstrofo, guion, una letra) quedan entre 0.933 y 1.0.
- Los negativos más altos están justo ahí: Alexandra Popov y Elizabeth Parker (0.933, empatados con Benjamln), Thomas Miller (0.923) y Mario Garcia (0.917).
- Los tres positivos difíciles quedan **debajo** de esos negativos: Wi11iams 0.857, J. Anderson 0.833 y Maria Jose Garcia 0.828 (igual que el negativo Daniel Nakamura).

**Los dos grupos se mezclan:** ningún umbral los separa limpio. Cuento, para varios umbrales, cuántos positivos acepto (**recall**) y cuántos negativos acepto (**FPR**, tasa de falsos positivos).
""")

code(r"""
pos, neg = pairs[pairs["match"]], pairs[~pairs["match"]]
sweep = pd.DataFrame({"threshold": [0.80, 0.85, 0.90, 0.95]})
sweep["tp"] = [(pos["score"] >= t).sum() for t in sweep["threshold"]]
sweep["fp"] = [(neg["score"] >= t).sum() for t in sweep["threshold"]]
sweep["recall"] = sweep["tp"] / len(pos)
sweep["fpr"] = sweep["fp"] / len(neg)
sweep.round(2)
""")

md(r"""
Con 15 y 12 pares cada proporción es muy incierta. Añado el intervalo de Wilson al 95 % (`proto/ner.py`, el mismo del 02c; fórmula en `18-metricas.md`).
""")

code(r"""
from proto.ner import wilson

sweep["recall_ic95"] = [np.round(wilson(k, len(pos)), 2) for k in sweep["tp"]]
sweep["fpr_ic95"] = [np.round(wilson(k, len(neg)), 2) for k in sweep["fp"]]
sweep.round(2)
""")

md(r"""
**Lo que veo:**
- **0.90:** recall 12/15 (0.55-0.93) y FPR 4/12 (0.14-0.61).
- **0.85:** recall 13/15 (entra Wi11iams), la misma FPR.
- **0.95:** FPR 0/12 (0-0.24), pero la recall cae a 9/15.
- **0.80:** recall 15/15, pero la FPR sube a 8/12.

Los intervalos se traslapan mucho: con tan pocos pares no puedo decir que un umbral sea mejor. Mover el umbral cambia qué error prefiero, no lo elimina. Miro los errores a 0.90 uno por uno.
""")

code(r"""
pairs["predicted"] = pairs["score"] >= 0.90
errors = pairs[pairs["predicted"] != pairs["match"]].copy()
errors["kind"] = errors["predicted"].map({True: "FP", False: "FN"})
errors[["kind", "extracted", "query", "score", "why"]].round(4)
""")

md(r"""
**Lo que veo:**
- **3 falsos negativos**, los límites que ya conocía: Wi11iams (dos caracteres de OCR), J. Anderson (inicial) y Maria Jose Garcia (segundo nombre). No los resuelvo (decisión F6) y quedan documentados.
- **4 falsos positivos**, nombres a una o dos letras de otro: Mario Garcia, Thomas Miller, Alexandra Popov y Elizabeth Parker. Una distancia de edición no distingue "Maria" de "Mario"; lo debe ver quien revise la caja.

**Por qué reporto recall y FPR y no precisión:** la precisión depende de cuántos positivos meto frente a negativos (15 contra 12), y esa proporción la elegí yo. Recall y FPR no dependen de ella. Detalle y fórmula en `research/18-metricas.md`, sección 5.

**Cuidado:** los pares los construí yo con los mismos casos que me llevaron a elegir el puntaje (resubstitución). Estas cifras muestran la sensibilidad, no prometen rendimiento en datos nuevos.

**Decisión:** el 0.90 del README **no cambia**.

## 4. P4 · ¿Qué devuelve el match? (decisiones F1 y F5)
**Por qué surge.** El README no dice qué hacer si un extraído se parece a varios pedidos. Devuelvo **todos los pares ≥ umbral** (F1), para que quien revise vea las alternativas, ordenados por score descendente, luego extraído y luego pedido. Cada petición trae **un solo PDF**, así que uso solo `company_memo.pdf`. Un nombre repetido (Margaret Thompson sale dos veces) o un pedido duplicado no deben duplicar resultados: **dedupe por clave normalizada**, conservando la primera aparición original (F5).

Mi lista pedida de ejemplo trae un duplicado (Robert Chen), uno con acentos, uno que no existe y Mario Garcia, el falso positivo conocido.
""")

code(r"""
# Lista pedida, en el formato de la API, y los nombres extraídos de un solo PDF.
query_names = [
    {"first_name": "Robert", "last_name": "Chen"},  # nombre real del 02a
    {"first_name": "María", "last_name": "García"},  # acento, como en el ejemplo del README, sobre Maria Garcia (02a)
    {"first_name": "Mario", "last_name": "Garcia"},  # el falso positivo de P3 (Mario frente a Maria)
    {"first_name": "Robert", "last_name": "Chen"},  # duplicado a propósito: pruebo el dedupe
    {"first_name": "Juan", "last_name": "Pérez"},  # sintético: no está en mis datos, el caso sin match
]
raw_extracted = boxes.loc[boxes["pdf"] == "company_memo.pdf", "name"].tolist()
raw_extracted
""")

code(r"""
# Dedupe por clave normalizada: me quedo con la primera aparición de cada nombre.
extracted, wanted = {}, {}
for name in raw_extracted:
    key = normalize_name(name)
    if key and key not in extracted:
        extracted[key] = name
for q in query_names:
    full = f"{q['first_name']} {q['last_name']}"
    key = normalize_name(full)
    if key and key not in wanted:
        wanted[key] = full
list(extracted.values()), list(wanted.values())
""")

md(r"""
**Lo que veo:** 8 menciones bajan a 7 nombres (Margaret Thompson estaba dos veces) y 5 pedidos bajan a 4 (se fue el Robert Chen repetido). Ahora puntúo todos contra todos.
""")

code(r"""
scores = pd.DataFrame(
    [{"extracted_name": e, "matched_name": m, "score": name_score(e, m)} for e in extracted.values() for m in wanted.values()]
)
scores.sort_values("score", ascending=False).head(6)
""")

code(r"""
# Filtro sobre el score crudo (>=), luego redondeo a 4 decimales y ordeno.
kept = scores[scores["score"] >= 0.90].copy()
kept["score"] = kept["score"].round(4)
kept = kept.sort_values(["score", "extracted_name", "matched_name"], ascending=[False, True, True])
kept
""")

md(r"""
**Lo que veo:** 3 pares de 28. `Maria Garcia` con `María García` (1.0: el acento no cuenta), `Robert Chen` con `Robert Chen` (1.0) y `Maria Garcia` con `Mario Garcia` (0.9167), el falso positivo de P3, que sale con su score para poder revisarlo. Filtro **antes** de redondear para que un 0.89996 no pase como 0.90.

**Como función.** `fuzzy_match_names` mantiene la firma del stub y añade `threshold` (en `app/` vendrá de la config). Debe dar lo mismo.
""")

code(r"""
from proto.fuzzy import fuzzy_match_names

matches = fuzzy_match_names(raw_extracted, query_names)
assert matches == kept.to_dict("records")
pd.DataFrame(matches).to_csv(ARTIFACTS / "03_matches.csv", index=False)
pd.DataFrame(matches)
""")

code(r"""
# Pedidos que no encontraron a nadie.
found = {m["matched_name"] for m in matches}
[q for q in wanted.values() if q not in found]
""")

md(r"""
**Lo que veo:** el único pedido sin pares es `Juan Pérez`.

## Criterios de aceptación
Fijo el comportamiento con un assert por criterio (AC-FUZ). Estos pasan a tests en `app/`. `one` es un atajo para probar un solo par.
""")

code(r"""
# Origen de los datos: "María GARCÍA", "Gonzalez Maria", "Maria", "Robert Chen" y "Catherine Dubois" salen del
# README o del 02a (con variación; "Catherlne" es Catherine con una l por una i). "Ana Ruiz" y
# "abcd efghi" son sintéticos, inventados solo para fijar el dedupe y el borde del umbral.
one = lambda name, first, last: fuzzy_match_names([name], [{"first_name": first, "last_name": last}])
ana = [{"first_name": "Ana", "last_name": "Ruiz"}, {"first_name": "ANA", "last_name": "RUIZ"}]

assert one("María GARCÍA", "maria", "garcia")[0]["score"] == 1.0  # 01 acentos y mayúsculas
assert one("Maria", "Maria", "Gonzalez") == []  # 02 un nombre a medias no pasa
assert one("Catherlne Dubois", "Catherine", "Dubois")  # 03 un carácter de ruido OCR pasa
assert one("Gonzalez Maria", "Maria", "Gonzalez")[0]["score"] == 1.0  # 04 orden invertido
assert one("Robert Chen", "James", "Chen") == []  # 05 mismo apellido, otra persona
assert len(fuzzy_match_names(raw_extracted, query_names, threshold=0.99)) < len(matches)  # 06 el umbral manda
assert all(0 <= m["score"] <= 1 and m["score"] == round(m["score"], 4) for m in matches)  # 07 rango y 4 decimales
assert [m["score"] for m in matches] == sorted((m["score"] for m in matches), reverse=True)  # 07 orden descendente
assert fuzzy_match_names(["Ana Ruiz", "ana  ruiz"], ana) == [
    {"extracted_name": "Ana Ruiz", "matched_name": "Ana Ruiz", "score": 1.0}
]  # 08 dedupe en ambos lados, primera aparición
assert fuzzy_match_names([], query_names) == [] and fuzzy_match_names(raw_extracted, []) == []  # 09 vacíos
assert set(matches[0]) == {"extracted_name", "matched_name", "score"}  # 10 claves de FuzzyMatch
assert one("Dr. Robert Chen", "Robert", "Chen")[0]["score"] == 1.0  # 11 título
# 12: 1 letra cambiada = indel 2 sobre 20 caracteres -> 1 - 2/20 = 0.90 exacto, y se reporta (>=).
assert one("abcd efghi", "abcd", "efghk")[0]["score"] == 0.9
"AC-FUZ-01..12 ok"
""")

md(r"""
## Mis respuestas
- **P1** ¿Cómo normalizo un nombre? ...
- **P2** ¿Qué puntaje uso y por qué no `partial_ratio` ni `token_set_ratio`? ...
- **P3** ¿Sirve el 0.90, con qué incertidumbre y qué falla? ...
- **P4** ¿Qué devuelve el match y cómo trato los duplicados? ...

## Qué me llevo a `app/`
- **Funciones** (`proto/fuzzy.py` -> `app/services/fuzzy_service.py`; firma del stub más `threshold`): `normalize_name`, `name_score`, `fuzzy_match_names`.
- **Config** (`app/config.py`): `fuzzy_threshold: float = Field(0.90, ge=0.0, le=1.0)`, inyectada en el servicio.
- **Logging sin PII:** solo conteos y umbral, nunca los nombres.
- **Tests:** AC-FUZ-01..12 -> `test_ac_fuzzy_<nn>_*`, con datos pequeños, sin red ni modelos.
- **Límites documentados:** `ø`/`ł`, `ü` frente a `ue`, iniciales y segundos nombres, ruido OCR de 2 o más caracteres y nombres a una letra (Mario/Maria).

## Lo que tengo que poder explicar
1. Qué es `ratio` (Indel: inserciones y borrados) y por qué es de cadena completa.
2. Por qué el máximo de `ratio` y `token_sort`: "Gonzalez Maria" necesita ignorar el orden; "Katherine" necesita no mover la palabra con el error.
3. Por qué no `partial_ratio` ni `token_set_ratio`: dan 100 a "Maria" contra "Maria Gonzalez".
4. Por qué recall y FPR, con Wilson, y no precisión: la proporción de positivos la fijé yo.
5. Por qué filtro antes de redondear.
6. Qué es la resubstitución y por qué estas cifras no son una promesa.
""")

nb = nbf.v4.new_notebook(cells=cells)
nb.metadata = {
    "kernelspec": {"display_name": "cuesta (uv 3.12)", "language": "python", "name": "cuesta"},
    "language_info": {"name": "python", "version": "3.12"},
}
nbf.write(nb, sys.argv[1])
print(len(cells))
