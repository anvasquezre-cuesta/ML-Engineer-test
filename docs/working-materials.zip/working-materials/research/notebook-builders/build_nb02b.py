import json
import sys
import uuid

cells = []


def md(s):
    cells.append(("markdown", s.strip("\n")))


def code(s):
    cells.append(("code", s.strip("\n")))


# Lo que veo en cada página (P4), verificado mirando las imágenes.
PAGE_MD = {
    "company_memo.pdf|0": "**Lo que veo:** 8 personas en el papel, 8 cajas. Margaret Thompson sale 2 veces (renglones 3 y 21) y las dos tienen caja. No hay pistas-persona en esta página: nada falta.",
    "meeting_minutes.pdf|0": "**Lo que veo:** 14 personas en el papel, 12 cajas. Elizabeth Park sale 3 veces (renglones 7, 18 y 22) y spaCy solo tiene la del 22: faltan las de los renglones 7 y 18, que son justo las pistas de P3. Las otras 11 personas (Hernandez, Muller, Patel, O'Brien, Liu y Mendoza en la cabecera y las repetidas del cuerpo) tienen caja. No sobra ninguna caja.",
    "meeting_minutes.pdf|1": "**Lo que veo:** 10 personas en el papel, 10 cajas, cada una sobre su nombre (Richard Hernandez sale 3 veces y las 3 tienen caja). No hay pistas-persona: nada falta.",
    "research_report.pdf|0": "**Lo que veo:** 12 personas en el papel, 11 cajas. En el renglón 11, \"Senior Researchers: Dr. Priya Sharma, Lucas Zimmermann\", Priya Sharma tiene caja y Lucas Zimmermann no: es la pista de P3. Las otras 11 (Priya Sharma sale 2 veces) tienen caja y ninguna sobra.",
    "research_report.pdf|1": "**Lo que veo:** 11 personas en el papel, 11 cajas (Fatima Al-Rashidi sale 3 veces y Benjamin Foster 2). Algunas cajas traen la puntuación pegada (\"Foster);\"), como decidí en el 02a. No hay pistas-persona: nada falta.",
}

md(r"""
# 02b · Mi oro de nombres (gold)

## Por qué este notebook importa
En el 02c mido qué tan bien encuentro nombres, pero eso solo vale si comparo contra una **verdad que no salga de mi propio sistema**. Si el oro fuera lo que dice spaCy, nunca vería los nombres que spaCy pierde, y la recall saldría optimista justo donde la prueba me califica (correctness, 30 %).

Por eso **el oro lo etiqueto yo mirando cada página**. El notebook solo me ayuda a que no se me escape nada y a que quede escrito **qué falta, dónde está y cómo lo encontré**:
1. Me propone lo que encontró mi sistema (spaCy con los filtros del 02a).
2. Numera los renglones de cada página, para poder decir "falta este nombre, en el renglón 7".
3. Me da pistas: candidatos de una regex sencilla que spaCy no cubre. Yo decido a mano cuáles son personas.
4. Yo leo cada página entera, una por una, y anoto lo que falta (`missing`) y lo que sobra (`wrong`).
5. El notebook escribe `eval/gold_names.csv` solo cuando marco que terminé de revisar.

## Convenciones del oro
- Una fila por **cada aparición** de una persona (3 veces en la página = 3 filas).
- Cuenta cualquier persona con nombre propio, también si solo aparece el apellido. No cuentan cargos sin nombre, organizaciones ni lugares.
- El nombre **como está en el papel**, sin título ("Dr.", "Prof.") y sin puntuación pegada; acentos tal cual.
- Columnas del CSV: `pdf, page, name`. Nada más (aquí además llevo `source` para ver de dónde sale cada fila).

## Preguntas que tengo que tener claras al terminar
- **P1.** ¿Qué me propone mi sistema?
- **P2.** ¿En qué renglón de la página está cada nombre?
- **P3.** ¿Qué encuentra una regex que spaCy no cubre, y cuáles de esas pistas son personas?
- **P4.** Mirando cada página, ¿falta o sobra algún nombre?
- **P5.** ¿Cuál es mi oro final y de dónde sale cada fila?
- **P6.** ¿Cómo sé que no se me escapó nada?
- **P7.** ¿Cuándo escribo el oro?

Orden: **01 (OCR) → 02a (NER y cajas) → 02b (este, oro) → 02c (evaluación)**. Cada uno se corre entero y solo lee lo que dejaron los anteriores.
""")

md(r"""
## 0. Preparación
""")

code(r"""
%load_ext autoreload
%autoreload 2

import re

import pandas as pd
from IPython.display import display
""")

code(r"""
# Rutas y draw_boxes, que ya conozco del 01.
from proto.common import ARTIFACTS, PDFS, ROOT, draw_boxes

PAGE = ["pdf", "page"]
COLS = ["pdf", "page", "name"]
KEY = ["pdf", "page", "line", "name"]  # una mención: dónde está y cómo se llama
""")

md(r"""
## 1. P1 · ¿Qué me propone mi sistema?
Es la salida del 02a: los nombres que spaCy encontró (después de mis 3 filtros), con su caja y su posición en el texto (`start`, `end`). Es solo un punto de partida. Me quedo con `source == "spacy"`: las filas `propagated` (D4) no son propuesta de spaCy y, si entraran, el oro duplicaría a Elizabeth Park (57 filas en vez de 55).
""")

code(r"""
system = pd.read_csv(ARTIFACTS / "02a_name_boxes.csv", keep_default_na=False)
system = system.query("source == 'spacy'").reset_index(drop=True)
system.groupby(PAGE).size()
""")

code(r"""
system.head()
""")

code(r"""
len(system)
""")

md(r"""
**Lo que veo:** 52 nombres repartidos en las 5 páginas. Todavía no sé en qué renglón está cada uno; eso lo resuelvo en P2.
""")

md(r"""
## 2. P2 · ¿En qué renglón está cada nombre?
Para decir "falta el nombre del renglón 7" necesito numerar los renglones. Tesseract agrupa las palabras en líneas (`block, par, line`); yo las numero de arriba abajo por su altura `y`. Primero el texto de cada página con `add_offsets`, que ya probé en el 01.
""")

code(r"""
# El texto de cada página, como en el 02a (add_offsets por PDF, ahora en una función).
from proto.ocr import add_offsets_all

words = pd.read_csv(ARTIFACTS / "01_ocr_words.csv", keep_default_na=False)
raw = words  # las palabras tal como salen del 01, para probar add_lines más abajo
words, texts = add_offsets_all(words)
list(texts)
""")

code(r"""
# Una fila por renglón de Tesseract: su texto y su caja (la unión de sus palabras).
# El número de renglón es el orden por y dentro de la página.
words = words.rename(columns={"line": "tess_line"})
words["right"] = words["x"] + words["width"]
words["bottom"] = words["y"] + words["height"]

key = PAGE + ["block", "par", "tess_line"]
lines = words.groupby(key, as_index=False).agg(
    text=("text", " ".join),
    x=("x", "min"),
    y=("y", "min"),
    right=("right", "max"),
    bottom=("bottom", "max"),
)
lines["line"] = lines.groupby(PAGE)["y"].rank(method="first").astype(int)
lines["width"] = lines["right"] - lines["x"]
lines["height"] = lines["bottom"] - lines["y"]

# Cada palabra también sabe en qué renglón está.
words = words.merge(lines[key + ["line"]], on=key)
lines.query("pdf == 'meeting_minutes.pdf' and page == 0")[["line", "text"]].head(10)
""")

code(r"""
# Como función: add_lines() hace lo mismo y la reuso en el 02c. Compruebo que da igual
# (raw: las palabras del 01 con start y end, antes de renombrar nada).
from proto.ocr import add_lines

words_fn, lines_fn = add_lines(add_offsets_all(raw)[0])
pd.testing.assert_frame_equal(words_fn, words)
pd.testing.assert_frame_equal(lines_fn, lines)
""")

md(r"""
**Lo que veo:** el renglón 7 del acta es `- Elizabeth Park, Chief Financial Officer` (la lista de asistentes) y los renglones siguen el orden en que se leen. Ahora paso de una posición en el texto a su renglón: para cada posición busco la última palabra que empieza en ella o antes (`start <= pos`), que es la que la contiene. Lo hago con `pd.merge_asof`, que cruza cada fila con la clave más cercana hacia atrás dentro de su página.
""")

code(r"""
# Renglón de cada nombre: el de la última palabra que empieza en su posición o antes.
# merge_asof pide ordenar por la clave; asigno por índice para no mover las filas.
starts = words[["pdf", "page", "start", "line"]].sort_values("start")
by_start = system.sort_values("start")
system["line"] = pd.merge_asof(by_start, starts, on="start", by=PAGE).set_index(by_start.index)["line"]
system.query("pdf == 'meeting_minutes.pdf' and page == 0")[KEY]
""")

code(r"""
# Chequeo: el nombre de cada fila está escrito en el renglón que le asigné.
checked = system.merge(lines, on=PAGE + ["line"], suffixes=("", "_line"))
assert checked.apply(lambda r: r["name"] in r["text"], axis=1).all(), "un nombre no está en su renglón"
len(checked)
""")

md(r"""
**Lo que veo:** cada nombre de mi propuesta ya tiene su renglón y el nombre sí está en ese renglón. En el acta, Elizabeth Park solo aparece con renglón en la propuesta una vez (la 22). Esa es la pista de lo que sigue.
""")

md(r"""
## 3. P3 · ¿Qué encuentra una regex que spaCy no cubre?
Una regex no depende de spaCy, así que me sirve de pista para lo que spaCy pudo perder: toda secuencia de 2 o más palabras que empiezan en mayúscula, en la misma línea. Habrá mucho ruido (cargos, títulos). A cada candidato le pongo su renglón con el mismo `merge_asof`, y le quito el título ("Dr.", "Prof.") y el punto final, porque mi oro es el nombre sin título.
""")

code(r"""
# Candidatos de la regex con su renglón (con `starts` de P2).
pattern = r"[A-Z][\w'.-]*(?: [A-Z][\w'.-]*)+"
title = r"^(?:Dr|Prof|Mr|Mrs|Ms)\. "
regex = pd.DataFrame(
    [
        {"pdf": pdf, "page": page, "start": m.start(), "candidate": m.group()}
        for (pdf, page), text in texts.items()
        for m in re.finditer(pattern, text)
    ]
)
by_start = regex.sort_values("start")
regex["line"] = pd.merge_asof(by_start, starts, on="start", by=PAGE).set_index(by_start.index)["line"]
regex["name"] = regex["candidate"].str.replace(title, "", regex=True).str.rstrip(".")
len(regex)
""")

md(r"""
**¿Cuáles de esos candidatos ya tiene spaCy?** No basta con mirar el nombre: "Elizabeth Park" está 3 veces en el acta y spaCy solo acertó una. Si comparara solo por nombre, las 3 parecerían cubiertas. Lo que tiene que coincidir es **la mención: página, renglón y nombre**. Un ejemplo con ella:
""")

code(r"""
# Las 3 veces que la regex ve a Elizabeth Park, y si spaCy tiene esa mención.
elizabeth = regex.query("name == 'Elizabeth Park'")[KEY]
elizabeth.merge(system[KEY].assign(spacy_la_tiene=True), how="left").fillna(
    {"spacy_la_tiene": False}
)
""")

md(r"""
**Lo que veo:** spaCy solo tiene la del renglón 22. Las de los renglones 7 y 18 son menciones que la regex ve y spaCy no. Hago eso mismo para todos los candidatos. Si un mismo nombre sale dos veces en un renglón, `cumcount` las numera (0, 1) para que la segunda no se dé por cubierta con la primera.
""")

code(r"""
# hints = candidatos de la regex cuya mención (página, renglón, nombre) no tiene spaCy.
covered = system[KEY].assign(n=system.groupby(KEY).cumcount())
hints = (
    regex.assign(n=regex.groupby(KEY).cumcount())
    .merge(covered, on=KEY + ["n"], how="left", indicator=True)
    .query("_merge == 'left_only'")[KEY + ["candidate"]]
)
len(hints)
""")

md(r"""
**Lo que veo:** esas son las menciones que la regex ve y spaCy no. Son muchas porque la regex también agarra cargos, áreas y títulos. Las voy reduciendo paso a paso.
""")

code(r"""
# Paso a: todas las pistas. Paso b: quito las que están todo en mayúsculas
# (títulos de sección como "EXECUTIVE SUMMARY").
no_caps = hints[~hints["candidate"].str.isupper()]
pd.Series({"a) todas las pistas": len(hints), "b) sin mayúsculas": len(no_caps)})
""")

code(r"""
# Paso c: lo que queda, sin repetir nombres.
no_caps["name"].value_counts()
""")

md(r"""
**Lo que veo:** de lo que queda, casi todo son cargos ("Chief Financial Officer"), áreas ("Machine Learning Division"), lugares ("Southeast Asia"), organizaciones ("Stanford University") o frases partidas ("NovaTech Solutions. The"). Los únicos que son **personas** son "Elizabeth Park" y "Lucas Zimmermann". Esta decisión la tomo yo, a mano, leyendo la lista: no hay regla que la haga.
""")

code(r"""
# Lo que decido a mano: personas entre las pistas. Todo lo demás son cargos, áreas,
# lugares, organizaciones o frases.
hint_persons = ["Elizabeth Park", "Lucas Zimmermann"]
hint_found = hints.query("name in @hint_persons")
hint_found[KEY + ["candidate"]]
""")

md(r"""
**Lo que veo:** 3 menciones que la regex encuentra y spaCy no: Elizabeth Park en los renglones 7 y 18 del acta (página 0) y Lucas Zimmermann en el renglón 11 de la página 0 del reporte. Son candidatas a faltar; lo confirmo mirando cada página en P4.
""")

md(r"""
## 4. P4 · Reviso cada página
Una página por celda. Cada celda muestra la imagen con las cajas de mi sistema en rojo, los nombres de spaCy con su renglón y las pistas-persona de esa página. Leo la página **entera** de arriba abajo, no solo las pistas:
- un nombre de persona **sin caja roja** → va a `missing`;
- una caja roja sobre algo que **no es una persona** → va a `wrong`.
""")

for key, text in PAGE_MD.items():
    pdf, page = key.split("|")
    code(
        f"""
# Página {page} de {pdf}: imagen con las cajas de spaCy, sus nombres y las pistas-persona.
pdf, page = "{pdf}", {page}
names = system.query("pdf == @pdf and page == @page")
people = hint_found.query("pdf == @pdf and page == @page")
display(draw_boxes(PDFS[pdf], page, names, dpi=110), names[["line", "name"]], people[["line", "name"]])
"""
    )
    md(text)

md(r"""
## 5. P5 · Mis correcciones y el oro final
**Aquí registro lo que encontré al revisar.** Cada corrección dice dónde la vi:
- `missing`: `(pdf, página, línea, nombre como está en el papel)`, personas que mi sistema no encontró;
- `wrong`: lo que encontró y no es una persona (quita una aparición cada vez que lo escribo).

El oro siempre se recalcula desde la propuesta más mis correcciones, así que puedo correr estas celdas las veces que quiera sin duplicar nada.
""")

code(r"""
# Mis correcciones: (pdf, página, línea donde lo vi, nombre como está en el papel).
missing = [
    ("meeting_minutes.pdf", 0, 7, "Elizabeth Park"),
    ("meeting_minutes.pdf", 0, 18, "Elizabeth Park"),
    ("research_report.pdf", 0, 11, "Lucas Zimmermann"),
]
wrong = []
missing = pd.DataFrame(missing, columns=KEY[:2] + ["line", "name"])
""")

code(r"""
# De dónde salió: lo que anoté es exactamente lo que la regex había señalado en P3.
check = missing.merge(hint_found[KEY], on=KEY, how="outer", indicator=True)
assert check["_merge"].eq("both").all(), "una corrección no coincide con las pistas de P3"
len(check)
""")

code(r"""
# Chequeo: el nombre que anoté está en el renglón que dije.
seen = missing.merge(lines, on=PAGE + ["line"])
assert seen.apply(lambda r: r["name"] in r["text"], axis=1).all(), "un nombre añadido no está en su renglón"
len(seen)
""")

code(r"""
# Los renglones que anoté, marcados en su página.
for (pdf, page), boxes in seen.groupby(PAGE):
    display(f"{pdf} · página {page} · líneas {list(boxes['line'])}")
    display(draw_boxes(PDFS[pdf], page, boxes, dpi=110))
""")

md(r"""
Ahora el oro. Parto de la propuesta de spaCy, le quito lo que anoté en `wrong` y le añado `missing`. Cada fila lleva `source` para ver de dónde sale.
""")

code(r"""
# Aplico las correcciones a la propuesta.
SPACY, ADDED = "spaCy (02a)", "añadido (pista P3 + página)"
gold = system[COLS].assign(source=SPACY)
for pdf, page, name in wrong:
    hit = gold.query("pdf == @pdf and page == @page and name == @name")
    assert len(hit), f"no está en la propuesta: {(pdf, page, name)}"
    gold = gold.drop(hit.index[0])

gold = (
    pd.concat([gold, missing[COLS].assign(source=ADDED)])
    .sort_values(PAGE, kind="stable")
    .reset_index(drop=True)
)
len(system), len(missing), len(wrong), len(gold)
""")

code(r"""
# Lo que se añadió a la propuesta.
gold.query("source == @ADDED")
""")

code(r"""
# Por página: cuántos vienen de spaCy, cuántos añadí y el total.
by_page = gold.groupby(PAGE)["source"].value_counts().unstack(fill_value=0)
by_page = by_page[[SPACY, ADDED]].assign(total=lambda t: t.sum(axis=1))
by_page
""")

code(r"""
# Lo mismo en barras apiladas.
by_page[[SPACY, ADDED]].plot.bar(
    stacked=True,
    title="Oro por página: de spaCy y añadidos",
    ylabel="menciones",
    rot=20,
    ylim=(0, 18),
    figsize=(9, 4),
);
""")

md(r"""
**Lo que veo:** el oro tiene 55 menciones: 52 que ya tenía spaCy y 3 que añadí. Las 3 están en dos páginas (acta p0 y reporte p0); en las otras tres páginas el oro es igual a la propuesta.
""")

md(r"""
## 6. P6 · ¿Cómo sé que no se me escapó nada?
Cuento cada apellido de mi oro en las palabras del OCR del 01 (sin la puntuación pegada, como "Park,"). Si un apellido aparece más veces en el papel que en mi oro, hay una mención que no anoté.

Es un aviso (si falla, `assert` detiene el notebook antes de escribir el oro), no una prueba: no ve a una persona que yo haya omitido entera (eso lo cubren las pistas de P3 y mirar la página), y si el OCR leyera mal un apellido también saldría aquí; lo resolvería mirando la imagen.
""")

code(r"""
last = gold["name"].str.split().str[-1]
token = words["text"].str.strip(",.;:()")

in_ocr = words[token.isin(last)].assign(t=token).groupby(PAGE + ["t"]).size()
in_gold = gold.assign(t=last).groupby(PAGE + ["t"]).size()
diff = in_ocr.compare(in_gold)  # vacío = cuadra
assert diff.empty, "un apellido aparece en el papel más veces que en el oro"
diff
""")

md(r"""
La tabla sale vacía: cada apellido aparece en el papel tantas veces como en mi oro. Si la corro con `missing = []`, aparecen Park (3 en el OCR, 1 en el oro) y Zimmermann (1 y 0): el mismo hallazgo por otro camino.

## 7. P7 · Escribo el oro
Cuando termine de revisar las 5 páginas, cambio `REVIEWED = True` y corro la celda. Solo entonces se escribe el oro, con las columnas que necesito y nada más (sin `source`).
""")

code(r"""
REVIEWED = True

gold_path = ROOT / "eval" / "gold_names.csv"
if REVIEWED:
    gold[COLS].to_csv(gold_path, index=False)
gold_path.exists()
""")

code(r"""
gold_path
""")

md(r"""
## Si el volumen creciera: un modelo de visión como segundo anotador
Con 5 páginas, etiquetar yo es lo más confiable y lo puedo defender. Con cientos de páginas no escala. Entonces agregaría un **modelo de visión** que lea cada imagen y proponga nombres, como un segundo anotador independiente de spaCy y del OCR:
- **local con Ollama** (por ejemplo `qwen2.5vl:7b`, que cabe en una GPU de 8 GB): sin llaves y sin enviar documentos fuera;
- o una **API externa**, con la llave en `.env` (nunca en el notebook) y sabiendo que los documentos salen de la máquina.

Yo seguiría revisando una muestra, y mediría el acuerdo entre el modelo y mis etiquetas antes de confiar en él.

## Mis respuestas
- **P1** ¿Qué me propone mi sistema? ...
- **P2** ¿En qué renglón está cada nombre? ...
- **P3** ¿Qué encuentra la regex que spaCy no cubre, y cuáles son personas? ...
- **P4** ¿Qué faltaba o sobraba en cada página? ...
- **P5** ¿Cuál es mi oro final y de dónde sale cada fila? ...
- **P6** ¿Cómo sé que no se me escapó nada? ...
- **P7** ¿Cuándo escribo el oro? ...

## Lo que tengo que poder explicar
1. Por qué el oro no es la salida de spaCy: la propuesta se corrige mirando cada página.
2. Por qué comparo menciones por página, renglón y nombre, y no solo por nombre (Elizabeth Park).
3. Cómo se pasa de decenas de pistas a 3 personas: quito mayúsculas y decido a mano; ninguna regla lo hace por mí.
4. Cómo registro correcciones sin perder trazabilidad (propuesta + `missing` + `wrong` + columna `source`).
5. Cuándo y cómo usaría un modelo de visión como segundo anotador.
""")


def to_cell(kind, src):
    cell = {"cell_type": kind, "id": uuid.uuid4().hex[:8], "metadata": {}, "source": src}
    if kind == "code":
        cell.update(execution_count=None, outputs=[])
    return cell


nb = {
    "cells": [to_cell(kind, src) for kind, src in cells],
    "metadata": {
        "kernelspec": {
            "display_name": "cuesta (uv 3.12)",
            "language": "python",
            "name": "cuesta",
        },
        "language_info": {"name": "python", "version": "3.12"},
    },
    "nbformat": 4,
    "nbformat_minor": 5,
}
with open(sys.argv[1], "w", encoding="utf-8") as f:
    json.dump(nb, f, ensure_ascii=False, indent=1)
print(len(cells))
