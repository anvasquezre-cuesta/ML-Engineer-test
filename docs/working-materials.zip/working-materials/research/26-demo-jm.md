# 26 · Tutorial de demo (solo para Jeison, no va al PR)

Cómo lanzar el servicio y qué enseñar, en orden, en unos 10-12 minutos. Todos los comandos son para PowerShell.

## 0. Antes de la demo (15 minutos antes)

1. **Ollama arriba y el modelo caliente.** La primera llamada tarda unos 50 s, así que no conviene que pase delante del entrevistador.
   ```powershell
   & "$env:LOCALAPPDATA\Programs\Ollama\ollama.exe" run qwen2.5:7b-instruct "hi"
   ```
   Si responde algo, está listo. Si da error de conexión, abre Ollama desde el menú Inicio y repite.
2. **Una base vectorial limpia para la demo**, para no mezclar documentos de pruebas anteriores:
   ```powershell
   cd C:\Users\Jeikosd\Documents\jeikosd\parterns_test_ML\ML-Engineer-test
   Remove-Item -Recurse -Force "$env:TEMP\demo-chroma" -ErrorAction SilentlyContinue
   $env:CHROMA_PATH = "$env:TEMP\demo-chroma"
   ```
3. **Arranca el servicio en esa misma terminal**, para que tome `CHROMA_PATH`:
   ```powershell
   uv run uvicorn app.main:app
   ```
   Espera `Uvicorn running on http://127.0.0.1:8000`. Deja la terminal visible: sus logs JSON también se enseñan.
4. **Calienta los modelos.** Haz una ingesta del memo antes de la demo (paso 4 de abajo). La primera carga de MiniLM tarda cerca de un minuto. Luego puedes volver a ingestarlo en vivo, porque reemplaza sus chunks y no los duplica.
5. **Pestañas abiertas en el navegador:**
   - http://127.0.0.1:8000/health
   - http://127.0.0.1:8000/docs (Swagger: probar endpoints sin escribir comandos)
   - http://127.0.0.1:8000/viewer/

## 1. El problema, en 30 segundos
"Compliance necesita cada nombre **con su ubicación exacta** en la página, para poder verificarlo. Mi servicio hace OCR, detecta personas, devuelve su caja en puntos PDF y la compara con una lista. Además responde preguntas sobre los documentos, citando fuentes."

## 2. Salud y contrato (1 min)
- `/health` → `{"status":"ok"}`.
- `/docs`: los 4 endpoints y sus esquemas. "El contrato de `schemas.py` está fijo: no lo cambié."

## 3. Visor de auditoría: lo más visual (3 min)
En `/viewer/`:
1. **PDF:** `sample_pdfs\company_memo.pdf`. **Names:**
   ```json
   [{"first_name":"Robert","last_name":"Chen"},{"first_name":"María","last_name":"García"},{"first_name":"Juan","last_name":"Pérez"}]
   ```
   Pulsa **Extract**.
2. Qué decir:
   - "8 cajas, cada una sobre un nombre. Las coordenadas vienen de la API en puntos PDF; el visor solo las multiplica por la escala."
   - "En verde, las coincidencias: María García con acento coincide con Maria Garcia del OCR, con score 1.0, porque normalizo acentos y mayúsculas. Juan Pérez no está en el documento y no aparece."
   - "Las organizaciones y los lugares no salen: solo personas."
3. **`meeting_minutes.pdf`** con `[]`: "Page 1 of 2" y "Page 2 of 2". "El OCR procesa todas las páginas, también la primera." Baja con el scroll.
4. **Error controlado:** sube `%TEMP%\falso.pdf` (créalo antes con `Set-Content $env:TEMP\falso.pdf "no pdf"`). Sale un 422 legible. "Valido por contenido, no por la extensión."

## 4. RAG: ingesta y pregunta (3 min)
En **http://127.0.0.1:8000/viewer/ask.html** (o con el enlace "Ask the documents" del visor):
1. **Ingest:** elige los 3 PDFs de `sample_pdfs` a la vez (Ctrl + clic) y pulsa *Ingest*. Sale una línea por archivo, por ejemplo "company_memo.pdf: 2 chunks stored".
   "Chunks por página, que nunca cortan una palabra. El ID es el hash del PDF más página y chunk: un segundo documento no pisa al primero."
2. **Ask:** "Who was promoted to Vice President of Engineering?". Responde Robert Chen, con fuentes "company_memo.pdf · page 1 · chunk 0".
   "Las fuentes las construye el código con los chunks recuperados. Nunca salen del texto del LLM, así que no pueden ser inventadas."
3. **Abstención:** "Who won the 2022 football World Cup?" y "What is the salary of the Chief Data Scientist?". Las dos dan "I don't know based on the documents." y "No sources (the service abstained)".
4. Para enseñar el JSON crudo, `/docs` (Swagger) sigue disponible.

**Preguntas de control** (de `eval/questions.json`, con respuesta conocida; hay que ingestar antes los 3 PDFs):

| Pregunta | Respuesta esperada | Fuente esperada | Qué demuestra |
|---|---|---|---|
| Who presented the plan to move the infrastructure to the cloud? | Alexander Popov | meeting_minutes.pdf · page 2 | Paráfrasis (búsqueda semántica), documento correcto entre 3 y página 2 |
| Which city is the office where Maria Garcia used to lead the UX team? | London | company_memo.pdf · page 1 | Respuesta que exige leer una frase, no copiar un nombre |
| At what time was the meeting adjourned? | 12:25 PM | meeting_minutes.pdf · page 2 | Dato puntual al final de un documento de 2 páginas |
| Who won the 2022 football World Cup? | "I don't know based on the documents." | No sources | Abstención: no inventa |

- Si la primera sale bien, el RAG funciona de punta a punta.
- Las fuentes listan los 5 chunks recuperados (`TOP_K`), y el de la respuesta tiene que estar entre ellos.
- Si una pregunta responde "I don't know…" y el log del servidor dice `"chunks": 0`, la base está vacía: falta ingestar, o el servidor se arrancó con otra `CHROMA_PATH`.
   "Hay dos puertas. Si nada recuperado supera `MIN_SCORE = 0.20`, ni siquiera llamo al LLM. Si sí lo supera, el prompt obliga al modelo a decir esa frase exacta cuando el contexto no tiene la respuesta."

## 5. Resiliencia en vivo (1-2 min, opcional pero impresiona)
1. Cierra Ollama: icono de la bandeja → *Quit Ollama*.
2. Repite la pregunta de Robert Chen. Da **503** en pocos segundos.
   "El LLM está caído: reintento con backoff y devuelvo 503, no un 500 ni un cuelgue. Un timeout daría 504 y una respuesta inutilizable, 502."
3. Señala en la terminal los intentos y el log JSON con `status: 503`.
4. Vuelve a abrir Ollama. Antes de la siguiente pregunta, recalienta el modelo con el comando del paso 0.

## 6. Observabilidad (30 s)
En la terminal: cada request deja una línea JSON con `request_id`, método, ruta, status y ms, y cada pipeline otra con sus conteos. "Nunca logueo nombres ni texto de documentos."

## 7. Calidad: tests y CI (1-2 min)
En otra terminal:
```powershell
cd C:\Users\Jeikosd\Documents\jeikosd\parterns_test_ML\ML-Engineer-test
uv run pytest tests/unit -q
uv run pytest -q -k "ac_ask" -v
```
- "Unitarios sin modelos ni red: Tesseract, spaCy y el LLM se sustituyen por fakes con inyección de dependencias."
- "Cada test lleva el nombre de un criterio de la spec, `test_ac_<área>_<nn>`."
- Enseña la pestaña **Actions** del fork en verde (cuando exista).

## 8. Diseño (si preguntan)
Abre `DESIGN.md`:
- **Escalado:** 0.8 s por página de OCR → 4500 páginas por hora por proceso → cola con workers.
- **Por qué 1 worker:** Chroma embebido.
- **Peor caso del LLM:** ~184 s.
- **Ruteo de modelos:** con reglas antes que un router entrenado.

Preguntas preparadas: `research/20-preguntas-entrevista.md` (1-67).

## Si algo falla en vivo
| Síntoma | Causa | Arreglo |
|---|---|---|
| `/` da 404 | la raíz no existe | ir a `/viewer/` o `/docs` |
| `/api/ask` da 503 | Ollama cerrado | abrirlo y recalentar el modelo |
| La primera ingesta tarda ~1 min | carga de MiniLM | calentar antes (paso 0.4) |
| El visor no dibuja nada | sin red hacia cdnjs | F12 → Console; la página necesita internet |
| La respuesta incluye documentos viejos | otra `CHROMA_PATH` | arrancar desde la terminal donde se fijó `$env:CHROMA_PATH` |
| Puerto 8000 ocupado | un uvicorn anterior sigue vivo | `Get-NetTCPConnection -LocalPort 8000 -State Listen \| % { Stop-Process -Id $_.OwningProcess -Force }` |

Para terminar: **Ctrl + C** en la terminal del servidor.
