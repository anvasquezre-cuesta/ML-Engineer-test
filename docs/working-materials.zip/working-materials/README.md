# Jeison Mesa · Document intelligence take-home: working materials

The pull request is the deliverable. This archive adds the material behind it, for reviewers who want to see how each decision was reached.

| Folder | What it is |
|---|---|
| `notebooks/` | One notebook per stage (OCR, NER and boxes, gold review, evaluation, fuzzy, extract end-to-end, RAG ingest, RAG answers). `proto/` holds the prototype code; `artifacts/` holds the executed copies and the CSVs that the numbers in `DECISIONS.md` come from. To run them, copy the folder into the repo root and install with `uv sync --group notebooks`. |
| `research/` | Notes in Spanish: literature and package reviews, plans, metrics and the decision log (`DECISIONS-LOG.md`). |
| `papers/` | `INDEX.md` and one short analysis per paper (`analysis/`). The papers themselves are not included; each analysis cites its source. |
| `tasks/` | One folder per slice: research, evaluation gates, plan, reviews and the explanation of each acceptance criterion. |
| `.claude/`, `CLAUDE.md` | The Claude Code setup used as a pair-programmer: subagent roles, rules, skills, hooks (git writes blocked for the AI, secrets never read) and the verify script. |

Most notes are in Spanish, my working language; the code and the PR documents are in English.
