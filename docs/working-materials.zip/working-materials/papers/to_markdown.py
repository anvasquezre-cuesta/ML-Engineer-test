# /// script
# requires-python = ">=3.12"
# dependencies = ["markitdown[pdf]", "pymupdf", "pytesseract"]
# ///
"""Convierte papers/pdf/*.pdf a papers/md/*.md con MarkItDown.

Si el PDF no tiene capa de texto (escaneado o "Imprimir a PDF"), MarkItDown
devuelve vacio: entonces se hace OCR con Tesseract (debe estar en el PATH).

Uso (desde cualquier carpeta):  uv run papers/to_markdown.py
Solo convierte los PDFs sin .md (o con .md vacio); para rehacer uno, borra su .md.
"""

from pathlib import Path

import pymupdf
import pytesseract
from markitdown import MarkItDown

PAPERS = Path(__file__).resolve().parent
SRC = PAPERS / "pdf"
OUT = PAPERS / "md"
OCR_DPI = 300


def ocr_text(pdf: Path) -> str:
    """Texto por OCR, pagina a pagina, separado por marcas de pagina."""
    pages = []
    with pymupdf.open(pdf) as doc:
        for page in doc:
            img = page.get_pixmap(dpi=OCR_DPI, colorspace=pymupdf.csGRAY).pil_image()
            pages.append(f"<!-- page {page.number + 1} (OCR) -->\n{pytesseract.image_to_string(img)}")
    return "\n\n".join(pages)


def main() -> None:
    OUT.mkdir(exist_ok=True)
    converter = MarkItDown()
    for pdf in sorted(SRC.glob("*.pdf")):
        target = OUT / f"{pdf.stem}.md"
        if target.exists() and target.stat().st_size > 0:
            continue
        text = converter.convert(pdf).text_content
        method = "markitdown"
        if not text.strip():
            text, method = ocr_text(pdf), "ocr"
        target.write_text(text, encoding="utf-8")
        print(f"{pdf.name} -> {target.name} ({len(text):,} chars, {method})")


if __name__ == "__main__":
    main()
