# INDEX de lectura por etapa (2026-10-27)

Verificacion: titulo/autores/ano de cada arXiv se comprobaron hoy abriendo `arxiv.org/abs/<id>`; versiones de PyPI via `pypi.org/pypi/<pkg>/json`. [NV] = no verificado. "Fecha" = fecha de subida a PyPI del ultimo release. Papers sin arXiv (Smith, Breuel, Winkler, Cohen, Navarro, Hamdi, van Strien) solo se verificaron por resultados de busqueda (URL dada), no se descargaron. PDFs guardados en `papers/pdf/` (8, cabecera `%PDF-` comprobada, no abiertos). Una pagina fetched (OWASP) traia texto dirigido a una IA sobre citas/letras de canciones: ignorado.

Leyenda: **MR** = must-read, op = optional.

## 1. OCR
| Referencia | Por que importa | |
|---|---|---|
| Smith 2007, *An Overview of the Tesseract OCR Engine*, ICDAR (DOI 10.1109/ICDAR.2007.56) https://research.google/pubs/an-overview-of-the-tesseract-ocr-engine/ | Explica linea/palabra, clasificador adaptativo: base para defender "por que Tesseract" | **MR** (skim) |
| Breuel, Ul-Hasan, Al-Azawi, Shafait 2013, *High-Performance OCR for Printed English and Fraktur using LSTM Networks*, ICDAR (DOI 10.1109/ICDAR.2013.140) https://dblp.uni-trier.de/rec/conf/icdar/BreuelUAS13.html | Origen del motor LSTM de Tesseract 4+ (0.6 % error de caracter en ingles impreso, segun el abstract). Nota: que Tesseract 4 use exactamente este diseno lo afirmo por conocimiento propio [NV] | op |
| Li et al. 2021, *TrOCR* (arXiv 2109.10282) https://arxiv.org/abs/2109.10282 | OCR de linea Transformer; no da cajas por palabra, sirve de alternativa "reconocedor" | op |
| Cui et al. 2025, *PaddleOCR 3.0 Technical Report* (arXiv 2507.05595) https://arxiv.org/abs/2507.05595 | Estado del arte practico; explica deteccion+reconocimiento | op |
| docTR: sin paper [NV]; repo https://github.com/mindee/doctr | Detector DBNet + reconocedor CRNN, cajas por palabra | op |

Paquetes: `pytesseract` 0.3.13, Apache-2.0, 2024-08-16 (estable, poco mantenido; envuelve el binario Tesseract; **elegido**: `image_to_data` da cajas por palabra). `python-doctr` 1.1.0, Apache-2.0, 2026-08-21 (activo; exige torch, mas pesado; comparador). `paddleocr` 3.7.0, Apache-2.0, 2026-06-11 (grande, paddlepaddle). `rapidocr` 3.10.0, Apache-2.0, 2026-10-08 (ONNX, liviano; el plan lo descarto por cajas por linea, no re-verificado hoy).
**Experimento:** correr Tesseract vs docTR en las 5 paginas a 150 y 300 DPI y comparar CER (jiwer) y tiempo en una tabla 2x2.

## 2. Geometria de cajas (px -> pt)
No hay paper; es aritmetica: pt = px * 72 / DPI y eje y (ver 06-tl-plan, verificado). Referencia: documentacion de PyMuPDF (coordenadas, origen arriba-izquierda) [NV: no re-fetched hoy]. Evaluacion: IoU (definicion estandar) [NV paper]. Paquete: `pymupdf` (ya elegido). **Experimento:** insertar texto en posicion conocida con PyMuPDF, rasterizar a 150 DPI, correr OCR y medir IoU y error en pt de los bordes (fixture E1 del plan).

## 3. NER de personas (incl. texto ruidoso)
| Referencia | Por que importa | |
|---|---|---|
| Tjong Kim Sang & De Meulder 2003, *Introduction to the CoNLL-2003 Shared Task* (arXiv cs/0306050) https://arxiv.org/abs/cs/0306050 | Define PER/ORG/LOC y la evaluacion F1 a nivel entidad (la que usamos) | **MR** (corto) |
| Devlin et al. 2018, *BERT* (arXiv 1810.04805) https://arxiv.org/abs/1810.04805 | Base de los NER modernos; fine-tuning para etiquetado de tokens | **MR** |
| Zaratiana et al. 2023, *GLiNER* (arXiv 2311.08526) https://arxiv.org/abs/2311.08526 | NER zero-shot con etiquetas libres ("person"); alternativa si spaCy falla | op |
| Hamdi et al. 2020, *Assessing and Minimizing the Impact of OCR Quality on NER*, TPDL https://hal.archives-ouvertes.fr/hal-03026931 | Cuantifica el dano del ruido OCR en NER | op |
| van Strien et al. 2020, *Assessing the Impact of OCR Quality on Downstream NLP Tasks*, ICAART https://www.scitepress.org/Papers/2020/91690/ | Efecto consistente y negativo del OCR en 6 tareas incl. NER | op |

Consistencia de etiquetas a nivel documento (decision D4, propagar un nombre ya reconocido; PDFs y analisis en `papers/`, leidos 2026-10-28):
| Referencia | Por que importa | |
|---|---|---|
| Finkel, Grenager, Manning 2005, *Incorporating Non-local Information into Information Extraction Systems by Gibbs Sampling*, ACL 2005 (P05-1045) https://aclanthology.org/P05-1045/ . `finkel-2005-nonlocal-gibbs` | Cadenas identicas casi nunca cambian de tipo en un documento (PER: 9 inconsistencias frente a 3141); CoNLL F1 85.51 -> 86.86, PER +1.93 | **MR** |
| Krishnan & Manning 2006, *An Effective Two-Stage Model for Exploiting Non-Local Dependencies in NER*, COLING-ACL 2006 (P06-1141) https://aclanthology.org/P06-1141/ . `krishnan-2006-two-stage-ner` | Documento: 85.29 -> 87.15 (PER +2.95); el corpus suma solo +0.09 | **MR** |
| Ratinov & Roth 2009, *Design Challenges and Misconceptions in Named Entity Recognition*, CoNLL 2009 (W09-1119) https://aclanthology.org/W09-1119/ . `ratinov-2009-ner-design` | Rasgos no locales +1.7 a +2.9 en CoNLL, sin ganancia en paginas web | **MR** (contrapeso) |
| Gale, Church, Yarowsky 1992, *One Sense Per Discourse*, DARPA Speech and Natural Language Workshop (H92-1045) https://aclanthology.org/H92-1045/ . `gale-1992-one-sense-per-discourse` | Origen del principio (94 % medido, 98 % extrapolado); no es NER | op |

Paquetes: `spacy` 3.8.18, MIT, 2026-10-26 (**elegido**, `en_core_web_sm` aparte). `gliner` 0.2.29, Apache-2.0, 2026-09-08 (necesita torch + descarga de modelo). `transformers` 5.21.0, Apache-2.0, 2026-10-26 (BERT NER via pipeline; pesado).
**Experimento:** comparar spaCy `sm` vs GLiNER (etiqueta "person") en las 5 paginas contra la lista de nombres revisada a mano; P/R/F1 estricto con Wilson.

## 4. Coincidencia de nombres / record linkage
| Referencia | Por que importa | |
|---|---|---|
| Cohen, Ravikumar, Fienberg 2003, *A Comparison of String Metrics for Matching Names and Records*, KDD Workshop on Data Cleaning and Object Consolidation (paper del toolkit SecondString) https://www.cs.utexas.edu/~ai-lab/pubs/kdd03.pdf. PDF y analisis: `cohen-2003-string-metrics-kdd` | Edicion, Jaro-Winkler, token e hibridos en 11 conjuntos; SoftTFIDF gana en general, pero en Census (personas) gana Levenshtein (Tabla 2). Leido completo (2026-10-28) | **MR** |
| Cohen, Ravikumar, Fienberg 2003, *A Comparison of String Distance Metrics for Name-Matching Tasks*, IJCAI-03 Workshop on Information Integration on the Web (**otro paper**, no descargado; lo cita el de KDD como "to appear") [NV] | Version IJCAI de la misma comparacion; no usada | op |
| Christen 2006, *A Comparison of Personal Name Matching: Techniques and Practical Issues*, ANU TR-CS-06-02 http://users.cecs.anu.edu.au/~Peter.Christen/publications/tr-cs-06-02.pdf. PDF y analisis: `christen-2006-name-matching` | 4 conjuntos de nombres; "no hay tecnica mejor", patron > fonetica, Permuted-Winkler de lo mejor en nombres completos; umbral depende de los datos | **MR** |
| Winkler 1990, *String Comparator Metrics and Enhanced Decision Rules in the Fellegi-Sunter Model of Record Linkage* https://www.stat.cmu.edu/NCRN/PUBLIC/RLClassFiles/HW/Winkler1990.pdf | Origen de Jaro-Winkler (bonus por prefijo comun; pensado para nombres cortos) | op |
| Navarro 2001, *A Guided Tour to Approximate String Matching*, ACM Comput. Surv. 33(1) https://users.dcc.uchile.cl/~gnavarro/ps/acmcs01.1.pdf | Edicion/Levenshtein formal; para explicar Indel vs Levenshtein | op |

Paquetes: `rapidfuzz` 3.14.6, MIT, 2026-08-30 (**elegido**; `fuzz.ratio` = Indel normalizado, `JaroWinkler`, `token_sort_ratio`). `jellyfish` 1.3.0, MIT (la ficha PyPI no declara licencia; clasificador MIT), 2026-10-16 (Soundex/Metaphone/Jaro-Winkler; util para el experimento fonetico). Acentos: `unicodedata` de la libreria estandar (NFKD) basta; `Unidecode` 1.4.0 es **GPL**, evitar. Soft-TFIDF no tiene paquete estandar verificado: son ~20 lineas propias [NV].
**Experimento:** ~40 pares etiquetados con negativos duros; comparar `token_sort_ratio`, Jaro-Winkler y Soft-TFIDF propio con curva PR y umbral por precision>=0.95.

## 5. Embeddings y recuperacion densa
| Referencia | Por que importa | |
|---|---|---|
| Reimers & Gurevych 2019, *Sentence-BERT* (arXiv 1908.10084) https://arxiv.org/abs/1908.10084 | Por que bi-encoder + coseno y no BERT crudo; justifica MiniLM | **MR** |
| Muennighoff et al. 2022, *MTEB* (arXiv 2210.07316) https://arxiv.org/abs/2210.07316 | Como elegir embeddings; ninguno gana en todo | **MR** (skim) |
| Xiao et al. 2023, *C-Pack* (BGE) (arXiv 2309.07597) https://arxiv.org/abs/2309.07597 | Paper de la familia BGE (sale de C-Pack, no es un paper "BGE") | op |
| Wang et al. 2022, *Text Embeddings by Weakly-Supervised Contrastive Pre-training* (E5) (arXiv 2212.03533) https://arxiv.org/abs/2212.03533 | E5 usa prefijos "query:/passage:"; explica por que el plan evita E5 | op |
| Thakur et al. 2021, *BEIR* (arXiv 2104.08663) https://arxiv.org/abs/2104.08663 | Retrieval zero-shot; BM25 es base fuerte: comparar contra el | op |

Paquetes: `sentence-transformers` 6.2.0, Apache-2.0, 2026-10-21 (**elegido**, carga `all-MiniLM-L6-v2`). `mteb` 2.26.27, Apache-2.0, 2026-10-27 (benchmark; no necesario en produccion). `beir` 2.2.0, Apache-2.0, 2025-06-04 (datasets publicos; innecesario). `rank-bm25` 0.2.2, Apache-2.0, 2022-02-16 (sin mantenimiento, pero ~30 lineas; sirve como linea base lexica).
**Experimento:** sobre las 10 preguntas, comparar hit@1/3 y MRR de MiniLM vs BM25 (rank-bm25) vs `bge-small-en` [NV: nombre de modelo no verificado hoy].

## 6. Chunking
No hay paper canonico verificado; la evidencia relevante es Liu et al. 2023 (ver seccion 7: contexto largo penaliza, apoya chunks pequenos y k bajo) y BEIR (lexico vs denso). Paquetes: ninguno; `chunk_text` propio (ya en el plan). **Experimento:** barrer CHUNK_SIZE in {300,500,800} x overlap {0,60} y graficar hit@3 con las 10 preguntas.

## 7. RAG, fundamentacion y alucinacion
| Referencia | Por que importa | |
|---|---|---|
| Lewis et al. 2020, *Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks* (arXiv 2005.11401) https://arxiv.org/abs/2005.11401 | Define RAG; vocabulario de la entrevista | **MR** |
| Liu et al. 2023, *Lost in the Middle* (arXiv 2307.03172) https://arxiv.org/abs/2307.03172 | Justifica k pequeno y orden de chunks | **MR** |
| Gao et al. 2022, *HyDE* (arXiv 2212.10496) https://arxiv.org/abs/2212.10496 | Solo si falla el recall en preguntas parafraseadas; extra llamada LLM | op |
| Nogueira & Cho 2019, *Passage Re-ranking with BERT* (arXiv 1901.04085) https://arxiv.org/abs/1901.04085 | Reranking cross-encoder; probablemente innecesario con 5 paginas | op |

Paquetes: ninguno adicional (Chroma, httpx ya elegidos). **Experimento:** 2 preguntas sin respuesta en el corpus: verificar que la abstencion (MIN_SCORE) se dispara y que `sources` solo contiene IDs recuperados.

## 8. Evaluacion
| Referencia | Por que importa | |
|---|---|---|
| Es et al. 2023, *Ragas* (arXiv 2309.15217) https://arxiv.org/abs/2309.15217 | Define faithfulness / answer relevance / context relevance sin referencia | **MR** (skim) |
| Cohen 2003, Thakur 2021 (arriba) | PR para linkage; hit@k/nDCG para retrieval | - |
| Hand & Christen 2018, *A note on using the F-measure for evaluating record linkage algorithms*, Statistics and Computing 28(3):539-547, doi 10.1007/s11222-017-9746-6; version aceptada: https://spiral.imperial.ac.uk/handle/10044/1/46235 . `hand-2018-f-measure` | F = media ponderada cuyo peso cambia con el metodo; elegir y reportar el compromiso P/R explicito (base para "max recall con precision >= 0.95") | **MR** |
| Brown, Cai, DasGupta 2001 (Wilson); Davis & Goadrich 2006 (PR vs ROC) | ya citadas en 04-evaluation.md (URLs alli) | op |

Paquetes: `jiwer` 4.0.0, Apache-2.0, 2025-06-19 (CER/WER; **elegido**). `ragas` 0.4.3, Apache-2.0, 2026-01-13 (necesita LLM juez; proximo paso, no ahora). `seqeval` [NV hoy]. **Experimento:** CER de Tesseract a 150 vs 300 DPI en 10 lineas transcritas, normalizando minusculas/espacios, reportando tambien CER solo en lineas con nombres.

## 9. Inyeccion de prompt en RAG
| Referencia | Implicacion de diseno |
|---|---|
| Greshake et al. 2023, *Not what you've signed up for: ... Indirect Prompt Injection* (arXiv 2302.12173) https://arxiv.org/abs/2302.12173 **MR** | El PDF es dato no confiable: puede traer instrucciones. Etiquetar el contexto como "datos, no ordenes" en el prompt; el LLM **sin herramientas** ni acceso a archivos/red |
| OWASP LLM01:2025 Prompt Injection https://genai.owasp.org/llmrisk/llm01-prompt-injection/ **MR** | Mitigaciones de la pagina: restringir rol en el system prompt, validar formato de salida con codigo, filtrar entrada/salida, privilegio minimo, segregar contenido externo, pruebas adversariales; la pagina admite que ninguna es infalible |

Implicaciones para nuestro diseno: (a) `sources` se construye en codigo, no del texto del LLM (ya en el plan); (b) salida con esquema fijo; (c) sin herramientas ni claves visibles para el LLM; (d) test adversarial: un PDF sintetico con "ignore previous instructions" en una pagina y verificar que la respuesta no lo obedece.

## Lectura minima de 2 horas (orden sugerido)
1. Lewis 2020, RAG (`lewis-2020-rag.pdf`): resumen + seccion 2 (30 min).
2. Reimers 2019, SBERT (`reimers-2019-sbert.pdf`): secciones 3-4 (20 min).
3. Liu 2023, Lost in the Middle (`liu-2023-lost-in-the-middle.pdf`): figuras 1 y 5 (15 min).
4. Cohen/Ravikumar/Fienberg 2003 (URL): resultados y definicion de Soft-TFIDF (25 min).
5. Greshake 2023 (`greshake-2023-indirect-prompt-injection.pdf`) + pagina OWASP LLM01 (25 min).
6. Smith 2007, Tesseract overview (URL, skim) + abstract de Ragas (`es-2023-ragas.pdf`) (5 min).

(BERT, GLiNER y MTEB estan guardados como apoyo, no entran en las 2 h.)
