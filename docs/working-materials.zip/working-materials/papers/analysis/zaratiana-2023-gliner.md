# GLiNER: NER generalista con codificadores bidireccionales (Zaratiana et al., 2023)
**Veredicto:** CITAR — solo para justificar en DESIGN.md/DECISIONS.md por que GLiNER queda como alternativa y no entra al core.

## Resumen (max 5 bullets)
- Modelo compacto de NER de tipo abierto: un codificador bidireccional (DeBERTa-v3) recibe las etiquetas de entidad como prompt y puntua cada span contra cada tipo con producto punto + sigmoide (Fig. 1-2, Sec. 2).
- Tamanos: S 50M, M 90M, L 0.3B parametros. Promedio zero-shot en el benchmark OOD (Tabla 1): 52.7 / 55.4 / 60.9; ChatGPT 47.5, UniNER-13B 55.6.
- Extrae en paralelo (no genera token a token como los LLM); limita la longitud de span a K=12 y decodifica en O(n log n) (Sec. 2).
- En 20 datasets zero-shot (Tabla 2): CoNLL03 con GLiNER-L 64.6 frente a 72.2 de UniNER-7B y 52.5 de ChatGPT; OntoNotes 32.2.
- El paper no mide latencia ni memoria en CPU, no prueba texto con ruido de OCR y no reporta resultados solo de PERSON.

## Que nos sirve (concreto)
- **DECISIONS.md (alternativa descartada):** el argumento "modelo pequeno, no LLM" es real (Sec. 1, Conclusion), pero 50-300M parametros son mucho mas que `en_core_web_sm`; el paper respalda la afirmacion de tamano, no de latencia (no la mide). Hay que decir que la latencia/peso es nuestra estimacion, no del paper.
- **Extension documentada:** el tipo "person" se pide como etiqueta en lenguaje natural y la salida son spans (inicio, fin, tipo) (Fig. 1); encajaria detras del mismo Protocol de NER sin tocar el resto. Una frase en DESIGN.md.
- **Honestidad sobre zero-shot:** en CoNLL03 el zero-shot de GLiNER-L (64.6) queda lejos de los ~90 de los modelos supervisados; si se usara, seria con datos propios o ajuste. No es un reemplazo gratuito de spaCy.

## Que no nos sirve / limitaciones para nuestro caso
- Anade dependencia (`gliner` + torch + pesos de HuggingFace) no aprobada en 14-revision-plan.md seccion 4; contradice el objetivo de poco codigo.
- Sin evidencia sobre texto OCR ni sobre ruido; sin comparacion con spaCy `sm/md/lg`; benchmark en F1 de coincidencia exacta de muchos tipos, no de personas.
- Su ventaja (tipos arbitrarios) no se usa: solo necesitamos PERSON.
- Casi todo el trabajo es entrenamiento (Pile-NER), negativos y ablaciones de backbone: irrelevante para el servicio.

## Acciones propuestas (max 3)
1. (0.2 h, DECISIONS.md) Fila "GLiNER como alternativa, no core": razon = dependencia nueva y peso; citar Tabla 1 (tamanos) y aclarar que latencia no esta en el paper.
2. (0.1 h, DESIGN.md) Una linea en "Extensiones": intercambiar el NER detras del Protocol, con GLiNER-S (50M) como candidato.
3. (Opcional, 1.5-2 h, notebook 02, solo tras terminar el core y con aprobacion de la dependencia) Comparar GLiNER-S contra spaCy sm en el oro de 55. No recomendado dentro del presupuesto de 8-10 h.

## Citas utiles
- GLiNER-M (90M) "achieves comparable results to UniNER-13B (55 F1 for both)... 140 times smaller" (Sec. 4.1, Tabla 1).
- "ChatGPT significantly lags behind fine-tuned models for NER" en zero-shot (Sec. 4.1, Tabla 2).
- Paralelismo frente a la generacion secuencial de los LLM (Resumen, Fig. 1); longitud maxima de span K=12 (Sec. 2).
- Zero-shot CoNLL03: GLiNER-L 64.6, UniNER-7B 72.2, ChatGPT 52.5 (Tabla 2).
- Conclusion: alternativa "more resource-efficient" para entornos con computo limitado (Sec. 7).
