# Extraccion de nombres de persona en texto OCR ruidoso (Packer et al., 2010)
**Veredicto:** USAR — como referencia metodologica (protocolo de evaluacion, riesgos del OCR, justificacion de reglas simples), no como implementacion.

## Resumen (max 5 bullets)
- Compara tres extractores de personas (diccionario, regex, MEMM entrenado en CoNLL) sobre OCR "salvaje": 12 titulos historicos, WER muy alto (Tabla 1; el promedio de WER y los 490 nombres anotados salen en una fila OCR-ilegible [OCR dudoso]).
- Con poco tiempo y sin datos de dominio, los metodos basados en reglas/conocimiento superan al ML supervisado entrenado en noticias (Sec. 6, punto 3); el MEMM cae por desajuste de dominio (Sec. 3.3).
- Un ensamble por votacion mayoritaria supera a cada extractor; union da recall, interseccion da precision (Sec. 4, Figs. 2-3).
- La calidad de NER baja con el WER (Fig. 7: ajuste lineal y = -0.4484x + 63.276, R2 = 0.5962 [OCR dudoso]), pero errores de orden de palabras y perdida de layout (columnas intercaladas) pesan mas que errores de caracter (Sec. 6, punto 2).
- Metricas a dos niveles: coincidencia exacta del nombre completo y coincidencia por token; el gold se anota sobre la salida OCR y, aparte, sobre la imagen (Sec. 2.2-2.3, Figs. 5-6).

## Que nos sirve (concreto)
- **Notebook 02, P/R contra oro de 55:** reportar dos vistas, exacta (nombre completo) y por token, como Sec. 2.3. Aclara si un error es de limite de span o de entidad.
- **Convencion de oro y titulos:** el paper anota titulos dentro del nombre ("Mrs Herschel Williams") y, si el extractor omite "Mrs", cuenta 1 FP + 1 FN en exacta (Sec. 2.3). Nuestro plan quita titulos: el oro debe excluirlos igual, y debe quedar escrito para que no haya FP/FN artificiales.
- **Oro "segun OCR" vs "segun imagen":** distincion util para el AC de recall: lo que el OCR no leyo no es culpa del NER. Con conf media ~95 la diferencia sera pequena; basta una linea en DESIGN.md.
- **Filtros simples y sobreajuste (R3):** el extractor de diccionario exige al menos un token que no sea inicial (o exactamente dos iniciales) y 5 tokens o menos (Sec. 3.1), analogo a `NER_MIN_TOKENS`. Ademas, una gramatica libre de contexto mas elaborada ganaba en desarrollo y perdia en el test ciego, "most likely over-fitting" (Sec. 3.2): respalda mantener pocos filtros y la regla configurable.
- **Riesgo documentable:** PSM 3 con documentos de varias columnas puede intercalar texto y romper nombres (Sec. 6, punto 2). Va en limitaciones de DESIGN.md.
- **Trade-off P/R segun uso:** busqueda exige precision, exploracion exige recall (Sec. 2 y 6); justifica un umbral/filtros configurables.

## Que no nos sirve / limitaciones para nuestro caso
- No trata cajas/coordenadas, mapeo de offsets ni fuzzy match: solo extraccion de texto. Cero evidencia para las etapas de ubicacion y fuzzy.
- Corpus historico, con WER muy superior al nuestro (OCR limpio, conf ~95): sus cifras absolutas no se transfieren; no hay que compararlas con las nuestras.
- Modelos de 2010 (diccionarios, regex, MEMM); no evalua spaCy ni transformers. Entrenar o ensamblar tres extractores esta fuera de alcance.
- Gold muy pequeno (1-2 paginas por titulo) y sin IC; no da precedente para Wilson, aunque su propia varianza lo sugiere.
- Texto del paper obtenido por OCR: las figuras (barras) son ilegibles; solo las cifras del texto son fiables.

## Acciones propuestas (max 3)
1. (0.5 h, notebook 02 + spec) Anotar el oro de 55 sin titulos y calcular P/R exacta y por token; dejar la convencion escrita en el notebook.
2. (0.3 h, DESIGN.md) Parrafo "Limitaciones del OCR": columnas/orden de lectura pesan mas que errores de caracter; nuestras muestras son OCR limpio, asi que las metricas son optimistas (Packer Sec. 6).
3. (0.3 h, DECISIONS.md) Fila: reglas pocas y configurables en vez de ensamble o modelo propio; razon: sobreajuste (Sec. 3.2) y desajuste de dominio del ML (Sec. 3.3).

## Citas utiles
- "the knowledge-based approaches performed better than the machine learning approaches" en el escenario de pocos recursos (Sec. 6, punto 3).
- "word order errors and lost page formatting can play a bigger role in poor extraction performance than character recognition errors" (Sec. 6, punto 2).
- Un nombre sin su titulo cuenta como un FP y un FN en la metrica exacta (Sec. 2.3).
- El MEMM, entrenado en CoNLL (83.1 % F exacta in-domain), rinde mal en directorios por el desajuste de genero (Sec. 3.3).
- Gramatica mas compleja: mejor en desarrollo, peor en ciego, "most likely over-fitting" (Sec. 3.2).
- Mayoria: mayor F global; interseccion: mayor precision; union: mayor recall (Sec. 6, punto 4).
