# BERT: preentrenamiento de transformers bidireccionales (Devlin et al., 2018)
**Veredicto:** CITAR — contexto historico del NER con transformers; no aporta decisiones ni codigo al servicio.

## Resumen (max 5 bullets)
- Preentrena un transformer bidireccional con modelado de lenguaje enmascarado (15 % de tokens WordPiece) y prediccion de la siguiente frase (Sec. 3.1).
- Dos tamanos: BASE (110M parametros) y LARGE (340M) (Sec. 3).
- Ajustado fino, mejora el estado del arte en GLUE, SQuAD y otras tareas (Sec. 4).
- NER en CoNLL-2003 (Tabla 7): F1 test 92.4 (BASE) y 92.8 (LARGE) con ajuste fino; dev 96.4 y 96.6.
- Como extractor de caracteristicas (sin ajustar): concatenar las ultimas 4 capas da 96.1 dev, solo 0.3 por debajo del ajuste fino (Sec. 5.3).

## Que nos sirve (concreto)
- **DECISIONS.md / DESIGN.md:** referencia canonica de por que existe la alternativa "transformer" al NER de spaCy y de que el tamano de BASE es 110M (la comparacion de peso con `sm/md/lg` es nuestra, no del paper).
- **Cultura para la entrevista:** el NER se plantea como etiquetado por token con una capa lineal, sin CRF, usando el primer sub-token de cada palabra (Sec. 5.3). Explica de forma sencilla el problema de alinear sub-tokens con palabras, analogo (no igual) a nuestro mapeo de offsets de caracter a palabras OCR.
- **Detalle menor:** el experimento de NER usa un modelo WordPiece que conserva mayusculas (Sec. 5.3), lo que indica que el modelo ve la capitalizacion; es una pista para la regla `NER_DROP_ALL_CAPS`, pero el paper no la prueba.

## Que no nos sirve / limitaciones para nuestro caso
- Todos los resultados son en texto limpio (CoNLL-2003, noticias); nada de OCR, ruido, ni documentos escaneados.
- No evalua personas aisladas ni latencia de inferencia ni uso en CPU.
- Traer BERT al core requiere fine-tuning y datos etiquetados, o un checkpoint de NER de terceros: dependencia, peso y codigo no aprobados.
- Mucho contenido (GLUE, SQuAD, SWAG, ablaciones de NSP) es irrelevante para el servicio.
- Las cifras de CoNLL no son comparables con nuestro oro de 55 menciones.

## Acciones propuestas (max 3)
1. (0.1 h, DECISIONS.md) En la fila de alternativas descartadas (BERT/GLiNER), citar BERT-BASE 110M como referencia de tamano y el 92.4 de test en CoNLL como "techo en texto limpio", sin compararlo con nuestras metricas.
2. (0.1 h, DESIGN.md) Una frase en Referencias: el paper originario del NER por ajuste fino de transformers.
3. (Ninguna otra: no hace falta notebook ni test.)

## Citas utiles
- BERT_BASE: L=12, H=768, A=12, 110M parametros; BERT_LARGE: 340M (Sec. 3).
- CoNLL-2003 NER (Tabla 7): ajuste fino BASE 96.4 dev / 92.4 test; LARGE 96.6 / 92.8; concatenar las ultimas 4 capas 96.1 dev (feature-based).
- "we formulate this as a tagging task but do not use a CRF"; se usa la representacion del primer sub-token (Sec. 5.3).
- El modelo de NER usa WordPiece que conserva mayusculas (Sec. 5.3).
