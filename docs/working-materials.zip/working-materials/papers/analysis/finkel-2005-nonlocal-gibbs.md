# Informacion no local en extraccion de informacion con Gibbs sampling (Finkel, Grenager & Manning, 2005)
**Veredicto:** USAR — evidencia empirica de que un mismo texto casi nunca recibe etiquetas de tipo distinto dentro de un documento (consistencia de etiquetas), y de cuanto mejora imponerla.

Metadatos: J. R. Finkel, T. Grenager, C. Manning, *Incorporating Non-local Information into Information Extraction Systems by Gibbs Sampling*, ACL 2005 (43rd Annual Meeting; ACL Anthology P05-1045). PDF: https://aclanthology.org/P05-1045.pdf.

## Resumen (max 5 bullets)
- Cambia Viterbi por Gibbs sampling con enfriamiento simulado en un CRF de NER, para anadir restricciones de consistencia a larga distancia sin perder tratabilidad (Sec. 1-3).
- Evidencia de la restriccion (Sec. 5.1, Tabla 3, CoNLL train): la misma cadena de tokens etiquetada con tipos distintos en un documento es muy rara. Para PER: 3141 casos PER-PER frente a 4 PER-LOC, 5 PER-ORG y 0 PER-MISC. Excepcion notable ORG/LOC (equipos y ciudades en noticias deportivas).
- Con subcadenas la restriccion es mucho mas debil (Tabla 4): "China" dentro de "China Daily" (ORG vs LOC) aparece 328 veces; para PER la fila es 1941 consistentes frente a 10 inconsistentes (5 LOC, 2 ORG, 3 MISC) [fila leida de tabla desordenada].
- Resultado CoNLL-2003 (Tabla 5, F1 por entidad): total 85.51 -> 86.86 (+1.35, ~9 % de reduccion de error), PER 90.36 -> 92.29 (+1.93). En CMU Seminars (Tabla 6): 91.85 -> 92.29. Los autores lo llaman "about 1.3 %" y subrayan que parten de un sistema casi estado del arte (Sec. 7).
- Costo: Gibbs sampling con muchas muestras (200 por prueba en CoNLL); Krishnan & Manning 2006 reportan que el tiempo de inferencia sube por un factor ~30.

## Que nos sirve (concreto)
- **Cuanto mejora la consistencia a nivel documento:** en un NER ya fuerte, del orden de +1.3 puntos F1 totales y ~+1.9 en PER. Es un techo realista para "propagar etiquetas": no es un salto grande.
- **Riesgo de falsos positivos:** para el nombre de persona *completo* repetido, la evidencia es de bajo riesgo: PER recibe otro tipo solo 9 veces de 3150 PER-PER-o-otro (Tabla 3: 4 + 5 + 0 frente a 3141). El riesgo sube con subcadenas (apellido solo: 10 de ~1951 en Tabla 4) y en nombres que son tambien ORG/LOC (equipos, ciudades).
- **Version minima defendible para D4:** match exacto de cadena del nombre completo ya reconocido como PER, dentro del mismo documento. Es la configuracion donde la restriccion se cumple casi siempre (Tabla 3), y evita el caso debil de subcadenas (Tabla 4). Pagina vs documento: el paper trabaja a nivel de documento (articulo de noticias); no mide a nivel de pagina.
- **Diferencia con D4:** Finkel *corrige etiquetas* de entidades que el modelo ya marco; D4 *anade menciones* que el NER no marco. El paper no mide ese caso (recuperar menciones omitidas), asi que su evidencia cubre el riesgo de "mismo texto, otro tipo", no la precision de las menciones nuevas. Eso hay que medirlo en el oro propio.
- **No copiar el metodo:** Gibbs + penalizaciones estimadas del corpus es mucho mas que lo que necesitamos.

## Que no nos sirve / limitaciones para nuestro caso
- Texto limpio de noticias (CoNLL, Reuters 1996) y modelo CRF entrenado ahi; el NER de spaCy y el OCR son otro regimen.
- Las cifras de Tablas 3-4 salieron de MarkItDown con celdas desordenadas; contrastar con el PDF antes de citar en el PR.
- Sin analisis de errores de OCR (un nombre mal leido no coincide por cadena exacta).

## Acciones propuestas (max 3)
1. (0.3 h, NB de NER/oro) Contar en las 5 paginas cuantas menciones de nombres ya reconocidos aparecen sin etiquetar, para estimar el recall que D4 podria ganar.
2. (0.2 h, spec) Fijar D4 como "match exacto del nombre completo, mismo documento" y anotar el riesgo de apellido solo.
3. (0.1 h, DECISIONS.md, previa consulta) Fila: consistencia a nivel documento, no Gibbs (Finkel 2005).

## Citas utiles
- "inconsistent labelings are very rare" para cadenas identicas (Sec. 5.1, Tabla 3); la restriccion es mas debil para subcadenas, ej. "China Daily" vs "China" (Sec. 5.1, Tabla 4).
- "the non-local models increase the F1 accuracy by about 1.3 %" sobre un baseline casi estado del arte (Sec. 7).
