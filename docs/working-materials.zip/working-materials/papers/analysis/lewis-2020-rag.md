# RAG: Retrieval-Augmented Generation (Lewis et al., 2020)
**Veredicto:** CITAR — define el patron "recuperar y luego generar" y sirve de vocabulario y respaldo en DESIGN.md, pero su metodo (entrenar retriever y generador de punta a punta) no se implementa.

## Resumen (max 5 bullets)
- Combina memoria parametrica (BART, seq2seq) con memoria no parametrica (indice vectorial denso de Wikipedia, recuperador DPR) y entrena ambos de punta a punta (Fig. 1, Sec. 2).
- Dos variantes: RAG-Sequence (mismo documento para toda la salida) y RAG-Token (documento distinto por token); el documento es una variable latente marginalizada sobre los top-K (Sec. 2.1).
- Indexa Wikipedia (volcado de diciembre de 2018) en trozos disjuntos de 100 palabras (21M documentos) con FAISS; entrena con k en {5, 10} y fija k de prueba con el conjunto dev (Sec. 3).
- Estado del arte en tres tareas de QA abierto (NQ, WebQuestions, CuratedTrec); en generacion, mas factual y especifico que BART, "alucina" menos (Sec. 4.2).
- "Index hot-swapping": cambiar el indice actualiza el conocimiento sin reentrenar (70 % con el indice 2016 para lideres 2016; 12 % con indice 2018 y lideres 2016) (Sec. 4.5).

## Que nos sirve (concreto)
- **DESIGN.md / entrevista:** vocabulario y justificacion de la arquitectura. La memoria no parametrica es texto crudo "human-readable" y "human-writable" (Sec. 5); respalda `sources` legibles `archivo:pN:cK` y la reingesta que reemplaza.
- **Reingesta reemplaza (ID `{sha256[:16]}:{pagina}:{chunk}`):** el experimento de hot-swapping muestra que el conocimiento se actualiza cambiando el indice, no el modelo.
- **05_rag, tamano de chunk:** precedente de trozos pequenos y disjuntos (100 palabras; nuestros 500 caracteres son unas 80 palabras, mismo orden de magnitud). El overlap de 60 no viene de este paper.
- **Valor de k:** entrenan con 5 o 10 y no observan "significant differences" entre ellos (Sec. 4.5). Respalda un k pequeno como punto de partida; la decision final sale de hit@k/MRR en 05_rag.
- **Procedencia:** el abstract la cita como problema abierto ("provenance"); nuestros `sources` construidos en codigo son la respuesta de ingenieria.

## Que no nos sirve / limitaciones para nuestro caso
- Entrenamiento conjunto retriever + generador, marginalizacion, RAG-Token: fuera de alcance (embeddings y LLM congelados).
- Mas documentos mejoran QA con RAG-Sequence y RAG-Token pico en 10 (Fig. 3); no se transfiere a un LLM con el contexto en el prompt (Liu 2023 muestra saturacion).
- No trata abstencion: el modelo siempre genera. No hay umbral tipo MIN_SCORE.
- Sin OCR ni PDFs escaneados; BM25 gana solo en FEVER (Tabla 6), irrelevante aqui.
- Metricas (Exact Match, Bleu, Rouge) sobre benchmarks grandes; no aplican a 10 preguntas.

## Acciones propuestas (max 3)
1. Citar Lewis 2020 en DESIGN.md, parrafo de arquitectura (recuperador + generador, memoria no parametrica auditable). Costo: 0.2 h.
2. DECISIONS.md, fila de chunk 500 / overlap 60: "mismo orden que los trozos de 100 palabras de Lewis (Sec. 3); el valor se valida con hit@k en 05_rag". Costo: 0.2 h.
3. Notebook 05_rag: barrer k en {1, 3, 5} y reportar que k pequeno basta con n=10, en paralelo a la observacion de Lewis (k=5 vs 10 sin diferencias significativas). Costo: 0.3 h (ya esta en el barrido de recuperacion).

## Citas utiles
- Sec. 3: "split into disjoint 100-word chunks"; "We consider k in {5, 10} for training and set k for test time using dev data".
- Sec. 4.5 (Index hot-swapping): se actualiza el conocimiento "by simply replacing its non-parametric memory" (70 % con indice correcto vs 12 % y 4 % con indices desfasados).
- Sec. 5: la memoria en texto crudo es "human-readable ... and human-writable", lo que da interpretabilidad.
- Abstract: "providing provenance for their decisions ... remain open research problems".
