# Sentence-BERT (Reimers y Gurevych, 2019)
**Veredicto:** CITAR — fundamenta la receta (encoder siames, pooling MEAN, coseno), pero no evalua MiniLM ni recuperacion; no cambia ningun codigo.

## Resumen (max 5 bullets)
- BERT como cross-encoder exige pasar cada par por la red: encontrar el par mas similar entre 10.000 frases requiere 49.995.000 inferencias (~65 h en V100); SBERT lo baja a ~5 s (Resumen, Sec. 1).
- SBERT aplica pooling a la salida de BERT en una red siamesa/triplete y compara con coseno; el pooling por defecto es MEAN (Sec. 3).
- Sin fine-tuning, BERT promedio da 54.81 de correlacion media en STS y el vector CLS 29.19, peores que GloVe promedio (61.32) (Tabla 1).
- Ablacion de pooling (Tabla 6, columnas NLI / STSb): MEAN 80.78 / 87.44, MAX 79.07 / 69.92, CLS 79.80 / 86.62.
- Eficiencia (Tabla 7, frases/seg): SBERT-base 44 en CPU y 1378 en GPU; con "smart batching" 83 y 2042.

## Que nos sirve (concreto)
- 05_rag / DECISIONS.md: justifica por que un bi-encoder y no un cross-encoder: el corpus se embebe una vez al ingestar y cada consulta cuesta un solo forward (Sec. 1, 7). Argumento de arquitectura barato y verificable.
- Justifica `normalize_embeddings=True` + coseno: el paper compara siempre con coseno (Sec. 4) y MEAN es el pooling por defecto; all-MiniLM-L6-v2 hereda ese esquema (inferencia nuestra; el paper no menciona MiniLM).
- Failure mode "usar BERT crudo como embedding": la Tabla 1 muestra que no sirve; refuerza no usar un modelo sin entrenamiento de similitud.
- Rendimiento: el "smart batching" (agrupar por longitud) sugiere pasar la lista completa de chunks a `encode` por lotes, no uno a uno, en `store_document_chunks` (Tabla 7).

## Que no nos sirve / limitaciones para nuestro caso
- Solo evalua similitud semantica entre frases (STS, SentEval, AFS, secciones de Wikipedia). Cero experimentos de recuperacion pregunta -> pasaje; no da hit@k ni MRR.
- Modelos SBERT-NLI base/large (BERT/RoBERTa) entrenados con NLI; no incluye MiniLM ni all-MiniLM-L6-v2, entrenado despues con otros datos.
- No trata longitud maxima de entrada ni truncado: el limite de 256 word pieces del plan no sale de aqui.
- Hardware de 2019 (i7-5820K, Tesla); las cifras de velocidad no extrapolan a nuestra CPU.

## Acciones propuestas (max 3)
1. Una frase en DECISIONS.md (fila de embeddings) citando bi-encoder vs cross-encoder (Sec. 1). Costo 0.1 h.
2. En 05_rag, codificar los chunks en una sola llamada a `encode` con `batch_size` en config; sin codigo extra. Costo 0.1 h.
3. No hacer ablacion de pooling (viene fijado en el modelo preentrenado); decir "no probado" en DESIGN.md. Costo 0 h.

## Citas utiles (frase corta o parafrasis + seccion/tabla)
- "Reduce el esfuerzo de encontrar el par mas similar de 65 horas con BERT/RoBERTa a unos 5 segundos con SBERT" (Resumen; Sec. 8).
- BERT sin ajuste: promedio 54.81 y CLS 29.19, ambos peores que GloVe promedio (Sec. 4, Tabla 1).
- Pooling MEAN supera a MAX y CLS en la ablacion (Sec. 6, Tabla 6).
- Velocidad: smart batching da +89 % en CPU y +48 % en GPU (Sec. 7, Tabla 7).
