# Nota sobre el uso de la F-medida en record linkage (Hand & Christen, 2018)
**Veredicto:** USAR — justifica elegir el umbral por una preferencia explicita (precision minima) en vez de maximizar F1, y obliga a reportar esa eleccion.

Metadatos: D. J. Hand, P. Christen, *A note on using the F-measure for evaluating record linkage algorithms*, Statistics and Computing 28(3):539-547, mayo 2018, doi 10.1007/s11222-017-9746-6 (verificado en Crossref). PDF: version aceptada (`stco-d-16-00349-final.pdf`) del repositorio Spiral de Imperial College, https://spiral.imperial.ac.uk/handle/10044/1/46235. La pagina no declara licencia abierta (solo copyright de Springer); se guarda para lectura personal y no se redistribuye. Titulo del PDF: coincide con el publicado.

## Resumen (max 5 bullets)
- La F-medida (media armonica de P y R) es tambien una media aritmetica ponderada pR + (1-p)P con p = (c+d)/(c+b+2d) (Ec. 1-3, Sec. 2).
- Ese peso p depende del numero de pares predichos como match (b+d), asi que cambia con el metodo y el umbral: comparar metodos por F usa, en la practica, un criterio distinto para cada uno (Ec. 4, Sec. 2).
- Comparacion justa: o todos los metodos predicen el mismo numero de matches, o se fija p segun la importancia relativa de P y R del problema. La ponderacion debe ser "aspecto del problema y del usuario, no del metodo" (Abstract, Sec. 3).
- Hay que reportar la eleccion de pesos; una convencion posible es p = 1/2, con la salvedad de que no debe preferirse sobre una motivacion cientifica concreta (Sec. 5-6).
- Con desbalance de clases accuracy no sirve: 99.99 % prediciendo todo no-match (Sec. 2). Experimentos en conjuntos de linkage de registros (Cora, votantes NCVR; Tabla 1), no de nombres sueltos.

## Que nos sirve (concreto)
- **Criterio "max recall con precision >= 0.95":** respaldo indirecto pero solido. El paper no trata restricciones de precision, pero su tesis es que la ponderacion P/R debe venir del problema (aqui un falso match cuesta mas que una omision) y declararse; maximizar F1 impone un trade-off que no elegimos. Nuestro criterio hace explicita esa preferencia; debe quedar escrito en la spec.
- **Comparar scorers (`ratio`, `token_sort`, `max`):** compararlos por F1 maximo solo es justo si predicen igual numero de matches. Mas defendible: recall a precision fija (0.95) o la curva PR completa.
- **Reporte:** P, R y umbral elegido (los IC de Wilson no vienen de este paper).

## Que no nos sirve / limitaciones para nuestro caso
- Linkage de bases con blocking, no emparejar una lista corta de nombres contra entidades extraidas; sin OCR.
- No propone criterio de umbral concreto ni valida un valor.

## Acciones propuestas (max 3)
1. (0.2 h, spec NB03) Escribir el criterio de umbral y su razon (costo asimetrico), citando Hand & Christen 2018.
2. (0.2 h, NB03) Comparar scorers por recall a precision 0.95 y curva PR, no solo por F1 maximo.
3. (0.1 h, DECISIONS.md, previa consulta) Fila: umbral por restriccion de precision.

## Citas utiles
- "the relative weighting given to precision and recall should be an aspect of the problem and the researcher or user, but not of the particular linkage method being used" (Abstract).
- "researchers and users must report the choice they made when reporting comparative performance of linkage methods" (Sec. 5).
