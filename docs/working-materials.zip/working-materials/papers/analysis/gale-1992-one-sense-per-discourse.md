# Un sentido por discurso (Gale, Church & Yarowsky, 1992)
**Veredicto:** CITAR — respaldo conceptual de D4 (una palabra repetida en un discurso conserva su sentido); no es evidencia de NER.

Metadatos: W. A. Gale, K. W. Church, D. Yarowsky, *One Sense Per Discourse*, Speech and Natural Language: Proceedings of a Workshop, Harriman, Nueva York, 23-26 febrero 1992 (ACL Anthology H92-1045). PDF: https://aclanthology.org/H92-1045.pdf.

## Resumen (max 5 bullets)
- Hipotesis: una palabra polisemica que aparece varias veces en un discurso bien escrito casi siempre conserva el mismo sentido (Abstract, Sec. 3).
- Prueba preliminar no ciega: 108 sustantivos, 100 conjuntos de concordancias de la enciclopedia Grolier; solo 6 de 300 juicios mostraron sentidos multiples; acuerdo medio de jueces 96.8 % (99.1 % sin el juez 2) (Tabla 4).
- Prueba ciega: de 54 pares de una misma entrada, la mayoria de 5 sujetos dijo que 51 compartian sentido y 3 no, es decir ~94 % (51/54) (Sec. 3).
- El 98 % de la cabecera es una extrapolacion: suponen 60 % de palabras no ambiguas y 40 % polisemicas (100 % x 0.60 + 94 % x 0.40 = 98 %), no una medicion directa (Sec. 3).
- Uso propuesto: restriccion adicional para desambiguar y para recolectar datos etiquetados (Sec. 3-4).

## Que nos sirve (concreto)
- **Nombre de la idea para D4 / la spec:** "one sense per discourse" es la referencia clasica para justificar consistencia de etiquetas por documento; basta citarla junto a Finkel 2005 y Krishnan 2006.
- **Riesgo de falsos positivos:** el paper mismo reporta ~6 % de pares polisemicos con sentidos distintos (3/54) en los casos dificiles y 98 % solo si se mezclan palabras no ambiguas. Para nombres propios es una analogia, no una medicion: no hay datos de nombres de persona.
- **Version minima defendible:** no aporta; la minima (match exacto de nombre completo, mismo documento) se apoya en Finkel/Krishnan.

## Que no nos sirve / limitaciones para nuestro caso
- Desambiguacion de sentidos de 9 palabras en enciclopedia, no NER; escala de 54 pares.
- Texto "bien escrito y coherente"; un PDF escaneado puede no serlo.
- Tablas leidas de texto desordenado por MarkItDown.

## Acciones propuestas (max 3)
1. (0.1 h, spec) Citar como origen del principio, sin usar su 98 % como cifra de riesgo.
2. (0.1 h, DECISIONS.md, previa consulta) Mencionar en la fila de D4 junto a Finkel/Krishnan.

## Citas utiles
- "if a polysemous word such as sentence appears two or more times in a well-written discourse, it is extremely likely that they will all share the same sense" (Abstract).
- "with probability about 94 % (51/54), two polysemous nouns drawn from the same article will have the same sense" (Sec. 3).
