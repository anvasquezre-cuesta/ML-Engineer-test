# Modelo de dos etapas para dependencias no locales en NER (Krishnan & Manning, 2006)
**Veredicto:** USAR — separa cuanto aporta el alcance de documento frente al de corpus; da la mejor cifra para "misma etiqueta dentro del documento".

Metadatos: V. Krishnan, C. D. Manning, *An Effective Two-Stage Model for Exploiting Non-Local Dependencies in Named Entity Recognition*, COLING-ACL 2006 (21st COLING and 44th ACL, Sydney; ACL Anthology P06-1141), pp. 1121-1128. Ojo: no es un ACL "a secas"; es la conferencia conjunta. PDF: https://aclanthology.org/P06-1141.pdf.

## Resumen (max 5 bullets)
- Entrena un primer CRF con rasgos locales y un segundo CRF con rasgos locales mas los de la salida del primero: etiqueta mayoritaria del token, de la entidad completa y de las superentidades (Sec. 3-4).
- Tabla 3 (CoNLL-2003, F1): linea base 85.29 (PER 89.76). Con rasgos de documento (token, entidad, superentidad): 87.15 (PER 92.71), 12.6 % de reduccion relativa de error. Anadiendo rasgos de corpus de prueba: 87.24 (PER 92.57), 13.3 %.
- Contribucion de cada bloque (total): token-majority de documento 86.50 (+1.21), entity-majority 86.75, superentity 87.15; el alcance de corpus solo suma +0.09 sobre el de documento.
- Supera a Finkel et al. 2005 (9.3 %) y a Bunescu & Mooney 2004 (11.1 %), con inferencia de solo dos CRF secuenciales frente a Gibbs (que dicen ~30 veces mas lento, Sec. 7).
- Recoge las mismas tablas de inconsistencia de Finkel: etiquetas diferentes para la misma cadena son raras; para subcadenas, mas frecuentes (Tablas 1-2, Sec. 4).

## Que nos sirve (concreto)
- **Cuanto mejora la consistencia a nivel documento:** +1.86 F1 total y +2.95 en PER sobre una linea base fuerte (Tabla 3). Casi toda la ganancia (>= 95 % del +1.95 final) viene del alcance de documento; el de corpus anade 0.09. Defiende no propagar entre documentos distintos (aqui: entre PDFs).
- **Riesgo de falsos positivos:** la tabla de inconsistencias (Tabla 1 del paper, CoNLL train) repite que cadenas identicas casi siempre conservan tipo; el riesgo aparece con subcadenas/superentidades, que el paper trata con un rasgo propio. Con match exacto de cadena completa evitamos ese caso.
- **Version minima defendible para D4:** match exacto del nombre completo ya reconocido, dentro del mismo documento (equivalente a su "entity-majority" de documento). Un "token-majority" (apellido o primer nombre solo) tambien ayudo (+1.21 total), pero es la variante riesgosa para nuestro uso.
- **Pagina vs documento:** el paper compara documento vs corpus, no pagina vs documento. Los PDFs del oro son cortos; empiricamente conviene decidirlo con el recuento del NB de oro.
- **Diferencia con D4:** sus rasgos entran como entradas de un segundo modelo (aprende cuando fiarse); D4 es una regla dura. La regla puede sobrecorregir lo que el segundo CRF atenuaria.

## Que no nos sirve / limitaciones para nuestro caso
- Requiere entrenar dos CRF sobre CoNLL (con validacion cruzada para el primero); inviable y fuera del plan.
- Noticias limpias en ingles; no evalua OCR.
- Las filas de Tabla 3 y las tablas de inconsistencia vinieron desordenadas por MarkItDown; contrastar con el PDF antes de citar.

## Acciones propuestas (max 3)
1. (0.2 h, spec) Alcance de D4 = un documento (PDF), sin propagar entre PDFs; citar Tabla 3.
2. (0.3 h, NB oro) Medir cuantas menciones adicionales recupera el match exacto de nombre completo y cuantas serian falsos positivos en las 5 paginas.
3. (0.1 h, DECISIONS.md, previa consulta) Fila: rasgo de consistencia por regla de cadena exacta en vez de modelo de dos etapas.

## Citas utiles
- "a 12.6 % relative error reduction" restringiendose a dependencias dentro del documento; "13.3 %" al incluir el corpus de prueba (Sec. 6.2, Tabla 3).
- La tabla muestra que los rasgos de documento ya aportan casi todo; el corpus suma poco (Tabla 3).
