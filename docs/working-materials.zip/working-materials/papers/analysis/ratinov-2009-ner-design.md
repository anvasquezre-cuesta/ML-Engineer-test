# Retos de diseno y concepciones erroneas en NER (Ratinov & Roth, 2009)
**Veredicto:** USAR (con cautela) — cuantifica cuanto aportan los rasgos no locales y muestra que no ayudan siempre; da el contrapeso a Finkel/Krishnan.

Metadatos: L. Ratinov, D. Roth, *Design Challenges and Misconceptions in Named Entity Recognition*, CoNLL 2009 (Thirteenth Conference on Computational Natural Language Learning; ACL Anthology W09-1119), pp. 147-155. PDF: https://aclanthology.org/W09-1119.pdf.

## Resumen (max 5 bullets)
- Estudia cuatro decisiones de diseno de un NER (inferencia, representacion BIO/BILOU, rasgos no locales, conocimiento externo) y cuanto vale cada una (Sec. 1, Tablas 1-5).
- Tres formas de modelar dependencias no locales (Sec. 5): *context aggregation* (agrega el contexto de todas las apariciones de un token en una ventana de 200 tokens), *two-stage prediction aggregation* (como Krishnan & Manning, con ventana de 1000 tokens) y *extended prediction history* (usa etiquetas ya predichas para el mismo token).
- Tabla 3, F1: CoNLL-2003 test, linea base 83.65; context aggregation 85.40 (+1.75), extended history 85.57 (+1.92), two-stage 85.01 (+1.36), todas 86.53 (+2.88). Ninguna tecnica gana en todos los conjuntos; la combinacion es la mas estable.
- No siempre ayuda: MUC7 test 71.28 -> 71.53 con context aggregation y 73.61 con todas; en paginas web 71.41 -> 70.76 (context aggregation) y 71.21 con todas, sin ganancia. Explican que "named entities in Webpages have less context" (Sec. 5.4).
- Contexto de magnitud: el conocimiento externo (gazetteers) aporta mas, 83.65 -> 88.55 en CoNLL (+4.90, Tabla 5), que los rasgos no locales (+2.88).

## Que nos sirve (concreto)
- **Cuanto mejora la consistencia a nivel documento:** +1.7 a +2.9 F1 en noticias CoNLL; ganancia pequena o nula (incluso negativa) en texto con poco contexto o distinto dominio (Tabla 3). Sirve de freno: D4 puede dar poco si los PDFs son cortos y tienen pocas repeticiones.
- **Riesgo de falsos positivos:** la Sec. 5 aclara que "identical tokens should have identical label assignments" no siempre se cumple (ejemplo "Australia" frente a "The Bank of Australia"). Con match exacto del nombre completo el problema es menor; con apellido o token solo, mayor.
- **Primera mencion canonica:** en la Sec. 5.3 observan que las entidades al inicio del documento son mas faciles de identificar porque la primera mencion usa el nombre canonico. Respalda anclar D4 en una mencion completa ya reconocida y propagarla a las posteriores [texto leido fragmentado, citar con cuidado].
- **Version minima defendible para D4:** el match exacto de cadena del nombre completo reconocido, por documento. Su "context aggregation" (ventana de 200 tokens) es un alcance local, no una pagina: sugiere que la distancia importa, pero no hay experimento pagina vs documento.
- **Fuera del alcance:** usa un NER con CRF/regresion, no spaCy.

## Que no nos sirve / limitaciones para nuestro caso
- Sistema propio (LBJ-NER) entrenado en CoNLL; las cifras no se transfieren a `en_core_web_sm`.
- Rasgos aprendidos, no una regla dura de cadena.
- La Tabla 3 salio de MarkItDown con celdas desordenadas; contrastar con el PDF antes de citarla en el PR.

## Acciones propuestas (max 3)
1. (0.2 h, spec) Citar Tabla 3 como techo y como aviso: puede no ayudar en texto con poco contexto; D4 debe medirse en el oro propio.
2. (0.3 h, NB oro) Comparar P/R con y sin D4 en las 5 paginas; reportar el cambio con IC.
3. (0.1 h, DECISIONS.md, previa consulta) Fila: D4 como regla de cadena exacta, no rasgos aprendidos.

## Citas utiles
- "Surprisingly, no single technique outperformed the others on all datasets" (Sec. 5.4).
- "Since the named entities in Webpages have less context, this result is expected" (Sec. 5.4).
- "Our key conclusion is that no single approach is better than the rest and that the approaches are complimentary" (Sec. 5.4).
