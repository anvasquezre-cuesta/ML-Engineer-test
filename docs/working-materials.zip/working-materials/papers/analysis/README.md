# Analisis de papers: resumen (2026-10-27)

Fuente: `papers/md/` (generado con `uv run papers/to_markdown.py`). Un analisis por paper en esta carpeta, hecho por 3 subagentes Sonnet; Claude verifico contra el Markdown las cifras y citas marcadas con [V]. Ningun paper trae texto dirigido a una IA (los prompts maliciosos de Greshake son ejemplos del estudio).

## Veredictos

| Paper | Veredicto | Para que nos sirve |
|---|---|---|
| Packer et al. 2010, nombres en OCR ruidoso | **USAR** (metodo) | Medir P/R exacta y por token; convencion de titulos en el oro; reglas pocas por sobreajuste [V Sec. 3.2]; columnas/orden de lectura pesan mas que errores de caracter [V Sec. 6] |
| Liu et al. 2023, Lost in the Middle | **USAR** | k pequeno, mejor chunk primero; pasar de 20 a 50 docs mejora ~1.5 % [V] |
| Muennighoff et al. 2022, MTEB | **USAR** | Justifica all-MiniLM-L6-v2: Retr 41.95, Avg 56.26 [V Tabla 1]; MPNet/L12 ganan poco, el multilingue pierde en recuperacion |
| Greshake et al. 2023, inyeccion indirecta | **USAR** | Failure mode central del RAG; respalda `sources` en codigo y LLM sin tools; "hard to imagine a foolproof solution" [V Sec. 5.6] |
| Lewis et al. 2020, RAG | CITAR | Origen de RAG; chunks de 100 palabras [V], mismo orden que nuestros 500 caracteres |
| Es et al. 2023, Ragas | CITAR | "Siguiente paso" en DESIGN.md; exige juez LLM (validado con gpt-3.5); acuerdo 0.95/0.78/0.70 [V Tabla 1] |
| Reimers & Gurevych 2019, SBERT | CITAR | Por que bi-encoder (embeddings precalculados) y no cross-encoder |
| Zaratiana et al. 2023, GLiNER | CITAR | Alternativa de NER, no core |
| Devlin et al. 2018, BERT | CITAR | Contexto; aporta casi nada al core |

### Anadidos 2026-10-28 (NB03 fuzzy y decision D4, leidos completos; cifras de tablas con columnas desordenadas: contrastar con el PDF)

| Paper | Veredicto | Para que nos sirve |
|---|---|---|
| Christen 2006, emparejamiento de nombres | **USAR** | Patron > fonetica; no hay mejor tecnica; Permuted-Winkler 0.883 vs Winkler 0.868 en nombres completos (Tabla 4) apoya la idea del `max` de ordenes, no la prueba (no usa Indel); umbral depende de los datos (rec. 8) |
| Cohen et al. 2003 (KDD), metricas de cadena | **USAR** (secundario) | En Census (personas) gana Levenshtein (0.832/0.865 recortado) frente a TFIDF 0.518 y SoftTFIDF 0.685 (Tabla 2); SoftTFIDF necesita corpus; no da umbral |
| Hand & Christen 2018, F-medida | **USAR** | F pondera P y R segun el metodo (Ec. 2-4); respalda fijar y reportar un compromiso explicito, es decir "max recall con precision >= 0.95" (apoyo indirecto) |
| Finkel et al. 2005, informacion no local | **USAR** | Misma cadena, otro tipo: PER 9 de 3150 (Tabla 3); F1 total +1.35, PER +1.93; Gibbs es excesivo para nosotros |
| Krishnan & Manning 2006, dos etapas | **USAR** | Documento: 85.29 -> 87.15 (PER +2.95); corpus +0.09 mas; justifica alcance de un documento |
| Ratinov & Roth 2009, diseno de NER | **USAR** (cautela) | Rasgos no locales +1.7 a +2.9 en CoNLL, pero 0 o negativo en paginas web (Tabla 3); medir D4 en el oro propio |
| Gale et al. 1992, un sentido por discurso | CITAR | Origen del principio; 94 % medido (51/54), el 98 % es extrapolacion |

## Acciones consolidadas (por destino)

| Destino | Accion | Fuente | h |
|---|---|---|---|
| NB 02 + spec 01 | Oro de 55 **sin titulos** (convencion escrita); reportar P/R **exacta y por token** | Packer | 0.5 |
| NB 05_rag | Prompt con chunks en orden de score descendente; k pequeno (3-5) validado con hit@k | Liu | 0.3 |
| Test (rebanada ask) | `test_ac_rag_nn_injected_chunk_keeps_sources`: un chunk inyectado no altera `sources` ni el formato (fakes) | Greshake | 0.5 |
| DESIGN.md | "Contenido no confiable": modelo de amenaza, `sources` en codigo, sin tools, delimitadores **sin prometer** que mitigan | Greshake | 0.4 |
| DESIGN.md | Limitaciones del OCR: columnas/orden de lectura (PSM 3); metricas optimistas con OCR limpio | Packer | 0.3 |
| DESIGN.md | Ragas como siguiente paso y por que no en el core | Es | 0.2 |
| DECISIONS.md | Filas: MiniLM (MTEB), bi-encoder (SBERT), k pequeno (Liu), reglas pocas y configurables (Packer), GLiNER alternativa | varios | 0.6 |

Ninguno contradice el plan (`research/14`). Total ~2.8 h, repartidas en rebanadas existentes (no suman etapas nuevas).

## Cautelas
- Cifras de MTEB y Liu salen de tablas extraidas con columnas desordenadas: antes de citarlas en el PR, contrastar con el PDF.
- Packer se obtuvo por OCR: figuras de barras y la fila "Over all" de su Tabla 1 son ilegibles ([OCR dudoso] en su analisis).
