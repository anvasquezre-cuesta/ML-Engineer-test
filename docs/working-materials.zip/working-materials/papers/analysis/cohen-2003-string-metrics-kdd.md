# Comparacion de metricas de cadena para nombres y registros (Cohen, Ravikumar & Fienberg, 2003, KDD Workshop)
**Veredicto:** USAR (secundario) — evidencia de que en nombres de personas una distancia de edicion supera a las de token; no da umbral.

Metadatos: W. W. Cohen, P. Ravikumar, S. E. Fienberg, *A Comparison of String Metrics for Matching Names and Records*, KDD Workshop on Data Cleaning and Object Consolidation, 2003. PDF: `papers/pdf/cohen-2003-string-metrics-kdd.pdf` (https://www.cs.utexas.edu/~ai-lab/pubs/kdd03.pdf). Es distinto del paper IJCAI-03 *A Comparison of String Distance Metrics for Name-Matching Tasks* (IIWeb-03): este PDF lo cita en su bibliografia como "to appear". Este es el articulo del toolkit SecondString.

## Resumen (max 5 bullets)
- Presenta el toolkit Java SecondString y compara metricas de edicion, heuristicas (Jaro, Jaro-Winkler), de token (Jaccard, TFIDF) e hibridas (SoftTFIDF) en 11 conjuntos (Tabla 1), con MaxF1 y precision promedio.
- En general SoftTFIDF es la mejor metrica individual (Fig. 1-3); Monge-Elkan la mejor de edicion y TFIDF la mejor de token.
- Excepcion: Census (nombres sinteticos de personas), donde Levenshtein supera a SoftTFIDF. Tabla 2 (MaxF1/AvgPrec): Levenshtein 0.832/0.901, recortado 0.865/0.925, Jaro-Winkler 0.648/0.703, L2 Jaro-Winkler 0.746/0.770, SoftTFIDF 0.685/0.782, TFIDF 0.518/0.369, Jaccard 0.567/0.402.
- Los autores dicen que Census es atipico y conjeturan que Levenshtein gana porque los campos venian rellenos con blancos a longitud uniforme (el caso "recortado" mejora aun).
- Con estructura de campos (Tabla 3): Levenshtein-Winkler + SVM 0.936/0.951, el mejor; Winkler sobre Levenshtein escalado es el mejor MaxF1 entre las metricas simples.

## Que nos sirve (concreto)
- **Familia de scorer:** para nombres de personas (Census) las metricas de token (TFIDF 0.518, Jaccard 0.567) pierden con claridad frente a las de edicion (0.83-0.87). Respalda que `ratio` (edicion Indel) sea parte del scorer y desconfiar de scorers solo de token. No prueba `token_sort_ratio` (reordena y luego compara por edicion; no es token-set).
- **`max(ratio, token_sort)`:** no evaluado; solo apoya el componente `ratio`.
- **Soft-TFIDF:** necesita frecuencias de tokens de un corpus; con ~5 nombres pedidos no aplica (coincide con `research/17`). Ojo: en 10 de 11 conjuntos Levenshtein pierde frente a SoftTFIDF, pero esos conjuntos son nombres de entidades (animales, empresas, restaurantes), no personas.
- **Evaluacion:** ordena pares por distancia (MaxF1, precision promedio interpolada a 11 niveles de recall), sin umbral fijo. Respalda reportar curva PR; no da criterio de umbral ni "precision >= 0.95".
- **Normalizacion:** no la trata (Census ya viene limpio).

## Que no nos sirve / limitaciones para nuestro caso
- Solo Census son personas, y es sintetico; sin ruido OCR; sin umbral; sin rapidfuzz.
- Las cifras de Tabla 2/3 salieron de tablas desordenadas por MarkItDown; contrastar con el PDF antes de citar.

## Acciones propuestas (max 3)
1. (0.2 h, NB03) Incluir un baseline de token (Jaccard) junto a `ratio` en la curva PR para ilustrar el resultado de Census.
2. (0.1 h, DECISIONS.md, previa consulta) Fila: no Soft-TFIDF (requiere corpus; Cohen 2003).
3. (0.1 h, INDEX.md) Mantener separados los dos papers de Cohen (hecho en esta curaduria).

## Citas utiles
- "SoftTFIDF is the best overall distance measure for these datasets" (seccion de experimentos; Census es la excepcion).
- "the Census dataset is generally speaking an outlier compared to the other datasets" (seccion de experimentos).
