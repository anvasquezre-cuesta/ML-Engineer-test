# Lost in the Middle: como los LMs usan contextos largos (Liu et al., 2023)
**Veredicto:** USAR — respalda con evidencia empirica un k pequeno y poner el mejor chunk primero en el prompt; es la cita mas directa para una decision de DECISIONS.md.

## Resumen (max 5 bullets)
- En QA multi-documento y recuperacion clave-valor, el rendimiento depende de la posicion de la informacion relevante: curva en U, mejor al inicio o al final, peor en el medio (Abstract, Fig. 1).
- Ocurre tambien con modelos de contexto extendido, que a menudo rinden igual que sus versiones cortas (Sec. 2.3).
- El rendimiento de GPT-3.5-Turbo con documentos en el contexto puede quedar por debajo de su version sin documentos (cerrado-libro, 56.1 %) (Introduccion).
- Caso de estudio retriever-lector: el lector se satura mucho antes que el recall del recuperador; pasar de 20 a 50 documentos mejora solo ~1.5 % para GPT-3.5-Turbo (Sec. 5, Fig. 11).
- Sugiere reordenar (relevantes al inicio) o truncar la lista recuperada ("ranked list truncation") (Sec. 5).

## Que nos sirve (concreto)
- **Valor de k (05_rag, DECISIONS.md):** mas contexto no ayuda y puede danar; justifica k pequeno y no "mandar todo". Su saturacion se mide con decenas de documentos; con k de 3 a 5 chunks de 500 caracteres estamos lejos de ese regimen, asi que es respaldo cualitativo, no un k recomendado.
- **Orden del prompt:** enviar los chunks de mayor a menor score (el mejor primero) y numerarlos. Costo de codigo casi cero y alineado con el sesgo de primacia.
- **Abstencion sin LLM:** contexto irrelevante degrada la respuesta; filtrar por MIN_SCORE antes de armar el prompt es consistente.
- **Prueba de posicion:** su montaje (un documento con la respuesta mas k-1 distractores) inspira una prueba corta en 05_rag: mover el chunk correcto entre posiciones con el LLM local y ver si cambia la respuesta de las 8 preguntas.
- **Ventana grande no es garantia:** una ventana amplia en qwen2.5:7b no implica que use mejor el contexto (Sec. 2.3); respalda no ampliar k solo porque cabe.

## Que no nos sirve / limitaciones para nuestro caso
- Modelos de 2023 (MPT-30B-Instruct, LongChat-13B, GPT-3.5, Claude-1.3); no evalua qwen2.5:7b, la curva puede ser distinta.
- Contextos de ~4K a ~16K tokens y 10-30 documentos; con 3-5 chunks cortos el efecto "medio" es pequeno o inexistente. No afirmar que lo observamos sin medirlo.
- Sin abstencion ni OCR; datos de Wikipedia (NaturalQuestions) y clave-valor sinteticos.
- No recomienda un k concreto; solo dice que mas de 20 documentos casi no ayuda.

## Acciones propuestas (max 3)
1. DECISIONS.md: fila "k por defecto pequeno (el que salga de hit@k) y mejor chunk primero; sin ventana larga", citando Sec. 5 y Fig. 11. Costo: 0.3 h.
2. Test `test_ac_rag_*_orden_prompt`: el prompt lista los chunks por score descendente y descarta los que no superan MIN_SCORE (fakes, sin LLM). Costo: 0.5 h.
3. Notebook 05_rag: ablacion de posicion (correcto primero / ultimo) en las 8 preguntas con Ollama; reportar con "n pequeno". Costo: 0.5 h; solo si sobra tiempo.

## Citas utiles
- Abstract: "performance is often highest when relevant information occurs at the beginning or end of the input context, and significantly degrades when models must access relevant information in the middle".
- Introduccion: con documentos el rendimiento puede ser menor que el cerrado-libro (56.1 % en GPT-3.5-Turbo).
- Sec. 5: "using 50 documents instead of 20 ... only marginally improves performance (~1.5 % for GPT-3.5-Turbo)"; "model performance saturates long before retriever recall saturates".
- Sec. 5: "effective reranking ... or ranked list truncation ... may be promising directions".
- Sec. 2.3: los modelos de contexto extendido "are not necessarily better at using their input context".
