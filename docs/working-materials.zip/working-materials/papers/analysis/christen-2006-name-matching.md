# Comparacion de tecnicas de emparejamiento de nombres personales (Christen, 2006)
**Veredicto:** USAR — respaldo para elegir familia de scorer (patron, no fonetico), para el `max` sobre ordenes de palabras y para no fijar el umbral a priori.

Metadatos: P. Christen, ANU Technical Report TR-CS-06-02, septiembre 2006 (portada del PDF). PDF: `papers/pdf/christen-2006-name-matching.pdf`.

## Resumen (max 5 bullets)
- Revisa causas de variacion en nombres y 20+ tecnicas (foneticas, de patron, combinadas) y corre 123 pruebas en 4 conjuntos de nombres (3 de registros de parteras de NSW, 1 "COMPLETE"); concluye que no hay una tecnica mejor (Sec. 4.3, Sec. 5, Sec. 6).
- Las tecnicas de patron superan con claridad a las foneticas (Sec. 4.3); rec. 3: codigo fonetico + igualdad exacta "no debe usarse" (Sec. 5).
- Nombres completos sin separar (Midwives full names), F medio sobre umbrales (Tabla 4): PermWink 0.883, LCS-2 0.877, Winkler 0.868, SortWink 0.809, Levendist 0.737, Soundex 0.376. Rec. 5: LCS conviene para nombres sin parsear con palabras intercambiadas.
- Permuted-Winkler = maximo de Winkler sobre todas las permutaciones de palabras; Sorted-Winkler ordena las palabras alfabeticamente antes (Sec. 3.2). En Tabla 4 Sorted queda por debajo de Winkler simple en los 3 conjuntos de Midwives.
- Umbral: el optimo depende de tecnica y datos; cambios pequenos hunden la calidad y sin pares etiquetados es dificil fijarlo (Sec. 4.3, rec. 8, Fig. 1). Tiempo (Tabla 6): PermWink 2.826 ms vs Winkler 0.284 ms en nombres completos.

## Que nos sirve (concreto)
- **Familia de scorer:** respalda comparar cadenas con una medida de patron y descarta fonetica + igualdad (rec. 3). Coherente con la lista "No hacer" de `research/17`.
- **`max(ratio, token_sort_ratio)`:** respalda la idea (maximo sobre varios ordenes de palabras = Permuted-Winkler limitado a 2 ordenes, que fue de lo mejor en nombres completos: 0.883 vs 0.868 Winkler). NO prueba esa combinacion: los scorers de Christen son Jaro/Winkler, no Indel (`rapidfuzz.fuzz.ratio`). Que Sorted solo rinda peor que Winkler simple (0.809 vs 0.868) apoya no usar `token_sort_ratio` solo; es inferencia nuestra: en sus pares el orden nombre-apellido ya coincidia y ordenar solo agregaba ruido. Defendible por analogia; hay que medirlo en NB03.
- **Normalizacion:** la Sec. 2 menciona que el OCR produce sustituciones entre caracteres parecidos (p. ej. "q"/"g") y recomienda conocer/estandarizar los nombres antes (rec. 1-2). No evalua acentos ni puntuacion: no respalda ni contradice la tabla de normalizacion de `research/17`.
- **Umbral:** respalda fijarlo con pares etiquetados propios (rec. 8), no copiar uno. Aviso: sus negativos son pares aleatorios en conjuntos balanceados (Sec. 4.1), es decir faciles; NB03 necesita negativos duros (mismo apellido) o el umbral saldra optimista.
- **Criterio de evaluacion:** usa F-medida promediada sobre todos los umbrales (Sec. 4.3). NO respalda "max recall con precision >= 0.95"; ese criterio se apoya en Hand & Christen 2018.
- **Coste:** las permutaciones crecen factorialmente, pero con 2 ordenes y ~5 nombres es irrelevante.

## Que no nos sirve / limitaciones para nuestro caso
- Datos de registros de salud australianos (cambios de apellido de mujeres), no OCR de documentos; no mide ruido OCR.
- No incluye Indel/`fuzz.ratio`, `token_sort_ratio` de rapidfuzz ni normalizacion Unicode.
- Informe tecnico, no revisado por pares.
- La Tabla 4 vino de MarkItDown con columnas desordenadas: las cifras se leyeron por fila de tecnica; contrastar con el PDF antes de citarlas en el PR.

## Acciones propuestas (max 3)
1. (0.3 h, NB03) Medir `ratio`, `token_sort`, `max(ratio, token_sort)` y Jaro-Winkler sobre los pares etiquetados, con negativos duros.
2. (0.2 h, DECISIONS.md, previa consulta a Jeison) Fila: scorer de cadena completa, sin fonetica (Christen rec. 3).
3. (0.2 h, NB03) Dejar escrito que el umbral se elige con pares propios (rec. 8) y se expone en config.

## Citas utiles
- "there is no single best name matching technique" (Sec. 5).
- "Phonetic encoding followed by exact comparison of the phonetic codes should not be used" (Sec. 5, rec. 3).
- "Even small changes of the threshold can result in dramatic drops in matching quality" (Sec. 5, rec. 8).
- "The longest common sub-string technique is suitable for unparsed names that might contain swapped words" (Sec. 5, rec. 5).
