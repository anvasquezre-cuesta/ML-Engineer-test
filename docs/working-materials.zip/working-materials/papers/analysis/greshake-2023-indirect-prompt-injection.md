# Inyeccion indirecta de prompt en apps con LLM (Greshake et al., 2023)
**Veredicto:** USAR — fundamenta el failure mode central del RAG (texto OCR/PDF tratado como instrucciones) para DESIGN.md; no ofrece defensas probadas.

## Resumen (max 5 bullets)
- Las apps con recuperacion "desdibujan la linea entre datos e instrucciones": un adversario inyecta prompts en datos que luego se recuperan, sin acceso directo al sistema (Resumen, Sec. 1).
- Taxonomia por amenaza: recoleccion de informacion, fraude, malware, intrusion, contenido manipulado, disponibilidad (Sec. 3.2, 4.2).
- Entrega: pasiva (datos recuperados), activa, guiada por el usuario y oculta; hay inyecciones en comentarios Markdown, en Base64 y en varias etapas (Sec. 3.1, 4.3).
- Contenido manipulado relevante a RAG: resumenes erroneos, sesgo, bloqueo de fuentes, desinformacion; el modelo puede citar fuentes y aun asi responder mal (Sec. 4.2.5).
- Defensas (RLHF, filtrado, moderador LLM, interpretabilidad) con dilemas abiertos: "dificil imaginar una solucion a prueba de fallos" (Sec. 5.6).

## Que nos sirve (concreto)
- DESIGN.md (failure modes): amenaza citable para PDFs subidos a `/api/ingest`. Modelo de amenaza: el atacante controla el contenido del PDF; llega por la ruta pasiva, incluso con modelos sin internet que leen archivos propios ("poisoning the input data", Sec. 3.1).
- El plan de armar `sources` en codigo, no con el texto del LLM, esta respaldado: el paper muestra respuestas que citan fuentes mientras estan manipuladas (Sec. 3.2, 4.2.5). Limita el dano a texto de respuesta.
- Superficie reducida por diseno: el dano grande del paper ocurre cuando el modelo tiene herramientas (busqueda, URL, email, memoria; Sec. 4.1.1). Nuestro LLM no tiene tools ni salida a red: argumento de DESIGN.md.
- Test en 05_rag: el chunk con "ignora las instrucciones" cae en manipulacion de contenido / bloqueo de fuentes / disponibilidad (Sec. 4.2.5, 4.2.6); sirve para definir el criterio del test (no cambia `sources`, no rompe formato).
- Mitigaciones baratas ya en el plan: contexto delimitado como dato, abstencion por MIN_SCORE, timeout y limite de salida (contra disponibilidad).

## Que no nos sirve / limitaciones para nuestro caso
- Experimentos con GPT-4, text-davinci-003 y Bing Chat; no con qwen2.5:7b local. Evaluacion cualitativa, sin tasas de exito (Sec. 5.2).
- Ningun experimento con PDFs ni OCR; el ruido de Tesseract puede deformar la inyeccion, no cubierto.
- No prueba defensas: los delimitadores en el prompt no estan evaluados aqui; no afirmar en DESIGN.md que "mitigan" sin prueba propia.
- Gran parte (malware, worming, fraude por email, persistencia) no aplica: no hay agentes ni acciones.

## Acciones propuestas (max 3)
1. DESIGN.md: apartado "Contenido no confiable" con modelo de amenaza, `sources` en codigo, sin tools, delimitadores y limites; declarar que no hay garantia (Sec. 5.6). Costo 0.4 h.
2. Test unitario con LLM y retriever falsos: un chunk con instruccion inyectada no altera `sources` ni el formato de respuesta (`test_ac_rag_nn_*`). Costo 0.5 h. Mas una prueba real con Ollama en 05_rag, registrando el resultado sin prometer exito (0.3 h).
3. DECISIONS.md: fila "defensa de prompt: delimitar + instruccion de sistema, sin moderador LLM", citando el dilema de Sec. 5.6. Costo 0.1 h.

## Citas utiles (frase corta o parafrasis + seccion/tabla)
- La recuperacion "desdibuja la linea entre datos e instrucciones" (Resumen, Sec. 1).
- Mensaje clave 1: la recuperacion abre la puerta a inyecciones donde el filtrado de entrada actual, probablemente fragil, no se aplica (Sec. 3).
- El modelo puede resumir mal el documento citado y hallar fuentes que respalden lo falso, sonando plausible y fundamentado (Sec. 3.2).
- Defensa tipo "Whack-A-Mole"; es dificil imaginar una solucion a prueba de fallos (Sec. 5.6).
- Disponibilidad: instruir tareas largas en segundo plano puede hacer que el modelo expire sin responder (Sec. 4.2.6).
