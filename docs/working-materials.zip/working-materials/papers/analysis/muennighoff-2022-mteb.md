# MTEB: Massive Text Embedding Benchmark (Muennighoff et al., 2022)
**Veredicto:** USAR — unica fuente del trio con numeros de recuperacion de MiniLM-L6 (all-MiniLM-L6-v2) para respaldar la eleccion en DECISIONS.md.

## Resumen (max 5 bullets)
- MTEB: 8 tareas, hasta 15 datasets cada una (58 en total), 112 idiomas; mas de 30 modelos y cerca de 5.000 experimentos (Sec. 3, 5).
- Ningun modelo domina todas las tareas: hay gran variabilidad entre tareas (Sec. 4.2).
- Los modelos orientados a STS (SimCSE, ST5, SGPT-nli) rinden mal en recuperacion; el campo se bifurca en recuperacion (asimetrica) y similitud (simetrica) (Sec. 4.2).
- Eficiencia: los MPNet y MiniLM afinados lideran el cluster medio de velocidad/rendimiento, lo que "hace facil la eleccion" (Sec. 4.3, Fig. 4).
- Retrieval, clustering y reranking son solo en ingles; lo multilingue cubre clasificacion, STS y bitext (Sec. 4.4, Apendice).

## Que nos sirve (concreto)
- DECISIONS.md, fila de embeddings: Tabla 1 da MiniLM-L6 con Retr. 41.95, Rerank. 58.04, STS 78.90 y Avg. 56.26. El apendice lo mapea a `sentence-transformers/all-MiniLM-L6-v2` (md ~L1722). Es el modelo del plan con fuente primaria (R11).
- Justifica no subir de modelo: MiniLM-L12 tiene Retr. 42.69 y Avg. 56.53; MPNet 43.81 y 57.78. Ganancia pequena a cambio de mas capas/costo.
- Justifica descartar multilingual: MiniLM-L12-multilingual tiene Retr. 32.45 y Avg. 52.44, y nuestro corpus es ingles.
- Failure mode "modelo equivocado para la tarea": un modelo de STS rinde mal en recuperacion (Sec. 4.2); sustenta medir hit@k/MRR propios en 05_rag en vez de fiarse del promedio.
- Contexto asimetrico consulta/documento para DESIGN.md: explica por que e5 pide prefijos y por que no lo necesitamos con MiniLM (el prefijo es dato nuestro, no del paper).

## Que no nos sirve / limitaciones para nuestro caso
- Datasets de texto limpio (BEIR y similares); no hay OCR ruidoso. Los puntajes no predicen el rendimiento sobre salida de Tesseract.
- MTEB no impone limite de longitud y deja el truncado al modelo (Sec. 3.1, P2P); no valida chunks de 500 caracteres ni el tope de 256 word pieces.
- Fig. 4 mide velocidad relativa, sin cifras citables para MiniLM-L6 en CPU; sin comparacion con fastembed/ONNX ni cuantizacion.
- Columnas de Tabla 1: Class., Clust., PairClass., Rerank., Retr., STS, Summ., Avg.; la extraccion a md es desordenada, verificar contra el PDF antes de citar.

## Acciones propuestas (max 3)
1. DECISIONS.md: fila con la cita de Tabla 1 (MiniLM-L6 vs L12 vs MPNet vs MiniLM multilingue) y la fuente. Costo 0.2 h.
2. 05_rag: medir hit@k/MRR sobre las 10 preguntas oro y mencionar en DESIGN.md que MTEB no sustituye la prueba propia. Costo 0 h extra (ya planeado).
3. Opcional, DESIGN.md: anotar como mejora futura "MPNet si se necesitara mas calidad", con la cifra de Tabla 1. Costo 0.1 h.

## Citas utiles (frase corta o parafrasis + seccion/tabla)
- Ningun modelo reclama el estado del arte en las siete tareas en ingles (Sec. 4.2, Tabla 1).
- MiniLM-L6: Retr. 41.95, STS 78.90, Avg. 56.26; MiniLM-L12: 42.69, 79.80, 56.53; MPNet: 43.81, 80.28, 57.78 (Tabla 1).
- Los modelos entrenados solo para STS rinden mal en recuperacion (Sec. 4.2).
- Los MPNet y MiniLM afinados lideran el cluster medio de velocidad y rendimiento (Sec. 4.3).
