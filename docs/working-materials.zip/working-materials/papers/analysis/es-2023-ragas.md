# Ragas: evaluacion automatica de RAG (Es et al., 2023)
**Veredicto:** CITAR — define bien las tres dimensiones de evaluacion para el "siguiente paso" de DESIGN.md, pero exige un LLM juez y no entra en el core.

## Resumen (max 5 bullets)
- Marco "reference-free" para evaluar RAG sin respuestas humanas de referencia (Abstract, Sec. 3).
- Tres metricas: faithfulness (afirmaciones de la respuesta inferibles del contexto, F = |V|/|S|), answer relevance (coseno entre la pregunta y preguntas generadas desde la respuesta) y context relevance (oraciones del contexto necesarias / oraciones totales) (Sec. 3, ec. 1 y 2).
- Todas se calculan prompteando un LLM (`gpt-3.5-turbo-16k`) y embeddings `text-embedding-ada-002` (Sec. 3).
- Crean WikiEval: 50 paginas de Wikipedia posteriores al corte del modelo, anotadas por dos personas (Sec. 4).
- Acuerdo con humanos en comparacion por pares (Tabla 1): Ragas 0.95 / 0.78 / 0.70 (faithfulness / answer relevance / context relevance) frente a GPTScore 0.72 / 0.52 / 0.63 y GPT Ranking 0.54 / 0.40 / 0.52.

## Que nos sirve (concreto)
- **DESIGN.md, "siguiente paso":** nombra con exactitud que mediria un juez LLM despues del core (fidelidad, relevancia) y por que se pospone: requiere LLM y no hay referencias.
- **05_rag, taxonomia:** separa calidad de recuperacion (context relevance) de calidad de generacion (faithfulness). Nuestro hit@k/MRR mide solo la primera con oro; la frase de limitacion puede decir que la fidelidad no se mide automaticamente.
- **Grounding y abstencion:** la definicion de faithfulness (lo no deducible del contexto se penaliza) es el criterio que el prompt con contexto delimitado intenta forzar. El prompt de context relevance devuelve "Insufficient Information" cuando el contexto no alcanza (Sec. 3), analogo a nuestro MIN_SCORE.
- **Chequeo manual barato sin instalar Ragas:** revisar a mano las 8 respuestas con la pregunta de faithfulness ("se deduce cada afirmacion del contexto?").
- **Honestidad estadistica:** WikiEval tiene 50 paginas; el propio paper trabaja con n pequeno, lo que normaliza nuestro n=10 si se declara.

## Que no nos sirve / limitaciones para nuestro caso
- Necesita un juez LLM; el nuestro seria qwen2.5:7b local. El paper no valida jueces pequenos, por lo que las cifras de Tabla 1 no se transfieren.
- Context relevance, la mas ligada a recuperacion, es la mas debil (0.70) y la "hardest quality dimension to evaluate" (Sec. 5).
- Evalua sobre WikiEval (texto limpio), no sobre OCR ruidoso de PDFs escaneados.
- Metricas por LLM no deterministas: chocan con tests unitarios sin LLM y con "poco codigo".
- No define abstencion correcta ni hit@k/MRR.

## Acciones propuestas (max 3)
1. DESIGN.md, seccion "Siguiente paso": "Ragas (faithfulness, answer relevance, context relevance) requiere juez LLM; con un modelo local pequeno su acuerdo con humanos no esta validado". Costo: 0.2 h.
2. DECISIONS.md: fila "Sin Ragas ni juez LLM en el core: dependencia pesada, no determinista, validada solo con gpt-3.5 (Tabla 1)". Costo: 0.1 h.
3. Notebook 05_rag: revision manual de faithfulness en las 8 respuestas (si/no por afirmacion, tabla en `results.md`). Costo: 0.5 h; opcional.

## Citas utiles
- Sec. 3: faithfulness = respuesta "grounded in the given context"; F = |V|/|S| (afirmaciones respaldadas / totales).
- Sec. 3: context relevance penaliza "the inclusion of redundant information"; el prompt devuelve "Insufficient Information" si no hay oraciones relevantes.
- Sec. 4: WikiEval, 50 paginas de Wikipedia; Tabla 1: 0.95 / 0.78 / 0.70 frente a baselines.
- Sec. 5: "context relevance to be the hardest quality dimension to evaluate".
- Sec. 6: las predicciones de Ragas estan "closely aligned with human predictions, especially for faithfulness and answer relevance".
