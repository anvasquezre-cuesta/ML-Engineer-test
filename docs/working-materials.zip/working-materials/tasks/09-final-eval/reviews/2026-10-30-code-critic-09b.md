# code-critic (opus) · 09b vector-store-di · 2026-10-30

**Veredicto r1: CHANGES** (solo un test).
- Bloqueante: `tests/unit/test_ask_api.py:74`. AC-VEC-DI-02 solo probaba de forma indirecta que Chroma no se consulta. Aplicado: `monkeypatch.setattr(_collection(), "query", chroma_queried)`, que lanza `AssertionError` si se consulta (+5 líneas). El crítico comprobó que sin el override salta el error.
- AC-VEC-DI-01: correcto (chunks, metadata y `count() == 0`).
- Patrón: `get_chunk_store`/`get_chunk_search` como `get_embedder`/`get_llm`. Los valores por defecto de `rag_service` se usan en los tests de integración y en los notebooks; se quedan.
- `metadata` obligatorio: ningún llamador roto.
- DESIGN.md:30 dice la verdad.

Tras aplicar el cambio: verify verde, 110 passed. Equivale a APPROVE.
