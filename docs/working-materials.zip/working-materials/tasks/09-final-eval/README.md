# 09-final-eval · Evaluación final y entrega

**Alcance:** final-evaluator (opus) sobre la rama completa; arreglos top-5 con el mismo ciclo; PR (Jeison); `.zip` con harness, research y notebooks para el evaluador.
**Spec:** no aplica
**Estado:** pendiente (al final)

| Etapa | Archivo |
|---|---|
| Research | [research.md](research.md) |
| Evaluación | [evaluation.md](evaluation.md) |
| Plan (JM) | [plan.md](plan.md) |
| Reviews | [reviews/](reviews/) |

## Qué necesitamos
**Depende de:** todas las anteriores cerradas.
**Entradas:** rama completa; README:133-150.
**Entregables:** informe del final-evaluator en `reviews/`; arreglos top-5; `.zip` de entrega.

**Pasos que faltan (en orden):**
1. final-evaluator (opus) sin conclusiones previas -> `reviews/`.
2. Cada arreglo del top-5 pasa por el ciclo normal (mini-spec si cambia comportamiento).
3. JM arma el `.zip` y abre el PR (Claude no ejecuta git de escritura).

**Commits previstos** (uno por idea, siempre verde y explicado):
- `fix(...)` / `refactor(...)` según los hallazgos

**Hecho cuando:** todos los gates de [evaluation.md](evaluation.md) cumplidos, code-critic APPROVE, explicación de JM firmada y commits hechos.
