## What this PR does

- **`POST /api/extract`**: OCR of every page (Tesseract), PERSON names (spaCy), one bounding box per mention in **PDF points**, and fuzzy matching against the requested names (case-, accent- and title-insensitive, full-string similarity).
- **`POST /api/ingest`** and **`POST /api/ask`**: word-safe chunks per page in embedded Chroma (ids `sha256:page:chunk`, so a second document never overwrites the first), answers from an OpenAI-compatible LLM grounded in the retrieved chunks. `sources` are built in code, never parsed from the reply, and the service abstains when the context does not answer.
- **Bonus**: audit viewer at `/viewer/` (pdf.js; draws the returned boxes over each page), a page to ingest and ask at `/viewer/ask.html`, and CI on GitHub Actions (ruff, format, pytest with Tesseract).

`app/models/schemas.py` and `README.md` are unchanged.

## How to review

1. **`DECISIONS.md` → Summary** (10 bullets), then the section of any decision you want to challenge. Each one says how it was measured and its known limits.
2. **`DESIGN.md`**: components, the `/api/ask` sequence, scaling to 1000+ PDFs/hour, failure modes, routing between models.
3. **`RUNNING.md`**: setup (uv, Tesseract on `PATH`, Ollama for `/api/ask`) and curl examples. Quick start:
   ```bash
   uv sync --extra dev
   uv run uvicorn app.main:app      # then open http://127.0.0.1:8000/viewer/
   ```
4. **`docs/specs/`**: one short spec per slice; tests are named after its acceptance criteria (`test_ac_<area>_<nn>_*`).

## Architecture in one paragraph

Routers are one line: they validate the input and call a plain function. Services depend on small Protocols (`OcrEngine`, `NameRecognizer`, `Embedder`, `LLM`, `ChunkStore`, `ChunkSearch`) injected with `Depends`, so unit tests swap in fakes and never load a model, Tesseract or an LLM. Settings live in `app/config.py` (environment-overridable, listed in `.env.example`). Domain errors map to HTTP in one table (422, 413, 502, 503, 504). The LLM client has timeouts and retries on network errors, 429 and 5xx. Every request writes one JSON log line with a request id, and names are never logged.

## Measured on the sample PDFs

| Check | Result |
|---|---|
| NER (55 hand-labeled mentions) | precision 1.0, recall 54/55 |
| Boxes | within ±2 pt of a hand-checked reference; no hard-coded DPI (tested at 150 DPI) |
| Fuzzy (27 labeled pairs, threshold 0.90) | recall 12/15, false positives 4/12 |
| RAG (22 answerable + 4 unanswerable questions, `qwen2.5:7b-instruct`) | 21/22 correct, 4/4 abstentions |
| Prompt injection (475 runs) | 0 replies with the attacker's word |

These are regression checks on 3 small PDFs, not quality estimates; `DECISIONS.md` gives the intervals and caveats.

## Tests

- `uv run pytest`: **110 passed** locally with Tesseract, the embedding model and Ollama.
- CI: the same suite with Tesseract; the 3 RAG integration tests skip there (no model cache, no LLM).
- Unit tests cover the tricky parts: pixel → point conversion at a non-default DPI, every page including the first, fuzzy matching with accents and OCR noise, word-safe chunking, unique ids across documents, sources never taken from the LLM, prompt injection, and the HTTP status of each failure.

## Not included

- Docker / docker-compose (optional bonus; the README allows a local setup).
- Multi-language NER, and Chroma as a separate service (DESIGN.md, section 3, says what would change).

## Use of AI

Claude Code was used as a pair-programmer (research, drafts, review). I reviewed and ran every change and own every line; details in `DECISIONS.md` → "Use of AI tools". The working notebooks and research notes are not in this PR; I am sharing them separately.
