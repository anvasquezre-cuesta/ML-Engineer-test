# 09-final-eval · Evaluación

| Qué | Cómo | Esperado |
|---|---|---|
| Rubric | final-evaluator | tabla 0-5 por criterio con evidencia `archivo:linea` |
| Correctness | detalles de README:89-98 uno a uno | todos cumplidos o justificados |

Gates comunes (spec -> plan JM -> tests rojo -> verde -> code-critic -> explicación -> commit): `research/19-plan-implementacion.md`.
