# 09-final-eval · Explicación de los AC (para JM)

## 09a · Log de peticiones que fallan sin control

**Problema.** `log_requests` (`app/log.py`) escribía la línea de log después de `await call_next(request)`. Si el endpoint lanza una excepción que no está en la tabla de `main.py` (por ejemplo, un `RuntimeError` dentro de Tesseract), `call_next` relanza, la función se corta y el 500 no deja ningún rastro en el log.

**AC-LOG-02: el 500 queda en el log.** `status = 500` se fija antes del `try`. Si `call_next` devuelve una respuesta, `status` pasa a ser su código. El `log_event` está en `finally`, que se ejecuta haya excepción o no. Así el log siempre tiene `request_id`, `method`, `path`, `status` y `ms`. El test cambia el motor OCR por uno que lanza `RuntimeError("secret detail")` y usa `TestClient(app, raise_server_exceptions=False)` para recibir el 500 como lo vería un cliente. Comprueba la respuesta 500, `request_id` `boom`, `status` 500, `ms` ≥ 0, y que "secret detail" no aparece en el log.

**AC-LOG-03: la excepción no se silencia.** No hay `except`: `finally` no atrapa nada, solo se ejecuta al salir. La excepción sigue subiendo hasta el `ServerErrorMiddleware` de Starlette, que es el que devuelve el 500. El test usa el `TestClient` por defecto (`raise_server_exceptions=True`) y espera el `RuntimeError` con `pytest.raises`. Si alguien añadiera un `except Exception: return ...`, este test fallaría.

**Por qué no se registra el mensaje de la excepción.** Puede contener texto del PDF, y con él nombres de personas (PII). La regla de DECISIONS ("Extraction endpoint") es no registrar nunca nombres.

**Preguntas de entrevistador:**
1. *¿Por qué `finally` y no `except Exception`?* Porque no quiero manejar el error, solo registrar que ocurrió. `except` invita a tragarlo. `finally` deja que el error siga su curso y el 500 lo produce Starlette.
2. *¿Por qué `status = 500` por defecto?* Si `call_next` lanza, no hay respuesta de la que leer el código. Starlette convierte cualquier excepción no controlada en un 500, así que es el valor correcto.
3. *¿Y los errores de dominio (422, 503…)?* Esos no llegan como excepción a `log_requests`: el manejador de `main.py` los convierte antes en respuesta, así que se registran con su código real.

## 09b · Almacén vectorial inyectable

**Problema.** `rag_service` importaba `store_document_chunks` y `search_similar` de Chroma y los llamaba directamente. `embed` y `llm` ya se inyectaban, pero el almacén no. El README pide que los servicios dependan de abstracciones y no de singletons concretos.

**Qué cambió.** En `vector_service.py` hay dos `Protocol` con `__call__`: `ChunkStore` (`chunks, metadata, embed -> None`) y `ChunkSearch` (`query_embedding, top_k -> list[dict]`). Las funciones de Chroma ya los cumplen, así que no hace falta ninguna clase. `dependencies.py` añade `get_chunk_store()` y `get_chunk_search()`, y `api/rag.py` los pide con `Depends`, igual que `get_embedder` y `get_llm`. `ingest` y `generate_answer` reciben `store` y `search`, y por defecto usan las funciones de Chroma, para que los tests de integración y los notebooks sigan llamándolas igual. `metadata` pasa a ser obligatorio: antes valía `None` por defecto y reventaba en el `for`.

**AC-VEC-DI-01.** Un almacén falso guarda lo que recibe. Tras `POST /api/ingest`, el test comprueba que recibió los chunks esperados con su metadata y que la colección de Chroma sigue con 0 elementos.

**AC-VEC-DI-02.** Un buscador falso devuelve un hit `fake.pdf` página 3, chunk 2, y `collection.query` se sustituye por una función que lanza `AssertionError`. Tras `POST /api/ask`, `sources` es `["fake.pdf:p3:c2"]` y el test no falla, así que Chroma no se consultó.

**Preguntas de entrevistador:**
1. *Si cambio Chroma por Qdrant, ¿qué toco?* Dos funciones nuevas que cumplan `ChunkStore` y `ChunkSearch`, y las dos funciones de `dependencies.py` que las devuelven. `rag_service` y los routers no cambian.
2. *¿Por qué Protocols callables y no una clase `VectorStore`?* Es el patrón que ya siguen `Embedder` y `LLM`. Una función cumple el Protocol sin envoltorio, y en un test basta una lambda.
3. *¿Por qué valores por defecto en el servicio y además en `dependencies.py`?* El router siempre inyecta. Los valores por defecto sirven para llamar al servicio sin FastAPI (tests de integración y notebooks), igual que `embed=get_embeddings` y `llm=chat`.
