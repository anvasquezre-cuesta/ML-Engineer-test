Subject: ML Engineer take-home: PR ready for review

Hi [name],

My take-home is ready for review: [PR link]

A good place to start is the Summary at the top of `DECISIONS.md` (10 bullets), then `DESIGN.md`. `RUNNING.md` shows how to run it, and the audit viewer is at `/viewer/`.

A few words on how I worked, since the PR shows the result but not the process:

- **Research first.** Before writing code I reviewed the literature and the candidate packages for each stage (OCR and PDF geometry, person NER, name matching, RAG, evaluation), so each choice in `DECISIONS.md` cites a source or a measurement.
- **Understand the need, then build an MVP.** I read the task as a compliance tool: names must be found on every page and their boxes must land where a reviewer can check them. So I built the critical path first (`/api/extract` on the sample memo), measured it, and only then hardened it and added RAG and the bonus pieces.
- **Notebooks to decide, code to ship.** Each stage was prototyped in a notebook on the sample PDFs; the code in `app/` reproduces the prototype, and the numbers in `DECISIONS.md` come from those runs.
- **A harness built around the problem.** I used Claude Code as a pair-programmer with a setup I wrote for this task: skills that solve this project's own steps (questioning a slice before its spec, preparing commits), and subagents with one job each: an implementer, a critic that challenges every line of a diff against its spec, notebook and package reviewers, and an independent final evaluator scored against your rubric. Hooks keep git writes and secrets out of the AI's reach, so every commit is mine.
- **Reviewable by a person.** I'm one of the MCP leads at Disney and review more than 15 PRs a day, so I know what a large PR costs the reviewer. The task asks for a single PR, so I kept it reviewable in other ways: about 1,000 lines of application code, 72 small single-idea commits that read in order, and one short spec per slice in `docs/specs/` with tests named after its acceptance criteria.

The attached zip holds the material that is not in the PR: the notebooks with their measurements, my research notes (mostly in Spanish), and the Claude Code setup. Its `README.md` explains each folder.

Thanks for your time. I look forward to your feedback.

Best regards,
Jeison Mesa
