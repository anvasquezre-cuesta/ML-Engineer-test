# Commit 4 (/api/ask) · code-critic (opus, 2026-10-29)

**Veredicto: APPROVE**, sin cambios. 5 tests en verde.

## Mutaciones (Claude, `scratchpad/mutate4.py`, sobre una copia)
Mueren las 6:
- loguear la pregunta;
- quitar el `log_event`;
- quitar la fila 503;
- timeout → 503;
- respuesta inválida → 503;
- no inyectar `llm` en el endpoint.

Con esto mueren también las dos mutaciones del log que sobrevivían en el commit 3.

## Crítico
- El router es un `def` de una línea, como `ingest_pdf`. `RAGResponse(**...)` sobra respecto a `response_model`, pero lo exige la spec.
- No sobra ningún import.
- `dependency_overrides.clear()` en el teardown.
- `"Richard" not in caplog.text` es robusto: "Richard" está en la pregunta y en el chunk.
- `detail` no filtra nada: los mensajes son fijos y como mucho llevan el código HTTP.
- Opcional (no aplicado): probar `VectorStoreError` en `/ask`. Esa fila ya la prueba la 05 y AC-ASK-05 no lo pide.
