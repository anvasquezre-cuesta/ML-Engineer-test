# Commit 2 (cliente LLM) · code-critic r1 (opus, 2026-10-29)

**Veredicto: CHANGES** (~+4 líneas). 9 tests en 0.04 s, sin red ni esperas.

## Mutaciones (hechas en una copia, con el script `scratchpad/mutate.py`)
- **Mueren:**
  - sin `temperature`;
  - `max_tokens`, timeout o modelo fijos;
  - `Authorization` siempre;
  - no reintentar 429;
  - sin `AttributeError` o sin `ValueError` en el `except`;
  - `reraise=False`;
  - el orden de los `except` invertido;
  - `wait_fixed(1)`;
  - `transport` ignorado;
  - sin `.strip()`.
- **Sobreviven:**
  - reintentar 4xx (hallazgo 1);
  - `stop_after_attempt(3)` fijo (hallazgo 3);
  - `wait_fixed(0.1)` (hallazgo 4).

## Hallazgos (enviados al implementer)
1. `test_llm_client.py:46-47`: `replay` lanza `IndexError` antes del `append`. Ese error se convierte en `LLMBadResponseError` y tapa el reintento indebido. Arreglo: `append` primero.
2. `llm_client.py:62-83`: un solo `try` tapa los bugs de la llamada como un 502. Arreglo: dos `try`, uno para el I/O y otro para el parseo.
3. Los tests de LLM-03 usan 3 intentos, que es el default. Arreglo: `LLM_MAX_ATTEMPTS=4`.
4. El assert de tiempo `< 0.5` es demasiado laxo. Arreglo: `< 0.1`.

## Sin cambios
- El Protocol `LLM` lo exige la spec.
- Las docstrings de las excepciones, el dict condicional de la cabecera y `response` siempre definida (`reraise=True`, `ge=1`).
- Los mensajes no filtran el cuerpo del upstream ni la clave.

## r2 (Claude, 2026-10-29)
Los 4 cambios están aplicados. Claude corrió el script de mutaciones del crítico sobre una copia en el scratchpad: **17/17 mutaciones mueren**, incluidas reintentar 4xx, `stop_after_attempt(3)` fijo y `wait_fixed(0.1)`. `verify` en verde. Sentencias de `app/`: 331. **APPROVE.**
