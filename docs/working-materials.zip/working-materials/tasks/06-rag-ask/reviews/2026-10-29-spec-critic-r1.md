# Spec 06 · code-critic r1 (opus, 2026-10-29)

El crítico es de solo lectura; Claude pasó aquí su reporte.

**Veredicto: CHANGES.** Todo lo aplicó Claude en `docs/specs/06-rag-ask.md`.

## Obligatorios (aplicados)
1. **El filtro por chunk no es lo que validó NB05b.** El notebook usa una puerta sobre el top1 y siempre manda los 5 chunks.
   - Claude lo comprobó en `build_nb05b.py:395`.
   - Con un filtro por chunk cambiaría el contexto en 9 de las 26 preguntas.
   - Ahora: `if not hits or hits[0]["score"] < min_score`, y `sources` son todos los recuperados.
2. **Los reintentos no se podían implementar como estaban escritos.**
   - `retry_with` no existe en una función que envuelve a otra decorada.
   - Un decorador lee la config al importar.
   - Ahora: un bucle `Retrying(...)` dentro de `chat` y `llm_retry_max_wait_s` en la config (0 en los tests).
3. **Errores sin traducir:** un cuerpo no JSON da `ValueError` y `content: null` da `AttributeError`. Ahora se capturan `KeyError`, `IndexError`, `TypeError`, `AttributeError` y `ValueError` → 502, y AC-LLM-02 tiene 4 casos.

## Recomendados (aplicados)
4. `is_abstention` usa solo "contiene".
5. AC-LLM-01 comprueba la URL `{base}/chat/completions` y la cabecera `Authorization` según la clave.
6. AC-ASK-04 ya no comprueba el literal del system prompt.
7. El presupuesto se cuenta en líneas lógicas, como en la 05 (~57).

## Se mantienen
- Las 3 excepciones, el parámetro `transport` y `llm_connect_timeout_s`.
- El peor caso de `ReadTimeout` (≈184 s) se declara en DESIGN.md.
