# Commit 3 (generate_answer) · code-critic r1 (opus, 2026-10-29)

**Veredicto: CHANGES** (solo en los tests: unas +6 líneas; `app/` queda igual salvo la docstring).

Comprobado:
- El prompt es idéntico al del proto (`SYSTEM_PROMPT`, `REMINDER`, `SENTINEL`, `build_messages`).
- La puerta mira el top1; `sources` lleva todos los hits; hay un solo `log_event`, sin la pregunta; la abstención devuelve `SENTINEL` y `[]`; ningún unitario usa el `chat` real.

## Mutaciones (`scratchpad/mutate3.py`, sobre una copia del árbol)
- **Mueren:**
  - filtro por chunk;
  - `top_k`=5;
  - `min_score` fijo;
  - LLM antes de la puerta;
  - `sources` sacadas del texto del LLM;
  - sin normalizar `’`;
  - sin `rstrip`;
  - sin escape;
  - `REMINDER` antes del contexto;
  - `sources` cuando hay abstención;
  - devolver la respuesta cruda al abstenerse;
  - puerta sobre el último hit.
- **Sobreviven:**
  - `top_k`=3, centinela exacto y sin `lower`: los matan los hallazgos 1 y 2;
  - loguear la pregunta y quitar el log: los cubre AC-ASK-05 con `caplog`. **Hay que comprobarlo en el commit 4.**

## Hallazgos
1. ASK-03: parametrizar con un caso en mayúsculas y otro que contiene la frase sin ser exacto (enviado al implementer).
2. ASK-02: parametrizar `top_k` con 2 y 3 (enviado al implementer).
3. `unit(*[0.0] * n, 1.0)` es más legible (enviado al implementer).
4. La docstring de `generate_answer` debe mencionar la abstención (enviado al implementer).
5. `FakeLLM` no lanza excepciones, pero no hace falta. Se corrigió el plan.

## r2 (Claude, 2026-10-29)
Los hallazgos 1 a 4 están aplicados. 15 tests en verde y `verify` en verde. Sentencias de `app/`: 353.

Claude volvió a correr `mutate3.py` sobre una copia nueva: **mueren 16 de 18**. Sobreviven "loguear la pregunta" y "sin log", como estaba previsto. Las tiene que matar AC-ASK-05 (`caplog`) en el commit 4, y Claude lo vuelve a correr allí.

**APPROVE.**
