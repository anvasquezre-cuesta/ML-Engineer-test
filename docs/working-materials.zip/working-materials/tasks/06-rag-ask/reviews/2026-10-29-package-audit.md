# 06 · Auditoría de paquetes (package-auditor, 2026-10-29)

Scripts en el scratchpad de la sesión (`p1.py`, `p3.py`, `p4.py`, `p5.py`), ejecutados con `uv run --project ML-Engineer-test python`. Nada instalado ni editado en el repo. [V] = ejecutado hoy; [NV] = no verificado.

## P1 Versiones
| Paquete | Instalada | PyPI (hoy) | Licencia | Fecha PyPI | En pyproject |
|---|---|---|---|---|---|
| httpx | 0.28.1 | 0.28.1 | BSD-3-Clause | 2024-12-06 | sí (línea 28) |
| tenacity | 9.2.1 | 9.2.1 | Apache-2.0 | 2026-10-07 | sí (línea 29) |
[V] No hay que añadir nada. httpx lleva casi un año sin release (estable, no abandonado: es la base de Starlette `TestClient`).

## P2 Ollama
**[BLOQUEADO] Ollama no está corriendo ni instalado en esta máquina**: `httpx.get("http://localhost:11434/api/tags")` -> `ConnectError [WinError 10061]`; no hay proceso `ollama`, ni binario en PATH, ni en `%LOCALAPPDATA%\Programs\Ollama`. No lo he arrancado ni instalado. Por tanto NO verifiqué forma de respuesta, determinismo, latencia ni modelo inexistente. Lo único [V] es la doc oficial (docs.ollama.com/api/openai-compatibility): `/v1/chat/completions` soporta `temperature`, `max_tokens` y `seed`; la doc no documenta el código/cuerpo de "modelo inexistente" [NV] (la literatura de la comunidad dice 404 con `{"error":{"message":"model \"x\" not found..."}}`, sin verificar). Pendiente para Jeison: con Ollama arriba, correr dos llamadas idénticas, una con modelo falso y medir cold/warm.
- Ollama apagado, puerto cerrado 11999 [V]: `ConnectError` (hereda `NetworkError > TransportError`). Sorpresa Windows: tarda **4.16 s con `localhost`** (prueba ::1 y luego 127.0.0.1) y **2.07 s con `127.0.0.1`**. Con `connect=2.0` sobre localhost salió `ConnectTimeout`, no `ConnectError`. Ambos son `TransportError`, así que el reintento los cubre igual; pero un `connect` < 5 s sobre `localhost` convierte "caído" en "timeout" (504 en vez de 503). Recomendación: `LLM_BASE_URL` por defecto `http://127.0.0.1:11434/v1` y connect >= 5 s.

## P3 Timeouts y jerarquía de httpx [V]
```python
httpx.Timeout(10.0)  # -> connect=10 read=10 write=10 pool=10 (cada fase 10 s, NO total)
httpx.Timeout(10.0, read=60)  # -> connect=10, read=60, write=10, pool=10
```
Servidor que acepta y no responde, `read=1.0` -> `ReadTimeout` a 1.0 s. IP no ruteable, `connect=1.0` -> `ConnectTimeout` a 1.0 s. Puerto cerrado -> `ConnectError`.
Jerarquía (mro):
- `ConnectError > NetworkError > TransportError > RequestError > HTTPError`
- `ReadTimeout/ConnectTimeout/PoolTimeout > TimeoutException > TransportError > ...`
- `RemoteProtocolError > ProtocolError > TransportError`
- `HTTPStatusError > HTTPError` (**NO** es `TransportError`; solo sale tras `raise_for_status()`).
Base común "timeout o red": `httpx.TransportError`. Ojo: `read` es entre bytes, no total; un LLM que gotea tokens no dispara `ReadTimeout`, así que sin `stream` el presupuesto total lo da `tenacity`/`stop_after_delay` (o aceptarlo).

## P4 tenacity [V] (contando llamadas con `MockTransport`)
```python
def transient(e):
    if isinstance(e, httpx.HTTPStatusError):
        return e.response.status_code == 429 or e.response.status_code >= 500
    return isinstance(e, httpx.TransportError)
@retry(retry=retry_if_exception(transient), stop=stop_after_attempt(3),
       wait=wait_exponential_jitter(multiplier=0.5, max=8), reraise=True)
```
Salidas:
```
503,503,200: calls=3 OK        400: calls=1 HTTPStatusError   404: calls=1 HTTPStatusError
429,200: calls=2 OK            ReadTimeout,200: calls=2 OK
503x3 reraise=True : calls=3 -> HTTPStatusError (503)
503x3 reraise=False: calls=3 -> RetryError (la causa en .last_attempt.exception())
ConnectError x3: calls=3 -> ConnectError
503x3 con espera real: 2.51 s
```
- `reraise=True` entrega la excepción original (el servicio mapea `httpx` -> dominio); sin él, el llamador vería `RetryError` y tendría que desenvolverla.
- **Sorpresa:** `wait_exponential_jitter(initial=0.5)` emite `DeprecationWarning` ("use 'multiplier'") en 9.2.1; usar `multiplier=`. Con multiplier=0.5: esperas 0.88, 1.11, 2.24 s (jitter aditivo hasta 1 s). `wait_random_exponential(multiplier=0.5,max=8)` da 0.43, 0.97, 0.45 (jitter completo); ambas valen.
- Esperar cero en tests: `fn.retry_with(wait=wait_none())(...)` o `fn.retry.wait = wait_none()` (ambos probados; el segundo muta la función global). Preferible inyectar el parámetro o usar `retry_with`.

## P5 MockTransport [V]
```python
def h(req):
    seen.append(json.loads(req.content))          # cuerpo JSON enviado
    raise httpx.ReadTimeout("t", request=req)     # simula timeout
```
Salida: `ReadTimeout ok http://llm/v1/chat/completions`; `seen[1]["temperature"] == 0`; `seen[1]["messages"][0]["content"] == "<context>x</context>"`. El `request=` en la excepción es opcional pero evita `RuntimeError` si se lee `e.request`.

## P6 Mapeo a HTTP
Hoy `app/main.py:23-28` `ERROR_STATUS` = {InvalidPdfError:422, DocumentTooLargeError:413, OcrEngineError:503, VectorStoreError:503}; `domain_error` en `main.py:37-38` busca `ERROR_STATUS[type(exc)]` (clave exacta: **una subclase daría KeyError -> 500**, por eso cada error de dominio debe mapearse tal cual, sin herencia).
| Fallo del LLM | Excepción de dominio | HTTP | Porqué |
|---|---|---|---|
| Caído / red / 5xx / 429 tras 3 intentos | `LlmUnavailableError` | 503 | dependencia no disponible, coherente con OCR/Vector |
| Timeout tras reintentos | `LlmTimeoutError` | 504 | el plan 06 ya fija 504; distingue lentitud de caída |
| 4xx del LLM (400/401/404 modelo) | `LlmRequestError` | 502 | no es culpa del cliente de nuestra API: mala config/respuesta del upstream (bad gateway) |
| Respuesta sin `choices[0].message.content` | mismo `LlmRequestError` | 502 | upstream devolvió algo inválido |
Nota: 429 agotado -> 503 (no 502). Dos `ERROR_STATUS` nuevas entradas + dos/tres clases.

## P7 `top_k` en Chroma 1.5.9 [V]
```
n_results=0  -> builtins.TypeError: Number of requested results 0, cannot be negative, or zero. in query.
n_results=-1 -> builtins.TypeError: Number of requested results -1, cannot be negative, or zero. in query.
n_results=10 (3 docs) -> OK, devuelve 3 ids ['a','c','b'], sin warning
n_results=1  -> OK ['a']
```
`TypeError` no es `ChromaError`, así que `except ChromaError` (`vector_service.py:~85`) no lo atrapa -> 500 (confirma al crítico). N > count es inofensivo. Dónde validar: **en config**, `top_k: int = Field(5, gt=0)` en `app/config.py` (falla al arrancar, no por petición); además `search_similar` puede leer ese valor en vez de aceptar parámetro libre. Si algún día `top_k` llega por petición, validarlo con `Field(gt=0)` en el modelo de la ruta, no en schemas.py.

## Recomendación para la spec
1. Dependencias: ninguna nueva (httpx 0.28.1, tenacity 9.2.1 ya están).
2. Config: `llm_base_url="http://127.0.0.1:11434/v1"`, `llm_api_key`, `llm_model="qwen2.5:7b-instruct"`, `llm_temperature=0`, `llm_max_tokens`, `llm_connect_timeout_s>=5`, `llm_read_timeout_s` generoso, `top_k: int = Field(5, gt=0)`.
3. Cliente: `httpx.Timeout(read, connect=...)`, `raise_for_status()`, tenacity con `transient`, `multiplier=` (no `initial=`), `reraise=True`; envolver en `LlmUnavailableError`/`LlmTimeoutError`/`LlmRequestError`.
4. Tests: `retry_with(wait=wait_none())`, contar llamadas con `MockTransport` (casos 503,503,200 / 400 / 503×3 / ReadTimeout), inspeccionar `req.content`.
5. Verificar P2 con Ollama arriba antes de fijar el prompt/MIN_SCORE (determinismo, 404 de modelo, latencia).
