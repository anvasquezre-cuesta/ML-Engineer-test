# 06-rag-ask · RAG: pregunta y respuesta

**Alcance:** `embedding_service.get_query_embedding`, `vector_service.search_similar`, `rag_service.generate_answer`, cliente LLM compatible con OpenAI (httpx, timeout, tenacity) y `POST /api/ask`.
**Spec:** `ML-Engineer-test/docs/specs/06-rag-ask.md` (por escribir)
**Estado:** research parcial (sin NB05) · evaluación borrador · spec pendiente

| Etapa | Archivo |
|---|---|
| Research | [research.md](research.md) |
| Evaluación | [evaluation.md](evaluation.md) |
| Plan (JM) | [plan.md](plan.md) |
| Reviews | [reviews/](reviews/) |

## Qué necesitamos
**Depende de:** 05 cerrada.
**Entradas:** NB05; `research/06-tl-plan.md:26-30`; `.claude/rules/rag.md`; Ollama `qwen2.5:7b-instruct`; README:58-61, 83-85, 96-97.
**Entregables:** `app/services/llm_client.py` (cliente LLM con timeout y tenacity); `app/services/rag_service.py` (prompt, abstención, `sources` en código); `/api/ask` en `app/api/rag.py`; config `min_score`, `llm_*`; tests con `httpx.MockTransport` y prueba de inyección.

**Pasos que faltan (en orden):**
1. package-auditor: Ollama API (`/api/chat`), tenacity (qué excepciones reintenta), `httpx.MockTransport`.
2. notebook-builder: NB05 parte pregunta (`MIN_SCORE`, abstención, inyección con el modelo real); notebook-reviewer.
3. code-critic: decide D-ASK-1..3.
4. evaluation + spec `06-rag-ask.md`; crítica; firma JM.
5. JM escribe [plan.md](plan.md).
6. implementer -> verify -> code-critic -> explicación JM -> `/commit-handoff`.

**Commits previstos** (uno por idea, siempre verde y explicado):
- `docs(spec): add RAG ask spec`
- `feat(rag): add LLM client with timeout and retries`
- `feat(rag): answer from retrieved chunks or abstain`
- `feat(api): add /api/ask endpoint`

**Hecho cuando:** todos los gates de [evaluation.md](evaluation.md) cumplidos, code-critic APPROVE, explicación de JM firmada y commits hechos.
