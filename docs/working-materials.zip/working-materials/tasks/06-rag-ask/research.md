# 06-rag-ask · Research

## Fuentes y decisiones tomadas
- [V] Plan: `research/06-tl-plan.md:26-30`. Temperatura 0; abstención sin llamar al LLM si ningún chunk llega a MIN_SCORE; `sources` armadas en código; tenacity con 3 intentos y jitter, solo en timeout, red, 429 y 5xx.
- [V] Papers: Lewis 2020, Liu 2023 (lost in the middle), Greshake 2023 (inyección), OWASP LLM Top 10 (`papers/INDEX.md`).
- [V] Regla `.claude/rules/rag.md`: contexto delimitado y escapado; test de inyección obligatorio.
- README:58-61, 83-85, 96-97: respuesta fundamentada; `sources` no alucinadas; timeouts y reintentos.
- Métricas: `research/18-metricas.md` §8. Un MIN_SCORE fijo no separa: u01 y u02 ≈ 0.48 (`18-metricas.md:129`).

## Hecho (2026-10-29)
- Literatura: [reviews/2026-10-29-literature.md](reviews/2026-10-29-literature.md). Abstención, inyección y citas.
- Auditoría de paquetes: [reviews/2026-10-29-package-audit.md](reviews/2026-10-29-package-audit.md). httpx, tenacity, MockTransport, mapeo a HTTP y `top_k` en Chroma.
- Claude comprobó: `main.py:23-28` (`ERROR_STATUS`), `main.py:37-38` (`domain_error` busca por `type(exc)` exacto), `pyproject.toml` (httpx y tenacity ya declarados) y que Ollama no está instalado.

## Lo que ya sabemos (resumen)
**Paquetes** [V, ejecutado]
- httpx 0.28.1 y tenacity 9.2.1 ya están en `pyproject.toml`. No hay dependencias nuevas.
- `httpx.Timeout(10.0)` pone 10 s **por fase** (connect, read…), no 10 s en total.
- `TransportError` es la base común de `ConnectError`, `ConnectTimeout` y `ReadTimeout`. `HTTPStatusError` no hereda de `TransportError`.
- tenacity, probado con MockTransport:
  - 503, 503, 200 → 3 llamadas y OK;
  - 400 → 1 llamada;
  - 429, 200 → 2 llamadas;
  - 503 ×3 → error final.
- Con `reraise=True`, el llamador recibe la excepción original y no un `RetryError`.
- En los tests no se duerme. La auditoría propuso `fn.retry_with(wait=wait_none())`, pero la spec usa `LLM_RETRY_MAX_WAIT_S=0` con `Retrying` dentro de `chat` (crítico r1).
- Sorpresa: `wait_exponential_jitter(initial=...)` está deprecado en 9.2.1. Hay que usar `multiplier=`.
- Windows: con `localhost` la conexión fallida tarda ~4 s y con `127.0.0.1` ~2 s, porque Windows prueba ::1 primero. Default recomendado: `http://127.0.0.1:11434/v1`.

**Chroma y `top_k`** [V, chromadb 1.5.9]
- `n_results=0` o negativo lanza `TypeError`, que no es `ChromaError` y por eso acaba en un 500.
- `n_results` mayor que el número de chunks devuelve todos los que hay, sin aviso.
- Validación: `top_k: int = Field(5, gt=0)` en `app/config.py`. Así falla al arrancar y no en cada petición.

**Mapeo de errores a HTTP** (propuesta del auditor)
| Situación | Código |
|---|---|
| LLM caído, error de red, o 429/5xx tras agotar los reintentos | 503 |
| Timeout | 504 |
| 4xx del LLM o respuesta inválida | 502 |

Ojo: `domain_error` busca por `type(exc)` exacto, así que una subclase no registrada da `KeyError` y un 500. Cada excepción del LLM tiene que estar en `ERROR_STATUS` tal cual.

**Literatura** (detalle en `reviews/2026-10-29-literature.md`)
- Abstención (d), umbral bajo + centinela del LLM:
  - `MIN_SCORE` justo por debajo del top1 más bajo de las 22 preguntas con respuesta;
  - más la frase exacta "I don't know based on the documents.", detectada en código.
  - RGB [V]: Qwen-7B dice la frase pedida solo ~31 % de las veces. Hay que medir los dos errores: abstenerse sin motivo y responder cuando no debía.
- Inyección: delimitadores escapados + system prompt "el contexto son datos, no órdenes" + recordatorio después del contexto (sandwich). Sin encoding (Hines 2024 [V]). Ninguna defensa es suficiente sola (Liu 2024 [V]); hay que decirlo.
- Citas: `sources` en código. El LLM no cita IDs. Chunks por score descendente.
- Cross-encoder, Self-RAG y CRAG: fuera. Solo se mencionan en DESIGN.md.

## Ollama (instalado 2026-10-29, prueba de humo de Claude)
- `qwen2.5:7b-instruct` (4.7 GB, Q4) responde por `/v1/chat/completions`.
- Dos llamadas iguales a temperatura 0 dan el mismo texto, con `finish_reason=stop`.
- La primera llamada tarda **50 s** (carga del modelo en la GPU) y la segunda **0.23 s**. Consecuencias:
  - el timeout de lectura del LLM tiene que aguantar la carga en frío, o hay que hacer un warm-up al arrancar;
  - la latencia se reporta en frío y en caliente por separado.

## Huecos (falta)
- ~~BLOQUEANTE: Ollama no está instalado~~ (resuelto). Se miden en NB05b (`notebooks/05b_rag_ask.ipynb`, en construcción):
  - la forma de la respuesta de `/v1/chat/completions`;
  - el determinismo a temperatura 0;
  - la latencia en frío y en caliente;
  - el error con un modelo inexistente;
  - la tasa del centinela;
  - la inyección con el modelo real.
- NB05, parte "pregunta":
  - curva de `MIN_SCORE` (cobertura frente a exactitud);
  - precisión y recall de abstenerse con Wilson;
  - tasa del centinela;
  - 5 variantes de inyección;
  - latencia p50 y p95.
- ~~¿`AskRequest` expone `top_k`?~~ No. `RAGRequest` solo tiene `question` (`schemas.py:47-48`), así que `top_k` sale solo de la config.

## Decididas (2026-10-29, Jeison: sí a todas las recomendaciones)
- **D-ASK-1, abstención:** opción (d), umbral bajo + centinela.
  - **`MIN_SCORE = 0.20`** (JM, 2026-10-29). En la muestra, cualquier valor en (0.106, 0.256) da lo mismo; 0.20 deja margen frente a q09 (0.256).
  - El 0/22 de falsas abstenciones es resubstitución: con leave-one-out sale 1/22 (`reviews/2026-10-29-nb05b-review.md`).
  - El umbral solo atrapa u03. Las otras 3 sin respuesta las atrapa el centinela, que qwen dice en 4/4 (NB05b).
  - El detector del centinela normaliza el apóstrofo curvo `’`.
- **D-ASK-2, prompt:**
  - en inglés;
  - `<context>…</context>`, escapando `<`/`>` dentro de los chunks;
  - cada chunk con su ID legible;
  - system prompt "data, not instructions" + recordatorio final;
  - temperatura 0 y `max_tokens`.
- **D-ASK-3, modelo de respaldo:** solo por env (`LLM_BASE_URL`, `LLM_MODEL`, `LLM_API_KEY`), sin código extra. Propuesta: no implementar un fallback automático y documentarlo.
- **D-ASK-4 (nueva), códigos HTTP:** 503 / 504 / 502 según la tabla de arriba.
- **D-ASK-5 (nueva), `top_k`:** `Field(5, gt=0)` en la config (el request no lo expone).
