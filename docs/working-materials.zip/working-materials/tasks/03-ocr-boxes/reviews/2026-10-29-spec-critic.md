# 03-ocr-boxes · Crítica de la spec (code-critic, Opus)

## Ronda 1 (2026-10-29): CHANGES, 9 cambios menores, todos aplicados
Medido por el crítico (`scratchpad/c1.py`): `b""`, `b"not a pdf"` y `b"%PDF-1.4\n%garbage"` lanzan `FileDataError`; render en blanco de 2 páginas 0.03 s.
1. `page_text` devuelve copias de las palabras con `start`/`end` (no una lista paralela); `boxes_for_spans(words, spans)`.
2. AC-OCR-05 añade `%PDF-1.4\n%garbage` (el que el chequeo de magic de 04 no ataja; justifica `InvalidPdfError` en 03).
3. AC-OCR-01 con `ocr_dpi=150` (mata DPI fijo); Then exacto con `page` y `line`; AC-OCR-06 pasa a `792 - 96 - 12`.
4. AC-OCR-04 vía `ocr_pages` con "Bob" en otro bloque y mismo `line_num`; texto y offsets exactos.
5. AC-BOX-01/02 con números fijos (mata altura de la última palabra; ancho hasta "Thompson,").
6. AC-BOX-05: "para cada caja hallada existe una fila de oro a ±2 pt", sin emparejar por orden; 15-25 s.
7. `locate_names` hace una sola llamada a `find_person_spans` (propagación entre páginas).
8. E1: span con `text.index(n)` sobre el texto OCR.
9. El `RuntimeError` del timeout de Tesseract se propaga (mapeo en 04).
Se quedan: `Word = dict`, `OcrEngine` con columnas de `image_to_data`, `line` en `Word`, `"\n\n"` entre páginas, `locate_names`, AC-CFG-04.
Líneas estimadas: `ocr_service` ~70, `bbox_service` ~28, tests ~120.

## Ronda 2 (2026-10-29): APPROVE
Coherencia de contrato, datos, ACs y tareas comprobada. Números medidos (`scratchpad/c2.py`): Letter a 150 DPI = 1275x1650 px, escala 0.48 exacta (48/96/24/12); AC-OCR-06 = 684.0; offsets de AC-OCR-04 y caja de AC-BOX-01 correctos. Retoque opcional aplicado: AC-BOX-01 con offsets `(0, 3)`, `(4, 7)` y span `("Ann Lee", 0, 7)`. Nada que borrar.
