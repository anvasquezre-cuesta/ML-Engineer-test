# 03-ocr-boxes · Decisiones D-OCR-1..6 (code-critic, Opus, 2026-10-29)

Entradas: reporte del `assistant` (medición `scratchpad/m.py`) y del `package-auditor` (`q1.py`, `q2.py`, `q2b.py`), resumidos en `scratchpad/03-reports.md`. El crítico no recibió recomendación de Claude. Claude verificó: `schemas.py:21-23`, `bbox_service.py:6-15`, `README.md:88-96`, `.git/info/exclude` (contiene `notebooks/`), `uv.lock:3435` (pymupdf 2.0), fila de Margaret Thompson en `02a_name_boxes.csv:2`.

| Id | Decisión | Por qué | Líneas |
|---|---|---|---|
| D-OCR-1 | Núcleo `ocr_pages(pdf_bytes, engine)`; abre una vez con `with pymupdf.open(stream=pdf_bytes, filetype="pdf")`; los stubs hacen `Path(pdf_path).read_bytes()` y delegan | R1 + R6 (`research/14:13,18`); el proto abre 1+N veces (`proto/ocr.py:20,56`) | ~8 sobre el proto |
| D-OCR-2 | Caja unión | 0/54 menciones cruzan renglón (02 filtra `"\n"`, `ner_service.py:32`); `ExtractedName` tiene una sola caja | 0 |
| D-OCR-3 | `bbox_origin` en config, top-left por defecto; volteo `y = H - y - h` a nivel de palabra | R10 (`14:22`); el README no fija origen; el volteo conserva la unión min/max | ~4 + 1 test |
| D-OCR-4 | Aceptar puntuación de borde y documentarlo | R5 (`14:17`); 19/54 menciones, +5 pt de media sobre 67 pt; la caja contiene el nombre | 0 |
| D-OCR-5 | Pura `boxes_for_spans(words, spans)`; envoltorio del stub hace OCR + `find_person_spans` y devuelve `{name, page, x, y, width, height}`; `text` queda sin usar (R1, dicho en docstring) | offsets salen del OCR del mismo PDF | ~8 + ~6 |
| D-OCR-6 | No se reabre 02 | "case-insensitive / OCR noise / accents" está en README:92-94 bajo name matching (fuzzy, ya en `fuzzy_service`); las cajas se cruzan por offsets, sin comparar cadenas. `_propagate` exacta = límite de recall, va a DECISIONS.md | 0 |

**E2E:** `notebooks/` está excluido del repo, así que ningún test puede leer `01_ocr_words.csv`. Test e2e con `skipif` sin Tesseract sobre `company_memo.pdf`: 1 página, todas las cajas dentro de 612x792, "Margaret Thompson" a ±2 pt de (76.8, 98.88, 88.32, 9.12). La igualdad exacta con el CSV va en "Desde `app/`" del notebook.

**E1:** no IoU ≥ 0.5 (medido 0.546: margen mínimo, por caja de línea vs tinta). Criterio: caja OCR dentro de la caja de `search_for` ±1 pt y ancho ≥ 0.95 del de referencia. Medido con fuentes 11/14/24: siempre dentro, ancho 0.982-0.987 (`scratchpad/e1check.py`). Fixture en memoria (fixture de pytest); sobra `make_scanned_pdf.py`.

**ACs propuestos:** OCR-01 px->pt con `page.rect.width / pix.width`; 02 todas las páginas incl. 0; 03 descarta conf < 0 o vacías; 04 `text[start:end] == word`, " " en renglón y "\n" entre renglones; 05 bytes vacíos/no-PDF -> `FileDataError` -> error de dominio; 06 `bottom-left` -> `y = H - y - h`. BOX-01 unión en pt; 02 "Thompson," dentro; 03 una caja por ocurrencia; 04 E1; 05 e2e memo.

**Veredicto:** lista para spec cuando Jeison acepte (a) el criterio E1 y (b) que el e2e no use el CSV.
