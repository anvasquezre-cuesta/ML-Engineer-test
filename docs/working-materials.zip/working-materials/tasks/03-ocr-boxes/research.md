# 03-ocr-boxes · Research

## Fuentes y decisiones tomadas
- [V] OCR 300 DPI, px->pt, todas las páginas, descartar conf < 0, texto con offsets: `notebooks/01_ocr.ipynb`, `proto/ocr.py`.
- [V] Caja unión por mención y una caja por ocurrencia: `notebooks/02a_ner_cajas.ipynb`, `proto/ner.py` (`name_box`, `locate_names`).
- [V] R5 (puntuación de borde), R6 (`pymupdf.open(stream=bytes)`), R10 (ejes): `research/14-revision-plan.md:17-22`.
- README:46-48 y 90-91 (todas las páginas incluida la 0; cajas en espacio PDF, no píxeles).

## Hechos medidos (2026-10-29)
- **Muestras:** 54 menciones en `02a_name_boxes.csv` (memo 8, minutes 24, report 22); 3 PDFs de 612x792 pt, rotación 0, con 1/2/2 páginas.
- **Contrato:** `ExtractedName` lleva un solo `bounding_box` (`schemas.py:21-23`), y el origen no está fijado ni en el schema ni en el README. El stub `bbox_service.py:12` es `find_name_bounding_boxes(pdf_path, text) -> list[dict]`, con la forma sugerida `{name, page, x, y, width, height}`.
- **pymupdf 2.0** (`uv.lock:3435`), con licencia AGPL 3.0 o comercial de Artifex:
  - abrir por path o por `stream=bytes, filetype="pdf"` da pixmaps idénticos (mismo md5) y el mismo `page.rect`;
  - `with ... as d` funciona, y el pixmap sigue válido después de cerrar el doc;
  - bytes vacíos dan `EmptyFileError` (subclase de `FileDataError`) y un texto que no es PDF da `FileDataError`;
  - sin `filetype="pdf"`, un PNG se abre como si fuera un PDF válido;
  - `pix.pil_image()` da lo mismo que `frombytes` y que el roundtrip por PNG.
- **El proto abre el PDF 1+N veces** (`proto/ocr.py:20,56`) y usa pandas, que no puede pasar a `app/`.
- **Renglones:** 0 de 54 menciones cruzan renglón, porque 02 filtra los spans con `"\n"`.
- **Puntuación de borde:** 19 de 54 menciones (35 %) la tienen, y ensancha la caja entre 3.5 y 8.0 pt (media 5.1) sobre anchos de 47 a 88 pt.
- **Fixture E1 en memoria:** pesa entre 9 y 24 KB y tarda unos 0.05 s en generarse más 0.2 s de OCR. `get_text() == ""`.
  - El IoU contra `search_for` es 0.54-0.57, porque `search_for` da la caja de renglón (15 pt de alto) y Tesseract la de la tinta (8 pt).
  - Aun así, la caja del OCR queda dentro de la de referencia con ±1 pt, con ancho entre 0.982 y 0.987 de la referencia, en las fuentes 11, 14 y 24.
- **`notebooks/` no llega al repo** (`.git/info/exclude`), así que los tests no pueden leer los CSV del proto.
- **El README dice "case-insensitive… OCR noise… accents"** (README:92-94), dentro del apartado de name matching, que es el fuzzy.

## Decisiones (code-critic, `reviews/2026-10-29-decisions-critic.md`)
- **D-OCR-1:** el núcleo recibe bytes y abre el PDF una vez. Los stubs leen el path y delegan.
- **D-OCR-2:** caja unión.
- **D-OCR-3:** `bbox_origin` con top-left por defecto. El volteo se hace a nivel de palabra.
- **D-OCR-4:** se acepta la puntuación de borde y se documenta.
- **D-OCR-5:** `boxes_for_spans(words, spans)`, que es pura, más el envoltorio del stub. `text` queda sin usar (R1).
- **D-OCR-6:** no se reabre 02. Que la propagación sea exacta queda como límite de recall.

**Aceptado por Jeison (2026-10-29):** el criterio E1 y un e2e contra la referencia nueva `eval/gold_boxes.csv` (55 cajas), en lugar del CSV de los notebooks.
