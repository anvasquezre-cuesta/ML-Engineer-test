# 03-ocr-boxes · OCR y cajas en puntos PDF

**Alcance:** `ocr_service` (`extract_text_from_pdf`, `get_word_bounding_boxes`) y `bbox_service.find_name_bounding_boxes`, detrás de un Protocol `OcrEngine`. Núcleo sobre bytes (R6), px->pt, caja unión. Fuera: validación del upload (04).
**Spec:** `ML-Engineer-test/docs/specs/03-ocr-boxes.md` (por escribir)
**Estado:** código commiteado (be9dccf spec AC-BOX-06, dfa5939 config, 3eb7b2a ocr, 3bb169a bbox; regresión = proto, P 1.0 R 54/55). NB02a "Desde app/" hecho y revisado (0 errores). edade67 fix(ocr) is_pdf, 68b07a7 DECISIONS.md; Explicación en NB02a. Pendiente: commit puntero en spec, JM estudia y firma; luego 04-extract.

| Etapa | Archivo |
|---|---|
| Research | [research.md](research.md) |
| Evaluación | [evaluation.md](evaluation.md) |
| Plan (JM) | [plan.md](plan.md) |
| Reviews | [reviews/](reviews/) |

## Qué necesitamos
**Depende de:** 02 cerrada.
**Entradas:** `notebooks/proto/ocr.py`, `proto/ner.py` (`name_box`, `locate_names`); `01_ocr.ipynb`, `02a`; `artifacts/01_ocr_words.csv`, `02a_name_boxes.csv`; R5, R6, R10 en `research/14`.
**Entregables:** `app/services/ocr_service.py` (Protocol `OcrEngine`, bytes, px->pt); `app/services/bbox_service.py`; config `bbox_origin`; `tests/unit/test_ocr_service.py`, `test_bbox_service.py`; fixture sintético E1 (`tests/fixtures/`).

**Pasos que faltan (en orden):**
1. assistant: opciones de D-OCR-1..4 con costo en líneas.
2. package-auditor: pymupdf `open(stream=bytes)` y generación del PDF sintético E1 (snippet ejecutado).
3. code-critic: decide D-OCR-1..4.
4. Claude completa evaluation (tolerancia del e2e de OCR); spec `03-ocr-boxes.md`; crítica; firma JM.
5. JM escribe [plan.md](plan.md).
6. implementer -> verify -> code-critic -> explicación JM -> `/commit-handoff`.

**Commits previstos** (uno por idea, siempre verde y explicado):
- `docs(spec): add OCR and bounding box spec`
- `feat(ocr): extract words with boxes in PDF points`
- `feat(bbox): locate name boxes from OCR words`
- `test(ocr): add synthetic PDF fixture for box IoU`

**Hecho cuando:** todos los gates de [evaluation.md](evaluation.md) cumplidos, code-critic APPROVE, explicación de JM firmada y commits hechos.
