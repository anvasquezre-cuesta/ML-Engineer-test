# Plan · Tarea 03-ocr-boxes (OCR y cajas en puntos PDF)

## Contexto
La spec `docs/specs/03-ocr-boxes.md` (commit `88567ba`) fue aprobada por el code-critic en 2 rondas. La referencia del e2e, `eval/gold_boxes.csv` (55 cajas), está en `ea9209a`. Las decisiones D-OCR-1..6 están en `tasks/03-ocr-boxes/reviews/2026-10-29-decisions-critic.md`.

Hoy `ocr_service.py` y `bbox_service.py` son stubs con `NotImplementedError`. Hay que llevar a `app/` el prototipo validado, sin pandas:
- de `notebooks/proto/ocr.py`: `render_page`, `ocr_page`, `ocr_pdf` y `add_offsets`;
- de `proto/ner.py`: `name_box` y `locate_names`.

El servicio va sobre bytes, abre el PDF una sola vez y está detrás de un Protocol `OcrEngine`.

Resultado buscado:
- 13 tests nuevos en verde y `verify.ps1` en verde;
- `ocr_service` de unas 70 líneas y `bbox_service` de unas 28;
- desde `app/`, las mismas palabras y cajas que el proto: P 1.0 y R 54/55.

Al aprobar el plan, lo primero es copiarlo a `tasks/03-ocr-boxes/plan.md`.

## Subagentes (este plan pide tu sí para todos)
| Rol | Modelo | Habilidades | Lee | Devuelve | Interacción |
|---|---|---|---|---|---|
| `implementer` | Sonnet | Read/Edit/Write, `uv run`, `verify.ps1`; sin git | la spec, este plan, el proto, los stubs y `ner_service.py` (estilo) | diff y tests de rojo a verde, en ≤300 palabras | Responde al crítico con un cambio o con una justificación |
| `code-critic` | Opus | Solo lectura; `uv run` para mutar sobre una copia en el scratchpad | la spec y el diff, **sin** las conclusiones del implementer | APPROVE/CHANGES y las mutaciones que mueren | Corre en paralelo. No tiene SendMessage, así que yo llevo las preguntas al implementer y arbitro; máximo 2 rondas |
| `assistant` | Sonnet | Read y `uv run` en el scratchpad; no edita el repo | `01_ocr_words.csv`, `02a_name_boxes.csv` y los 3 PDFs | La regresión: palabras y cajas desde `app/` comparadas con el proto (diferencia máxima en pt), y P/R | Solo me reporta a mí |
| `notebook-builder` | Sonnet | Edita `research/notebook-builders/build_nb02a.py` y ejecuta con nbconvert | NB02a y su builder | Sección "Desde `app/`" (ver paso 5), ejecutada con 0 errores | Después pasa a revisión |
| `notebook-reviewer` | Opus | Solo lectura | NB02a ejecutado, **sin** las conclusiones del builder | Comprueba que cada afirmación tiene su celda | Si hace falta corregir, lo hago con el builder |

## Orden (3 commits de código, cada uno en verde)
1. **Config** (commit `feat(config): add bounding box origin setting`)
   1. AC-CFG-04 en `tests/unit/test_config.py`, en rojo.
   2. En `app/config.py`, bajo `# OCR`: `bbox_origin: Literal["top-left", "bottom-left"] = "top-left"`.
   3. Agregar `BBOX_ORIGIN=top-left` a `.env.example`.
2. **OCR** (commit `feat(ocr): extract words with boxes in PDF points`)
   1. Tests en rojo en `tests/unit/test_ocr_service.py`: AC-OCR-01..06. Usan un PDF en blanco creado en memoria con `pymupdf.open()` y `new_page`, y un fake que devuelve las columnas de `image_to_data`.
   2. Implementar `ocr_service.py`:
      - `Word`, `OcrEngine`, `tesseract_data` e `InvalidPdfError`;
      - `ocr_pages`, con `with pymupdf.open(stream=..., filetype="pdf")` dentro de un `try` que convierte `FileDataError` en `InvalidPdfError`;
      - `page_text`;
      - los 2 stubs, que leen `Path(pdf_path).read_bytes()`.
3. **Cajas** (commit `feat(bbox): locate name boxes from OCR words`)
   1. Tests en rojo:
      - AC-BOX-01..03 en `tests/unit/test_bbox_service.py`;
      - AC-BOX-04 (E1) y AC-BOX-05 (e2e) en `tests/integration/test_ocr_boxes.py`, con `pytestmark = skipif(shutil.which("tesseract") is None)`.
   2. Implementar `bbox_service.py`: `boxes_for_spans`, `locate_names` (una sola llamada a `find_person_spans`) y el stub `find_name_bounding_boxes`.
   3. `verify.ps1`, el crítico en paralelo y la regresión del assistant.
4. **Fixture E1:** una fixture de pytest en el mismo archivo de integración (unas 8 líneas, del snippet del package-auditor). No va como archivo en `tests/fixtures/`.
5. **Cierre** (después de los 3 commits)
   1. **Notebook 02a**, que es el notebook de la tarea porque ya lee `01_ocr_words.csv` y dibuja las cajas:
      - "Desde `app/`" con `ocr_pages` sobre los 3 PDFs comparado con `01_ocr_words.csv` (mismas palabras, diferencia máxima en pt) y `locate_names` comparado con `02a_name_boxes.csv`;
      - "Preguntas" y un borrador de "Mis respuestas".
   2. **NB01:** solo una celda markdown que apunta a 02a.
   3. **Documentación:**
      - `research/20`: preguntas de implementación;
      - `research/18-metricas.md`: la regla "contenida ±1 pt y ancho ≥ 0.95" si no está.
   4. **`DECISIONS.md`:** una sección "OCR and bounding boxes" con bytes y una sola apertura, px→pt por `page.rect`, la caja unión, la puntuación de borde aceptada, el origen configurable, la licencia AGPL de pymupdf y E1/e2e. **Te muestro el texto exacto antes.** Commit `docs: record OCR and bounding box decisions`.
   5. **Spec:** tu Explicación en la spec. Commit `docs(spec): explain OCR and bounding box acceptance criteria`.
   6. **Estado:** `tasks/INDEX.md`, `research/22-estado` y la fila en `DECISIONS-LOG`.

## Archivos y funciones
| Archivo | Cambio | AC |
|---|---|---|
| `app/config.py`, `.env.example` | `bbox_origin` | CFG-04, OCR-06 |
| `app/services/ocr_service.py` | `Word = dict`, `OcrEngine(Protocol)` y `tesseract_data(image)` (de `proto/ocr.py:29-35`) | inyección |
| | `InvalidPdfError(ValueError)`, que envuelve `pymupdf.FileDataError` | OCR-05 |
| | `ocr_pages(pdf_bytes, engine=None)`: una sola apertura; render en gris a `ocr_dpi`; escala `page.rect.width / pix.width`; filtro `conf >= 0` y `strip()`; volteo `H - y - h`; `page` y `line` | OCR-01, 02, 03, 06 |
| | `page_text(words)`: texto y palabras con `start`/`end` (de `proto/ocr.py:66-89`, sin `.loc`) | OCR-04 |
| | stubs `extract_text_from_pdf` (`"\n\n"`) y `get_word_bounding_boxes` | R1 |
| `app/services/bbox_service.py` | `boxes_for_spans(words, spans)`: unión de las palabras con `start < e and end > s` (de `proto/ner.py:26-35`) | BOX-01..04 |
| | `locate_names(pages)`, que usa `find_person_spans` de `ner_service.py` | BOX-05 |
| | stub `find_name_bounding_boxes(pdf_path, text)`; `text` no se usa y lo dice el docstring | R1 |

**Se reutiliza:**
- `app.config.get_settings`;
- `ner_service.find_person_spans` y `Span`;
- el patrón de fixture `autouse` con `Settings(_env_file=None)` de `tests/unit/test_ner_service.py:8-10`;
- `proto/ocr.py:add_offsets_all` y `proto/ner.py:precision_recall`, solo en la regresión y en el notebook, nunca en `app/`.

## Tests (rojo primero)
- **`tests/unit/test_ocr_service.py`:**
  - fixture `autouse` de config y un helper `blank_pdf(n)` de unas 4 líneas;
  - el fake devuelve un dict de columnas;
  - AC-OCR-01 a 150 DPI: 48 / 96 / 24 / 12, con `page=0` y `line=(1,1,1)`;
  - AC-OCR-02: 2 páginas y 2 llamadas;
  - AC-OCR-03: `conf=-1` y texto `"  "`;
  - AC-OCR-04: `"Ann Lee\nBob"` con offsets `(0,3), (4,7), (8,11)`;
  - AC-OCR-05: 3 casos de bytes, con `parametrize`;
  - AC-OCR-06: 684.0.
- **`tests/unit/test_bbox_service.py`:**
  - AC-BOX-01: `{"name": "Ann Lee", "page": 1, "x": 10, "y": 5, "width": 40, "height": 12}`;
  - AC-BOX-02: el ancho llega hasta "Thompson,";
  - AC-BOX-03: 2 cajas distintas.
- **`tests/integration/test_ocr_boxes.py`:**
  - AC-BOX-04: E1 con `parametrize` de fuentes 11, 14 y 24;
  - AC-BOX-05: las 3 muestras contra `gold_names.csv` y `gold_boxes.csv`, leídas con `csv.DictReader`, sin pandas.
- **`tests/unit/test_config.py`:** AC-CFG-04.

## Líneas esperadas y qué no se escribe
- **Tamaño:** `ocr_service` ~70 (tope 80), `bbox_service` ~28 (tope 35) y tests ~120. Si se pasa del tope, lo decide el crítico.
- **No se escribe:**
  - pandas en `app/`;
  - `make_scanned_pdf.py` ni el fixture como archivo;
  - recorte de puntuación;
  - caja por renglón;
  - validación del upload, el router y el lifespan (eso es la spec 04);
  - cambios a `schemas.py`, `main.py` o `ner_service.py`.

## Riesgos y cómo se verifican
- **Un `.env` local con `OCR_*` o `BBOX_*`:** los tests usan un fixture `autouse` con `_env_file=None`.
- **La mutación del DPI fijo:** AC-OCR-01 usa 150 DPI, no 300.
- **Otra versión de Tesseract en el evaluador:** tolerancia de ±2 pt, recall como umbral y `skipif`. Los unitarios no dependen de Tesseract.
- **Tiempo del e2e (~15-25 s) dentro de `verify.ps1`:** es aceptable. Se mide y se anota.
- **Divergencia con el proto:** el assistant compara palabra por palabra contra `01_ocr_words.csv` (diferencia esperada 0, porque se usan el mismo DPI y el mismo psm) y caja por caja contra `02a_name_boxes.csv`.
- **Mutaciones que debe matar el crítico:**
  - sin escala;
  - `range(1, n)`, que salta la página 0;
  - sin el filtro de `conf`;
  - origen ignorado;
  - altura tomada de la última palabra;
  - renglón agrupado solo por `line_num`;
  - `find_person_spans` llamado por página.

## Verificación
1. `uv run pytest tests/unit/test_config.py -q`: de rojo a verde.
2. `uv run pytest tests/unit/test_ocr_service.py tests/unit/test_bbox_service.py -q`: de rojo a verde en cada commit.
3. `uv run pytest tests/integration -q`: E1 y e2e en verde con Tesseract 5.4.
4. `powershell -NoProfile -File .claude/tools/verify.ps1`: ruff, formato y pytest en ok.
5. Regresión del assistant: igual al proto, con P 1.0 y R 54/55.
6. El code-critic da APPROVE con las mutaciones, NB02a se ejecuta con 0 errores y el notebook-reviewer da OK.
7. Tu Explicación, y después `/commit-handoff` para cada commit.

## Compact (una línea, para después de aprobar)
`/compact Tarea 03-ocr-boxes: spec 88567ba y gold_boxes ea9209a commiteados; plan aprobado en tasks/03-ocr-boxes/plan.md; siguiente: implementer + code-critic en paralelo (config bbox_origin -> ocr_service -> bbox_service), assistant regresión, NB02a "Desde app/"; DECISIONS.md solo con texto mostrado a JM.`
