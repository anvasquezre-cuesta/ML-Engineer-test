# 03-ocr-boxes · Evaluación

| Qué | Cómo | Esperado |
|---|---|---|
| ACs | unitarios con un engine falso | AC-OCR-01 px->pt; 02 todas las páginas incl. 0; 03 descarta conf < 0 o vacías; 04 `text[start:end] == word`; 05 bytes inválidos -> error de dominio; 06 `bottom-left`; AC-BOX-01 unión en pt; 02 "Thompson," dentro; 03 una caja por ocurrencia |
| Geometría | fixture sintético E1 generado en memoria (fuentes 11/14/24) | caja OCR dentro de la de `search_for` ±1 pt y ancho ≥ 0.95 (medido 0.982-0.987). No IoU: da 0.55 por caja de renglón vs tinta |
| E2E (AC-BOX-05) | `skipif` sin Tesseract; flujo completo OCR -> NER -> cajas sobre las 3 muestras | P = 1.0 y R ≥ 54/55 contra `eval/gold_names.csv`; cada mención hallada tiene caja a ±2 pt de `eval/gold_boxes.csv` en la misma página |
| Regresión | notebook, sección "Desde `app/`" | palabras y cajas idénticas a `01_ocr_words.csv` y `02a_name_boxes.csv` |
| Calidad | `verify.ps1` + code-critic | verde; APPROVE |

Criterios E1 y E2E aceptados por Jeison (2026-10-29). `eval/gold_boxes.csv` (55 filas, pt, top-left): 54 cajas del proto (`02a_name_boxes.csv`, revisadas sobre las imágenes en 02a) + Lucas Zimmermann armada a mano con sus 2 palabras OCR (`01_ocr_words.csv:488-489`). No se genera desde `app/`, para que el test no se compare consigo mismo.
Gates comunes (spec -> plan JM -> tests rojo -> verde -> code-critic -> explicación -> commit): `research/19-plan-implementacion.md`.
