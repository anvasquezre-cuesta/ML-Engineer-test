# 04-extract-api · Endpoint /api/extract

**Alcance:** Router delgado `POST /api/extract`, parseo y validación de `names`, validación del upload (contenido PDF, vacío, tamaño, `MAX_PAGES`), errores de dominio -> HTTP, logging estructurado sin PII, inyección de dependencias, `/health` (R8) y test e2e.
**Spec:** `ML-Engineer-test/docs/specs/04-extract-api.md` (por escribir)
**Estado:** research listo · evaluación lista · spec fe8c7fc · cerrada 2026-10-29 · NB04 revisado (39 celdas, 0 errores)

| Etapa | Archivo |
|---|---|
| Research | [research.md](research.md) |
| Evaluación | [evaluation.md](evaluation.md) |
| Plan (JM) | [plan.md](plan.md) |
| Reviews | [reviews/](reviews/) |

## Qué necesitamos
**Depende de:** 01, 02 y 03 cerradas.
**Entradas:** README:38-49 y 78-101; contrato en `app/models/` (solo lectura); R7, R8 en `research/14`; `artifacts/03_matches.csv`.
**Entregables:** `app/api/extract.py`; orquestador (D-API-2); errores de dominio y handlers; logging; `/health`; config `max_upload_mb`, `max_pages`; `tests/unit/test_extract_api.py`; `tests/e2e/test_extract_e2e.py` (`skipif` sin Tesseract).

**Pasos que faltan (en orden):**
1. package-auditor: `UploadFile` y límites, `exception_handler`, logging stdlib, `Depends` + `lru_cache` (snippets ejecutados).
2. assistant: tabla errores de dominio -> HTTP en [research.md](research.md).
3. code-critic: decide D-API-1..3.
4. evaluation + spec `04-extract-api.md`; crítica; firma JM.
5. JM escribe [plan.md](plan.md).
6. implementer -> verify -> code-critic -> assistant corre el e2e (8 menciones, 3 matches) -> explicación JM -> `/commit-handoff`.

**Commits previstos** (uno por idea, siempre verde y explicado):
- `docs(spec): add extract endpoint spec`
- `feat(api): add domain errors mapped to HTTP status`
- `feat(api): validate uploaded PDF`
- `feat(api): add /api/extract endpoint`
- `test(e2e): extract names from company memo`

**Hecho cuando:** todos los gates de [evaluation.md](evaluation.md) cumplidos, code-critic APPROVE, explicación de JM firmada y commits hechos.
