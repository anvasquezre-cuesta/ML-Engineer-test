# 04-extract-api · Evaluación

| Qué | Cómo | Esperado |
|---|---|---|
| ACs | `TestClient` + `dependency_overrides` con fakes (sin Tesseract ni spaCy) | AC-OCR-07..09, AC-API-01..05, AC-LOG-01 en verde |
| Tabla de errores | AC-API-02..05 | 422 (names, vacío/no PDF/cifrado), 413 (tamaño, páginas), 503 (OCR) |
| PII | AC-LOG-01 | ningún nombre en el log; `X-Request-ID` en toda respuesta |
| E2E | AC-API-06, `skipif` sin Tesseract, `company_memo.pdf` + lista del NB03 | 8 menciones en la página 0; matches = `notebooks/artifacts/03_matches.csv` (3 filas) |
| Tamaño | presupuesto de la spec | ~62 líneas en `app/` (tope 75); cada pieza justificada por una línea del README |
| Calidad | `verify.ps1` + code-critic | verde; APPROVE |

Gates comunes (spec -> plan JM -> tests rojo -> verde -> code-critic -> explicación -> commit): `research/19-plan-implementacion.md`.
