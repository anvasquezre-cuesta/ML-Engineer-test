# 2026-10-29 · code-critic (opus) · spec 04, ronda 1 · CHANGES

Snippets: scratchpad `critic04spec/m1.py`, `m2.py`. Verificado por Claude: `Json[list[NamePair]]` en `Form` da el 422 nativo (FastAPI 0.162; el package-auditor solo había probado modelos sin `Json`); `get_settings` tiene `lru_cache` (`config.py:31`).

1. `names: Annotated[Json[list[NamePair]], Form()]` en vez de `str` + `TypeAdapter` (-5 líneas). **Aplicado.**
2. AC-API-01: `ocr_dpi=72` y caja literal. **Aplicado.**
3. AC-API-02: PDF válido y fake que cuenta llamadas (mata la mutación "validar después del OCR"). **Aplicado.**
4. Config en tests de API: `setenv` + `get_settings.cache_clear()` (el monkeypatch por módulo no llega al router). **Aplicado.**
5. `log.py` sin clase formatter: `log_event(**f)` + `json.dumps` (-6). **Aplicado.**
6. Quitar casos redundantes: cifrado en API-03 y `max_pages` en API-04 (los cubren OCR-07/08). **Aplicado.**
7. E2E en `tests/integration/`, esperado a mano, `skipif` sin `en_core_web_sm`, `FUZZY_THRESHOLD=0.90`, 8 nombres en orden. **Aplicado.**
8. `pdf_file.size` en vez de `read(limit+1)` (-1). **No aplicado:** `size` puede ser `None` (package-auditor); se deja `read(limit+1)`.

Total estimado: ~62 líneas en `app/` (antes ~73).
