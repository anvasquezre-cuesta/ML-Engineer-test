# 2026-10-29 · code-critic (opus) · D-API-1..4

Entrada: `research.md` (hechos del package-auditor + tabla borrador). Snippets: scratchpad `critic04/q1.py`, `q2.py`.
Verificado por Claude: `locate_names` (`bbox_service.py:26`) no recibe recognizer; `find_person_spans` sí (`ner_service.py:45-49`); pymupdf abre `b"junk\n" + pdf` (`is_pdf=True`); `TesseractError` es subclase de `RuntimeError`.

- **D-API-1:** log JSON stdlib + middleware `request_id` (contextvar, cabecera `X-Request-ID`); el formatter lee el contextvar (sin Filter). Campos: método, ruta, status, ms, páginas, nº de nombres; nunca nombres. `app/log.py` (no `logging.py`, tapa stdlib). ~22 líneas. NO: dependencias nuevas, tocar uvicorn.
- **D-API-2:** función pura `extract(pdf_bytes, names, engine, recognizer) -> ExtractionResponse` en `app/services/extraction_service.py` (sin estado → sin clase). ~15 líneas. `locate_names` gana `recognizer=None` (~2 líneas netas).
- **D-API-3:** `Depends` sobre `get_ocr_engine()` y `get_recognizer()` en `app/dependencies.py` (las reutiliza RAG). Sin `lru_cache` (sin estado; spaCy ya cacheado en `ner_service.py:18`). Tests con `dependency_overrides` (verificado). ~8 líneas. NO: lifespan, `app.state`.
- **D-API-4:**
  - Sin chequeo de magic `%PDF-` (0 líneas): `ocr_pages` ya rechaza por contenido; mupdf acepta basura antes de `%PDF` (la spec PDF lo permite) y el magic lo rechazaría por error.
  - Cifrado (`needs_pass` → `InvalidPdfError`) y `page_count > max_pages` (→ `DocumentTooLargeError`) dentro de `ocr_pages`, misma apertura, tras la línea 61. ~5 líneas.
  - `tesseract_data`: `except (RuntimeError, TesseractNotFoundError)` → `OcrEngineError`. ~4 líneas. Un handler global de `RuntimeError` sería peligroso.
  - Tabla: sin 415; vacío/corrupto/cifrado 422; tamaño y páginas 413 (`DocumentTooLargeError`); timeout y binario ausente 503 (`OcrEngineError`; 504 es de pasarelas).
  - Un dict `{excepción: status}` + un handler en `main.py` (~6 líneas, sirve a RAG). Sin `HTTPException` en routers.
  - Router: helper `read_pdf` (`read(max+1)`) + `TypeAdapter.validate_json` → `RequestValidationError` (~15 líneas; `loc` sin prefijo `body/names`, aceptable).
- **ACs propuestos:** API-01 200 con cajas y matches · 02 `names` inválido 422 · 03 vacío/no PDF 422 · 04 > `max_upload_mb` 413 · 05 > `max_pages` 413 · 06 cifrado 422 · 07 engine falla 503 · 08 `X-Request-ID` + log JSON sin nombres · 09 e2e memo 200.
- **Balance:** ~+100 líneas. **Veredicto: CHANGES** sobre el borrador (quitar 415, unificar 413/503, cifrado y `max_pages` en `ocr_pages`, `recognizer` en `locate_names`).
