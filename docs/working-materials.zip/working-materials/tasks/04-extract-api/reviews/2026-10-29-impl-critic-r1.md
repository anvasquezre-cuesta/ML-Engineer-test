# 2026-10-29 · code-critic (opus) · diff pasos 1-3 · CHANGES → aplicados

Mutaciones (copia en scratchpad `critic04impl`, script `mut.py`): mueren names-después-del-OCR (FastAPI valida antes), sin `needs_pass`, `max_pages` tras renderizar, sin wrap de Tesseract, `read(limit)`, lambda sin `status=status`, sin `model_dump`. `recognizer` ignorado solo moría por TypeError en BOX-06 (en API cargaba spaCy real). `>=` vs `>` sobrevive (borde de 1 byte, aceptado).

1. Obligatorio: `NER_MODEL=no-such-model` en la fixture de `test_extract_api.py` (el unitario nunca carga spaCy; mata la mutación del recognizer). **Aplicado.**
2. `extract` construye dicts y Pydantic valida (-6, sin imports de `BoundingBox`/`ExtractedName`). **Aplicado.**
3. `main.py`: función `domain_error` con `ERROR_STATUS[type(exc)]` en vez de lambda con default (más explicable; sin subclases propias hoy). **Aplicado.**

Fakes importados de `test_ocr_service`, edición de `test_bbox_service.py` y `dependencies.py`: correctos. Exceso sobre el presupuesto (~89 brutas vs ~48): imports partidos por ruff, firmas y docstrings; no se recorta más. verify.ps1 verde tras los cambios.
