# 04-extract-api · Research

## Fuentes y decisiones tomadas
- README:38-49 (contrato), 78-89 (arquitectura, config, resiliencia, validación, recursos, logging), 99-101 (tests e2e).
- [V] R7 `MAX_PAGES`, R8 `/health` liveness: `research/14-revision-plan.md:19-20`.
- Contrato: `ExtractionResponse`, `NamePair` en `app/models/` (no se cambia).

## Hechos de las librerías (package-auditor, 2026-10-29)
Versiones del lock: fastapi 0.162.0, starlette 1.10.0, python-multipart 0.0.32 (ya en el lock), pydantic 2.14.1, pymupdf 2.0, pytesseract 0.3.13, Tesseract 5.4.0. Snippets en el scratchpad (`audit04/q1..q7.py`). [V] = ejecutado; (C) = Claude lo re-ejecutó.

1. **Upload [V]:** `pdf_file.file.read(max + 1)` y comparar `len > max`. Starlette ya recibió todo el archivo antes del endpoint (spool a disco > 1 MB), así que el tope no ahorra descarga; solo rechaza. Sin tope de archivo en Starlette; `max_part_size` 1 MB solo para campos de texto (`names` > 1 MB → 400). Starlette cierra el archivo al terminar. Vacío: `read()` = `b""`. `pdf_file` ausente → 422 nativo.
2. **`names` [V]:** FastAPI no parsea JSON dentro de un `Form` (un modelo da 422 `model_attributes_type`), así que `names: str = Form()` + `TypeAdapter(list[...]).validate_json`. Su `ValidationError` re-lanzado como `RequestValidationError(e.errors(include_url=False, ...))` da el mismo 422 que el nativo. Campo ausente → 422 nativo.
3. **pymupdf [V] (C):** PDF con contraseña de usuario abre sin error, `is_pdf=True`, `needs_pass=1`, `page_count` disponible; renderizar lanza `ValueError("document closed or encrypted")` → hoy sería 500. Solo contraseña de dueño: renderiza normal. `page_count` antes de renderizar → `MAX_PAGES` cabe en la misma apertura de `ocr_pages`.
4. **pytesseract [V] (C):** timeout = `RuntimeError('Tesseract process timeout')` (tipo genérico; se distingue por mensaje). Binario ausente: `TesseractNotFoundError` (subclase de `OSError`).
5. **Handlers [V]:** `@app.exception_handler(InvalidPdfError)` funciona desde endpoint `def` (threadpool); un `ValueError` sin handler → 500.
6. **DI [V]:** `Depends(get_x)` con `get_x` en `lru_cache` acepta `app.dependency_overrides[get_x]` y no construye el real. `lifespan` + `app.state` también, pero solo corre dentro de `with TestClient(app)`.
7. **Logging [V]:** formatter JSON de ~5 líneas (vuelca `extra` restando las claves estándar del LogRecord). Un contextvar fijado en un middleware se ve en el endpoint `def`. Loguear antes de `reset`.

## Tabla de errores → HTTP (borrador de Claude, a decidir por el code-critic)
| Condición | Dónde se detecta | Excepción | HTTP |
|---|---|---|---|
| `pdf_file` o `names` ausentes | FastAPI | nativa | 422 |
| `names` no es JSON o no cumple el modelo | router | `ValidationError` → `RequestValidationError` | 422 |
| archivo vacío | validación del upload | `InvalidPdfError` | 422 |
| > `max_upload_mb` | validación del upload | dominio (p. ej. `PayloadTooLargeError`) | 413 |
| no es PDF por contenido (magic `%PDF-`) | validación del upload | dominio | 415 |
| con cabecera pero corrupto, o imagen | `ocr_pages` | `InvalidPdfError` | 422 |
| cifrado (`needs_pass`) | `ocr_pages` (falta) | `InvalidPdfError` | 422 |
| > `max_pages` | `ocr_pages` (falta) | dominio | 413 |
| timeout de Tesseract | `tesseract_data` | `RuntimeError` | 504 |
| Tesseract no instalado | `tesseract_data` | `TesseractNotFoundError` | 503 |

## Decisiones (code-critic, `reviews/2026-10-29-decisions-critic.md`; JM aprueba 2026-10-29: 422 sin magic, 503 para ambos)
- D-API-1: log JSON stdlib + middleware `X-Request-ID` (contextvar), sin nombres, en `app/log.py`.
- D-API-2: función pura `extract(...)` en `app/services/extraction_service.py`; `locate_names` gana `recognizer=None`.
- D-API-3: `Depends` sobre `get_ocr_engine`/`get_recognizer` en `app/dependencies.py`; sin `lru_cache` ni lifespan.
- D-API-4: sin magic ni 415; cifrado y `max_pages` en `ocr_pages`; `OcrEngineError` → 503; `DocumentTooLargeError` → 413; un handler con dict en `main.py`. La tabla de arriba queda corregida así.
