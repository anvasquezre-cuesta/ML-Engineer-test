# Plan · Tarea 04-extract-api (`POST /api/extract`)

## Contexto
La spec `docs/specs/04-extract-api.md` pasó la ronda 1 del code-critic (CHANGES aplicados). Jeison eligió saltar la ronda 2. Las decisiones D-API-1..4 están en `tasks/04-extract-api/reviews/`.
Hoy `app/api/extract.py` es un TODO. Hay que conectar `ocr_pages` → `locate_names` → `fuzzy_match_names` detrás de un router delgado, con errores de dominio → HTTP (422/413/503) y un log JSON por request sin nombres.
Objetivo: **~62 líneas en `app/`** (tope 75). Cada pieza responde a una línea del README:78-89. Si una pieza se pasa de su presupuesto, el crítico decide si se recorta.
Al aprobar: (0) copiar este plan a `tasks/04-extract-api/plan.md`; (1) Jeison hace el commit de la spec:
```powershell
$r = "C:\Users\Jeikosd\Documents\jeikosd\parterns_test_ML\ML-Engineer-test"
git -C $r add -- "$r\docs\specs\04-extract-api.md"
git -C $r commit -m "docs(spec): add extract endpoint spec"
```

## Subagentes (este plan pide tu sí para todos)
| Rol | Modelo | Habilidades | Lee | Devuelve | Interacción |
|---|---|---|---|---|---|
| `implementer` | Sonnet | Read/Edit/Write, `uv run`, `verify.ps1`; sin git | spec 04, este plan, servicios y tests actuales (estilo) | diff + tests de rojo a verde, ≤300 palabras | responde al crítico con cambio o justificación |
| `code-critic` | Opus | solo lectura; `uv run` para mutar sobre una copia en el scratchpad | spec y diff, **sin** las conclusiones del implementer | APPROVE/CHANGES, mutaciones que mueren, líneas que sobran | en paralelo; yo llevo preguntas al implementer y arbitro; máx. 2 rondas |
| `notebook-builder` | Sonnet | crea `research/notebook-builders/build_nb04.py`, ejecuta con nbconvert | spec 04, NB03 (estilo), `app/` | NB04 ejecutado con 0 errores | luego revisión |
| `notebook-reviewer` | Opus | solo lectura | NB04 ejecutado, **sin** conclusiones del builder | cada afirmación tiene su celda | correcciones las hago yo vía builder |

Sin `assistant` de regresión: el e2e AC-API-06 ya compara contra los artefactos del proto (8 nombres, 3 matches).

## Orden (4 commits de código, cada uno en verde)
1. **Config + OCR** (`feat(ocr): reject encrypted and oversized PDFs and wrap engine errors`)
   - `app/config.py`: `max_upload_mb: int = Field(20, gt=0)`, `max_pages: int = Field(50, gt=0)`; `.env.example` (sección nueva `# Upload limits`).
   - Rojo: AC-OCR-07 (cifrado), 08 (`max_pages=1`, 2 páginas, `fake.calls == 0`), 09 (`monkeypatch` de `pytesseract.image_to_data` que lanza `RuntimeError("Tesseract process timeout")` y `TesseractNotFoundError`; `err.__cause__` es el original) en `tests/unit/test_ocr_service.py`, con su `use_settings` (`test_ocr_service.py:12-14`).
   - Verde en `ocr_service.py`: `DocumentTooLargeError(ValueError)`, `OcrEngineError(RuntimeError)`; tras `doc.is_pdf` (línea 60): `needs_pass` → `InvalidPdfError`, `page_count > max_pages` → `DocumentTooLargeError`; `try/except` en `tesseract_data`.
2. **Extracción** (`feat(api): add extraction service and dependencies`)
   - `bbox_service.locate_names(pages, recognizer=None)` → `find_person_spans(texts, recognizer)` (AC-BOX-06 sigue verde).
   - `app/services/extraction_service.py`: `extract(pdf_bytes, names, engine, recognizer) -> ExtractionResponse`; mapea `{"name","page","x",...}` → `ExtractedName(BoundingBox(page_number=...))`; `fuzzy_match_names([b["name"] for b in boxes], [n.model_dump() for n in names])`; `log_event(pages=..., names_in=..., names_found=..., matches=...)` → este se añade en el paso 4 (aquí no).
   - `app/dependencies.py`: `get_ocr_engine()` → `tesseract_data`; `get_recognizer()` → `spacy_persons`.
3. **Router + errores** (`feat(api): add /api/extract endpoint with domain error mapping`)
   - Rojo: `tests/unit/test_extract_api.py` AC-API-01..05. Fixture: `setenv` + `get_settings.cache_clear()` (antes y después) y `app.dependency_overrides` limpiado al final. Reutiliza `FakeEngine`/`row`/`blank_pdf`: se importan de `tests/unit/test_ocr_service.py` (sin `conftest` nuevo, salvo que el crítico lo pida).
   - Verde: `app/api/extract.py` (`Json[list[NamePair]]` en `Form`, `read(limit + 1)`, `Depends`), y en `main.py` el dict `{InvalidPdfError: 422, DocumentTooLargeError: 413, OcrEngineError: 503}` registrado con `app.add_exception_handler` en un bucle; respuesta `{"detail": str(exc)}`.
4. **Log** (`feat(api): log each request as JSON with a request id`)
   - Rojo: AC-LOG-01 (`caplog` sobre el logger `app`; parsea `record.getMessage()` como JSON; "Ann" no está en ningún mensaje).
   - Verde: `app/log.py` (`request_id` contextvar, `log_event`, middleware `@app.middleware("http")` registrado en `main.py`; `basicConfig(format="%(message)s", level=INFO)` en `main.py`); `extract` llama a `log_event` con los conteos.
5. **E2E** (`test(e2e): extract names from company memo`)
   - `tests/integration/test_extract_e2e.py`: `skipif` sin Tesseract o sin `en_core_web_sm` (`spacy.util.is_package`); `FUZZY_THRESHOLD=0.90` vía `setenv` + `cache_clear`; esperado a mano: 8 nombres en orden de `02a_name_boxes.csv`, página 0, y las 3 tuplas de matches.
6. **Cierre**
   - `verify.ps1` verde; crítico APPROVE.
   - NB04_extract_e2e (nuevo, tope 0.5 h; numeración de `research/14` sec. 3): `TestClient` sobre las 3 muestras, compara con `02a_name_boxes.csv` y `03_matches.csv`; muestra los códigos 422/413/503 y una línea de log; sección "Explicación de los AC de la spec 04" (la redacto yo), "Preguntas" y borrador de "Mis respuestas". Spec ya apunta al notebook.
   - `DECISIONS.md` sección "Extraction endpoint": **te muestro el texto exacto antes**. Commit `docs: record extraction endpoint decisions`.
   - Estado: `tasks/INDEX.md`, README de la tarea, `DECISIONS-LOG`, `research/20` (preguntas de entrevistador), memoria del proyecto.

## Archivos
| Archivo | Cambio | AC |
|---|---|---|
| `app/config.py`, `.env.example` | `max_upload_mb`, `max_pages` | OCR-08, API-04 |
| `app/services/ocr_service.py` | 2 excepciones, `needs_pass`, `max_pages`, wrap de `tesseract_data` | OCR-07..09 |
| `app/services/bbox_service.py` | `recognizer=None` en `locate_names` | API-01 |
| `app/services/extraction_service.py` (nuevo) | `extract` | API-01 |
| `app/dependencies.py` (nuevo) | `get_ocr_engine`, `get_recognizer` | API-01..05 |
| `app/api/extract.py` | router | API-01..05 |
| `app/log.py` (nuevo) | contextvar, `log_event`, middleware | LOG-01 |
| `app/main.py` | handlers, middleware, `basicConfig` | API-03..05, LOG-01 |

**Se reutiliza:** `ocr_pages`, `InvalidPdfError` (`ocr_service.py:19,56`); `locate_names` (`bbox_service.py:26`); `find_person_spans(pages, recognizer)` (`ner_service.py:45`); `spacy_persons` (`ner_service.py:24`); `fuzzy_match_names` (`fuzzy_service.py:31`); `FakeEngine`, `row`, `blank_pdf` (`tests/unit/test_ocr_service.py:22-42`).

**No se escribe:** chequeo `%PDF-`/415, reintentos, lifespan, `lru_cache` en dependencias, clase formatter, `HTTPException` en routers, cambios a `schemas.py` y `/health`.

## Riesgos
- `.env` local con `MAX_*`/`FUZZY_*`: los tests de API usan `setenv` explícito y `cache_clear`.
- `basicConfig` en `main.py` no toca los loggers de uvicorn (tienen handler propio); el test usa `caplog`, no stdout.
- Mutaciones que debe matar el crítico: validar `names` después del OCR; olvidar `needs_pass`; `max_pages` después de renderizar; `RuntimeError` sin envolver (500); loguear nombres; no reutilizar `X-Request-ID`; `recognizer` ignorado en `locate_names`.

## Verificación
1. `uv run pytest tests/unit -q` de rojo a verde en cada commit.
2. `uv run pytest tests/integration -q`: AC-API-06 (8 nombres, 3 matches) con Tesseract 5.4.
3. `powershell -NoProfile -File .claude/tools/verify.ps1` en verde.
4. Arranque real: `uv run uvicorn app.main:app` + `curl -F pdf_file=@sample_pdfs/company_memo.pdf -F names='[...]' localhost:8000/api/extract` → 200 y una línea JSON en consola.
5. Conteo de líneas de `app/` (`git diff --stat`) ≤ 75.
6. Crítico APPROVE; NB04 0 errores; notebook-reviewer OK; tu Explicación y `/commit-handoff` por commit.
