# 05-rag-ingest · RAG: ingesta

**Alcance:** `rag_service.chunk_text` e `ingest`, `embedding_service`, `vector_service` (`init_collection`, `store_document_chunks`, `search_similar`) y `POST /api/ingest`.
**Spec:** `ML-Engineer-test/docs/specs/05-rag-ingest.md` (firmada por JM; 1e8876b, alineada con los tests en ebcfddc)
**Estado:** implementada (6 commits, `app/` = 120 líneas) · NB05 "Desde `app/`" y Explicación de los AC listos (113 celdas, 0 errores) · `DECISIONS.md` escrito · falta: JM estudia y firma la Explicación y "Mis respuestas" del NB05

| Etapa | Archivo |
|---|---|
| Research | [research.md](research.md) |
| Evaluación | [evaluation.md](evaluation.md) |
| Plan (Plan Opus + respuestas de JM) | [plan.md](plan.md) |
| Borrador de DECISIONS.md | [decisions-draft.md](decisions-draft.md) |
| Reviews | [reviews/](reviews/) |

## Qué se hizo
**Entradas:** `research/06-tl-plan.md:26-30`, `03-rag-stack.md`; `.claude/rules/rag.md`; papers de `papers/INDEX.md`; README:54-56, 95-98.
**Entregables:** NB05 `notebooks/05_rag.ipynb`; `eval/questions.json` (22 con respuesta + 4 sin respuesta); `app/services/rag_service.py`, `embedding_service.py`, `vector_service.py`; `app/api/rag.py` (`/api/ingest`); tests unitarios con fakes y de integración con MiniLM real.

**Commits:**
- `1e8876b docs(spec): add RAG ingest spec`
- `379e411 feat(config): add RAG ingest settings`
- `380de61 test(eval): add RAG retrieval questions`
- `c7256ce feat(rag): chunk text without splitting words`
- `af0759c feat(rag): store chunks in Chroma with unique ids`
- `dda3a0c refactor(api): share capped PDF upload reading`
- `40bd28a feat(api): add /api/ingest endpoint`
- `7fe35d8 test(integration): re-ingest documents with real MiniLM embeddings`
- `ebcfddc docs(spec): align ingest ACs with the tests`
- pendiente: `docs: record RAG ingest decisions`

**Hecho cuando:** gates de [evaluation.md](evaluation.md) cumplidos (regresión pareada: 12/12 chunks idénticos, 0 rangos distintos), code-critic aplicado por commit, explicación de JM firmada y commits hechos.
