# 05 · Decisiones de diseño (code-critic Opus, 2026-10-29)

Claude verificó los puntos marcados (C) con `scratchpad/verify05/v2.py`.

1. **D-RAG-2:** `doc_id = sha256(bytes).hexdigest()` completo (sin `[:16]`: recortarlo no ahorra nada y obliga a explicar por qué 16), y `filename` en la metadata. Si el mismo PDF llega con otro nombre, la re-ingesta conserva el mismo count y gana el último nombre. Si se re-escanea, los bytes cambian y cuenta como otro documento (DESIGN).
2. **D-RAG-4:** `rag_service.ingest(pdf_bytes, filename, engine, embed) -> IngestResponse`, a imagen de `extraction_service.extract`: OCR, chunk por página, metadata `{doc_id, filename, page, chunk}` y log.
   - `store_document_chunks(chunks, metadata, embed=get_embeddings)` embebe, borra con `delete(where={"doc_id": {"$in": ...}})` (C) y luego hace `add`. Un `ChromaError` (C: es la base de InternalError, NotFoundError e InvalidArgumentError) → `VectorStoreError` → 503.
   - Protocol `Embedder` + `get_embedder()` en `dependencies.py` (`Depends`).
   - Chroma va sin Protocol: `_collection()` con `lru_cache`.
   - Tests con `PersistentClient(tmp_path)` real (unos 0.1 s), sin `EphemeralClient` ni `reset`.
3. **PDF sin texto:** 200 con `chunks_stored=0`, registrado en el log. Lleva un guard porque `add([])` lanza `ValueError` (C), que no es un `ChromaError` y daría 500.
4. **Config (+5):** `embedding_model`, `chunk_size=Field(500, gt=0)`, `chunk_overlap=Field(60, ge=0)`, `chroma_path`, `chroma_collection="documents"`. El crítico descartó `revision`, `auto` y el modelo en la metadata de la colección (ver el arbitraje).
5. **`chunk_text` (11 líneas)** sobre `text.split()`, con overlap en caracteres por palabras enteras y `ValueError` si `overlap >= chunk_size` (C: 300 casos aleatorios según el crítico; Claude comprobó palabra gigante, texto vacío y "Jennifer Liu"). Colapsa los saltos de línea: hay que repetir la métrica del NB05 con esta función en "Desde `app/`".
6. **No escribir:**
   - Protocol `VectorStore`;
   - un context manager para los errores;
   - `upsert`;
   - lifespan;
   - `HttpClient` con reintentos;
   - `top_k` (es de 06);
   - las estrategias C, D y F.

   Opcional: un `read_pdf` compartido con `extract.py`.

Unas 100 líneas en `app/` + 6 en `.env.example`.

ACs propuestos:
- CHK-01..03: no corta palabras, overlap, texto vacío.
- VEC-01..04: IDs entre documentos, re-ingesta sin chunks sobrantes, score y metadata, 503.
- ING-01..03: 200 con `chunks_stored`, PDF en blanco con 0, 422 y 413.
- INT-01: A, B, A con `PersistentClient` en `tmp_path`.

## Arbitraje de Claude (para Jeison)
- **`embedding_device="auto"`:** el crítico lo quita porque el torch instalado es CPU. Jeison pidió un adaptador CPU/GPU, y el campo `embedding_device` (str) ya lo es: "cuda" funciona con un torch CUDA. `auto` solo tiene sentido junto con el empaquetado GPU, así que queda para la 08. 0 líneas ahora.
- **Modelo en la metadata de la colección:** el crítico tiene razón en que, sin comprobación, solo decora. Pero sin ella, cambiar MiniLM por bge-small (las dos de 384 dimensiones) mezcla vectores de dos modelos sin ningún error. Propuesta: guardarlo y, si no coincide, lanzar `VectorStoreError`. Son unas 3 líneas.
- **`revision` fija del modelo:** solo se fija en Docker (08), donde se descarga en el build. 0 líneas ahora.
