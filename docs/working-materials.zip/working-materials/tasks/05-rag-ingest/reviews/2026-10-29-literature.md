# 05 · Research de literatura (literature-researcher Opus, 2026-10-29)

Veredicto: no hay evidencia fuerte para cambiar el plan. Hay tres matices: chunks de 500 a 800 caracteres sin pasar de unos 250 tokens; el overlap solo se mantiene si NB05 muestra que ayuda; `MIN_SCORE` se calibra con nuestras propias preguntas.

## 1. Chunking
- **Informe de Chroma** (Smith y Troynikov, 2024-07-03), https://www.trychroma.com/research/evaluating-chunking, segunda tabla (all-MiniLM-L6-v2). [V] Lo volvió a verificar Claude con web-fetch.

  | Splitter | Tamaño | Overlap | Recall |
  |---|---|---|---|
  | RecursiveCharacterTextSplitter | 250 | 125 | 78.7 ± 39.2 |
  | RecursiveCharacterTextSplitter | 250 | 0 | 78.5 ± 39.5 |
  | RecursiveCharacterTextSplitter | 200 | 0 | 75.7 ± 40.7 |
  | TokenTextSplitter | 250 | 125 | 82.4 ± 36.2 |
  | TokenTextSplitter | 250 | 0 | 77.1 ± 39.3 |

  "Unsurprisingly, reducing chunk overlap improves IoU scores, as this metric penalizes redundant information" (sección de text-embedding-3-large). Las desviaciones de unos 39 puntos muestran cuánto varía de una pregunta a otra.
- **Chunking semántico:** Qu, Tu y Bao concluyen que no justifica su costo. arXiv 2410.13070 [V, resumen].
- **Proposiciones (Dense X):** exigen un LLM que reescriba el corpus. arXiv 2312.06648 [V].
- **Late chunking:** exige un modelo de contexto largo, y MiniLM corta en 256. arXiv 2409.04701 [V].
- **Ruido OCR (OHRBench, ICCV 2025):** degrada el RAG. arXiv 2412.02592 [V]. Acción: unir guiones de fin de línea y colapsar espacios.

## 2. Distancias
- Con norma 1, d_L2² = 2 − 2cos: coseno, producto punto y L2 dan el mismo ranking (derivación).
- Chroma usa L2² por defecto y define cosine como 1 − cos [V] (docs.trychroma.com/docs/collections/configure).
- El score no está calibrado entre consultas ni entre modelos [V] (fichas de bge-small y e5). Por eso `MIN_SCORE` sale de la distribución de nuestras preguntas con respuesta frente a las sin respuesta, y se vuelve a calibrar si cambia el modelo.
- HNSW con unas decenas de vectores: sin impacto (Chroma busca por fuerza bruta mientras hay menos de 100) [NV].

## 3. Embeddings (MTEB retrieval, promedio de 15 conjuntos; fichas de gte-small y bge-small) [V]
| Modelo | MTEB retrieval | Nota |
|---|---|---|
| all-MiniLM-L6-v2 | 41.95 | - |
| e5-small-v2 | 49.04 | exige prefijos |
| gte-small | 49.46 | - |
| bge-small-en-v1.5 | 51.68 | MIT |

Todos tienen 384 dimensiones. Se queda MiniLM, con bge-small como contraste en NB05; solo se cambia si sube hit@3 con intervalos que no se solapan.

## 4. Paquetes (PyPI) [V]
Ninguno aporta algo frente a unas 20 líneas propias más Chroma:
- fastembed 0.9.1: arrastra onnxruntime.
- qdrant-client 1.20.0: grpc.
- lancedb 0.41.0: pyarrow.
- faiss-cpu 1.15.1: no guarda metadata.
- sqlite-vec 0.1.9: pre-1.0.
- langchain-text-splitters 1.1.3: arrastra langchain-core.
- semchunk 4.1.1.
- chonkie 1.7.0.

## 5. Buenas prácticas
- **Ahora:**
  - metadata `filename`, `page`, `doc_id` y el modelo de embeddings, guardado en la colección;
  - ingesta idempotente;
  - normalización del texto OCR;
  - hit@k/MRR más abstención;
  - top_k ≤ 5, con el mejor chunk al inicio (Liu 2023).
- **Solo en DESIGN.md:** BM25 híbrido, cross-encoder, HyDE o reescritura de la consulta, MMR y RAGAS. Con 3 PDFs no dan una ganancia medible.

## Riesgos
- Con unas 20 preguntas, una diferencia de hit@3 menor a ~15 puntos es ruido.
- `MIN_SCORE` se descalibra si cambia el modelo.
- e5 sin prefijos falla en silencio.
- Las cifras de Chroma están en tokens y nuestros chunks en caracteres: medir tokens reales.

Papers para paper-curator, solo si se citan en DECISIONS.md: 2410.13070, el informe de Chroma, 2412.02592 y 2312.06648.
