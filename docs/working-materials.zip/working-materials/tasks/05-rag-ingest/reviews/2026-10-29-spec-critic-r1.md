# 05 · Crítica de la spec, ronda 1 (code-critic Opus, 2026-10-29)

Veredicto: CHANGES (4 obligatorios). Claude aplicó los 8 cambios en `docs/specs/05-rag-ingest.md`.

1. **Bug en el esbozo de `chunk_text`:** la cola del overlap más la palabra siguiente puede pasar de `chunk_size`. Medido sobre 300 textos: con overlap 20 y palabras ≤ 60, 1638 chunks se pasan del límite; con el arreglo, 0. Arreglo: el overlap también tiene que caber junto con la palabra siguiente (+2 líneas).
2. **AC-CHK-01 no detectaba ese bug** (10 + 1 + 30 ≤ 50). Ahora usa overlap 20 y palabras de 1 a 60, y comprueba que toda palabra de la entrada aparezca en algún chunk.
3. **AC-EMB-01:** la igualdad exacta falla con MiniLM real (difiere en 1.27e-07 dentro de un lote). Ahora con tolerancia 1e-5.
4. **AC-VEC-03 no detectaba quitar `space: cosine`.** Ahora el segundo resultado tiene que tener un score igual al coseno; con L2 saldría 2·cos − 1.
5. Quitada la validación de `metadata` (−2 líneas; ningún AC la pide).
6. `read_pdf` va en `app/dependencies.py`, inyectado con `Depends`.
7. **AC-VEC-04:** con un archivo en lugar de carpeta sale `InternalError` (os error 183) en Windows; Linux sin verificar. Al reabrir con otro modelo hace falta `_collection.cache_clear()` entre las dos configuraciones, y se lee con `(col.metadata or {}).get(...)`.
8. **ING-01:** se comprueba también el evento de log con `pages` y `chunks`, sin el filename.

**Medido:** `delete($in=[])` lanza ValueError, lo que confirma que el guard de vacío hace falta.

**Mutaciones cubiertas:**
| Mutación | AC que la detecta |
|---|---|
| quitar el delete | VEC-02 |
| ID sin `doc_id` | VEC-01, ING-01 |
| cortar por caracteres | CHK-01 |
| quitar el guard de vacío | ING-02 |
| `ChromaError` sin mapear | VEC-04 |
| quitar el 503 de `ERROR_STATUS` | ING-03 |
| colección con otro modelo | VEC-04 |

Presupuesto: unas 104 líneas, realista.
