# 05 · Auditoría de paquetes (package-auditor Sonnet, 2026-10-29)

Versiones del `uv.lock`: chromadb 1.5.9, sentence-transformers 6.2.0, torch 2.14.1+cpu. Snippets en el scratchpad de la sesión (`audit05/a1..a4.py`); los puntos marcados (C) los repitió Claude (`verify05/v.py`).

## chromadb 1.5.9
1. Métrica: la forma vigente es `configuration={"hnsw": {"space": "cosine"}}`; `metadata={"hnsw:space": "cosine"}` es la forma antigua y también funciona. Por defecto usa L2 (al cuadrado). Con cosine, `score = 1 - distance` (C: `[0.6, 0.8]` contra `[1, 0]` da 0.4).
2. `add` con un ID que ya existe se descarta en silencio: no lanza y conserva el documento viejo (C). `upsert` sí sobrescribe.
3. `delete(where={"doc_id": A})` + `add` deja solo los chunks nuevos de A y no toca B. Un `delete` sin coincidencias no lanza.
4. `docA:0:0` y `docB:0:0` conviven (count 2).
5. `EphemeralClient` es singleton por proceso: un segundo cliente ve las mismas colecciones (C). Con otros `Settings` lanza `ValueError`. `reset()` exige `allow_reset=True` (C). Para aislar tests: un único `Settings` + `reset()` en el fixture.
6. Con `embeddings` y `query_embeddings` explícitos no descarga el modelo ONNX. Con `query_texts` sí lo descarga (unos 79 MB en `~/.cache/chroma`). Regla: `embedding_function=None` al crear la colección y siempre `query_embeddings`.
7. `Settings(anonymized_telemetry=False)` funciona y no emite warnings.
8. Errores:
   - ruta no escribible → `chromadb.errors.InternalError` (no `OSError`);
   - `get_collection` de una colección inexistente → `NotFoundError`;
   - nombre de colección de menos de 3 caracteres → `InvalidArgumentError`.

   Todos van a 503.
9. La metadata acepta int, str, float y bool. `include=["documents", "metadatas", "distances"]` funciona. Si `n_results` es mayor que `count`, devuelve solo los que existen.

## sentence-transformers 6.2.0
10. `encode(..., normalize_embeddings=True)` devuelve un ndarray float32 de forma (n, 384), con norma 1; `.tolist()` da `list[list[float]]`. El modelo ya normaliza por sí mismo, así que el flag queda explícito e inofensivo.
11. `max_seq_length=256`. Un chunk de 500 caracteres ocupa unos 75 tokens y uno de 800 unos 119: no se trunca.
12. Tiempos en CPU:
    - primera carga: unos 7 s más el import;
    - cargas siguientes: unos 0.8 s;
    - encode de 50 chunks: 0.3 s.

    `get_sentence_embedding_dimension` lanza FutureWarning; usar `get_embedding_dimension`.

## Efecto en el diseño
- `init_collection`: `get_or_create_collection(name, configuration=cosine, embedding_function=None)`.
- La re-ingesta es delete + add. `upsert` sería una alternativa más corta, pero no borra los chunks sobrantes cuando la nueva versión tiene menos chunks.
- Tests con `EphemeralClient(Settings(allow_reset=True, anonymized_telemetry=False))` y `reset()` en el fixture.
- `VectorStoreError` envuelve `chromadb.errors.ChromaError` (por verificar si es la base común) → 503.
