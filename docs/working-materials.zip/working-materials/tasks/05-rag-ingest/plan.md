# 05-rag-ingest · Plan de implementación (JM)

_Redactado por un subagente Plan (Opus) a partir de la spec firmada, `evaluation.md` y `reviews/`; Claude comprobó las citas principales. Aprobado por JM el 2026-10-29 con las respuestas de "Respuestas de JM" (al final), que mandan sobre el texto de arriba._

## Contexto
La spec `ML-Engineer-test/docs/specs/05-rag-ingest.md` pasó la ronda 1 del code-critic (8 cambios aplicados) y Jeison la firmó. Las decisiones están en `tasks/05-rag-ingest/reviews/` y no se vuelven a discutir aquí:
- estrategia A: por página, 500 + overlap 60, palabras enteras;
- MiniLM normalizado;
- Chroma `PersistentClient` con `lru_cache`, coseno y `embedding_function=None`;
- re-ingesta = delete `$in` + add;
- el modelo en la metadata de la colección, con comprobación;
- `ChromaError` → `VectorStoreError` → 503;
- `ingest()` puro a imagen de `extract()`;
- `Embedder` como Protocol inyectado con `Depends`;
- `read_pdf` en `dependencies.py`;
- PDF en blanco → 200 con 0;
- tests con `PersistentClient(tmp_path)`;
- 1 worker de uvicorn.

Hoy los cuatro archivos del RAG son stubs (`rag_service.py:10-12`, `embedding_service.py:7-14`, `vector_service.py:11-25`, `api/rag.py:11`). Hay que conectar `ocr_pages` → `page_text` → `chunk_text` → embeddings → Chroma detrás de un router delgado, reutilizando el tope de subida y los errores de `/api/extract`.

Objetivo: **~104 líneas lógicas en `app/`** (± 15 %: de 88 a 120). Se cuentan como en la spec: sin imports, docstrings ni líneas en blanco. Abajo va también el `git diff --stat` esperado, que sale mayor (ver "Líneas esperadas").

Antes de empezar, Jeison hace el commit de la spec:
```powershell
$r = "C:\Users\Jeikosd\Documents\jeikosd\parterns_test_ML\ML-Engineer-test"
git -C $r add -- "$r\docs\specs\05-rag-ingest.md"
git -C $r commit -m "docs(spec): add RAG ingest spec"
```

## Subagentes (este plan pide tu sí para todos)
| Rol | Modelo | Habilidades | Lee | Devuelve | Interacción |
|---|---|---|---|---|---|
| `implementer` | Sonnet | Read/Edit/Write, `uv run`, `verify.ps1`; sin git | spec 05, este plan, servicios y tests actuales (estilo) | diff + tests de rojo a verde por commit, ≤ 300 palabras | responde al crítico con un cambio o una justificación |
| `code-critic` | Opus | solo lectura; `uv run` para mutar una copia en el scratchpad | spec y diff, **sin** las conclusiones del implementer | APPROVE/CHANGES, mutaciones que mueren, líneas que sobran | en paralelo; Claude lleva las preguntas y arbitra; máx. 2 rondas |
| `notebook-builder` | Sonnet | añade la sección "Desde `app/`" al NB05 (con tu permiso: el notebook es tuyo) y lo ejecuta con nbconvert a `artifacts/` | spec 05, NB05, `proto/rag.py`, `app/` | NB05 ejecutado con 0 errores | luego la revisión |
| `notebook-reviewer` | Opus | solo lectura | la copia ejecutada del NB05, **sin** las conclusiones del builder | cada afirmación respaldada por su celda | Claude aplica las correcciones a través del builder |

## Orden (6 commits con el refactor de la respuesta 6, cada uno en verde con `powershell -NoProfile -File .claude/tools/verify.ps1`)

1. **Config** (`feat(config): add RAG ingest settings`)
   - `app/config.py`:
     - en `# Embeddings`, añadir `embedding_model: str = "sentence-transformers/all-MiniLM-L6-v2"` junto a `embedding_device`;
     - sección nueva `# RAG` con `chunk_size: int = Field(500, gt=0)`, `chunk_overlap: int = Field(60, ge=0)`, `chroma_path: str = "data/chroma"` y `chroma_collection: str = "documents"`.
   - `.env.example`: `EMBEDDING_MODEL=...` en `# Embeddings` y una sección `# RAG` con `CHUNK_SIZE=500`, `CHUNK_OVERLAP=60`, `CHROMA_PATH=data/chroma` y `CHROMA_COLLECTION=documents`.
   - `.gitignore`: sección `# Local data` con `data/`.
   - Tests: la spec no tiene AC de config (ver Preguntas, 1). El gate es `verify.ps1` en verde y `Settings(_env_file=None).chunk_size == 500` a mano.
2. **Chunking** (`feat(rag): chunk text without splitting words`)
   - Paso 0, para que el rojo sea por la razón correcta: cambiar la firma del stub a `chunk_text(text, chunk_size=500, overlap=60)`, dejando el `raise NotImplementedError`. Sin esto, los tests fallarían con `TypeError` por el kwarg `overlap`.
   - Rojo: AC-CHK-01..03 en `tests/unit/test_rag_service.py`, que fallan con `NotImplementedError`.
   - Verde: `chunk_text` en `rag_service.py` (esbozo abajo).
3. **Vector store** (`feat(rag): store chunks in Chroma with unique ids`)
   - `embedding_service.py`: solo el Protocol `Embedder`. `get_embeddings` sigue siendo el stub: `vector_service` lo necesita como default de `embed`, y su implementación es del paso 4 (spec, tarea 4).
   - Rojo: AC-VEC-01..04 en `tests/unit/test_vector_service.py` (fixture `chroma` y `FakeEmbedder`, abajo). Fallan con `NotImplementedError` de los stubs; `VectorStoreError` todavía no existe, así que el test lo importa después del paso 0.
   - Paso 0: declarar `class VectorStoreError(RuntimeError)` primero, para que el test no falle por import.
   - Verde, en `vector_service.py`:
     - `_collection()` con `lru_cache`;
     - `init_collection()`;
     - `store_document_chunks(chunks, metadata=None, embed=get_embeddings)`;
     - `search_similar`.
   - `main.py`: `VectorStoreError: 503` en `ERROR_STATUS`, tal como pide la spec en la tarea 3. Lo prueba ING-03 en el paso 4.
4. **Endpoint** (`feat(api): add /api/ingest endpoint`)
   - Paso 0, para el rojo correcto: `get_embedder()` en `dependencies.py`, `ingest(...)` en `rag_service.py` con `raise NotImplementedError`, y el router `/ingest` cableado. Los tests fallan con `NotImplementedError` (TestClient lo relanza), no con 404 ni ImportError.
   - Rojo: AC-ING-01..03 en `tests/unit/test_ingest_api.py`.
   - Verde:
     - `embedding_service`: `_load_model`, `get_embeddings` y `get_query_embedding`;
     - `rag_service.ingest`;
     - `read_pdf` en `dependencies.py`;
     - `api/extract.py` deja de leer el upload por su cuenta (líneas 25-28 → `Depends(read_pdf)`); AC-API-03/04 deben seguir verdes, como regresión;
     - router `POST /api/ingest`.
5. **Integración** (`test(integration): re-ingest documents with real MiniLM embeddings`)
   - `tests/integration/test_rag_ingest.py`: AC-INT-01 y AC-EMB-01, con `skipif` si MiniLM no está en la caché de HF.
   - Salen verdes de entrada porque el código ya existe. Para demostrar que muerden: quitar el `delete` en local (sin commit) → INT-01 en rojo → revertir.
6. **Cierre** (después de los 5 commits; ver "Paso final").

**Archivos por commit** (para `/commit-handoff`, rutas completas, sin `-A`):
- 1: `app/config.py`, `.env.example`, `.gitignore`.
- 2: `app/services/rag_service.py`, `tests/unit/test_rag_service.py`.
- 3: `app/services/vector_service.py`, `app/services/embedding_service.py`, `app/main.py`, `tests/unit/test_vector_service.py`.
- 4: `app/services/embedding_service.py`, `app/services/rag_service.py`, `app/dependencies.py`, `app/api/rag.py`, `app/api/extract.py`, `tests/unit/test_ingest_api.py`.
- 5: `tests/integration/test_rag_ingest.py`.

### Esbozo de `chunk_text` (la pieza con más riesgo)
```python
if not 0 <= overlap < chunk_size:
    raise ValueError("overlap must satisfy 0 <= overlap < chunk_size")
chunks, current = [], []
for word in text.split():
    if current and len(" ".join([*current, word])) > chunk_size:
        chunks.append(" ".join(current))
        tail = []
        for prev in reversed(current):          # last whole words of the chunk
            n = len(" ".join([prev, *tail]))
            if n > overlap or n + 1 + len(word) > chunk_size:  # 2nd condition: critic r1
                break
            tail = [prev, *tail]
        current = tail
    current.append(word)
return chunks + [" ".join(current)] if current else chunks
```
- Una palabra más larga que `chunk_size` queda sola en su chunk: ninguna cola de overlap cabe con ella (ver Preguntas, 2).
- Hecho a mano para AC-CHK-02 (50/20):
  - chunk 1: `"Richard Hernandez called the meeting to order."` (46 caracteres);
  - la cola es `"meeting to order."` (17): `"the meeting to order."` daría 21 > 20;
  - chunk 2: `"meeting to order. Jennifer Liu confirmed quorum."` (48).

## Archivos y funciones
| Archivo | Función / cambio | Por qué existe (qué AC cubre) |
|---|---|---|
| `app/config.py`, `.env.example`, `.gitignore` | `embedding_model`, `chunk_size`, `chunk_overlap`, `chroma_path`, `chroma_collection`; `data/` fuera de git | sin valores fijos (README:80); ING-01 (lee `CHUNK_SIZE`), VEC-04 (`EMBEDDING_MODEL`, `CHROMA_PATH`) |
| `app/services/rag_service.py` | `chunk_text(text, chunk_size=500, overlap=60)` | CHK-01..03 (README:95) |
| `app/services/rag_service.py` | `ingest(pdf_bytes, filename, engine, embed) -> IngestResponse`: `doc_id = sha256(pdf_bytes).hexdigest()`, `ocr_pages`, `page_text` y `chunk_text` por página (`enumerate(pages)`, 0-based), metadata `{doc_id, filename, page, chunk}`, `store_document_chunks`, `log_event(pages=, chunks=)` | ING-01, ING-02, INT-01 |
| `app/services/embedding_service.py` | `Embedder` (Protocol); `_load_model(name, device)` con `lru_cache`; `get_embeddings` (`encode(..., normalize_embeddings=True).tolist()`); `get_query_embedding` (`get_embeddings([text])[0]`) | EMB-01, INT-01; el Protocol permite el fake de VEC/ING |
| `app/services/vector_service.py` | `VectorStoreError(RuntimeError)` | VEC-04, ING-03 |
| `app/services/vector_service.py` | `_collection()` con `lru_cache`: `PersistentClient(path, Settings(anonymized_telemetry=False))`, `get_or_create_collection(name, configuration=cosine, metadata={"embedding_model"}, embedding_function=None)`, `try/except ChromaError`, y la comprobación del modelo | VEC-03 (coseno), VEC-04 |
| `app/services/vector_service.py` | `init_collection()` → `_collection()` | VEC-04 (firma del stub, R1) |
| `app/services/vector_service.py` | `store_document_chunks(chunks, metadata=None, embed=get_embeddings)`: guard de vacío, embebe **antes** de borrar, `delete(where={"doc_id": {"$in": ...}})` + `add(ids=f"{doc_id}:{page}:{chunk}")`, `ChromaError` → `VectorStoreError` | VEC-01, VEC-02, ING-02 |
| `app/services/vector_service.py` | `search_similar(query_embedding, top_k=5)`: `query(query_embeddings=[...], include=[...])` → `{"text", "score": 1 - distance, "filename", "page", "chunk"}`; nunca `query_texts` | VEC-03, INT-01 (y la 06) |
| `app/dependencies.py` | `read_pdf(pdf_file: UploadFile) -> bytes` (lo que hoy está en `extract.py:25-28`); `get_embedder() -> Embedder` | ING-03 (413), API-04 sigue verde; ING-01 (override) |
| `app/api/extract.py` | `pdf_bytes: Annotated[bytes, Depends(read_pdf)]` en lugar de leer a mano | el mismo tope para los dos routers (spec, Contrato) |
| `app/api/rag.py` | `POST /ingest` (`def`, `response_model=IngestResponse`): `pdf_file: UploadFile` (por el `filename`), `pdf_bytes` vía `Depends(read_pdf)`, `engine` vía `get_ocr_engine` y `embed` vía `get_embedder` → `ingest(...)`. El TODO de `/ask` queda para la 06 | ING-01..03 (README:78) |
| `app/main.py` | `VectorStoreError: 503` en `ERROR_STATUS` | ING-03 |

**Se reutiliza:**
- `ocr_pages`, `page_text`, `OcrEngine` (`ocr_service.py:15,68,83`);
- `DocumentTooLargeError` (`ocr_service.py:23`);
- `log_event` (`log.py:15`);
- `get_ocr_engine` (`dependencies.py:7`);
- `domain_error` y el bucle de handlers (`main.py:31-36`);
- el patrón `_load_model` con `lru_cache` de `ner_service.py:18-21`;
- `FakeEngine`, `row` y `blank_pdf` (`tests/unit/test_ocr_service.py:30-50`);
- el patrón de fixture `setenv` + `cache_clear` + `dependency_overrides.clear()` (`tests/unit/test_extract_api.py:16-31`).

## Tests (rojo primero)
Fakes nuevos, en `tests/unit/test_vector_service.py` (los importa `test_ingest_api.py`, como 04 importa `FakeEngine` de `test_ocr_service.py`):
- `FakeEmbedder`: cuenta `calls`; por texto, `random.Random(text)` → 384 gaussianas → normalizadas. Es determinista y no usa red ni modelo.
- Fixture `chroma(tmp_path, monkeypatch)`:
  - `setenv("CHROMA_PATH", str(tmp_path / "chroma"))` y `setenv("EMBEDDING_MODEL", "fake-384")`;
  - `get_settings.cache_clear()` y `vector_service._collection.cache_clear()` antes y después;
  - `monkeypatch.setattr(embedding_service, "_load_model", boom)`, que lanza `AssertionError("model loaded in a unit test")` si algo carga MiniLM, como `NER_MODEL=no-such-model` en 04.

Fixture `client` de `test_ingest_api.py`:
- todo lo de `chroma`, más `OCR_DPI=72`, `MAX_UPLOAD_MB=1`, `CHUNK_SIZE=50` y `CHUNK_OVERLAP=20`;
- `dependency_overrides` de `get_ocr_engine` y `get_embedder`, limpiados al final.

| Test | AC | Qué falla antes del código |
|---|---|---|
| `test_ac_chk_01_random_text_keeps_whole_words_in_order` | CHK-01 | `NotImplementedError`. Detalle: semilla fija, unos 200 textos de 30 a 80 palabras de 1 a 60 letras, 50/20. Para cada chunk, `chunk.split()` es un trozo contiguo de `text.split()` que empieza después del anterior y no más allá de su fin (sin huecos); `len ≤ 50` salvo que contenga una palabra > 50; el último trozo termina en la última palabra. Mata "cortar por caracteres" y "overlap sin la segunda condición" (1638 chunks fuera del límite según el crítico) |
| `test_ac_chk_02_overlap_keeps_name_whole` | CHK-02 | `NotImplementedError`. Lista exacta: `["Richard Hernandez called the meeting to order.", "meeting to order. Jennifer Liu confirmed quorum."]`; la cola mide ≤ 20 y algún chunk contiene "Jennifer Liu" |
| `test_ac_chk_03_edge_cases` (parametrizado: `""`, `"   \n "`, `"x"*600`) y `test_ac_chk_03_overlap_not_smaller_raises` (`overlap=50, chunk_size=50`, y `overlap=-1`) | CHK-03 | `NotImplementedError` / no lanza `ValueError` |
| `test_ac_vec_01_two_documents_do_not_collide` | VEC-01 | `NotImplementedError`. Después: `count == 2` y `col.get(ids=["a:0:0", "b:0:0"])` devuelve los dos. Mata "ID sin `doc_id`" |
| `test_ac_vec_02_reingest_replaces_only_that_document` | VEC-02 | `NotImplementedError`. A con 3 chunks y B con 1; A otra vez con 2 textos **nuevos**. Se compara `get(where={"doc_id": "a"})` (ids **y** `documents`) con los 2 nuevos, y B no cambia. Mata "quitar el delete": deja `a:0:2` y `add` descarta en silencio los ids repetidos, así que quedarían los textos viejos |
| `test_ac_vec_03_search_returns_cosine_score_and_metadata` | VEC-03 | `NotImplementedError`. Top 2: el primero es `text_x` con `score ≈ 1` (±1e-6) y trae `filename`, `page` y `chunk`; el segundo tiene `score ≈ dot(vx, vy)` (±1e-6). Mata "sin `space: cosine`" (L2 da `2·cos − 1`) |
| `test_ac_vec_04_unusable_store_is_vector_store_error` (parametrizado: `file-as-path`, `other-model`) | VEC-04 | `NotImplementedError`. Caso a: `CHROMA_PATH` apunta a un archivo existente. Caso b: `init_collection()` con `EMBEDDING_MODEL=A`, luego `setenv B` + los dos `cache_clear` + `init_collection()`. Los dos lanzan `VectorStoreError`, con `__cause__` `ChromaError` en el caso a. Mata "`ChromaError` sin mapear" y "sin comprobación del modelo" |
| `test_ac_ing_01_ingests_two_pages_with_sha256_ids` | ING-01 | `NotImplementedError` de `ingest`. `blank_pdf(2)` y `FakeEngine` con las palabras de la frase de CHK-02 en una línea → 2 chunks por página. Respuesta `{"status": "ingested", "chunks_stored": 4}` (= `2 * len(chunk_text(frase, 50, 20))`); ids = `{f"{sha256(pdf)}:{p}:{c}"}` para p, c ∈ {0, 1}; `caplog` contiene `{"request_id": ..., "pages": 2, "chunks": 4}`; el filename (`secret_report.pdf`) no aparece en `caplog.text`. Mata "ingest ignora `chunk_size` de la config" y "loguear el filename" |
| `test_ac_ing_02_blank_pdf_stores_nothing` | ING-02 | `NotImplementedError`. Primero se guarda un doc previo; luego `FakeEngine()` sin filas → 200 con `chunks_stored == 0`, `count` igual que antes y `embedder.calls == 0`. Mata "quitar el guard de vacío" (`ValueError` → 500; TestClient lo relanza) |
| `test_ac_ing_03_invalid_upload_never_embeds` (parametrizado: `b"not a pdf"` → 422, `b"0" * (1 MiB + 1)` → 413) | ING-03 | `NotImplementedError` (el 422 sale de `ocr_pages`, que corre dentro de `ingest`); hay `detail` y `embedder.calls == 0` |
| `test_ac_ing_03_vector_store_down_is_503` | ING-03 | `monkeypatch.setattr(rag_service, "store_document_chunks", raise VectorStoreError("down"))` → `{"detail": "down"}` con 503. Mata "quitar el 503 de `ERROR_STATUS`" |
| `test_ac_int_01_reingest_a_b_a_with_minilm` | INT-01 | Verde de entrada (paso 5). Real: `ingest(pdf_a, "a.pdf", FakeEngine(texto A), get_embeddings)`, luego B y otra vez A **con el mismo objeto `pdf_a`** (los bytes de `blank_pdf` pueden variar entre llamadas). `count` = n_a, luego n_a + n_b, luego n_a + n_b; `search_similar(get_query_embedding(pregunta sobre B), 1)[0]["filename"] == "b.pdf"`. Se comprueba que muerde quitando el delete en local |
| `test_ac_emb_01_minilm_vectors_are_normalized` | EMB-01 | Verde de entrada. 2 vectores de 384, norma 1 ± 1e-6; `max(abs(q - v0)) ≤ 1e-5` |

`skipif` de integración: `not isinstance(huggingface_hub.try_to_load_from_cache("sentence-transformers/all-MiniLM-L6-v2", "config.json"), str)`. `huggingface_hub` ya llega con sentence-transformers, así que no es dependencia nueva. La fixture pone `HF_HUB_OFFLINE=1` para que nunca toque la red.

**Mutaciones que el crítico debe matar** (evaluation.md y spec-critic-r1):
- quitar el delete → VEC-02, INT-01;
- ID sin `doc_id` → VEC-01, ING-01;
- cortar por caracteres → CHK-01;
- quitar el guard de vacío → ING-02;
- `ChromaError` sin mapear → VEC-04;
- quitar el 503 → ING-03;
- sin la comprobación del modelo → VEC-04;
- L2 por defecto → VEC-03;
- overlap sin la segunda condición → CHK-01;
- ignorar `chunk_size` de la config → ING-01;
- loguear el filename → ING-01.

Hay una mutación que **ningún AC** mata: "embeber después del delete". Ver Riesgos.

## Líneas esperadas y qué no voy a escribir
| Archivo | Pieza (spec) | Lógicas (como la spec) | `git diff` estimado (+/−) |
|---|---|---|---|
| `rag_service.py` | `chunk_text` (~13) | ~14 | +19 / −2 |
| `rag_service.py` | `ingest` + `doc_id` (~18) | ~14 | +20 (con imports) |
| `embedding_service.py` | (~12) | ~9 | +16 / −4 |
| `vector_service.py` | (~41) | ~42 | +60 / −6 |
| `dependencies.py` + `api/rag.py` + `api/extract.py` | router + `read_pdf` + dependencia (~14) | ~13 (`read_pdf` 5, `get_embedder` 2, router 9, `extract` −4) | +30 / −7 |
| `config.py` + `main.py` | (~6) | ~7 | +12 / −1 |
| **Total `app/`** | **~104** | **~99 (gate: de 88 a 120)** | **unas +157 / −20** |

Fuera de `app/` y del presupuesto: `.env.example` (+8) y `.gitignore` (+2).

El `git diff` sale mayor por las mismas razones que en la 04 (`research/20-preguntas-entrevista.md:27`: ~62 previstas, ~89 reales): imports que ruff parte en varias líneas, firmas multilínea, el dict de `search_similar` con 5 claves y docstrings. Si las lógicas pasan de 120, lo revisa el crítico; no se fuerza.

**No se escribe** (spec, "Fuera de alcance", y `reviews/2026-10-29-decisions-critic.md` punto 6):
- de la 06: `/api/ask`, el cliente LLM, `MIN_SCORE`, el prompt y el `top_k` de la respuesta;
- de la 08: `HttpClient` con reintentos, compose, varios workers, `embedding_device="auto"` y `revision` fija;
- `upsert`, un Protocol `VectorStore`, un context manager para los errores y lifespan;
- las estrategias C, D, E y F, la normalización OCR y otro modelo;
- `EphemeralClient`/`reset()`;
- validación de `metadata` en `store_document_chunks` (quitada en la crítica r1);
- `[:16]` en el `doc_id`;
- `lru_cache` en las dependencias;
- `HTTPException` en los routers;
- cambios a `schemas.py`, al README o a `/health`.

## Riesgos y cómo los verifico
- **`add` con un ID repetido se descarta en silencio** (medido): sin el delete, el `count` puede salir bien y el texto ser el viejo. VEC-02 compara `documents`, no solo ids y count.
- **`add([])` y `delete($in=[])` lanzan `ValueError`**, que no es `ChromaError` y daría 500: el guard `if not chunks: return` va al principio de `store_document_chunks`. Lo verifica ING-02, porque TestClient relanza el 500 y el test cae.
- **`get_or_create` conserva la metadata original** (medido): la comprobación `(col.metadata or {}).get("embedding_model") != settings.embedding_model` va **después** de `get_or_create`. Lo verifica VEC-04b.
- **`lru_cache` de `_collection` entre tests**: si un test no limpia, el siguiente escribe en el `tmp_path` ya borrado de otro test.
  - Las fixtures `chroma`, `client` y la de integración hacen `_collection.cache_clear()` y `get_settings.cache_clear()` antes **y** después.
  - `lru_cache` no guarda las excepciones, así que tras un fallo el siguiente request reintenta.
  - Se verifica con `uv run pytest -q -p no:randomly` y también con el orden inverso: `uv run pytest tests/unit/test_ingest_api.py tests/unit/test_vector_service.py -q`.
- **`skipif` de INT/EMB sin el modelo en caché**: `verify.ps1` puede salir verde con los tests saltados. En el cierre se corre `uv run pytest tests/integration -rs -q` y se comprueba "2 passed" en `test_rag_ingest.py`, no "skipped". Con `HF_HUB_OFFLINE=1` no hay descargas.
- **Cargar MiniLM en un unitario por error** (lento y con red): el `_load_model` parcheado lanza `AssertionError` en las fixtures unitarias.
- **Importar sentence-transformers/torch al importar `app.main`** alarga el arranque de todos los tests. Antes y después del paso 4 se mide `uv run pytest tests/unit -q --durations=5`; si el arranque pasa de unos 10 s, el import se mueve dentro de `_load_model` (0 líneas netas). Por defecto el import va arriba, como `ner_service`.
- **`pdf_file` declarado en el endpoint y en `read_pdf`**: FastAPI debe resolverlo como un solo campo de formulario. Lo verifican ING-01 (200) y que `/openapi.json` muestre un único `pdf_file` en `/api/ingest`. Si fallara, ver Preguntas, 6.
- **Tolerancia ±1e-6 de VEC-03 con float32 en Chroma**: si fallara por precisión y no por la métrica, se avisa a JM; 1e-5 seguiría matando L2. La spec no se cambia sin JM.
- **VEC-04a solo se midió en Windows** (`InternalError`, os error 183). En Linux (CI/Docker de la 08) podría salir un `OSError` sin envolver → 500. Se verifica en la 08.
- **delete + add no es atómico**: si `add` falla tras el delete, el documento queda sin chunks → 503 y el cliente re-ingesta. Embeber antes del delete reduce esa ventana (lo pide la spec), pero ningún AC lo detecta. El crítico lo revisa leyendo el código y queda en DESIGN (07).
- **`CHUNK_OVERLAP >= CHUNK_SIZE` por env**: `chunk_text` lanza `ValueError` → 500. Ver Preguntas, 4.
- **`data/chroma` es relativa al cwd**: lanzar uvicorn desde otra carpeta crea otro store. Se documenta en DESIGN (07), sin código.
- **Con varios workers la recuperación falla en silencio** (medido): 1 worker, documentado en DESIGN (07).
- **Windows y `tmp_path`**: sqlite deja archivos abiertos y pytest puede no borrar los `tmp` viejos. No rompe tests, es basura local.
- **Contenido no confiable**: el log solo lleva conteos (ING-01). Los textos de los tests los escribe el implementer: no se copia nada de los PDFs como instrucción.

## Verificación
1. En cada commit, `uv run pytest tests/unit -q` de rojo a verde, con el rojo por `NotImplementedError` o por un assert, nunca por import.
2. `uv run pytest tests/integration -rs -q`: INT-01 y EMB-01 en "passed"; AC-API-06 sigue verde (la regresión de `read_pdf`).
3. `powershell -NoProfile -File .claude/tools/verify.ps1` en verde.
4. Arranque real:
   - `uv run uvicorn app.main:app` (1 worker);
   - `curl -F pdf_file=@sample_pdfs/company_memo.pdf localhost:8000/api/ingest` dos veces → 200 con el mismo `chunks_stored` y una línea JSON con `pages`/`chunks`;
   - `git status` no muestra `data/`.
5. `git diff --stat -- app/` y conteo de lógicas: ≤ 120.
6. Crítico APPROVE (máx. 2 rondas); `/commit-handoff` por commit.

## Paso final (cierre de la tarea)
1. **NB05 "Desde `app/`"**: la hace el notebook-builder con tu permiso, porque el notebook es tuyo; la copia ejecutada va a `artifacts/05_rag.executed.ipynb`. Las celdas siguen el patrón de `.claude/rules/notebooks.md`:
   - importar `from app.services.rag_service import chunk_text`;
   - comparar sus chunks con los del proto A en todas las páginas, mostrando el % idéntico tras colapsar espacios (`app` colapsa los `\n`; decisions-critic punto 5);
   - `fresh_collection(client, "app_A")` + `run_strategy` con `page_records(pages, partial(app_chunk_text, chunk_size=500, overlap=60))` sobre las 22 preguntas;
   - `paired_vs_base(ranks[["A 500+60", "app"]], base="A 500+60")`;
   - celda `assert`: `p_mcnemar >= 0.05` y `ic_lo <= 0 <= ic_hi` para ΔMRR;
   - `metric_strings` frente a la referencia: hit@1 0.68 [0.47-0.84], hit@3 0.95, MRR 0.82 [0.71-0.93];
   - opcional, dentro del tope de horas: ingestar con `app.services.vector_service.store_document_chunks` + `search_similar` en un `CHROMA_PATH` temporal y comprobar que los rangos coinciden.

   Después, el notebook-reviewer, sin las conclusiones del builder.
2. **"Explicación de los AC de la spec 05"** en el NB05: por cada uno de los 12 AC, de 3 a 5 líneas con qué líneas de `app/` lo cumplen y por qué, más 3 preguntas de entrevistador. Claude redacta el borrador y tú lo reescribes y lo firmas sin mirar.
3. **`research/20-preguntas-entrevista.md`**: sección `## Tarea 05 · Ingesta RAG (...)`, que sigue la numeración en el 28. Se parte de las 8 preguntas del NB05 y se añaden:
   - por qué delete + add y no `upsert`;
   - por qué coseno explícito si con norma 1 el ranking es el mismo;
   - por qué sha256 del contenido;
   - por qué embeber antes de borrar;
   - por qué el guard de vacío;
   - por qué 1 worker;
   - por qué el modelo va en la metadata;
   - por qué A si nada se distingue de ella (la robustez de los nombres en el borde).
4. `DECISIONS.md` sección "RAG ingest" desde `tasks/05-rag-ingest/decisions-draft.md` (cada decisión con su porqué): **te muestro el texto exacto antes**. Commit `docs: record RAG ingest decisions`.
5. Estado: `tasks/INDEX.md`, el README de la tarea, una fila en `DECISIONS-LOG`, el siguiente `research/2x-estado` y la memoria.

## Preguntas para JM (contradicciones encontradas; no se resuelven tocando la spec)
1. **El commit de config no tiene AC** (la spec no trae AC-CFG para los 5 campos). ¿Lo dejamos sin test propio, o añades a la spec `AC-CFG-05` (defaults y `gt=0`/`ge=0`)?
2. **Palabra gigante "junto con su overlap"** (spec:13) frente a la segunda condición del overlap: ninguna cola cabe con una palabra > `chunk_size`, así que esa palabra queda **sola**. AC-CHK-03 (`[palabra]`) es coherente con eso. ¿Se corrige la redacción de la spec?
3. **Método de conteo del presupuesto**: la 04 midió con `git diff --stat` (plan 04, Verificación 5), pero los ~104 de la 05 solo cuadran contando líneas lógicas. El diff real será de unas +157. ¿Cuál vale como gate?
4. **`CHUNK_OVERLAP >= CHUNK_SIZE` por env** → 500 en cada ingesta. ¿Lo aceptamos (es un error de configuración), o un `model_validator` en `Settings` (+3 líneas y un AC nuevo)?
5. **Dónde viven los fakes**: `.claude/rules/tests.md:7` pide `tests/fakes.py`, que no existe; la 04 importa los fakes desde módulos de test. El plan sigue a la 04. ¿Prefieres crear `tests/fakes.py`?
6. **`read_pdf` en `extract.py`**: el plan lo mete dentro de `feat(api): add /api/ingest endpoint`. ¿Prefieres un commit aparte `refactor(api): share capped PDF upload reading` antes de ese? Y si FastAPI no resolviera `pdf_file` dos veces, la alternativa es llamar a `read_pdf(pdf_file)` sin `Depends`, que contradice la spec:11.
7. **Claves de `search_similar`**: la spec lista 5. `{"text", "score", **meta}` ahorraría unas 6 líneas, pero añade `doc_id`. El plan sigue la spec literal.
8. **Orden de tareas de la spec**: la tarea 3 (`vector_service`) importa `Embedder`/`get_embeddings`, que la spec sitúa en la tarea 4. El plan pone el Protocol en el commit 3 y la implementación en el 4. ¿Ok?
9. **Documentos desactualizados** (sin efecto en el código):
   - `research.md:42` dice `sha256[:16]` y `proto/rag.py:31` usa `[:16]`; la spec usa el hash completo;
   - la revisión del NB05 (punto 5) y la auditoría proponían `EphemeralClient` + `reset()`; la spec usa `PersistentClient(tmp_path)`;
   - el README de la tarea lista 4 commits y "10 preguntas"; hoy son 5 commits y 22 + 4 preguntas.

   ¿Los actualizo al cerrar?
10. **VEC-04a en Linux sin verificar**: ¿lo dejamos como riesgo conocido para la 08, o se mide ya en Docker?

## Respuestas de JM (2026-10-29; mandan sobre lo anterior)
1. Sin AC de config: AC-ING-01 ya prueba que se lee `CHUNK_SIZE`.
2. Spec:13 corregida ("queda entera y sola en su chunk"); Jeison la incorpora al commit de la spec con amend.
3. Gate del presupuesto: líneas lógicas (88-120). El `git diff --stat` se reporta, no es gate.
4. `CHUNK_OVERLAP >= CHUNK_SIZE` por env → 500 aceptado como error de configuración; se documenta, sin validador.
5. Fakes en sus módulos de test, como la 04; no se crea `tests/fakes.py`.
6. Commit aparte antes del endpoint: `refactor(api): share capped PDF upload reading` (`read_pdf` en `dependencies.py` + `extract.py` con `Depends`; AC-API-03/04/06 en verde como regresión). Si FastAPI no resuelve `pdf_file` dos veces, parar y avisar a JM.
7. `search_similar` devuelve las 5 claves de la spec.
8. Protocol `Embedder` en el commit 3; implementación en el 4.
9. Los documentos desactualizados se corrigen al cerrar. `eval/questions.json` (hoy sin seguimiento en git) entra en su propio commit: propuesta `test(eval): add RAG retrieval questions`.
10. VEC-04a en Linux: riesgo conocido, se mide en Docker (08).

Commits resultantes:
1. `feat(config): add RAG ingest settings`
2. `feat(rag): chunk text without splitting words`
3. `feat(rag): store chunks in Chroma with unique ids`
4. `refactor(api): share capped PDF upload reading`
5. `feat(api): add /api/ingest endpoint`
6. `test(integration): re-ingest documents with real MiniLM embeddings`
