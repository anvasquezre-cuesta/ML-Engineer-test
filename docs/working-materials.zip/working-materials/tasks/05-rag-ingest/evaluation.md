# 05-rag-ingest · Evaluación

| Qué | Cómo | Esperado |
|---|---|---|
| ACs | unitarios con un embedder falso, fake de OCR y Chroma real en `tmp_path`; integración con MiniLM real | AC-CHK-01..03, AC-VEC-01..04, AC-ING-01..03 verdes sin red ni modelos; AC-INT-01 y AC-EMB-01 verdes (`skipif` sin el modelo en caché) |
| Mutaciones (code-critic) | quitar el `delete` antes del `add`; ID sin `doc_id`; cortar por caracteres; quitar el guard de chunks vacíos; `ChromaError` sin mapear | cada mutación hace fallar al menos un AC |
| Recuperación (regresión) | NB05 "Desde `app/`": `chunk_text` de `app/` sobre las 22 preguntas | MRR pareado frente al proto A: McNemar p ≥ 0.05 y ΔMRR con IC que contiene 0 (no empeora). Referencia del proto A: hit@1 0.68 [0.47-0.84], hit@3 0.95, MRR 0.82 [0.71-0.93] |
| Re-ingesta | AC-INT-01 + `scratchpad/verify05/stress_app.py` como referencia | `count` estable tras A, B, A; 0 errores |
| Presupuesto | líneas en `app/` sin tests | ~104 (± 15 %; si se pasa, lo revisa el crítico, no se fuerza) |
| Calidad | `verify.ps1` + code-critic sobre el diff y la spec | verde; APPROVE |

Métricas y sus límites: `research/18-metricas.md` §8. Con 5 páginas, hit@3 está saturado: sirve para detectar regresiones, no para estimar el rendimiento en producción.

Gates comunes (spec → plan JM → tests en rojo → verde → code-critic → explicación → commit): `research/19-plan-implementacion.md`.
