# 05-rag-ingest · Research

## Fuentes y decisiones tomadas
- [V] Plan: `research/06-tl-plan.md:26-30` (500 caracteres, overlap 60, corte en espacio, MiniLM normalizado, Chroma coseno, ID `{doc}:{page}:{chunk}`, re-ingesta = delete + add); 06:11 (`add` con ID repetido se descarta en silencio; Chroma usa L2 por defecto).
- [V] `research/03-rag-stack.md`; papers en `papers/INDEX.md` (Reimers 2019 SBERT, Muennighoff MTEB, Lewis 2020).
- [V] R1 (se conservan las firmas públicas de los stubs como envoltorios): `research/14-revision-plan.md:13`. R2 (Chroma embebido sin reintento, fallo → 503): `14:14`. Regla `.claude/rules/rag.md`.
- README:54-56, 95-98 (no cortar palabras; IDs únicos entre documentos).

## Lo que ya existe y se reutiliza (revisado 2026-10-29)
- `ocr_service.ocr_pages(pdf_bytes, engine)` + `page_text(words)`: texto por página. La ingesta no necesita NER ni cajas.
- `api/extract.py`: lectura con `read(limit + 1)` y `DocumentTooLargeError`; `main.py`: `ERROR_STATUS` (422/413/503) + `domain_error`. La ingesta usa lo mismo.
- `dependencies.py`: patrón `Depends` → tests con fakes. `ner_service._load_model` con `lru_cache`: mismo patrón para cargar MiniLM una vez.
- `pyproject.toml` ya declara `sentence-transformers`, `torch` (CPU) y `chromadb`. `config.py` ya tiene `embedding_device`.

## Stubs y su contrato (no se renombran, R1)
| Stub | Firma | Problema a resolver |
|---|---|---|
| `rag_service.chunk_text` | `(text, chunk_size=500) -> list[str]` | overlap sale de config; ¿qué pasa con una palabra más larga que `chunk_size`? |
| `embedding_service.get_embeddings` / `get_query_embedding` | `list[str] -> list[list[float]]` | carga única; Protocol/fake para tests |
| `vector_service.init_collection` | `() -> None` | métrica coseno explícita; ruta y nombre desde config |
| `vector_service.store_document_chunks` | `(chunks, metadata=None) -> None` | el stub dice "embed and store": ¿embebe aquí o recibe vectores? IDs `doc_id:page:chunk` tienen que salir de `metadata` |
| `vector_service.search_similar` | `(emb, top_k=5) -> [{"text","score"}]` | 06 necesita `filename/page/chunk` para `sources`: añadir claves al dict (tarea 06, pero la metadata se guarda aquí) |
| `POST /api/ingest` | `pdf_file` → `IngestResponse(status, chunks_stored)` | router delgado como `extract` |

## Hecho
- Auditoría de paquetes: `reviews/2026-10-29-package-audit.md`. Literatura: `reviews/2026-10-29-literature.md`.
- NB05, parte de ingesta: `notebooks/05_rag.ipynb` (6 estrategias, comparación pareada, bge-small, normalización OCR). Revisión: `reviews/2026-10-29-nb05-review.md`.
- `eval/questions.json`: 22 preguntas con respuesta + 4 sin respuesta, con `gold` como lista de páginas.

## Huecos (falta)
- Cierre del NB05 por el builder: la tanda final de ejecuciones.
- Texto vacío (PDF en blanco): ¿`chunks_stored=0` con 200 o 422?
- Confirmar que `chromadb.errors.ChromaError` es la base común de `InternalError` y `NotFoundError`.

## Decididas (2026-10-29, Jeison)
- Estrategia A: por página, 500 + overlap 60, cortado en espacio. MiniLM. Coseno. top_k candidato 5 (NB05).
- Chroma (ver `reviews/2026-10-29-nb05-review.md`, "Recomendación"): un `PersistentClient` por proceso y una sola colección; delete + add; `VectorStoreError` → 503; 1 worker de uvicorn en modo embebido; AC de integración de re-ingesta repetida. D-RAG-3 queda resuelta: embebido ahora, `HttpClient` en 08.

## Decisiones abiertas
- ~~D-RAG-1~~: por página (decidida: F, por documento, es la peor en NB05).
- ~~D-RAG-3~~ y ~~D-RAG-5~~: decididas (ver arriba).
- D-RAG-2: `doc_id = sha256(bytes).hexdigest()` completo (decisions-critic; el `[:16]` original quedó descartado); `filename` en metadata. Mismo PDF con otro nombre: re-ingesta idempotente (se queda el último nombre).
- D-RAG-3: Chroma embebido vs `HttpClient`. Propuesta: solo `PersistentClient` ahora; `HttpClient` + reintentos (R2) pasan a 08-bonus con compose.
- D-RAG-4 (nueva): dónde se embebe (`store_document_chunks` llama a `get_embeddings` como dice el stub, o lo hace un `ingest()` puro tipo `extract()`).
- D-RAG-5 (nueva): error del vector store → `VectorStoreError` en `ERROR_STATUS` (503).
- Config nueva: `embedding_model`, `chunk_size`, `chunk_overlap`, `chroma_path`, `chroma_collection` (+ `.env.example`).
