# Crítica de la spec 01-fuzzy (code-critic, Opus, 2026-10-28)

**Veredicto: CHANGES.** Todos los cambios se aplicaron a la spec el mismo día. Claude verificó el dato que decide el AC nuevo: `fuzz.ratio("", "") = 100`.

| # | Hallazgo | Cambio aplicado |
|---|---|---|
| 1 | AC-06 probaba dos cosas, y la parte del entorno era frágil: `get_settings` usa `lru_cache` y lee `.env` | Se separa en AC-06a (umbral explícito) y AC-06b (valor por defecto de la config). Que el entorno cambia el valor ya lo prueba AC-CFG-01 |
| 2 | El guard `if key` no tenía AC; sin él, "Dr." contra "."/"-" daría un match de 1.0 | Nuevo AC-FUZ-13 |
| 3 | `name_score` normalizaba dos veces y ampliaba la superficie pública | Se quita; `_normalize` queda privada (unas -4 líneas) |
| 4 | El porqué de `threshold: float \| None = None` | Queda documentado en la spec: R1, README:81, evaluación al importar, y el router lo inyecta |
| 5 | La parte "rango [0, 1]" del AC-07 duplicaba al AC-10 (`FuzzyMatch` tiene `ge/le`) | AC-07 se queda con el orden y los decimales |
| 6 | AC-01 debía citar el ejemplo literal del README | "María González" ~ Maria/Gonzalez (README:93) |
| 7 | AC-CFG-02 sí pertenece a esta spec | Va en `tests/unit/test_config.py` con `_env_file=None` |

El crítico midió con `uv run` y confirmó que coinciden con el prototipo: Catherlne 0.9375, Maria 0.526, Robert/James Chen 0.571 y orden invertido 1.0.
