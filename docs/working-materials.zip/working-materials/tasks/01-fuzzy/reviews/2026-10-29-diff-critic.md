# Crítica del diff 01-fuzzy (code-critic, Opus, 2026-10-29)

## Ronda 1: CHANGES
| # | Sev. | Hallazgo | Qué se hizo |
|---|---|---|---|
| 1 | Media | El desempate por `matched_name` (F4, AC-FUZ-07) no tenía test: mutar la clave a `(-h[0], h[1])` dejaba los 16 tests en verde, porque `sort` es estable | Se agregó un bloque de desempate a `test_ac_fuz_07` ("Ana Ruiz" contra Anna/Ruiz y Ana/Ruizz, que empatan) |
| 2 | Media | Las comprensiones con tuplas `(s, e, m)` reusaban `e` y `m` con dos significados | Doble `for` explícito con `e_key`/`e_name` y `w_key`/`w_name`; `best` (0-100) y la división `/ 100` en la comparación y en el redondeo; comentario "Filter on the raw score" |
| 3 | Baja | Ordenar sobre el score redondeado | No contradice F4: el orden coincide con lo que ve el cliente. No se cambia |
| 4 | Baja | Renombrar `_by_key` a `_dedupe_by_key` | No se aplica: ruff partía la línea en dos (+2) y el docstring ya dice que deduplica. El crítico lo aceptó en la ronda 2 |
| 5 | Baja | El docstring no decía de dónde sale el umbral | Se agrega "`threshold=None` uses `get_settings().fuzzy_threshold`" |

## Ronda 2: APPROVE
- La mutación del desempate ahora falla (1 failed, 15 passed).
- 51 líneas: 4 por encima del gate, todas de documentación (docstring y comentario). El crítico no propone recortes.
- `best` en escala 0-100 se explica igual de bien o mejor que `ratio`.

## Verificación de Claude
- `verify.ps1`: ruff check, ruff format y pytest en verde (16 tests).
- Regresión sobre `eval/gold_fuzzy_pairs.csv` a 0.90: recall 12/15 y FPR 4/12, par por par igual que el proto (NB03, sección 6).
