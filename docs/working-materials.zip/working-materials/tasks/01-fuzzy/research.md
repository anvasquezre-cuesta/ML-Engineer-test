# 01-fuzzy · Research

## Fuentes y decisiones tomadas
- [V] Decisiones F1-F7: `research/17-nb03-fuzzy-research.md` (sección "Decisiones del grill").
- [V] Métricas y papers (Christen 2006, Cohen 2003, Hand & Christen 2018): `research/18-metricas.md` secciones 4-5.
- [V] Prototipo: `ML-Engineer-test/notebooks/proto/fuzzy.py`; evidencia: `notebooks/03_fuzzy.ipynb`.
- [V] Oro de pares: `ML-Engineer-test/eval/gold_fuzzy_pairs.csv` (27 pares).
- [V] Paquete: rapidfuzz 3.14.6 (MIT), ya en `pyproject.toml`. `fuzz.ratio("", "")` = 100 (medido): claves vacías se descartan.
- README:93-94 (cadena completa, mayúsculas, acentos); stub `app/services/fuzzy_service.py:3-6` (umbral configurable, 0.90).

## Huecos (falta investigar)
Ninguno.

## Decisiones abiertas
Ninguna (resueltas en la crítica de la spec: `threshold=None`, `_normalize` privada, sin `name_score`).
