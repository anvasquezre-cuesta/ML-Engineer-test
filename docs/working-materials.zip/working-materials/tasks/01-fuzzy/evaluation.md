# 01-fuzzy · Evaluación

| Qué | Cómo | Esperado |
|---|---|---|
| ACs | `uv run pytest tests/unit/test_fuzzy_service.py tests/unit/test_config.py -q` | 15 tests verdes (AC-FUZ-01..13 con 06a/06b, AC-CFG-02) |
| Valores | asserts con cifras del NB03 | Catherlne 0.9375; "Maria" vs Maria Gonzalez 0.526 (no pasa); Robert/James Chen 0.571; borde 0.90 exacto se reporta |
| Regresión (fuera de CI) | assistant corre la función sobre `eval/gold_fuzzy_pairs.csv` a 0.90 | recall 12/15, FPR 4/12 (igual que el NB03) |
| Calidad | `verify.ps1` | ruff, formato y pytest verdes |
| Mínimo de líneas | code-critic | servicio <= ~47 líneas; APPROVE |
| Explicación | Jeison sin mirar | cada AC + 3 preguntas de entrevistador |

Gates comunes (spec -> plan JM -> tests rojo -> verde -> code-critic -> explicación -> commit): `research/19-plan-implementacion.md`.
