# 01-fuzzy · Fuzzy match de nombres

**Alcance:** `fuzzy_service.fuzzy_match_names` + `fuzzy_threshold` en `app/config.py`. Fuera: router y parseo de `names` (04).
**Spec:** `ML-Engineer-test/docs/specs/01-fuzzy.md`
**Estado:** research listo · evaluación lista · spec commiteada (fc00320) · plan aprobado · implementación verde · code-critic APPROVE (ronda 2) · explicación firmada · **CERRADA (2026-10-29)**

| Etapa | Archivo |
|---|---|
| Research | [research.md](research.md) |
| Evaluación | [evaluation.md](evaluation.md) |
| Plan (JM) | [plan.md](plan.md) |
| Reviews | [reviews/](reviews/) |

## Qué necesitamos
**Depende de:** nada (primera tarea).
**Entradas:** spec `docs/specs/01-fuzzy.md`; `notebooks/proto/fuzzy.py`; `notebooks/03_fuzzy.ipynb`; `eval/gold_fuzzy_pairs.csv`.
**Entregables:** `app/config.py` (`fuzzy_threshold`); `app/services/fuzzy_service.py`; `tests/unit/test_fuzzy_service.py`; AC-CFG-02 en `tests/unit/test_config.py`.

**Pasos que faltan (en orden):**
1. ~~JM revisa y firma la spec~~ hecho: fc00320.
2. JM escribe [plan.md](plan.md); Claude lo revisa contra la spec.
3. implementer: tests en rojo, luego código mínimo en verde y `verify.ps1`.
4. code-critic (opus) sobre el diff y la spec; máx. 2 rondas -> `reviews/`.
5. assistant: regresión sobre `eval/gold_fuzzy_pairs.csv` (recall 12/15, FPR 4/12).
6. JM escribe la sección Explicación de la spec.
7. `/commit-handoff`.

**Commits previstos** (uno por idea, siempre verde y explicado):
- `docs(spec): add fuzzy matching spec`
- `feat(config): add fuzzy threshold setting` (con AC-CFG-02)
- `feat(fuzzy): match extracted names against query names` (tests + servicio)

**Hecho cuando:** todos los gates de [evaluation.md](evaluation.md) cumplidos, code-critic APPROVE, explicación de JM firmada y commits hechos.
