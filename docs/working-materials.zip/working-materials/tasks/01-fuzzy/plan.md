# 01-fuzzy · Plan de implementación (JM)

_Hecho en modo plan con Claude y aprobado por Jeison el 2026-10-29. Lo revisa contra la spec `docs/specs/01-fuzzy.md`._


## Contexto
Tarea activa en `tasks/INDEX.md`. La spec `docs/specs/01-fuzzy.md` ya está firmada y commiteada (fc00320). El NB03 tiene sus respuestas y se ejecutó completo. Falta llevar `notebooks/proto/fuzzy.py` a `app/services/fuzzy_service.py`. Hoy el stub lanza `NotImplementedError`. Además hay que agregar `fuzzy_threshold` a la config, que el README pide "configurable", y escribir sus tests. Resultado buscado: 15 tests verdes, `verify.ps1` verde, servicio de unas 40 líneas y explicable línea a línea.


## Orden (2 commits, cada uno en verde)
1. **Config** (commit `feat(config): add fuzzy threshold setting`)
   1. Test AC-CFG-02 en `tests/unit/test_config.py`. Hoy da **rojo**: `extra="ignore"` acepta `FUZZY_THRESHOLD=1.5` sin error.
   2. `app/config.py`: `from pydantic import Field` y `fuzzy_threshold: float = Field(0.90, ge=0.0, le=1.0)` bajo un comentario `# Fuzzy matching`.
   3. `.env.example`: `FUZZY_THRESHOLD=0.90` en un bloque `# Fuzzy matching`, para dejar documentada la variable.
   4. `verify.ps1` verde.
2. **Servicio** (commit `feat(fuzzy): match extracted names against query names`)
   1. `tests/unit/test_fuzzy_service.py` con los 14 tests AC-FUZ. Dan **rojo**: el stub lanza `NotImplementedError` y no acepta `threshold`.
   2. `app/services/fuzzy_service.py`, código mínimo hasta verde.
   3. `verify.ps1` → code-critic (Opus, máx. 2 rondas, a `tasks/01-fuzzy/reviews/`) → regresión del assistant → Explicación de JM → `/commit-handoff`.

## Archivos y funciones
| Archivo | Cambio | AC |
|---|---|---|
| `app/config.py` | `fuzzy_threshold` con `Field(ge=0, le=1)` | CFG-02, FUZ-06b |
| `.env.example` | `FUZZY_THRESHOLD=0.90` | (documenta la config, README:81) |
| `app/services/fuzzy_service.py` | `_TITLES` (frozenset) | FUZ-11 |
| | `_normalize(name) -> str`: copia exacta de `proto/fuzzy.py:11-17` (normalize_name) | FUZ-01, 04, 11, 13 |
| | `_by_key(names) -> dict[str, str]`: clave normalizada a primera aparición, descarta las claves vacías (`if key: keys.setdefault(key, name)`). Elimina los dos bucles repetidos de `proto/fuzzy.py:31-39` | FUZ-08, 09, 13 |
| | `fuzzy_match_names(extracted_names, query_names, threshold: float \| None = None)`: con `None` usa `get_settings().fuzzy_threshold`; doble bucle sobre las claves; score `max(ratio, token_sort_ratio)/100` calculado en línea (sin `name_score`); filtro `>=` sobre el crudo; `round(score, 4)`; `sorted` por `(-score, extracted_name, matched_name)` | FUZ-02, 03, 05, 06a/b, 07, 10, 12 |

Se reusa `proto/fuzzy.py` (normalización, dedupe, orden) y `app/config.get_settings`; el servicio importa `get_settings` a nivel de módulo para que el test lo pueda parchear. Se reescribe el docstring del stub en inglés, como el resto de `app/`.

`_by_key` es un helper privado que la spec no nombra. Si el code-critic lo rechaza, se vuelve a los dos bucles del proto (unas +4 líneas).

## Tests (rojo primero)
`tests/unit/test_fuzzy_service.py`. El helper `_one(name, first, last, **kw)` llama con un solo par. Nombres `test_ac_fuz_<nn>_<qué>`:

| Test | Entrada → esperado |
|---|---|
| 01 accents_case | "María González" vs Maria/Gonzalez → score 1.0 |
| 02 partial_name_no_match | "Maria" vs Maria/Gonzalez → `[]` |
| 03 ocr_noise | "Catherlne Dubois" vs Catherine/Dubois → 0.9375 |
| 04 inverted_order | "Gonzalez Maria" vs Maria/Gonzalez → 1.0 |
| 05 same_last_name | "Robert Chen" vs James/Chen → `[]` |
| 06a explicit_threshold | Catherlne con `threshold=0.99` → `[]` |
| 06b default_from_settings | `Settings(_env_file=None).fuzzy_threshold == 0.90`; `monkeypatch.setattr(fuzzy_service, "get_settings", lambda: Settings(_env_file=None, fuzzy_threshold=0.95))` → Catherlne sin threshold da `[]` (prueba que el valor viene de la config, sin depender de `.env` ni de `lru_cache`) |
| 07 order_and_rounding | extraídos ["Robert Chen", "Maria Garcia"] vs María García, Robert Chen, Mario Garcia → lista exacta `[Maria Garcia/María García 1.0, Robert Chen/Robert Chen 1.0, Maria Garcia/Mario Garcia 0.9167]` (medido con el proto) |
| 08 dedupe_first_seen | ["Ana Ruiz", "ana  ruiz"] vs Ana/Ruiz, ANA/RUIZ → `[{"Ana Ruiz", "Ana Ruiz", 1.0}]` |
| 09 empty_inputs | `[]` en cualquiera de los dos lados → `[]` |
| 10 fuzzy_match_schema | `FuzzyMatch(**m)` valida y las claves son las del schema (se importa de `app.models.schemas`, que no se toca) |
| 11 title_removed | "Dr. Robert Chen" vs Robert/Chen → 1.0 |
| 12 threshold_inclusive | "abcd efghi" vs abcd/efghk con 0.90 → score 0.9 |
| 13 empty_keys_dropped | "Dr." vs "."/"-" → `[]` |

`tests/unit/test_config.py`: `test_ac_cfg_02_threshold_out_of_range_rejected`. `monkeypatch.setenv("FUZZY_THRESHOLD", "1.5")` y luego `pytest.raises(ValidationError)` al crear `Settings(_env_file=None)`.

Total: 15 tests más el AC-CFG-01 existente.

## Líneas esperadas y qué no voy a escribir
- Servicio: unas 40 líneas (gate: 47 o menos). Config: +3. Tests: unas 90.
- **No escribo:**
  - router ni parseo de `names` (spec 04);
  - logging: el servicio no loguea, el router contará y registrará sin PII en la spec 04;
  - un Protocol para el matcher (función pura, nada que inyectar);
  - lógica de iniciales o segundos nombres (F6);
  - tabla ø/ł;
  - cambios a `schemas.py`, a `DECISIONS.md` o al NB03, que podrá importar de `app/` en una tarea posterior.

## Riesgos y cómo los verifico
- **`.env` local con `FUZZY_THRESHOLD`**: 06b y CFG-02 usan `_env_file=None` y monkeypatch, sin depender de `get_settings()` cacheado.
- **Divergencia con el proto**: el assistant corre el servicio sobre `eval/gold_fuzzy_pairs.csv` a 0.90 y debe dar recall 12/15 y FPR 4/12 (lo mismo que el NB03).
- **Versión de rapidfuzz** (los scores pueden cambiar): está fijada en `uv.lock`, y la 3.14.6 es la medida en el NB03.
- **Hidden tests con 2 argumentos**: la firma conserva el orden del stub y `threshold` es opcional.

## Verificación
1. `uv run pytest tests/unit/test_config.py -q` en rojo → verde (paso 1).
2. `uv run pytest tests/unit/test_fuzzy_service.py -q` en rojo (NotImplementedError/TypeError) → 14 verdes.
3. `powershell -NoProfile -File .claude/tools/verify.ps1` → ruff, formato y pytest ok.
4. Regresión del assistant sobre el oro: 12/15 y 4/12.
5. Code-critic APPROVE y Explicación de JM en la spec; después `/commit-handoff` para cada commit.
