# 02-ner · Evaluación

| Qué | Cómo | Esperado |
|---|---|---|
| AC-NER-02..07 | Unitarios en `tests/unit/test_ner_service.py` con un recognizer falso (una lambda que devuelve `Span`), sin spaCy | Todos verdes |
| AC-NER-01 | Integración en `tests/integration/test_ner_spacy.py`, con el modelo real sobre una frase con PERSON, ORG, GPE y DATE | Solo PERSON |
| AC-CFG-03 | `Settings(_env_file=None)` | `ner_model == "en_core_web_sm"`, `ner_drop_all_caps is True` |
| Modelo real sobre las muestras | El assistant toma el texto por página de las 3 muestras (el mismo que usó 02c), llama a `find_person_spans` desde `app/` y compara con `eval/gold_names.csv` | P 1.0 y R 54/55 = 0.982, con los mismos `(name, start, end)` que `propagate_names` del proto, menos la columna `source` |
| Notebook | Sección "Desde `app/`" en 02a/02c, que importa `find_person_spans` y asserta que coincide con el proto | Sin diferencias |
| Tamaño | `ner_service.py` | ~40 líneas (gate: ≤ 48); config +2 |
| Calidad | `verify.ps1` y code-critic | Verde; APPROVE |

Gates comunes (spec, plan JM, tests en rojo, verde, code-critic, explicación, commit): `research/19-plan-implementacion.md`.
