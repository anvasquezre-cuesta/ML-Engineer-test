# 02-ner · Plan de implementación (JM)

_Hecho en modo plan con Claude y aprobado por Jeison el 2026-10-29. Se revisa contra la spec `docs/specs/02-ner.md`._


## Contexto
La spec `docs/specs/02-ner.md` está aprobada por el code-critic en 2 rondas y commiteada (`62a8d2e`). Las decisiones D-NER-1..4 están en `tasks/02-ner/reviews/2026-10-29-decisions-critic.md`.

Hoy `app/services/ner_service.py` es un stub que lanza `NotImplementedError`. Hay que llevar a `app/` el prototipo validado (`notebooks/proto/ner.py`: `person_spans`, `filter_persons`, `propagate_names`), sin pandas, que solo está en el grupo `notebooks`. Va detrás de un Protocol `NameRecognizer` y con la config `ner_model` y `ner_drop_all_caps`.

Resultado buscado:
- 8 tests nuevos en verde y `verify.ps1` en verde;
- un servicio de unas 40 líneas, explicable línea a línea;
- desde `app/`, la misma salida que el proto: P 1.0 y R 54/55 sobre `eval/gold_names.csv`.

Al aprobar, lo primero es copiar este plan a `tasks/02-ner/plan.md`.

## Subagentes (este plan pide tu sí para todos)
| Rol | Modelo | Habilidades | Lee | Devuelve | Interacción |
|---|---|---|---|---|---|
| `implementer` | Sonnet | Read/Edit/Write, `uv run`, `verify.ps1`; no hace git | spec, este plan, proto, stub, `fuzzy_service.py` (estilo) | diff + tests rojo→verde, ≤300 palabras | Responde al crítico con un cambio o una justificación |
| `code-critic` | Opus | solo lectura y `uv run` para mutar en copia | spec y diff, **sin** las conclusiones del implementer | APPROVE/CHANGES; prueba mutaciones (sin `sorted`, sin `(?<!\w)`, filtro de mayúsculas sin config) | Corre **en paralelo**: interroga al implementer por SendMessage; yo arbitro; máximo 2 rondas |
| `assistant` | Sonnet | Read y `uv run` en el scratchpad; no edita el repo | `notebooks/artifacts/01_ocr_words.csv`, `02a_name_boxes.csv`, `eval/gold_names.csv` | Regresión: `(name, start, end)` desde `app/` comparado con el proto, y P/R | Solo me reporta a mí |
| `notebook-builder` | Sonnet | Edit de los builders en `research/notebook-builders/`, ejecutar con nbconvert | 02a/02c y sus builders | Las 3 secciones de cierre de 02a/02c (ver paso 4), ejecutadas sin errores | Después pasa a revisión |
| `notebook-reviewer` | Opus | solo lectura | 02a/02c ejecutados, **sin** las conclusiones del builder | Cada afirmación tiene su celda | Yo corrijo con el builder si hace falta |

## Orden (3 commits de código, cada uno en verde)
1. **Config** (commit `feat(config): add NER model and all-caps settings`)
   1. AC-CFG-03 en `tests/unit/test_config.py`, en rojo: `Settings` no tiene `ner_model`.
   2. En `app/config.py`, bajo `# NER`: `ner_model: str = "en_core_web_sm"` y `ner_drop_all_caps: bool = True`.
   3. En `.env.example`: un bloque `# NER` con `NER_MODEL=en_core_web_sm` y `NER_DROP_ALL_CAPS=true`.
   4. `verify.ps1` en verde.
2. **NER con filtros** (commit `feat(ner): extract person names with spaCy and filters`)
   1. Tests en rojo:
      - AC-NER-02, 05 y 07 en `tests/unit/test_ner_service.py`;
      - AC-NER-01 en `tests/integration/test_ner_spacy.py`.
   2. `ner_service.py`: `Span`, `NameRecognizer`, `_load_model`, `spacy_persons`, `_is_name`, `find_person_spans` (por ahora sin propagación) y `extract_names`.
3. **Propagación D4** (commit `feat(ner): propagate detected names across the document`)
   1. AC-NER-03, 04 y 06, en rojo: sin propagación, la página 1 no tiene spans.
   2. `_propagate` y su llamada en `find_person_spans`.
   3. `verify.ps1`, crítico en paralelo, regresión del assistant.
4. **Cierre** (después de los 3 commits)
   1. **Notebooks:** 02a y 02c reciben tres cosas:
      - una sección "Desde `app/`" (en 02a, la igualdad de `(name, start, end)` con el proto; en 02c, P/R desde `app/`);
      - "Preguntas que me pueden hacer";
      - un borrador de "Mis respuestas", marcado como borrador.
   2. **Documentación:** `research/20` con su sección "Tarea 02" y `research/18-metricas.md` si sale una fórmula nueva.
   3. **`DECISIONS.md`:** una sección "Person NER" que cita Finkel 2005 y Gale 1992 / Krishnan & Manning 2006 para D4. **Te muestro el texto exacto antes de editarlo.** Va en el commit `docs: record person NER decisions`.
   4. **Spec:** tu Explicación en la spec, en el commit `docs(spec): explain person NER acceptance criteria`.
   5. **Estado:** `tasks/INDEX.md` y `research/21` (o un `22-estado`), más la fila en `DECISIONS-LOG`.

## Archivos y funciones
| Archivo | Cambio | AC |
|---|---|---|
| `app/config.py` | `ner_model` y `ner_drop_all_caps` | CFG-03, NER-05 |
| `.env.example` | bloque `# NER` | (documenta la config) |
| `app/services/ner_service.py` | `Span = tuple[str, int, int]` | contrato con 03 |
| | `NameRecognizer(Protocol)`: `__call__(text) -> list[Span]` | inyección |
| | `_load_model(name)` con `@lru_cache` → `spacy.load(name)` | carga única y perezosa |
| | `spacy_persons(text)`: PERSON con `ent.text`, `start_char`, `end_char` (viene de `proto/ner.py:9-16`) | NER-01 |
| | `_is_name(name, drop_all_caps)`: los 3 filtros (`proto/ner.py:22`) | NER-02, 05 |
| | `_propagate(text, names, found)`: regex `(?<!\w)…(?!\w)` y `sorted(set(found + hits), key=lambda s: s[1:])` (`proto/ner.py:85-100`) | NER-03, 04, 06 |
| | `find_person_spans(pages, recognizer=None)`: `recognizer or spacy_persons` y `get_settings()` dentro; filtra por página; reúne los `names` de todas las páginas; propaga por página | NER-02..07 |
| | `extract_names(text)`: `list(dict.fromkeys(n for n, _, _ in find_person_spans([text])[0]))` | NER-01, 07 (R1) |

Se reusan:
- `app.config.get_settings`;
- el patrón de monkeypatch de `tests/unit/test_fuzzy_service.py` (06b);
- `proto/ocr.py:add_offsets_all` y `proto/ner.py:precision_recall`, solo en la regresión del assistant y los notebooks, nunca en `app/`.

## Tests (rojo primero)
`tests/unit/test_ner_service.py`. El fake es una función que devuelve los spans fijos de cada página. La config se cambia con `monkeypatch.setattr(ner_service, "get_settings", lambda: Settings(_env_file=None, ...))`.

| Test | Entrada → esperado |
|---|---|
| `test_ac_ner_02_filters_drop_non_names` | "Robert\nChen", "Chen", "JOHN SMITH" → `[[]]` |
| `test_ac_ner_03_propagates_to_other_pages` | "Robert Chen" en la página 0 → 2 spans en la página 1 |
| `test_ac_ner_04_word_boundaries_and_no_duplicates` | "Ann Lee met Ann Leeds and LeeAnn Lee", el fake también devuelve (0, 7) → `[("Ann Lee", 0, 7)]` |
| `test_ac_ner_05_all_caps_kept_when_disabled` | `ner_drop_all_caps=False` → "JOHN SMITH" se conserva |
| `test_ac_ner_06_sorted_by_start_and_offsets_match` | `["Ann Lee met Bob Ray", "Bob Ray met Ann Lee"]` → página 0 `[("Ann Lee", 0, 7), ("Bob Ray", 12, 19)]` y `pages[i][s:e] == name` |
| `test_ac_ner_07_extract_names_unique_and_empty` | `spacy_persons` parcheado; nombres repetidos → únicos en orden; `extract_names("") == []`; `find_person_spans([]) == []` |

`tests/integration/test_ner_spacy.py`, con `test_ac_ner_01_only_persons` y el modelo real: "Maria Gonzalez met Acme Corp in Paris on Monday." → `["Maria Gonzalez"]`. Ya está comprobado con `uv run`.

`tests/unit/test_config.py`, con `test_ac_cfg_03_ner_defaults`.

## Líneas esperadas y qué no se escribe
- Tamaño: servicio de unas 40 líneas (gate: ≤ 48); config +3; tests unas 80.
- **No se escribe:**
  - pandas ni la columna `source`;
  - `ner_min_tokens`;
  - una clase `SpacyRecognizer`;
  - cajas (03), router y lifespan (04);
  - las funciones de evaluación (`keys`, `tokens`, `count_hits`, `precision_recall`, `wilson`);
  - cambios a `schemas.py` o a `main.py`.

## Riesgos y cómo se verifican
- **`.env` local con `NER_*`:** los tests usan `_env_file=None` y monkeypatch, nunca `get_settings()` cacheado.
- **El test de integración carga spaCy (~1 s) dentro de `verify.ps1`:** es aceptable, y el modelo está fijado como wheel (`pyproject.toml:47`).
- **Divergencia con el proto:** el assistant compara `(name, start, end)` desde `app/` contra `02a_name_boxes.csv` (sin `source`), con los mismos textos por página (`add_offsets_all` sobre `01_ocr_words.csv`, sin volver a correr el OCR). Debe dar igualdad total, P 1.0 y R 54/55.
- **Tests que no detectan errores:** el crítico corre 3 mutaciones (sin `sorted`, sin `(?<!\w)`, `drop_all_caps` ignorado) y cada una debe hacer fallar al menos 1 test.
- **Orden de páginas en la regresión:** las páginas se arman `range(n)` con `texts.get(..., "")` para que el índice coincida con `page`.

## Verificación
1. `uv run pytest tests/unit/test_config.py -q`: rojo → verde.
2. `uv run pytest tests/unit/test_ner_service.py tests/integration -q`: rojo (`NotImplementedError` o `ImportError`) → verde, en cada commit.
3. `powershell -NoProfile -File .claude/tools/verify.ps1`: ruff, formato y pytest en ok.
4. Regresión del assistant: igualdad con el proto, P 1.0 y R 54/55.
5. Code-critic APPROVE con las mutaciones, 02a/02c ejecutados con 0 errores y notebook-reviewer OK.
6. Tu Explicación y después `/commit-handoff` para cada commit.
