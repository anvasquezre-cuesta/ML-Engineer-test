# 02-ner · Research

## Fuentes y decisiones tomadas
- [V] Filtros (cruza renglón, MAYÚSCULAS, una palabra) y medición: `notebooks/02a_ner_cajas.ipynb`, `02c_evaluacion.ipynb`; `research/16-estado-2026-10-28.md`.
- [V] D4 (propagación en el documento) y papers (Finkel 2005, Krishnan & Manning 2006, Gale 1992, Ratinov & Roth 2009): `research/17:74-86` (tabla de decisiones) y `research/18-metricas.md` secciones 1-3 y 6.
- [V] Prototipo: `notebooks/proto/ner.py`:
  - `person_spans` (:9), `filter_persons` (:19-23) y `propagate_names` (:85-100);
  - solo evaluación, no va a `app/`: `keys`, `tokens`, `count_hits`, `precision_recall` y `wilson`;
  - `name_box` y `locate_names` son de la tarea 03.
- [V] R3 (`research/14-revision-plan.md:15`): filtro de MAYÚSCULAS configurable `NER_DROP_ALL_CAPS`.
- [V] Oro: `eval/gold_names.csv` (55 menciones). Medido: P 1.0, R 54/55 = 0.982 con D4 (`research/17:74`).

## Hechos verificados (2026-10-29, assistant + Claude)
- **Stubs:**
  - `extract_names(text: str) -> list[str]` (`app/services/ner_service.py:7`);
  - `find_name_bounding_boxes(pdf_path, text) -> list[dict]` (`bbox_service.py:12`);
  - `extract_text_from_pdf(pdf_path) -> str` (`ocr_service.py:13`, texto de todo el documento).
  - R1 conserva estas firmas.
- **pandas no es dependencia de `app/`:** solo está en el grupo `notebooks` (`pyproject.toml:39-44`). El proto usa DataFrames, así que en `app/` hay que reescribirlo con tuplas o listas.
- **Los offsets son por página.** `add_offsets` (`proto/ocr.py:66-89`) arma el texto de cada página: palabras unidas con " " y renglones con "\n". `name_box` (`proto/ner.py:26-35`) cruza los offsets del span con los de las palabras. `propagate_names` trabaja una página, con los `names` reunidos de todo el PDF.
- **`main.py` no tiene lifespan** (`app/main.py:13`). `config.py` todavía no tiene `ner_*`.
- `Protocol NameRecognizer` lo decidió Jeison el 28-oct (`DECISIONS-LOG`, fila 63) y figura en `research/19:55`.

## Opciones (assistant; costo en líneas de `app/`)

### D-NER-1 · Qué devuelve la función de spans
| Op | Forma | Líneas | Nota |
|---|---|---|---|
| a | `tuple[str, int, int]` (name, start, end) | +0 | 03 desempaqueta `for name, start, end in ...` |
| b | `@dataclass(frozen=True) NameSpan(name, start, end)` | +4 | Acceso por nombre y comparación por igualdad en los tests |
| c | `spacy.tokens.Span` | +0 | Acopla 03 y los tests a spaCy, y el fake tendría que construir `Doc` |

`extract_names(text)` queda como envoltorio R1: los nombres únicos de los spans, en 1-3 líneas. La función de spans es pública solo si 03 la importa.

### D-NER-2 · Propagación (D4)
| Op | Forma | Líneas |
|---|---|---|
| a | `_propagate(text, names, found) -> spans` privada, por página: regex `(?<!\w)…(?!\w)` y dedupe por `(start, end)` | ~8 |
| b | Lo mismo, pero pública | ~8 |
| c | Una función pública `find_person_spans(pages: list[str]) -> list[list[span]]` que hace NER, filtros y propagación (nombres de todo el PDF, spans por página), con (a) dentro | ~15 |

Si se quita la columna `source` (`spacy`/`propagated`), 02a/02c no se pueden reproducir 1:1 desde `app/`. Hay que decidir si se conserva (+1 campo) o se descarta.

### D-NER-3 · Filtros configurables
| Op | Qué | Líneas |
|---|---|---|
| a | Solo `ner_drop_all_caps: bool = True` (R3); "cruza renglón" y "una palabra" fijos | +1 config, +1 `if` |
| b | Además `ner_min_tokens: int = 2` (lo mencionan `research/06:22` y `07:49`) | +1 config |
| c | Ninguno configurable | 0, contradice R3 |

`research/14` manda sobre 06 y 07 (número mayor).

### D-NER-4 + hueco B · Inyección y carga única del modelo
| Op | Mecanismo | Líneas | Fake en tests |
|---|---|---|---|
| a | `NameRecognizer(Protocol)` que devuelve `(name, start, end)` de PERSON; `_load_spacy()` con `@lru_cache` (como `get_settings`); parámetro `recognizer=None` | ~8 | Se pasa `recognizer=fake` |
| b | Carga en el `lifespan` de `main.py` y guarda en `app.state`; el router lo pasa | +10 en main y router (tarea 04) | `dependency_overrides` |
| c | `nlp = spacy.load(...)` a nivel de módulo | 1 | Importar el módulo carga spaCy en los tests: viola la regla |

`lru_cache` carga en el primer request; el `lifespan` lo precalentaría (tarea 04). El Protocol devuelve spans, no `Doc`, para que el fake sea trivial. Los filtros quedan como función pura aparte.

### Hueco A · Spans para las cajas (03)
| Op | Qué | Efecto |
|---|---|---|
| a | Offsets de caracteres sobre el texto de **página**; 03 los cruza con las palabras (`proto/ner.py:32`) | +0 en NER; la lógica de cajas vive en 03 |
| b | NER devuelve índices de palabras OCR | NER conoce OCR: acoplamiento, descartada |
| c | Texto único del documento con offsets globales y una tabla página→rango | +5-10; solo si 03 se queda con `(pdf_path, text)` de texto único |

## Contradicciones y pendientes
1. **Choque de firmas:** `extract_names(text: str)` y `find_name_bounding_boxes(pdf_path, text)` reciben un solo texto, pero D4 y las cajas trabajan por página. Hay que decidir quién parte por páginas: lo arma 03, y 02 solo necesita una API que acepte páginas.
2. `NER_MIN_TOKENS` (06 y 07) frente al filtro fijo de dos palabras: manda el 14.
3. `Doc.char_span` y el API de spaCy no se probaron; no hace falta si se usa `ent.start_char`/`end_char` (`proto/ner.py:12`).

## Decisiones abiertas
D-NER-1..4 y huecos A/B: las decide el code-critic en `reviews/2026-10-29-decisions-critic.md`, y Claude arbitra.
