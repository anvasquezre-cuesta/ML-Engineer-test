# 02-ner · NER de personas

**Alcance:** `ner_service.extract_names` (spaCy `en_core_web_sm`, 3 filtros, propagación D4) detrás de un Protocol `NameRecognizer`. Fuera: cajas (03), router (04).
**Spec:** `ML-Engineer-test/docs/specs/02-ner.md` (por escribir)
**Estado:** **CERRADA 2026-10-29** · commits 62a8d2e (spec), b28e733 (config), 4578e39 (filtros), 1784712 (propagación), 90e3bbe (DECISIONS), 1ed51b8 (Explicación) + firma (pendiente JM)

| Etapa | Archivo |
|---|---|
| Research | [research.md](research.md) |
| Evaluación | [evaluation.md](evaluation.md) |
| Plan (JM) | [plan.md](plan.md) |
| Reviews | [reviews/](reviews/) |

## Qué necesitamos
**Depende de:** 01 cerrada (commit hecho).
**Entradas:** `notebooks/proto/ner.py`; `02a_ner_cajas.ipynb`, `02c_evaluacion.ipynb`; `eval/gold_names.csv`; `research/17` y `18`; R3 en `research/14`.
**Entregables:** `app/services/ner_service.py` (Protocol `NameRecognizer`, filtros, propagación); `app/config.py` (`ner_model`, `ner_drop_all_caps`); `tests/unit/test_ner_service.py` con recognizer falso.

**Pasos que faltan (en orden):**
1. assistant: lee proto y stubs; escribe opciones de D-NER-1..4 con costo en líneas en [research.md](research.md).
2. code-critic: decide D-NER-1..4 (mínimo de código) -> `reviews/`.
3. Claude completa [evaluation.md](evaluation.md) con los valores esperados.
4. Claude redacta la spec `docs/specs/02-ner.md`; code-critic la critica; JM la firma.
5. JM escribe [plan.md](plan.md).
6. implementer -> verify -> code-critic -> assistant mide P/R con el modelo real -> explicación JM -> `/commit-handoff`.

**Commits previstos** (uno por idea, siempre verde y explicado):
- `docs(spec): add person NER spec`
- `feat(ner): extract person names with spaCy and filters`
- `feat(ner): propagate detected names across the document` (si D4 va aparte)

**Hecho cuando:** todos los gates de [evaluation.md](evaluation.md) cumplidos, code-critic APPROVE, explicación de JM firmada y commits hechos.
