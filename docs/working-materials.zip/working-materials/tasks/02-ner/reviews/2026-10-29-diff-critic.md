# 02-ner · code-critic (Opus) sobre el diff · 2026-10-29

## Ronda 1: pasos 1-2 (config, NER con filtros), CHANGES
**Mutaciones (tests unitarios):**
- Mueren:
  - quitar el filtro de una palabra;
  - ignorar `drop_all_caps`;
  - quitar `dict.fromkeys`;
  - leer `get_settings()` al importar.
- Sobrevive quitar el filtro `"\n"`: el caso `"Robert\nChen"` ya caía por el de una palabra.
- También sobrevive quitar el `sorted`. Era de esperar: lo cubre AC-NER-06 en el paso 3.

| # | Problema | Decisión de Claude |
|---|---|---|
| C1 | Sobrevive la mutación sin el filtro `"\n"` | **Aplicado:** span `("Robert Chen\nCFO", 0, 15)`. La mutación ahora falla (lo comprobó el implementer) |
| C2 | AC-NER-02 dependía de `get_settings()` real, y falla con `NER_DROP_ALL_CAPS=false` | **Aplicado:** fixture `autouse` con `Settings(_env_file=None)` |
| 3 | El fake con `iter` depende del orden de las llamadas | **Aplicado:** `{page: spans}.get` o una lambda |
| 4 | `import spacy` arriba suma 2.6 s a los unitarios | **Rechazado:** el import arriba es lo estándar y lo más fácil de explicar, y el test de integración carga spaCy de todos modos |
| 5 | Los nombres `drop`, `p` y `s[1:]` | **Aplicado:** `drop_caps`, `page` y `(s[1], s[2])` |
| 6 | `delenv("NER_MODEL")` en AC-CFG-03 | **Rechazado:** riesgo bajo y es consistente con AC-CFG-01 y 02 |

**Presupuesto:** el servicio tiene 51 líneas tras los pasos 1-2, porque `ruff format` partió el `sorted`. Tope final del paso 3: **58 o menos** (antes 48). El `sorted` pasa a `_propagate` y `find_person_spans` se acorta. Se estiman unas 56 líneas.

`verify.ps1` en verde (21 passed), corrido por Claude.

## Ronda 2: paso 3 (propagación D4), APPROVE
- **Mutación sin `sorted`:** con dedupe por `set` sobrevivía en 25 de 200 semillas de PYTHONHASHSEED (12 %), porque el orden del `set` depende del hash; lo midió Claude. El dedupe pasó a `sorted(dict.fromkeys(found + hits), ...)`, que conserva el orden de inserción. Ahora, sin `sorted`, AC-06 falla siempre (3 de 3 semillas).
- **Mutaciones de la regex:** sin `(?<!\w)` y sin `(?!\w)`, cada una hace fallar AC-04. Sin `dict.fromkeys` fallan 3 tests.
- **Presupuesto:** acepto 60 líneas. Las 2 de más son de `ruff format` al cambiar `p` por `page`; no es lógica nueva. Volver a `p` ahorra 2 líneas a cambio de claridad.
- **Mejora opcional, aplicada:** el fake de AC-03 es `dict.get` con las dos páginas, sin lambda.
- `verify.ps1` en verde, con 24 tests.

Nota: `.claude/rules/tests.md` pide fakes en `tests/fakes.py`. Aquí son lambdas o `dict.get` de una línea dentro del test. Un archivo de fakes no tiene sentido hasta que haya fakes compartidos (`OcrEngine`, tarea 03).
