# 02-ner · code-critic (Opus) sobre D-NER-1..4 · 2026-10-29

Entrada: `tasks/02-ner/research.md` (opciones del assistant). El crítico no recibió la preferencia de Claude. **Veredicto: APPROVE** (ya alcanza para escribir la spec).

| Decisión | Elegida | Por qué | Líneas |
|---|---|---|---|
| D-NER-1 | (a) `Span = tuple[str, int, int]` | 03 desempaqueta y los tests comparan con `==`; un dataclass suma 4 líneas sin aportar | +1 |
| D-NER-2 | (c) `find_person_spans(pages)` pública con `_propagate` privada | Resuelve el choque de firmas: el trabajo es por página (`proto/ocr.py:74-87`) y los nombres se reúnen de todo el documento (D4, `research/17:76`) | ~15 |
| D-NER-3 | (a) solo `ner_drop_all_caps` | R3 (`research/14:15`). "Dos palabras" define qué es un nombre completo y hace segura a D4: propagar "Chen" sería peligroso | +2 |
| D-NER-4 + B | (a) Protocol invocable, `_load_model` con `@lru_cache` y `recognizer=None` | El fake es una lambda e importar el módulo no carga el modelo; la tarea 04 puede precalentarlo en el lifespan | ~8 |
| Hueco A | (a) offsets por página | NER no sabe de OCR; 03 cruza los offsets con las palabras (`proto/ner.py:32`) | 0 |
| `source` | se borra | El README no lo pide; "Desde `app/`" compara `(name, start, end)` | 0 |

**Firmas públicas:**
- `Span`
- `NameRecognizer.__call__(text) -> list[Span]`
- `spacy_persons(text) -> list[Span]`
- `find_person_spans(pages: list[str], recognizer: NameRecognizer | None = None) -> list[list[Span]]`
- `extract_names(text) -> list[str]` (R1, `[text]` como una página)

**Privadas:** `_load_model`, `_is_name`, `_propagate`.

**Dedupe:** un dict con clave `(start, end)` y `setdefault`, para que gane el span de spaCy, como `drop_duplicates` en `proto/ner.py:98`.

**No se escribe:**
- `ner_min_tokens`;
- `source`;
- DataFrames;
- las funciones de evaluación;
- una clase `SpacyRecognizer`;
- cambios a `main.py` y a `extract.py` (tarea 04).

**Riesgo residual:** la propagación distingue mayúsculas y minúsculas, a propósito: D4 pide coincidencia exacta.

## Ronda 1 sobre la spec (code-critic, CHANGES, 10 cambios)
Claude aceptó los 10 cambios y los aplicó en `docs/specs/02-ner.md`:
1. **Dedupe con `set` y orden por `(start, end)`.** Reemplaza al `setdefault` de arriba. Como `text[start:end] == name`, dos spans con el mismo `(start, end)` son la misma tupla, y "gana spaCy" no se puede observar (-2 líneas).
2. **AC-04 prueba los dos bordes de palabra** ("LeeAnn Lee"). Comprobado: sin `(?<!\w)` sale un segundo span en (29, 36).
3. **AC-06 con un caso concreto** que solo pasa si se ordena: `("Ann Lee", 12, 19)`, comprobado.
4. **`get_settings()` se lee dentro de la función**, y los tests hacen monkeypatch de `ner_service.get_settings`.
5. **AC-07 separado en dos casos:** `extract_names("")` y `find_person_spans([])`. El fake se parchea en `ner_service.spacy_persons`.
6. **`_load_model(name)`** guarda en caché un modelo por nombre.
7. **AC-01 vía `extract_names`**, la función que pide el README:45.
8. **Los AC llevan "When".**
9. **La tarea 3 mapea cada función** del proto a su versión en `app/`.
10. **Modelo ausente: queda fuera de alcance** (spec 04).

## Ronda 2 sobre la spec (code-critic)
Quedaba una sola cosa que bloqueaba:
- **Problema:** con los datos de AC-06, el span del fake ya iba primero. Sin `sorted`, el test pasaba por casualidad o fallaba al azar, según el hash del `set`.
- **Cambio:** los datos se invirtieron para que el span propagado `("Ann Lee", 0, 7)` vaya antes que el del fake `("Bob Ray", 12, 19)`. Los offsets se comprobaron con `uv run`.
- **Resultado:** los cambios 1-10 quedan bien aplicados. Con esta corrección, la spec está aprobada y lista para que Jeison la firme. Se cierran las 2 rondas.

## Arbitraje de Claude
- **Acepto todo.**
- **Un ajuste:** AC-NER-01 usa el modelo real, así que va en `tests/integration/test_ner_spacy.py` y no en `tests/unit/`. Así lo pide la regla de CLAUDE.md: los unitarios no cargan modelos.
- **Verificado:**
  - pandas solo está en el grupo `notebooks` (`pyproject.toml:39-44`);
  - `main.py` no tiene lifespan (`:13`);
  - el dedupe con `setdefault` replica `drop_duplicates(["start","end"])`, que conserva la primera fila, y en el proto las de spaCy van primero (`proto/ner.py:97-98`).
