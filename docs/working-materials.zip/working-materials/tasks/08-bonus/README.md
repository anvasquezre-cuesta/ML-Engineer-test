# 08-bonus · Bonus: CI, visor, Docker

**Alcance:** visor de auditoría (pdf.js, spec 08a-viewer) y CI (spec 08b-ci). Docker fuera por ahora (decisión de JM, 2026-10-30).
**Spec:** `docs/specs/08a-viewer.md` y `docs/specs/08b-ci.md` (crítico r1 aplicado; firmadas por JM el 2026-10-30)
**Estado:** cerrada (2026-10-30). JM probó en el navegador AC-VIEW-02/03 y AC-ASK-PAGE-02/03; CI verde en el fork (AC-CI-01).

| Etapa | Archivo |
|---|---|
| Research | [research.md](research.md) |
| Evaluación | [evaluation.md](evaluation.md) |
| Plan (JM) | [plan.md](plan.md) |
| Reviews | [reviews/](reviews/) |

## Qué necesitamos
**Depende de:** 07 cerrada; entra solo si queda tiempo antes de la entrega.
**Entradas:** README:102-111 y 152-155.
**Entregables:** según lo elegido: `.github/workflows/ci.yml`; visor de cajas; `Dockerfile` + `docker-compose.yml`.

**Pasos que faltan (en orden):**
1. JM fija la fecha de entrega y elige bonus (orden recomendado: CI > visor > Docker).
2. package-auditor o assistant: research corto del bonus elegido.
3. Una mini-spec por bonus y el mismo ciclo (plan JM -> implementer -> code-critic -> explicación -> commit).

**Commits previstos** (uno por idea, siempre verde y explicado):
- `ci: run lint and tests on push`
- `feat(viewer): draw name boxes over the PDF`
- `chore(docker): add Dockerfile and compose`

**Hecho cuando:** todos los gates de [evaluation.md](evaluation.md) cumplidos, code-critic APPROVE, explicación de JM firmada y commits hechos.
