# 08 · Explicación de los AC (borrador de Claude para que JM lo estudie)

## Visor (`docs/specs/08a-viewer.md`)

**AC-VIEW-01: la página se sirve con pdf.js fijado y llama a la API.**
- `app/main.py`: `app.mount("/viewer", StaticFiles(directory=Path(__file__).parent / "viewer", html=True))` sirve la carpeta `app/viewer/`. `html=True` hace que `/viewer/` devuelva `index.html`.
- El path sale de `__file__` y no del directorio actual, así que funciona arranques desde donde arranques.
- `tests/unit/test_viewer.py` pide `/viewer/` con TestClient y comprueba 200, `text/html`, las dos URL de pdf.js 6.4.299 y `/api/extract`. Antes del `mount` daba 404.

**AC-VIEW-02: las cajas caen sobre los nombres.**
- `index.html`, función `run()`:
  1. manda el PDF y `names` en un `FormData` a `/api/extract`;
  2. con la respuesta, pdf.js abre el mismo archivo;
  3. por cada página: `getPage(n + 1)`, porque pdf.js cuenta desde 1 y la API desde 0;
  4. `getViewport({scale: SCALE})` y un canvas de ese tamaño, sin escalado por CSS.
- `drawBox` pone un `div` absoluto en `x·SCALE, y·SCALE` con tamaño `w·SCALE × h·SCALE`.
- **Por qué basta multiplicar:** la API da puntos con origen arriba a la izquierda sobre la página tal como la dibuja PyMuPDF, y el viewport de pdf.js tiene ese mismo tamaño. Lo comprobé con una página recortada y otra rotada.
- **Verde:** las cajas cuyo nombre aparece en `fuzzy_matches[].extracted_name` (un `Set`).
- **"Page k of n":** dice cuántas páginas hay y en cuál estás.

**AC-VIEW-03: los errores se ven y la página sigue usable.**
- Si la API responde con error, se muestra `detail`: tal cual si es texto (por ejemplo "not a readable PDF"), y con `JSON.stringify` si es la lista de validación de FastAPI (JSON roto). Así nunca sale `[object Object]`.
- Cualquier otro fallo (servidor caído, respuesta que no es JSON, pdf.js que no carga) lo captura `run().catch(...)` y lo escribe en rojo.
- Los nombres se escriben con `textContent`, nunca como HTML, así que un PDF no puede inyectar código.

## CI (`docs/specs/08b-ci.md`)

**AC-CI-01: verde en tu fork.**
- `ci.yml` corre en cada push y PR:
  1. instala Tesseract por apt;
  2. imprime su versión;
  3. `uv sync --locked --extra dev`;
  4. ruff, formato y `pytest -rs -v`.
- `-rs` lista el motivo de cada skip: se ven corriendo OCR y extract e2e, y saltados los de RAG.

**AC-CI-02: el YAML es seguro.**
- Cada action va fijada por SHA de commit, no por tag, porque un tag se puede mover. Son releases de más de 2 semanas: checkout v7.0.1 y setup-uv v10.3.0.
- `permissions: contents: read`: el token del workflow no puede escribir.
- Runner `ubuntu-24.04` fijo, para que la versión de Tesseract no cambie sin aviso.

## Preguntas probables del entrevistador
1. **¿Por qué pdf.js desde una CDN y no un paquete?** Es lo que sugiere el enunciado: una página autocontenida, sin build ni npm. Coste: sin red no hay visor y el import no lleva hash de integridad. Está declarado en DECISIONS.
2. **¿Cómo sabes que la caja cae bien?** Dos pruebas: la geométrica (viewport de pdf.js = `page.rect` de PyMuPDF, también recortada o rotada) y la visual sobre las muestras, con captura.
3. **¿Por qué `--locked`?** Si alguien cambia `pyproject.toml` y no regenera el lock, el CI falla en vez de instalar algo distinto a lo probado.
4. **¿Y si en CI falla el e2e por Tesseract 5.3.4?** El log muestra la versión y la diferencia exacta. Se investiga el OCR antes de tocar el test.

## Página de preguntas (`docs/specs/08c-ask-page.md`)

**AC-ASK-PAGE-01: se sirve y llama al RAG.** `app/viewer/ask.html` está en la misma carpeta que el visor, así que el `mount` existente la sirve sin tocar Python. `tests/unit/test_ask_page.py` comprueba 200, `text/html`, `/api/ingest` y `/api/ask`.

**AC-ASK-PAGE-02: ingestar y preguntar.**
- `post(url, options)` envuelve `fetch`: si la respuesta no es ok, lanza un `Error` con el `detail` legible.
- `ingest()` sube los archivos uno a uno (en secuencia, para no lanzar varios OCR a la vez) y escribe una línea por archivo, con éxito o con error.
- `ask()` muestra "Thinking…", envía `{"question": ...}` y pinta la respuesta.
- `readableSource` convierte `company_memo.pdf:p0:c0` en `company_memo.pdf · page 1 · chunk 0`, porque la API cuenta las páginas desde 0.

**AC-ASK-PAGE-03: abstención y errores.**
- Si `sources` viene vacío, la página dice "No sources (the service abstained)": el servicio no encontró respaldo y no inventa fuentes.
- Un 503 (Ollama cerrado) o un 422 (no es PDF) llegan como `Error(detail)` y `show` los escribe en rojo.

**Pregunta probable:** *¿por qué la página no muestra el texto de las fuentes?* La API solo devuelve IDs, y el contrato está fijo. Mostrar el texto obligaría a añadir un campo o un endpoint, y eso queda fuera de alcance.
