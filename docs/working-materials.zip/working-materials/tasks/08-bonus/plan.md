# 08-bonus · Plan de implementación

Redactado por Claude a petición de JM (2026-10-30), a partir de las specs firmadas `08a-viewer.md` y `08b-ci.md`. Lo aprueba JM.

## Orden (cada commit pasa la verificación por sí solo)
1. `docs(spec): add viewer and CI specs`: las dos specs.
2. `feat(viewer): draw name boxes over the PDF`:
   - test AC-VIEW-01 en rojo;
   - `app/viewer/index.html` y el `mount` en verde;
   - línea en RUNNING.md.

   Después, la revisión manual de JM (AC-VIEW-02 y 03) con captura.
3. `ci: run lint and tests on push`:
   - `.github/workflows/ci.yml` y línea en RUNNING.md;
   - antes, JM crea el fork y añade el remoto;
   - después, JM hace el push y se revisa el log (AC-CI-01).
4. `docs: record viewer and CI decisions`:
   - viñetas en DECISIONS.md (texto exacto aprobado por JM);
   - nodo del visor en el diagrama de DESIGN.md.

## Archivos y funciones
| Archivo | Cambio | AC |
|---|---|---|
| `tests/unit/test_viewer.py` | `test_ac_view_01_page_pins_pdfjs_and_calls_extract`: `GET /viewer/` da 200 `text/html` y contiene las 2 URL de pdf.js 6.4.299 y `/api/extract` | AC-VIEW-01 |
| `app/main.py` | `from pathlib import Path`, `from fastapi.staticfiles import StaticFiles` y `app.mount("/viewer", StaticFiles(directory=Path(__file__).parent / "viewer", html=True), name="viewer")` | AC-VIEW-01 |
| `app/viewer/index.html` | Formulario (PDF y textarea de `names`) → `fetch("/api/extract")` → por página: canvas con pdf.js y `div` absolutos con la caja × `SCALE`; resaltado de coincidencias exactas; tabla de matches; `detail` legible | AC-VIEW-02, 03 |
| `.github/workflows/ci.yml` | Job según la spec 08b: actions fijadas por SHA verificado con `gh api` (solo lectura), releases de ≥ 2 semanas | AC-CI-01, 02 |
| `RUNNING.md` | "Audit viewer: `http://127.0.0.1:8000/viewer/`" y una línea sobre el CI | - |
| `DECISIONS.md` y `DESIGN.md` | CDN sin SRI y sin modo offline; el visor asume `top-left`; CI con runner y actions fijados, Tesseract 5.3.4 en CI frente a 5.4 en local; nodo `viewer` en el diagrama | - |

## Tests (rojo primero)
| Test | AC | Qué falla antes del código |
|---|---|---|
| `test_ac_view_01_page_pins_pdfjs_and_calls_extract` | AC-VIEW-01 | `GET /viewer/` da 404 (no hay mount) |
| Revisión manual con captura | AC-VIEW-02, 03 | - |
| Ejecución en GitHub | AC-CI-01 | - |

## Líneas esperadas y qué no voy a escribir
- **Presupuesto:**
  - `main.py`: +3;
  - `test_viewer.py`: unas 10;
  - `index.html`: ≤ 120 (HTML, CSS y JS juntos);
  - `ci.yml`: unas 25.
- **No voy a escribir:**
  - build de JS, npm, frameworks ni Playwright;
  - soporte de `bottom-left` en el visor;
  - nitidez HiDPI;
  - matriz de SO o de versiones de Python;
  - cobertura con umbral;
  - Docker.
- `app/` sube 3 sentencias `ast` (357 → 360). El HTML no cuenta.

## Agentes
- implementer (sonnet): commits 2 y 3.
- code-critic (opus): en paralelo, sobre cada diff y su spec. Máximo 2 rondas.
- Claude: arbitra y prepara `/commit-handoff`.
- JM:
  - revisión manual del visor;
  - fork, remoto y push;
  - aprobación del texto de DECISIONS;
  - explicación de cada AC.

## Riesgos y cómo los verifico
- **Desalineación en el navegador:** la captura de AC-VIEW-02 con `company_memo.pdf` (8 cajas) y `meeting_minutes.pdf` (2 páginas).
- **El import ESM desde cdnjs no carga en tu navegador:** se ve en la consola durante AC-VIEW-02. Si falla, probar `pdf.mjs` sin minificar antes de cambiar de enfoque.
- **Tesseract 5.3.4 rompe `test_extract_e2e` en CI:** `tesseract --version` en el log; se compara la salida antes de tocar el test.
- **`--locked` falla en CI:** indicaría que el lock no está sincronizado; se arregla con `uv lock` en local, no quitando el flag.
- **Fork:** sin fork no hay AC-CI-01. El commit 3 puede hacerse antes del fork, pero queda abierto hasta ver el verde.
