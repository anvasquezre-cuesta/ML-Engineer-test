# 08-bonus · Research

## Fuentes y decisiones tomadas
- README:102-111 y 152-155. Docker es bonus: "`docker compose up` levanta la app **y sus dependencias** y `GET /health` pasa".
- [V] Diseño mínimo previsto: `research/05-architecture-infra.md` §1.8. Builder `uv` multi-stage, runtime `python:3.12-slim`, `tesseract-ocr` por apt, usuario no root, `HEALTHCHECK` a `/health`, modelos descargados en el build y torch CPU.
- [V] `research/14-revision-plan.md`: R2 (Chroma `HttpClient` con reintentos), R8 (`/health` = liveness) y R9 (Ollama del host vía `host.docker.internal` + `extra_hosts`).

## Docker por tarea (registro vivo, desde 2026-10-29)
Cada tarea anota aquí lo que le exige al contenedor. Así el Dockerfile sale de una lista y no de memoria. No se implementa nada hasta 08; en cada tarea solo se cuida que su config no lo impida.

| Tarea | Qué exige al contenedor | Ya preparado en código | Falta en 08 |
|---|---|---|---|
| 01-fuzzy | nada (rapidfuzz trae wheel) | - | - |
| 02-ner | `en_core_web_sm` como wheel en `pyproject` (sin `spacy download`) | sí: `[tool.uv.sources]` | - |
| 03-ocr-boxes | binario `tesseract` 5 + `eng` en el PATH | sí: se resuelve por PATH, sin `TESSERACT_CMD` | `apt-get install tesseract-ocr` y versión fijada |
| 04-extract-api | `/health`; log JSON a stdout | sí | `HEALTHCHECK` (python urllib, sin curl) |
| 05-rag-ingest | torch CPU por defecto, GPU opcional (ver "CPU y GPU"); MiniLM descargado en el build (si no, el primer arranque descarga y falla offline); ruta de Chroma persistente en un volumen; no descargar el ONNX de Chroma (`embedding_function=None`) | por hacer en 05: `chroma_path` y `embedding_model` en config | `HF_HOME` fijo + paso de descarga del modelo en el build; volumen `chroma-data`; decidir Chroma embebido o servicio `chromadb/chroma` (D-RAG-3) |
| 06-rag-ask | LLM externo: Ollama en el host | por hacer en 06: `llm_base_url` en config | `extra_hosts: host.docker.internal:host-gateway`; bloque OpenAI comentado en `.env.example` |

## CPU y GPU (pedido de Jeison, 2026-10-29)
- **Quién usa GPU:**
  - Tesseract: solo CPU.
  - spaCy `sm`: CPU.
  - MiniLM: CPU, unos 0.3 s por 50 chunks (auditoría de 05); la GPU apenas acelera aquí.
  - El LLM (Ollama, en la RTX 4060 del host): es el único que aprovecha la GPU, y ya la usa fuera del contenedor.
- **Adaptador en el código (05):** `embedding_device: Literal["cpu", "cuda", "auto"]` en config; `auto` elige `cuda` si `torch.cuda.is_available()`. Son 1 o 2 líneas en la carga del modelo, y el resto del código no se entera. El Protocol `Embedder` permite cambiar el backend (fastembed u otro modelo) sin tocar los servicios.
- **Adaptador en el empaquetado (08):** hoy `torch` está fijado al índice `pytorch-cpu`. Para GPU harían falta dos extras de uv en conflicto (`cpu` y `cu12x`), cada uno con su índice (`[tool.uv.sources] torch = [{index=..., extra="cpu"}, {index=..., extra="gpu"}]` + `[tool.uv] conflicts`) [NV: el package-auditor tiene que probarlo]. En Docker: `ARG TORCH_VARIANT=cpu`, base `nvidia/cuda` solo para gpu, y en compose un perfil `gpu` con `deploy.resources.reservations.devices` (driver nvidia) [NV]. La imagen gpu pasa de 5 GB.
- **Propuesta:** CPU por defecto (lo que corre el evaluador). `auto` en config ya en 05. La variante GPU de empaquetado entra en 08 solo si hay tiempo; si no, se documenta en DESIGN.md como extensión.

## "Cualquiera debe poder correr todo" y entorno productivo (Jeison, 2026-10-29)
Quién tiene que poder correrlo y qué le hace falta:

| Entorno | Cómo arranca | Qué puede fallar | Mitigación |
|---|---|---|---|
| Evaluador local (Linux, macOS o Windows, sin GPU) | `uv sync` + `uv run uvicorn` | Tesseract no instalado; primera descarga de MiniLM y spaCy sin red; torch CPU sin wheel para su plataforma | README/DESIGN con un paso por sistema operativo; `/health` informa si falta Tesseract; mensajes 503 claros; verificar en el lock los wheels de mac arm64/x86 y Linux [NV] |
| Evaluador sin Ollama | igual | `/api/ask` sin LLM | `/api/ingest` y `/api/extract` no dependen del LLM; `/api/ask` → 503 con un mensaje que dice cómo configurar `LLM_BASE_URL` (Ollama u OpenAI) |
| Docker CPU | `docker compose up` | imagen enorme; descarga de modelos al arrancar | torch CPU; modelos dentro de la imagen; `HEALTHCHECK` |
| Docker GPU (opcional) | `docker compose --profile gpu up` | sin driver nvidia | perfil aparte; CPU sigue siendo el defecto |
| CI (GitHub Actions) | ruff + pytest unitario | modelos o red en los tests | unitarios con fakes; e2e con `skipif` |

Riesgos de producción que hay que tener presentes en 05 y 06 (y explicar en DESIGN.md):
- **Chroma embebido:** [V, medido 2026-10-29] con varios procesos sobre la misma ruta no se corrompe nada, pero el índice vectorial de cada proceso queda desactualizado: `count` ve los chunks nuevos, `query` no. En producción va un único worker o Chroma/Qdrant como servicio (`HttpClient`). Es la razón técnica para la "DB aislada" del bonus.
- **Memoria y arranque:** torch + spaCy + MiniLM ocupan aproximadamente 1-1.5 GB de RAM y tardan unos segundos en el primer request [NV: medir]. Los modelos se cargan una vez (lifespan o `lru_cache`); readiness ≠ liveness (R8).
- **Ingesta síncrona:** el OCR tarda unos 4 s por PDF de 3 páginas. A volumen alto (1000+ PDF/h) la ingesta pasa a una cola con workers (DESIGN.md, tarea 07).
- **Versión del modelo de embeddings** guardada en la metadata de la colección: si cambia el modelo, hay que reindexar, y no se mezclan vectores.
- **Config:** todo por variables de entorno (`app/config.py`); nada hardcodeado; `.env.example` completo.

Consecuencia para la prioridad: la frase "cualquiera debe poder correr todo" sube el valor de Docker (fija Tesseract, modelos y versiones). Jeison lo decidió el 2026-10-29: Docker > CI > visor.

## `.dockerignore` (borrador, se ajusta en 08)
`.venv/`, `__pycache__/`, `.pytest_cache/`, `.ruff_cache/`, `.git/`, `.env`, `.env.*` (`!.env.example`), `notebooks/`, `tests/`, `eval/`, `sample_pdfs/`, `docs/`, `*.ipynb`.

Pendiente de decidir: si el e2e corre dentro de la imagen, `tests/` y `sample_pdfs/` no se excluyen.

## Huecos (falta investigar)
- Tamaño real de la imagen con torch CPU + spaCy + chromadb.
- Si `uv sync --frozen` respeta el índice CPU de torch en Linux; probarlo en el build.
- Chroma como servicio: versión de la imagen `chromadb/chroma` compatible con el cliente 1.5.9.

## Decisiones abiertas
- Cuáles bonus entran, según la fecha de entrega (orden: **Docker > CI > visor**, decidido por Jeison el 2026-10-29).
- Compose con Chroma embebido (un servicio y un volumen) o separado ("DB aislada" del README; obliga a `HttpClient` + reintentos).

## Decisión de alcance (Jeison, 2026-10-30): visor + CI
Reemplaza el orden "Docker > CI > visor" del 2026-10-29, después de releer el enunciado:
- **Visor:** README:106-111, "strong positive". Una sola página autocontenida con JS y pdf.js, como sugiere el enunciado, que llama a `/api/extract` y superpone las cajas. Streamlit se descartó para no desviarse del ejemplo del README.
- **CI:** el README no lo nombra; entra como "other production hardening" (README:155). Es barato.
- **Docker:** fuera por ahora. Las notas de arriba quedan para cuando haya tiempo.

## Huecos del visor y del CI
1. **pdf.js:**
   - versión exacta en cdnjs, con más de 2 semanas;
   - build ESM (`.mjs`) y `workerSrc`;
   - API `getDocument`, `getPage`, `getViewport({scale})` y `render`.
2. **Coordenadas:** las cajas llegan en puntos con origen arriba a la izquierda (`BBOX_ORIGIN=top-left`). En pdf.js, ¿el píxel en el canvas es punto × scale, con el mismo origen? ¿Qué pasa con páginas con `rotate` o con mediabox desplazado?
3. **Servirlo:** `StaticFiles` de Starlette en `/viewer`, en el mismo origen (sin CORS). ¿Necesita alguna dependencia extra? ¿Cómo se monta sin engordar `main.py`? ¿Cómo se prueba sin navegador?
4. **CI:**
   - `astral-sh/setup-uv` con versión fijada y caché;
   - `tesseract-ocr` por apt en `ubuntu-latest`;
   - qué tests corren y cuáles se saltan;
   - si un PR desde un fork ejecuta Actions en el repo destino.

## Resultados (2026-10-30)
Ver `reviews/2026-10-30-viewer-research.md` y `reviews/2026-10-30-ci-research.md`.

### Visor
- pdf.js 6.4.299 desde cdnjs, como ESM.
- Caja en canvas = caja × scale (verificado con cropbox desplazado y con rotación).
- `StaticFiles` en `/viewer`, sin dependencias nuevas.
- Test con TestClient y revisión visual de JM.

### CI
- `ubuntu-24.04` fijo, actions fijadas por SHA a una release de ≥ 2 semanas, `permissions: contents: read`.
- Tesseract por apt (5.3.4).
- `uv sync --locked --extra dev`, luego ruff y pytest.
- RAG se salta solo; OCR y extract e2e corren.

### Riesgos
- Tesseract 5.3.4 en CI frente a 5.4 en local: `test_extract_e2e` compara nombres exactos. Se prueba en el primer push; no se afloja de antemano.
- El verde se ve en el fork de JM. Hoy solo existe el remoto `upstream`, con push desactivado: JM crea el fork y añade el remoto.
