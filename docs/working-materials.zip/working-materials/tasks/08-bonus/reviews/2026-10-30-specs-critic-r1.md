# 08 · code-critic sobre las specs 07-viewer y 08-ci (opus, 2026-10-30): CHANGES en las dos, todo aplicado

El crítico comprobó y dio por buenos tres puntos:
- el `mount` son 1 línea y 2 imports;
- la fórmula de la caja cuadra con `ocr_service.py:50-60`;
- `--locked` funciona en Linux: el lock trae torch+cpu manylinux, sin nvidia ni triton, y spaCy es `py3-none-any`.

## 07-viewer
1. **Aplicado:** contrato del layout. Cada página es un `div` relativo, el tamaño CSS del canvas es el del viewport sin escalado y `SCALE` es una constante. Así no se desalinean cajas y canvas.
2. **Aplicado:** cuando `detail` no es texto (la lista de validación de FastAPI) se muestra con `JSON.stringify`. AC-VIEW-03 incluye el JSON inválido.
3. **Aplicado:** quitado el assert de la redirección de `/viewer`, que probaba Starlette, no nuestro código.
4. **Aplicado:** el resaltado es una "coincidencia exacta con `name`" (fuzzy devuelve la primera grafía de cada nombre).
5. **Aplicado:** la CDN como trade-off (sin red no hay visor y no hay SRI) va a DECISIONS, en la tarea 4.

## 08-ci
1. **Aplicado:** `apt-get update` antes del install.
2. **Aplicado:** `pytest -rs -v`, para que AC-CI-01 se pueda verificar en el log.
3. **Aplicado:** paso `tesseract --version`. El paquete trae `eng`.
4. **Aplicado:** `concurrency.group` por workflow y ref.
