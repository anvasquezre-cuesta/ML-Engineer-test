# 08 · Revisión manual del visor (JM, 2026-10-30)

- **AC-VIEW-02:** el memo da 8 cajas alineadas sobre los nombres. Captura en `2026-10-30-viewer-memo.png`, tomada antes del título de página.
- **meeting_minutes.pdf:** en el primer intento JM no vio la página 2. Claude comprobó que pdf.js lee 2 páginas y que la API da 14 + 10 cajas, así que el dato era correcto y la página quedaba debajo, fuera de pantalla. Se añadió el título "Page k of n". En el segundo intento salen las dos páginas.
- **Nota:** la primera vez se abrió `/` en lugar de `/viewer/` y dio 404. RUNNING.md ya indica la URL correcta. Se decidió no añadir una redirección.
- **AC-VIEW-03:** pendiente de confirmar por JM (PNG falso y JSON inválido).
