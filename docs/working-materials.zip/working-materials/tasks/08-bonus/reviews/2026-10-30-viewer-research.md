# 08 · Research del visor (package-auditor, sonnet, 2026-10-30)

- **Scripts:** `scratchpad/viewer08/`. pdfjs-dist 6.4.299 se instaló solo ahí.
- Claude volvió a correr geom.py y t.mjs (con `../tricky.pdf`) y los resultados coinciden.

## pdf.js
- 6.4.299 (2026-10-03, 27 días), Apache-2.0 [V].
- URLs con 200, JS y CORS `*` [V]:
  - `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/6.4.299/pdf.min.mjs`
  - `https://cdnjs.cloudflare.com/ajax/libs/pdf.js/6.4.299/pdf.worker.min.mjs`
- API [V] (helloworld oficial y `api.d.ts`):
  - `GlobalWorkerOptions.workerSrc`;
  - `getDocument({data}).promise`;
  - `getPage(n)`, con n desde 1;
  - `getViewport({scale})`;
  - `render({canvasContext, viewport}).promise`.
- `<script type="module">` con import desde cdnjs: [NV] en navegador. El worker no funciona con `file://`, así que la página se sirve desde la app.

## Geometría
- Las 3 muestras tienen 5 páginas, todas con rotación 0 y rect = mediabox = cropbox = (0, 0, 612, 792) [V].
- PDF de prueba con cropbox desplazado y una página rotada 90° [V]:
  - `page.rect` de PyMuPDF da 400×400 y 792×612;
  - el viewport de pdf.js con scale 2 da 800×800 y 1584×1224.

  Son las mismas dimensiones. **Caja en canvas = `x·s, y·s, w·s, h·s`** con `BBOX_ORIGIN=top-left`.
- `convertToViewportRectangle` no existe en 6.4.299 [V].
- `bottom-left` no se soporta en el visor (fuera de alcance; se documenta).

## Servir la página
- fastapi 0.162.0, starlette 1.10.0; no hace falta `aiofiles` [V].
- `app.mount("/viewer", StaticFiles(directory=d, html=True))` [V]:
  - `/viewer/` da 200 text/html;
  - `/viewer` redirige con 307;
  - una ruta inexistente da 404;
  - si el directorio no existe, falla al importar (`RuntimeError`).
- Path con `Path(__file__)`, no con el cwd.

## Tests sin navegador
- TestClient: 200 y el HTML contiene la URL fijada de pdf.js y `/api/extract` (unas 10 líneas).
- Node para una función pura: posible, pero añade maquinaria. Playwright: no (más de 100 MB y la CDN sin red).
