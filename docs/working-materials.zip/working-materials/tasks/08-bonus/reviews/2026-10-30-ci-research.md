# 08 · Research de CI (literature-researcher, opus, 2026-10-30)

Ninguna página tenía instrucciones dirigidas a una IA.

## 1. setup-uv y uv
- **Versión de setup-uv:** la última mayor es v10. La v10.3.3 (`68559e9…`, "Latest") salió el 28-oct [V] https://github.com/astral-sh/setup-uv/releases. La guía de uv todavía muestra v9.0.0 (`c771a70e…`) [V] https://docs.astral.sh/uv/guides/integration/github/.
  **Nota de Claude:** la v10.3.3 tiene solo 2 días. Se fija una release de ≥ 2 semanas por SHA; JM elige cuál.
- **Seguridad:** GitHub recomienda fijar las actions a un SHA de commit y dar al GITHUB_TOKEN el mínimo [V] https://docs.github.com/en/actions/reference/security/secure-use.
- **Caché:** `enable-cache` vale `auto` (activo en runners de GitHub). El glob por defecto ya incluye `uv.lock` y `pyproject.toml` [V] README de setup-uv.
- **Python:** sin el input `python-version`, uv lee `.python-version` [V].
- **Sincronizar:** `uv sync --locked --extra dev`. `--locked` falla si el lock no coincide con `pyproject.toml`; `--frozen` no lo comprueba [V] https://docs.astral.sh/uv/concepts/projects/sync/.

## 2. Tesseract
- No viene en la imagen ubuntu-24.04 [V] runner-images Ubuntu2404-Readme. Se instala con `apt-get install tesseract-ocr`, que en noble da la 5.3.4 [V] launchpad. Que incluya `eng` es [NV].
- **Riesgo:** `test_extract_e2e.py:45-60` compara la lista exacta de nombres, y en local se usa la 5.4. El OCR podría salir distinto con 5.3.4. Hay que probarlo.

## 3. Qué tests se saltan en CI
- RAG ingest y ask se saltan: necesitan MiniLM en la caché de HF, y ask además Ollama.
- OCR y extract e2e corren, porque hay Tesseract.
- spaCy llega como wheel en `uv sync`, sin red al correr los tests.

## 4. Forks
- Los PRs de contribuidores primerizos piden aprobación en upstream y no tienen acceso a secrets [V].
- El verde fiable se ve con el `push` al fork. Que haya que activar Actions en el fork es [NV].

## 5. Otros mínimos
- `concurrency` con `cancel-in-progress` [V].
- `timeout-minutes`: el valor por defecto de 360 es [NV].

## Esqueleto (propuesta, sin probar)
Usa `ubuntu-24.04` fijo en lugar de `latest`, para que la versión de Tesseract no cambie sin aviso, y `permissions: contents: read`. Pasos: checkout, setup-uv, apt tesseract-ocr, `uv sync --locked --extra dev`, ruff check, ruff format --check, pytest.
