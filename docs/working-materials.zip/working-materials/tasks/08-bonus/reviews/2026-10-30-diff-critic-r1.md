# 08 · code-critic sobre el diff del visor y del CI (opus, 2026-10-30): CHANGES (1), aplicado

Comprobado por el crítico:
- verify pasa;
- los SHAs coinciden con `gh api` (checkout v7.0.1 `3d3c42e5…`, setup-uv v10.3.0 `1c37ad07…`);
- XSS: el único `innerHTML` es una cadena fija y los nombres van por `textContent`;
- layout, cajas × SCALE, resaltado exacto, `detail` legible y nota top-left cumplen la spec;
- el test cubre AC-VIEW-01 literalmente;
- el `mount` va después de los routers;
- `ci.yml` cumple 08b y AC-CI-02;
- RUNNING.md es correcto.

Hallazgos:
1. **Aplicado:** `index.html:84`. Un fallo dentro de `run()` (respuesta que no es JSON en un 500, servidor caído, error de pdf.js o de la CDN) quedaba como promesa sin manejar y la página en blanco. Ahora `run().catch(e => error.textContent = String(e))`, con +0 líneas netas.
2. **No aplicado (opcional):** el doble clic duplica las páginas. Costaba 3 líneas; el crítico lo acepta sin el arreglo.
