# 08-bonus · Evaluación (visor + CI)

| # | Qué | Cómo | Esperado |
|---|---|---|---|
| V1 | Página servida | TestClient `GET /viewer/` | 200 text/html; contiene la URL fijada de pdf.js 6.4.299 y `/api/extract` |
| V2 | Cajas sobre los nombres | JM abre `/viewer/` con `company_memo.pdf` y la lista de nombres del test e2e (`test_extract_e2e.py:18-24`) | 8 cajas sobre los 8 nombres de la página 0; Robert Chen y Maria Garcia, resaltados como coincidencias |
| V3 | Multipágina | `meeting_minutes.pdf` | Cajas en las páginas 0 y 1, cada una en su página |
| V4 | Error visible | Subir un PNG renombrado a .pdf | Se muestra el `detail` del 422, sin romper la página |
| V5 | Sin regresión | `verify.ps1` | ruff y pytest pasan |
| C1 | Workflow | Push al fork | Job verde: ruff, formato y pytest; OCR y extract e2e corren, RAG se salta |
| C2 | Seguridad | Lectura del YAML | Actions fijadas por SHA a releases de ≥ 2 semanas; `permissions: contents: read`; runner fijo |
| G | Comunes | code-critic, explicación de JM, `/commit-handoff` | APPROVE, firmada, commits hechos |
