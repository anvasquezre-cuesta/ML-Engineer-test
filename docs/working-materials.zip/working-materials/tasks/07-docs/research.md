# 07-docs · Research

## Qué pide el enunciado
README:112-115, `DESIGN.md` (<= 3 páginas) con 5 temas:
1. vista de componentes y de secuencia;
2. elecciones tecnológicas y trade-offs;
3. cómo escalar a 1000+ PDFs/hora;
4. modos de fallo y mitigaciones;
5. ruteo entre modelos por complejidad de la consulta (solo diseño).

README:118 también pide justificar en DESIGN.md cualquier desviación del stack sugerido: Ollama/qwen en lugar de un endpoint en la nube (el cliente sigue siendo OpenAI-compatible), y NER con spaCy más reglas.

## Lo que ya sabemos, por tema (fuentes)

### 1. Componentes y secuencia
- Código: `app/main.py` (app y lifespan), `app/dependencies.py` (DI), `app/api/{extract,rag}.py` (routers delgados), `app/services/*` (11 módulos, 922 líneas en total contando `app/`), `app/log.py` (logging estructurado), `app/config.py`.
- Tres secuencias: extract (validar, OCR, NER, cajas, fuzzy), ingest (OCR, chunk, embed, Chroma) y ask (embed, top-k, puerta `MIN_SCORE`, LLM o abstención, `sources` en código).
- Formato propuesto: Mermaid dentro del markdown. GitHub lo renderiza, es texto y se puede revisar en el diff.

### 2. Tecnología y trade-offs
- Ya está razonado en `DECISIONS.md` (una sección por tarea, 4326 palabras). DESIGN.md resume en una tabla (componente, elección, alternativa, por qué) y enlaza a la sección de DECISIONS. Así no se duplica y cabe en 3 páginas.

### 3. Escalado a 1000+ PDF/h
- 1000 PDF/h = 1 PDF cada 3.6 s.
- `tasks/08-bonus/research.md:44`: el OCR tarda unos 4 s por PDF de 3 páginas. Con un solo proceso no llega. **Este número no tiene salida medida por etapa (ver huecos).**
- `research/05-architecture-infra.md:61`: S3 + cola + workers de OCR, Postgres para estado e idempotencia por hash, y Qdrant o pgvector.
- `research/03-rag-stack.md:23`: cuándo se justifican pgvector o Qdrant.
- El `doc_id` ya es `sha256` del contenido (DECISIONS, RAG ingestion), lo que da idempotencia gratis en una cola con reintentos.
- Restricción medida: Chroma embebido exige 1 worker. Con varios procesos, `count` ve los chunks nuevos pero `query` devuelve el índice viejo, y falla en silencio (`DECISIONS-LOG` 2026-10-29; `tasks/08-bonus/research.md:42`).
- El contrato de `/api/extract` es síncrono y no se toca. Un endpoint asíncrono (202 + job id) se describe como extensión.

### 4. Modos de fallo
- Tabla `ERROR_STATUS` (`app/main.py:28-36`):
  - `InvalidPdfError` → 422: no es PDF por contenido, está cifrado o es ilegible (`ocr_service.py:72,74,79`);
  - `DocumentTooLargeError` → 413: por tamaño (`dependencies.py:33`) o por páginas (`ocr_service.py:76`);
  - `OcrEngineError`, `VectorStoreError` y `LLMUnavailableError` → 503;
  - `LLMTimeoutError` → 504;
  - `LLMBadResponseError` → 502.

  **No hay 415**: un archivo que no es PDF da 422. Verificado por Claude en el código.
- Lo que debe aparecer, según `research/24`:
  - peor caso de latencia del LLM, ~184 s con timeout en todos los intentos, ocupando un hilo (`tasks/06-rag-ask/plan.md:242`);
  - 1 worker con Chroma embebido;
  - temperatura 0 no garantiza el mismo texto (q03, NB05b);
  - límites de la inyección: 0/475 respuestas con la palabra del atacante y 6 abstenciones indebidas, medido solo con los ataques probados.
- Otros: timeout de OCR (`OCR_TIMEOUT_S`), nombres en mayúsculas descartados (`NER_DROP_ALL_CAPS`), primera carga del modelo (~50 s).
- Origen de ejes (R10, `research/14`): la fórmula `y_pdf = page_height - y - height` tiene que estar visible.

### 5. Ruteo de modelos
- Borrador en `research/03-rag-stack.md:21`: un clasificador barato (reglas o features) manda las preguntas simples a un modelo local pequeño y las complejas a uno grande, con fallback, y se mide con el set de preguntas. **Falta la cita [V].**
- Señal que ya existe en el código: el score del top1 y la puerta `MIN_SCORE` sirven como feature de "dificultad".

### Reglas de los entregables
- Idioma: inglés, como DECISIONS.md.
- Observabilidad (OpenTelemetry, Langfuse) y evaluación (RAGAS, cross-encoder, Self-RAG, CRAG) se mencionan solo como siguiente paso (`research/05:43`, `tasks/06-rag-ask/research.md:51`).

## Resultados del research (2026-10-29)
- **Literatura:** `reviews/2026-10-29-literature-scaling-routing.md`.
  - Ruteo: FrugalGPT (cascada con juez), RouteLLM (falla fuera de distribución) e Hybrid LLM (20 % menos llamadas, ≤1 % de pérdida). Aplica el umbral con fallback usando el score del top1. No aplica entrenar un router.
  - Escalado:
    - Tesseract: FAQ, un proceso por núcleo con `OMP_THREAD_LIMIT=1`;
    - colas: SQS at-least-once con DLQ; Celery con tareas idempotentes y `acks_late` + `prefetch=1`;
    - threadpool: AnyIO, 40 hilos;
    - Qdrant: el modo local es para desarrollo.
- **Tiempos:** `reviews/2026-10-29-timings-claims.md`.
  - El OCR cuesta ~0.8 s por página y es más del 95 % del tiempo.
  - Extract: 0.8 s con 1 página y 1.6 s con 2.
  - Proceso en serie: ~4500 páginas por hora.
  - El "4 s por PDF de 3 páginas" de 08 era una estimación: las muestras tienen 1 y 2 páginas, 5 en total.
- **Peor caso de `/api/ask`:** 3 × 60 s + esperas de 1.5 a 3.5 s ≈ 183.5 s, que cuadra con ~184 s.

## Huecos (cerrados salvo verificación de citas)
1. **Literatura con cita [V]:**
   - escalado de pipelines de OCR por lotes (cola, workers, batching, backpressure);
   - ruteo por complejidad (candidatos a verificar: FrugalGPT, Chen et al. 2023; RouteLLM, Ong et al. 2024).
2. **Tiempos medidos por etapa** (OCR, NER, cajas y embeddings por página; extract e ingest de punta a punta, p50/p95) sobre las 3 muestras, importando de `app/`. Sin esto, la cuenta de workers para 1000 PDF/h no se puede defender. La revisión del NB05b ya marcó que faltaban p50/p95 de ingest.
3. **Veracidad:** inventario de afirmaciones sobre el código (códigos HTTP, defaults, nombres) comprobadas contra `app/`.

## Decisiones tomadas (JM, 2026-10-29: "apruebo todo, lo más recomendado")
- **D-DOC-1:** `RUNNING.md` corto en la raíz del repo, con instalación, arranque, ejemplos curl y tests. El README del repo no se toca.
- **D-DOC-2:** 07 va ahora. Si 08 añade Docker o Chroma servidor, DESIGN.md recibe un commit de actualización.
- **D-DOC-3:** sin filas nuevas en DECISIONS.md. DESIGN enlaza a sus secciones.
- **D-DOC-4:** diagramas en Mermaid.
- Gates G1-G12 aprobados.

## Abierto
- Fecha de entrega, que decide cuánto de 08 entra.
