# 07-docs · Evaluación

07 no lleva spec de ACs: el checklist de esta tabla hace de spec. JM lo aprueba antes de redactar.

| # | Qué | Cómo | Esperado |
|---|---|---|---|
| G1 | Cobertura del enunciado | Checklist README:112-115 | Los 5 temas, cada uno con su encabezado |
| G2 | Lo obligatorio de `research/24` | Checklist | Aparecen el peor caso ~184 s, 1 worker con Chroma embebido, T=0 sin garantía de mismo texto y los límites de la inyección con sus números |
| G3 | Ejes | Grep | La fórmula `y_pdf = page_height - y - height` y `BBOX_ORIGIN` están presentes (R10) |
| G4 | Desviaciones del stack justificadas | Checklist README:118 | Ollama/qwen y spaCy + reglas con su por qué |
| G5 | Veracidad | code-critic (sin conclusiones de Claude) + inventario de afirmaciones | 0 afirmaciones que contradigan `app/`, `config.py` o `ERROR_STATUS` |
| G6 | Números trazables | Cada número apunta a un notebook, artefacto o DECISIONS | 0 números sin fuente; la cuenta de escalado usa tiempos medidos (hueco 2), no estimados |
| G7 | Fuentes | Revisión de citas | Solo fuentes primarias [V] |
| G8 | Longitud | `wc -w` sin bloques de código ni Mermaid | <= 1400 palabras de prosa (unas 3 páginas A4 con 2 diagramas) |
| G9 | Sin duplicar DECISIONS | Lectura | DESIGN resume y enlaza; ningún párrafo copiado |
| G10 | Diagramas | Vista previa de Markdown con Mermaid (VS Code o GitHub) | Renderizan sin error |
| G11 | Cómo correr (si D-DOC-1 lo incluye) | El assistant sigue los pasos en un clon limpio dentro del scratchpad | `GET /health` responde ok y `verify.ps1` pasa |
| G12 | Explicación | JM explica cada sección de vuelta | Firmada |

Gates comunes: `research/19-plan-implementacion.md`. Para docs, "tests en rojo" se sustituye por G1-G11.
