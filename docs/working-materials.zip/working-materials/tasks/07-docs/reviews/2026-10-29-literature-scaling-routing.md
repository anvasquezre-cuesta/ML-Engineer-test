# 07 · Literatura: escalado y ruteo (literature-researcher, opus, 2026-10-29)

Lo guardó Claude porque el subagente no tiene Write. Ninguna página tenía instrucciones dirigidas a una IA. Pendiente: Claude comprueba las citas clave antes de usarlas en DESIGN.md.

## 1. Ruteo por complejidad
- **FrugalGPT** (Chen, Zaharia, Zou; arXiv 2305.05176, preprint). Propone una cascada:
  - se pregunta primero a un modelo barato;
  - su respuesta se acepta si un juez DistilBERT le da un puntaje mayor que el umbral; si no, se pasa al siguiente modelo.

  La lista de modelos y los umbrales se aprenden con datos etiquetados (Sec. 3 y 4). En la Tabla 3 iguala a GPT-4 con un 98,3 % menos de costo en HEADLINES y un 73,3 % menos en OVERRULING. Sec. 5: "we need some labeled examples". [V] https://arxiv.org/html/2305.05176 (v1)
- **RouteLLM** (Ong et al. 2024; arXiv 2406.18665). Elige entre un modelo fuerte y uno débil (GPT-4 frente a Mixtral) con 4 routers:
  - SW ranking;
  - factorización de matrices;
  - BERT;
  - Llama-3-8B.

  Los routers se entrenan con 65k pares de preferencias de Chatbot Arena (Sec. 4.2 y 5). Ahorra hasta 3,66x en MT Bench, pero solo 1,4-1,5x en MMLU y GSM8K (Tabla 6). Entrenados solo con Arena, quedan "close to random" fuera de distribución (Sec. 5.1). [V] https://arxiv.org/html/2406.18665v4
- **Hybrid LLM** (Ding et al.; arXiv 2404.14618, "Accepted to ICLR 2024"). Un DeBERTa-v3-large predice si el modelo pequeño responderá igual de bien que el grande, con un umbral ajustable. Ahorra 20 % de llamadas al grande perdiendo ≤1 % de calidad (Sec. 4.2 y Tabla 1). El router tarda 0,036 s por consulta (Tabla 2). [V] https://arxiv.org/html/2404.14618
- **Qué aplica al proyecto:**
  - sí: el umbral con fallback y la cascada local → nube, usando como señal el score del top1;
  - no: entrenar un router. Con 26 preguntas no hay datos, y RouteLLM muestra que falla fuera de distribución.

  Propuesta: reglas simples, y medir en las 26 preguntas la fracción enviada a la nube y la exactitud de cada rama.

## 2. Escalado
- **(a) Tesseract.** Usa hasta 4 hilos por página. La FAQ recomienda "running one Tesseract process per CPU core" con `OMP_THREAD_LIMIT=1`. [V] https://tesseract-ocr.github.io/tessdoc/FAQ.html ("Can I increase speed of OCR?")
- **(b) Cola y workers.**
  - SQS entrega cada mensaje al menos una vez. El visibility timeout es de 30 s por defecto y como máximo 12 h, y los fallos persistentes van a una DLQ. [V] https://docs.aws.amazon.com/AWSSimpleQueueService/latest/SQSDeveloperGuide/sqs-visibility-timeout.html
  - Celery pide tareas idempotentes. [V] https://docs.celeryq.dev/en/stable/userguide/tasks.html
  - Para tareas largas, `task_acks_late=True` con `worker_prefetch_multiplier=1` hace que cada worker reserve una sola tarea a la vez, lo que da backpressure. [V] https://docs.celeryq.dev/en/stable/userguide/optimizing.html
  - Nuestro `doc_id` sha256 cubre la idempotencia.
- **(c) FastAPI.** Un endpoint `def` corre "in an external threadpool" [V] https://fastapi.tiangolo.com/async/. Esa página no da el número de hilos. AnyIO fija "maximum of 40 threads" [V] https://anyio.readthedocs.io/en/stable/threads.html. Que Starlette use ese limitador es [NV].
- **(d) Base vectorial.**
  - Qdrant: el modo local "is useful for development, prototyping and testing… switch to server mode". [V] https://github.com/qdrant/qdrant-client
  - Chroma documenta el modo cliente-servidor [V] https://docs.trychroma.com/guides/deploy/client-server-mode, pero no dice nada de concurrencia ni de varios procesos. Para eso se cita nuestra medición, no a Chroma.

## 3. Capacidad
- La página oficial de benchmarks da 1,96-6,2 por imagen para Tesseract 5.0.1 en un i7-10750H (6 núcleos), con el promedio de 15 corridas sobre una sola imagen. No indica unidades, DPI ni número de hilos. [V] https://tesseract-ocr.github.io/tessdoc/Benchmarks.html
- No sirve para dimensionar. Hay que medir p50/p95 por página a 300 DPI, la resolución que recomienda Tesseract ([V] https://tesseract-ocr.github.io/tessdoc/ImproveQuality.html). Fórmula: workers ≥ (s por PDF / 3,6 s) × margen.

## Comprobación de citas (web-fetch, 2026-10-29): 9 URL abiertas
- **Tesseract FAQ: DIFERENTE.** Solo dice "uses up to four CPU threads while processing a page" y "To disable multithreading, use OMP_THREAD_LIMIT=1". **No recomienda un proceso por núcleo.** DESIGN no se lo atribuye: el "un proceso por núcleo" se apoya en nuestra medición (1 hilo).
- **AnyIO, 40 hilos: CONFIRMADO.**
- **FastAPI, threadpool: CONFIRMADO.**
- **RouteLLM: CONFIRMADO** "close to random" (Sec. 5.1); el 3.66x está en la Sec. 5.4.
- **Hybrid LLM: CONFIRMADO** "up to 40% fewer calls… no drop in response quality" (abstract). El 20 % / ≤1 % solo aparece en un resumen, no textual. "ICLR 2024" no aparece en la página; no se cita.
- **FrugalGPT: CONFIRMADO** (cascada con scoring y umbral; "up to 98% cost reduction").
- **SQS: CONFIRMADO** (30 s por defecto, máximo 12 h, at-least-once).
- **Celery: CONFIRMADO.** Reserva una tarea por proceso worker, no por worker, y la página pide tareas idempotentes.
- **Qdrant: DIFERENTE (menor).** "When you need to scale, simply switch to server mode"; no dice "production".
