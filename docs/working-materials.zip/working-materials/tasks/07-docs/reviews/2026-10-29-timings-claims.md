# 07 · Tiempos por etapa e inventario de afirmaciones (assistant, sonnet, 2026-10-29)

- Script y datos crudos (fuera del repo): `scratchpad/timing07/` (`timing.py`, `raw_timings.csv` con 255 filas, `raw_timings.json`).
- Importa de `app/`, usa Chroma temporal y no llama al LLM.
- `verify.ps1` pasa: ruff check, formato y pytest.
- Claude revisó el CSV y el código citado.

## Hardware y configuración
- 16 núcleos lógicos, 31.7 GB de RAM, torch 2.14.1+cpu.
- Tesseract 5.4.0, `OCR_DPI=300`.

## Tiempos (6 repeticiones en caliente; las muestras tienen 1, 2 y 2 páginas)
| Etapa | Valor |
|---|---|
| OCR (rasterizado + Tesseract) | ~0.79 s por página, más del 95 % del total |
| NER | ~18 ms por página |
| Embeddings | 28-56 ms por PDF |
| Cajas, fuzzy y chunking | < 0.2 ms |
| Extract de punta a punta | memo (1 página) 0.79-0.85 s; minutes y report (2 páginas) 1.57-1.64 s |
| Ingest de punta a punta | 0.80-0.83 s con 1 página (1.79 s en la primera llamada); 1.61-1.65 s con 2 páginas |
| Carga en frío | spaCy 0.59 s; MiniLM 53.9 s una vez (sin desglosar; probablemente es sobre todo la importación de torch y sentence-transformers: hay que comprobarlo antes de citarlo) |

- `OMP_THREAD_LIMIT` no cambia nada (0.684 frente a 0.675 s): este Tesseract ya corre en 1 hilo.
- Capacidad por proceso, en serie: ~4500 páginas por hora, que son ~4500 PDF/h de 1 página o ~2260 de 2 páginas.
- Para 1000 PDF/h hacen falta 1 PDF cada 3.6 s, es decir, unas 4.5 páginas por PDF en un solo proceso. Con documentos más largos se añaden procesos de OCR: hasta un proceso por núcleo.

## Inventario de afirmaciones
- **`ERROR_STATUS`** (`app/main.py:28-36`):
  - `InvalidPdfError` → 422;
  - `DocumentTooLargeError` → 413;
  - `OcrEngineError`, `VectorStoreError` y `LLMUnavailableError` → 503;
  - `LLMTimeoutError` → 504;
  - `LLMBadResponseError` → 502.

  **No hay 415.**
- **413:** `dependencies.py:33` por tamaño y `ocr_service.py:76` por páginas.
- **422:** `ocr_service.py:72` (no es PDF), `:74` (cifrado), `:79` (ilegible), más la validación de FastAPI.
- **Peor caso de `/api/ask`:** 3 × 60 s + espera exponencial de 1.5 a 3.5 s = 183.5 s ≈ 184 s.
- **Workers y servicios:**
  - endpoints `def` (threadpool);
  - 1 worker (DECISIONS.md:114);
  - sin lifespan: los modelos se cargan de forma perezosa con caché;
  - cliente Chroma único por proceso (`vector_service.py:24-45`).
- **Logging:** JSON con `request_id` (`log.py:16,21`).
