# Fix de respuesta en blanco · code-critic (opus, 2026-10-30): CHANGES (2), aplicados

El crítico comprobó cuatro cosas:
- el test falla sin el cambio (`""` y `"  \n "` daban `False`) y pasa con él;
- la línea es la mínima; `is_abstention` solo se usa en `generate_answer`, y `content: null` sigue dando 502;
- la spec y DESIGN.md coinciden con el código;
- el nombre del test sigue la regla.

Hallazgos:
1. **Aplicado:** el docstring de 2 líneas desplazaba las líneas citadas en la Explicación del NB05b (`:115`, `:120`, `:121`). Volvió a una sola línea, y `:97`, `:102` y `:120` siguen apuntando a lo mismo.
2. **Aplicado:** `tasks/06-rag-ask/explicacion-ac.md` (que build_nb05b.py lee en la sección 9) explica ahora el caso en blanco. El notebook se actualiza en el próximo build.
