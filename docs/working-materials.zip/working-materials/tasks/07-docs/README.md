# 07-docs · DESIGN.md y DECISIONS.md

**Alcance:** `DESIGN.md` (<= 3 páginas) y las filas técnicas de `DECISIONS.md`; `.env.example` completo.
**Spec:** checklist de README:112-115 (no necesita spec)
**Estado:** DESIGN.md (1329 palabras de prosa) y RUNNING.md listos; code-critic r2 aplicado; verify ok; smoke ok. Falta: JM revisa los Mermaid (G10), explica (G12), decide el caso de content en blanco y hace los commits

| Etapa | Archivo |
|---|---|
| Research | [research.md](research.md) |
| Evaluación | [evaluation.md](evaluation.md) |
| Plan (JM) | [plan.md](plan.md) |
| Reviews | [reviews/](reviews/) |

## Qué necesitamos
**Depende de:** 04 y 06 cerradas (los docs describen código real).
**Entradas:** README:112-115; `research/16` punto 4; decisiones de cada `tasks/NN/research.md`.
**Entregables:** `DESIGN.md` (<= 3 páginas) y `RUNNING.md`; sin filas nuevas en DECISIONS.md (D-DOC-3).

**Pasos que faltan (en orden):**
1. literature-researcher: escalado (cola, workers, batching de OCR) y ruteo de modelos, con citas [V].
2. Claude redacta DESIGN.md; code-critic busca afirmaciones que contradigan el código.
3. Claude muestra a JM el texto exacto de cada fila de DECISIONS.md; JM aprueba.
4. `/commit-handoff`.

**Commits previstos** (uno por idea, siempre verde y explicado):
- `docs(design): add architecture and scaling design`
- `docs(decisions): record implementation decisions`

**Hecho cuando:** todos los gates de [evaluation.md](evaluation.md) cumplidos, code-critic APPROVE, explicación de JM firmada y commits hechos.
