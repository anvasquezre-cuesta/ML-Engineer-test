# Tareas (una carpeta por tarea)

Flujo de cada tarea, en orden. No se pasa a la etapa siguiente sin cerrar la anterior:
1. **research**: lo que ya sabemos, con sus fuentes, y lo que falta investigar.
2. **evaluación**: cómo sabremos que quedó bien. Son gates, métricas y valores esperados.
3. **spec**: los ACs, en `ML-Engineer-test/docs/specs/NN-*.md`.
4. **plan**: lo escribe Jeison.
5. **implementación**.
6. **reviews**.
7. **explicación** y commit.

Cada carpeta `tasks/NN-slug/` contiene:
- `README.md`: alcance, estado de cada etapa y enlaces;
- `research.md`: fuentes `[V]`, decisiones tomadas, huecos y decisiones abiertas;
- `evaluation.md`: gates, métricas, valores esperados y comandos de verificación;
- `plan.md`: plan de implementación (Jeison);
- `reviews/`: salidas del code-critic y del assistant, con fecha.

La plantilla está en `.claude/templates/task/`. Los gates comunes están en `research/19-plan-implementacion.md`.

## Una tarea a la vez (Jeison, 2026-10-28)
- Solo hay **una tarea activa**. La siguiente empieza cuando la activa tiene su último commit hecho; ni siquiera su research se adelanta.
- Lo que cada tarea necesita (dependencias, entradas, entregables, pasos con su agente y commits previstos) está en la sección "Qué necesitamos" de su `README.md`.
- Al cerrar una tarea: actualizar esta tabla, `research/16-estado-*.md` y una fila en `research/DECISIONS-LOG.md`.

**Tarea activa: 09-final-eval** (empieza en otra sesión). 08 cerrada el 2026-10-30: JM probó todo en el navegador y el CI está verde en el fork.

## Pendientes que cruzan tareas (Jeison)
- "Mis respuestas": 03, 02a y 02c redactadas por Claude (2026-10-29, borrador para JM, marcado en el notebook). JM las revisa antes de la entrevista.
- Fecha de entrega: decide qué entra en 08-bonus.
- Claude muestra el texto exacto de DECISIONS.md antes de editarlo.

| # | Tarea | Research | Eval | Spec | Plan | Impl | Commit |
|---|---|---|---|---|---|---|---|
| 01 | [fuzzy](01-fuzzy/README.md) | listo | listo | fc00320 | aprobado | verde, APPROVE | de8b999, 3f6e372 + docs (cerrada) |
| 02 | [ner](02-ner/README.md) | listo | listo | 62a8d2e | aprobado | verde, APPROVE (r2) | b28e733, 4578e39, 1784712 + docs (cerrada) |
| 03 | [ocr-boxes](03-ocr-boxes/README.md) | listo | listo | 88567ba | aprobado | verde, APPROVE | dfa5939, 3eb7b2a, 3bb169a, edade67 + docs (cerrada) |
| 04 | [extract-api](04-extract-api/README.md) | listo | listo | fe8c7fc | aprobado | verde, crítico r1 aplicado | 22e4ff3, 036dc86, a4d2dc2, f31f620, c616919 + docs (cerrada) |
| 05 | [rag-ingest](05-rag-ingest/README.md) | listo (NB05) | listo | 1e8876b | aprobado (Plan Opus + respuestas JM) | verde, crítico r1 por commit aplicado | 379e411, 380de61, c7256ce, af0759c, dda3a0c, 40bd28a, 7fe35d8, ebcfddc, d72152f + docs (cerrada) |
| 06 | [rag-ask](06-rag-ask/README.md) | listo (NB05b r3, revisor r2) | listo | 2fdf333 | aprobado (Plan Opus + JM) | verde, crítico por commit aplicado; mutaciones 39/41 + 2 en el commit 4 | e9b379b, 8dc8477, 4cafd5e, a3b4eee, 874dff0 + 7846680 DECISIONS (cerrada; JM estudia Explicación) |
| 07 | [docs](07-docs/README.md) | listo | aprobado G1-G12 | checklist (sin spec) | aprobado | crítico r1+r2 aplicado; fix de respuesta en blanco en verde | c0b8cfe, 4cc4463, 86ee068, 3a05713 (cerrada) |
| 08 | [bonus](08-bonus/README.md) | listo (visor pdf.js + CI) | listo V1-V5, C1-C2 | 08a-viewer, 08b-ci (firmadas) f793a80 | aprobado | verde; crítico r1 aplicado; manual del visor ok; CI verde en el fork | 50deb25, 61e7aee, 212590a, 5014727, 7885f7b, 9057fa6 (cerrada) |
| 09 | [final-eval](09-final-eval/README.md) | - | borrador | - | - | - | - |
