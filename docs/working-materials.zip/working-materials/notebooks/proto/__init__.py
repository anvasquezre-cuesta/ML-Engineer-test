"""Codigo de prototipo que importan los notebooks. Lo estable se mueve a app/."""
