"""Ingesta RAG: chunking por pagina, IDs, Chroma y metricas. Candidato a app/services/."""

import hashlib
import math
import re
import time
from collections import Counter
from functools import partial
from math import comb

import numpy as np
import pandas as pd


def pages_from_words(words: pd.DataFrame) -> list[str]:
    """Texto por pagina de UN pdf, a partir de la tabla de palabras del NB01."""
    from app.services.ocr_service import page_text

    texts = []
    for _, group in words.sort_values("page", kind="stable").groupby("page"):
        rows = [
            {"word": str(r.text), "line": (r.block, r.par, r.line)}
            for r in group.itertuples()
        ]
        texts.append(page_text(rows)[0])
    return texts


def doc_id(pdf_bytes: bytes) -> str:
    """Huella del contenido: mismo PDF, mismo id aunque cambie el nombre."""
    return hashlib.sha256(pdf_bytes).hexdigest()[:16]


def chunk_spans(text: str, chunk_size: int = 500, overlap: int = 60) -> list[tuple[int, int]]:
    """(inicio, fin) de ventanas de ~chunk_size caracteres cortadas en espacio, con overlap.

    Una palabra mas larga que chunk_size queda entera en su propia ventana.
    """
    assert 0 <= overlap < chunk_size, "overlap debe estar en [0, chunk_size)"
    spans, start, n = [], 0, len(text)
    while start < n:
        end = min(start + chunk_size, n)
        if end < n and not text[end].isspace():  # cortaria una palabra
            cut = max(text.rfind(" ", start, end), text.rfind("\n", start, end))
            if cut <= start:  # sin espacio en la ventana: palabra gigante
                found = re.compile(r"\s").search(text, end)
                cut = found.start() if found else n
            end = cut
        if text[start:end].strip():
            spans.append((start, end))
        if end >= n:
            break
        start = max(end - overlap, start + 1)
        while start < end and not text[start - 1].isspace():  # no empezar a media palabra
            start += 1
        while start < n and text[start].isspace():
            start += 1
    return spans


def chunk_text(text: str, chunk_size: int = 500, overlap: int = 60) -> list[str]:
    """Estrategia A (B con overlap=0): ventanas de caracteres cortadas en espacio."""
    return [text[s:e].strip() for s, e in chunk_spans(text, chunk_size, overlap)]


def chunk_sentences(text: str, chunk_size: int = 500) -> list[str]:
    """Estrategia C: agrupa oraciones (fin en . ! ?) hasta chunk_size; sin overlap."""
    chunks, cur = [], ""
    for sentence in re.split(r"(?<=[.!?])\s+", text):
        if cur and len(cur) + 1 + len(sentence) > chunk_size:
            chunks.append(cur)
            cur = ""
        cur = f"{cur} {sentence}" if cur else sentence
    return chunks + [cur] if cur else chunks


def chunk_recursive(text: str, size: int = 500, seps=("\n\n", "\n", ". ", " ")) -> list[str]:
    """Estrategia D: parte por el separador mas grande y baja de nivel solo en lo que no cabe."""
    text = text.strip()
    sep = next((s for s in seps if s in text), None)
    if len(text) <= size or sep is None:  # cabe, o es una palabra gigante
        return [text] if text else []
    rest = seps[seps.index(sep) + 1 :]
    out, cur = [], ""
    for part in text.split(sep):
        if cur and len(cur) + len(sep) + len(part) <= size:
            cur += sep + part
            continue
        if cur:
            out.append(cur)
        cur = part
        if len(part) > size:  # no cabe ni sola: bajo un nivel
            out.extend(chunk_recursive(part, size, rest))
            cur = ""
    return [c.strip() for c in out + [cur] if c.strip()]


def page_records(pages: list[str], chunker) -> list[dict]:
    """Un registro por chunk, con la pagina de la que sale (estrategias por pagina)."""
    return [
        {"page": i, "page_end": i, "text": chunk}
        for i, text in enumerate(pages)
        for chunk in chunker(text)
    ]


def doc_records(pages: list[str], chunk_size: int = 500, overlap: int = 60) -> list[dict]:
    """Estrategia F: una sola cadena con todo el PDF; la pagina es la del INICIO del chunk."""
    text = "\n\n".join(pages)
    starts = np.cumsum([0] + [len(p) + 2 for p in pages])

    def page_of(pos: int) -> int:
        return int(np.searchsorted(starts, pos, side="right")) - 1

    return [
        {"page": page_of(s), "page_end": page_of(e - 1), "text": text[s:e].strip()}
        for s, e in chunk_spans(text, chunk_size, overlap)
    ]


STRATEGIES = {
    "A 500+60": lambda pages: page_records(pages, chunk_text),
    "B 500 sin overlap": lambda pages: page_records(pages, partial(chunk_text, overlap=0)),
    "C oraciones": lambda pages: page_records(pages, chunk_sentences),
    "D recursivo": lambda pages: page_records(pages, chunk_recursive),
    "E pagina entera": lambda pages: page_records(pages, lambda t: [t.strip()]),
    "F documento": doc_records,
}


def token_counts(model, texts: list[str]) -> pd.Series:
    """Tokens por texto con el tokenizer del modelo (incluye los 2 tokens especiales)."""
    return pd.Series([len(ids) for ids in model.tokenizer(texts)["input_ids"]])


def embedder(model):
    """Funcion `list[str] -> list[list[float]]` con vectores normalizados."""

    def embed(texts: list[str]) -> list[list[float]]:
        return model.encode(texts, normalize_embeddings=True).tolist()

    return embed


def ingest(collection, embed, filename: str, pdf_bytes: bytes, records: list[dict]) -> int:
    """Re-ingesta idempotente: borra los chunks de este doc_id y vuelve a anadirlos."""
    did = doc_id(pdf_bytes)
    seen, ids, docs, metas = Counter(), [], [], []
    for r in records:
        k = seen[r["page"]]
        seen[r["page"]] += 1
        ids.append(f"{did}:{r['page']}:{k}")
        docs.append(r["text"])
        metas.append({"doc_id": did, "filename": filename, "page": r["page"], "chunk": k})
    collection.delete(where={"doc_id": did})
    if ids:
        collection.add(ids=ids, documents=docs, embeddings=embed(docs), metadatas=metas)
    return len(ids)


def search(collection, embed, question: str, top_k: int = 5) -> list[dict]:
    """Top-k chunks con score = 1 - distancia coseno. Siempre con query_embeddings."""
    for _ in range(5):  # chromadb 1.5.9 a veces devuelve 0 resultados de forma pasajera
        res = collection.query(
            query_embeddings=embed([question]),
            n_results=top_k,
            include=["documents", "metadatas", "distances"],
        )
        if res["ids"][0]:
            break
        time.sleep(0.5)
    return [
        {"text": doc, "score": 1 - dist, **meta}
        for doc, meta, dist in zip(
            res["documents"][0], res["metadatas"][0], res["distances"][0], strict=True
        )
    ]


def page_rank(hits: list[dict], gold: list) -> int | None:
    """Posicion (1 = primera) de la primera pagina de `gold` entre las paginas distintas de los hits."""
    pages = list(dict.fromkeys((h["filename"], h["page"]) for h in hits))
    wanted = {tuple(g) for g in gold}
    return next((i + 1 for i, page in enumerate(pages) if page in wanted), None)


def evaluate(collection, embed, questions: list[dict], top_k: int = 10) -> pd.DataFrame:
    """Una fila por pregunta: rango de la pagina de oro y pagina que quedo primera."""
    rows = []
    for q in questions:
        hits = search(collection, embed, q["question"], top_k)
        assert hits, f"query vacia para {q['id']}"
        gold = {tuple(g) for g in q["gold"]}
        top5 = {(h["filename"], h["page"]) for h in hits[:5]}
        rows.append(
            {
                "id": q["id"],
                "kind": q["kind"],
                "rank": page_rank(hits, q["gold"]),
                "top1": f"{hits[0]['filename']}:p{hits[0]['page']}",
                "score1": round(hits[0]["score"], 3),
                "gold_top5": len(gold & top5),
                "n_gold": len(gold),
            }
        )
    return pd.DataFrame(rows)


def wilson(k: int, n: int, z: float = 1.96) -> tuple[float, float]:
    """Intervalo de Wilson 95 % para una proporcion k/n."""
    p = k / n
    center = (p + z**2 / (2 * n)) / (1 + z**2 / n)
    half = z * math.sqrt(p * (1 - p) / n + z**2 / (4 * n**2)) / (1 + z**2 / n)
    return center - half, center + half


def retrieval_metrics(ranks: pd.Series, ks=(1, 3), seed: int = 42) -> pd.DataFrame:
    """hit@k con Wilson y MRR con bootstrap (semilla fija), a nivel de pagina.

    hit@5 no se pide: con solo 5 paginas en el corpus siempre vale 1.
    """
    r = ranks.astype(float).fillna(np.inf).to_numpy()
    rows = []
    for k in ks:
        hits = int((r <= k).sum())
        lo, hi = wilson(hits, len(r))
        rows.append({"metrica": f"hit@{k}", "valor": hits / len(r), "ic_lo": lo, "ic_hi": hi})
    rr = 1 / r
    boot = np.random.default_rng(seed).choice(rr, size=(2000, len(rr))).mean(axis=1)
    lo, hi = np.percentile(boot, [2.5, 97.5])
    rows.append({"metrica": "MRR", "valor": rr.mean(), "ic_lo": lo, "ic_hi": hi})
    return pd.DataFrame(rows).round(3)


def normalize_ocr(text: str) -> str:
    """Une guiones de fin de linea (`exam-\\nple` -> `example`) y colapsa espacios/tabs."""
    return re.sub(r"[ \t]+", " ", re.sub(r"(\w)-\n(?=[a-z])", r"\1", text))


def run_strategy(collection, embed, builder, pages_by_pdf, bytes_by_pdf, questions):
    """Ingesta los 3 PDFs con `builder`, evalua las preguntas y mide segundos de ingesta."""
    start = time.perf_counter()
    for pdf, pages in pages_by_pdf.items():
        ingest(collection, embed, pdf, bytes_by_pdf[pdf], builder(pages))
    seconds = time.perf_counter() - start
    return evaluate(collection, embed, questions), seconds


def fresh_collection(client, name: str, space: str = "cosine"):
    """Coleccion nueva y vacia: borra la que exista con ese nombre y la crea de nuevo."""
    if name in {getattr(c, "name", c) for c in client.list_collections()}:
        client.delete_collection(name)
    return client.create_collection(
        name, configuration={"hnsw": {"space": space}}, embedding_function=None
    )


def overlap_chars(a: str, b: str) -> int:
    """Caracteres del final de `a` que son el comienzo de `b` (el solape real)."""
    return next((k for k in range(min(len(a), len(b)), 0, -1) if a.endswith(b[:k])), 0)


def size_builder(chunk_size: int, overlap: int = 60):
    """Estrategia A con otro chunk_size: `pages -> registros` para `run_strategy`."""
    return lambda pages: page_records(pages, partial(chunk_text, chunk_size=chunk_size, overlap=overlap))


def metric_strings(ranks: pd.Series, keys=("hit@1", "hit@3", "MRR")) -> dict:
    """Cada metrica como texto `valor [ic_lo-ic_hi]`, para tablas."""
    m = retrieval_metrics(ranks).set_index("metrica")
    return {k: f"{m.loc[k, 'valor']:.2f} [{m.loc[k, 'ic_lo']:.2f}-{m.loc[k, 'ic_hi']:.2f}]" for k in keys}


def paired_vs_base(ranks: pd.DataFrame, base: str, seed: int = 42, n_boot: int = 5000) -> pd.DataFrame:
    """Compara cada columna de `ranks` (rango por pregunta) con `base`, pregunta por pregunta.

    McNemar exacto sobre hit@1 (binomial de dos colas sobre los discordantes) y
    bootstrap pareado de delta-MRR (otra - base).
    """
    rr = (1 / ranks.astype(float)).fillna(0)
    idx = np.random.default_rng(seed).integers(0, len(ranks), (n_boot, len(ranks)))
    rows = {}
    for name in ranks.columns.drop(base):
        only_base = int(((ranks[base] == 1) & (ranks[name] != 1)).sum())
        only_other = int(((ranks[base] != 1) & (ranks[name] == 1)).sum())
        n = only_base + only_other
        p = min(1.0, 2 * sum(comb(n, i) for i in range(min(only_base, only_other) + 1)) / 2**n) if n else 1.0
        d = (rr[name] - rr[base]).to_numpy()
        lo, hi = np.percentile(d[idx].mean(axis=1), [2.5, 97.5])
        rows[name] = {
            "solo_base": only_base,
            "solo_otra": only_other,
            "p_mcnemar": round(p, 3),
            "dMRR": round(d.mean(), 3),
            "ic_lo": round(lo, 3),
            "ic_hi": round(hi, 3),
            "rangos_distintos": int((ranks[name].fillna(-1) != ranks[base].fillna(-1)).sum()),
            "supera_a_base": bool((p < 0.05 and only_other > only_base) or round(lo, 3) > 0),
        }
    return pd.DataFrame(rows).T
