"""Nombres de persona y su caja en puntos. Candidato a ner_service y bbox_service."""

import re

import pandas as pd
from spacy.language import Language


def person_spans(nlp: Language, text: str) -> pd.DataFrame:
    """Entidades PERSON de spaCy con su posicion (start, end) en el texto."""
    rows = [
        {"name": ent.text, "start": ent.start_char, "end": ent.end_char}
        for ent in nlp(text).ents
        if ent.label_ == "PERSON"
    ]
    return pd.DataFrame(rows, columns=["name", "start", "end"])


def filter_persons(spans: pd.DataFrame) -> pd.DataFrame:
    """Quita lo que no parece nombre: cruza lineas, todo mayusculas o una palabra."""
    name = spans["name"]
    keep = ~name.str.contains("\n") & ~name.str.isupper() & name.str.contains(" ")
    return spans[keep].reset_index(drop=True)


def name_box(words: pd.DataFrame, start: int, end: int) -> dict:
    """Caja union de las palabras que tocan [start, end) en una pagina.

    Si la palabra trae puntuacion pegada ("Thompson,") la caja la incluye: es un
    poco mas ancha, pero nunca corta el nombre.
    """
    hit = words[(words["start"] < end) & (words["end"] > start)]
    x0, y0 = hit["x"].min(), hit["y"].min()
    x1, y1 = (hit["x"] + hit["width"]).max(), (hit["y"] + hit["height"]).max()
    return {"x": x0, "y": y0, "width": x1 - x0, "height": y1 - y0}


def locate_names(words: pd.DataFrame, spans: pd.DataFrame) -> pd.DataFrame:
    """Una fila por nombre (por ocurrencia) con su caja en puntos, en una pagina."""
    rows = [
        {"name": span.name, **name_box(words, span.start, span.end)}
        for span in spans.itertuples()
    ]
    return pd.DataFrame(rows, columns=["name", "x", "y", "width", "height"])


def keys(df: pd.DataFrame) -> pd.Series:
    """Clave de cada mencion: pdf | pagina | nombre."""
    return df["pdf"] + "|" + df["page"].astype(str) + "|" + df["name"]


def tokens(df: pd.DataFrame) -> pd.DataFrame:
    """Una fila por palabra del nombre."""
    return df.assign(name=df["name"].str.split()).explode("name")


def count_hits(pred: pd.Series, gold: pd.Series) -> int:
    """Aciertos contando repeticiones: de cada elemento, el minimo de los dos lados."""
    return int(
        pred.value_counts().combine(gold.value_counts(), min, fill_value=0).sum()
    )


def precision_recall(pred: pd.Series, gold: pd.Series) -> pd.Series:
    """P, R y F1 contando repeticiones (cada prediccion empareja un caso de oro)."""
    assert len(pred) > 0 and len(gold) > 0, (
        "precision_recall necesita pred y gold no vacios"
    )
    tp = count_hits(pred, gold)
    precision, recall = tp / len(pred), tp / len(gold)
    f1 = 2 * precision * recall / (precision + recall)
    return pd.Series({"precision": precision, "recall": recall, "f1": f1})


def wilson(k: int, n: int, z: float = 1.96) -> tuple[float, float]:
    """Intervalo de Wilson para una proporcion k/n (z = 1.96 es el 95 %)."""
    assert n > 0, "wilson necesita n > 0"
    p = k / n
    scale = 1 + z**2 / n
    center = (p + z**2 / (2 * n)) / scale
    half = z * (p * (1 - p) / n + z**2 / (4 * n**2)) ** 0.5 / scale
    return center - half, center + half


def propagate_names(text: str, names, found: pd.DataFrame) -> pd.DataFrame:
    """Suma a lo de spaCy las otras apariciones exactas de `names` en el texto.

    Solo quita duplicados identicos (start, end): un solape parcial con un span mas
    largo de spaCy daria dos cajas (0 casos en las muestras).
    """
    spacy_rows = found[["name", "start", "end"]].assign(source="spacy")
    rows = [
        {"name": n, "start": m.start(), "end": m.end(), "source": "propagated"}
        for n in names
        for m in re.finditer(rf"(?<!\w){re.escape(n)}(?!\w)", text)
    ]
    both = pd.concat([spacy_rows, pd.DataFrame(rows, columns=spacy_rows.columns)])
    return both.drop_duplicates(["start", "end"]).sort_values(
        "start", ignore_index=True
    )
