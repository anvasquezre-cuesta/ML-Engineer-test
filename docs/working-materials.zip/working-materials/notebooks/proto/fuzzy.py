"""Fuzzy match de nombres: normalizar, puntuar y comparar contra los pedidos."""

import re
import unicodedata

from rapidfuzz import fuzz

TITLES = {"dr", "mr", "mrs", "ms", "miss", "prof"}


def normalize_name(name: str) -> str:
    """Nombre en minusculas, sin acentos, apostrofos, puntuacion ni titulos."""
    text = unicodedata.normalize("NFKD", name.casefold())
    text = "".join(c for c in text if not unicodedata.combining(c))
    text = re.sub(r"['’]", "", text)
    words = re.sub(r"\W+", " ", text).split()
    return " ".join(w for w in words if w not in TITLES)


def name_score(a: str, b: str) -> float:
    """Similitud 0..1: max(ratio, token_sort_ratio) sobre nombres normalizados."""
    a, b = normalize_name(a), normalize_name(b)
    return max(fuzz.ratio(a, b), fuzz.token_sort_ratio(a, b)) / 100


def fuzzy_match_names(
    extracted_names: list[str], query_names: list[dict], threshold: float = 0.90
) -> list[dict]:
    """Pares con score >= threshold; asume nombres no vacios (lo valida NamePair)."""
    extracted, wanted = {}, {}  # clave normalizada -> primera aparicion original
    for name in extracted_names:
        key = normalize_name(name)
        if key and key not in extracted:
            extracted[key] = name
    for q in query_names:
        full = f"{q['first_name']} {q['last_name']}"
        key = normalize_name(full)
        if key and key not in wanted:
            wanted[key] = full
    rows = []
    for e in extracted.values():
        for m in wanted.values():
            score = name_score(e, m)
            if score >= threshold:
                rows.append(
                    {"extracted_name": e, "matched_name": m, "score": round(score, 4)}
                )
    return sorted(
        rows, key=lambda r: (-r["score"], r["extracted_name"], r["matched_name"])
    )
