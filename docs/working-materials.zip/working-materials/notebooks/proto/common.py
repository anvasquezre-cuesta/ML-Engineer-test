"""Rutas, configuracion, procedencia y dibujo de cajas (para todos los notebooks)."""

import hashlib
import subprocess
from pathlib import Path

import pandas as pd
import pymupdf
import pytesseract
from PIL import Image

from app.config import Settings

ROOT = Path(__file__).resolve().parents[2]  # raiz del repo ML-Engineer-test
PDFS = {p.name: p for p in sorted((ROOT / "sample_pdfs").glob("*.pdf"))}
ARTIFACTS = ROOT / "notebooks" / "artifacts"
SEED = 42


def load_settings() -> Settings:
    """Settings con el `.env` de la raiz del repo (el notebook corre en notebooks/)."""
    return Settings(_env_file=ROOT / ".env")


def versions() -> pd.Series:
    """Versiones que influyen en el resultado, para saber de donde salen los numeros."""
    import rapidfuzz
    import spacy

    commit = subprocess.run(
        ["git", "rev-parse", "--short", "HEAD"],
        cwd=ROOT,
        capture_output=True,
        text=True,
        check=False,
    ).stdout.strip()
    return pd.Series(
        {
            "tesseract": str(pytesseract.get_tesseract_version()),
            "pymupdf": pymupdf.__version__,
            "spacy": spacy.__version__,
            "rapidfuzz": rapidfuzz.__version__,
            "commit": commit,
        }
    )


def inspect_pdfs() -> pd.DataFrame:
    """Una fila por pagina: huella del PDF, tamano en pt, imagenes y texto nativo."""
    rows = []
    for name, path in PDFS.items():
        digest = hashlib.sha256(path.read_bytes()).hexdigest()[:16]
        with pymupdf.open(path) as doc:
            for page in doc:
                rows.append(
                    {
                        "pdf": name,
                        "sha256": digest,
                        "page": page.number,
                        "width_pt": page.rect.width,
                        "height_pt": page.rect.height,
                        "rotation": page.rotation,
                        "images": len(page.get_images()),
                        "text_chars": len(page.get_text().strip()),
                    }
                )
    return pd.DataFrame(rows)


def draw_boxes(
    pdf_path: Path, page_number: int, boxes: pd.DataFrame, dpi: int = 100
) -> Image.Image:
    """Dibuja cajas en PUNTOS sobre la pagina (en memoria) y la devuelve como imagen.

    Si las cajas caen sobre las palabras, quedan probadas la unidad (pt) y el
    origen (arriba-izquierda) sin convertir nada a mano. El PDF no se modifica.
    """
    with pymupdf.open(pdf_path) as doc:
        page = doc[page_number]
        for b in boxes.itertuples():
            page.draw_rect(
                pymupdf.Rect(b.x, b.y, b.x + b.width, b.y + b.height),
                color=(1, 0, 0),
                width=0.6,
            )
        return page.get_pixmap(dpi=dpi).pil_image()
