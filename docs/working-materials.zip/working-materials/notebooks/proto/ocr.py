"""OCR por palabra en puntos PDF. Candidato a app/services/ocr_service.py."""

from pathlib import Path

import pandas as pd
import pymupdf
import pytesseract
from PIL import Image

from app.config import Settings


def render_page(
    pdf_path: Path, page_number: int, dpi: int
) -> tuple[Image.Image, float]:
    """Pagina -> imagen en gris, y el factor puntos por pixel.

    La escala sale de page.rect (no se supone 72/dpi): a 300 DPI da 0.24.
    """
    with pymupdf.open(pdf_path) as doc:
        page = doc[page_number]
        pix = page.get_pixmap(dpi=dpi, colorspace=pymupdf.csGRAY)
        scale = page.rect.width / pix.width
    return pix.pil_image(), scale


def ocr_page(img: Image.Image, scale: float, settings: Settings) -> pd.DataFrame:
    """Una fila por palabra con caja en puntos. Descarta conf < 0 y texto vacio."""
    data = pytesseract.image_to_data(
        img,
        lang=settings.ocr_lang,
        config=f"--psm {settings.ocr_psm}",
        timeout=settings.ocr_timeout_s,
        output_type=pytesseract.Output.DICT,
    )
    df = pd.DataFrame(data)
    df["text"] = df["text"].str.strip()
    df = df[(df["conf"].astype(float) >= 0) & (df["text"] != "")]
    return pd.DataFrame(
        {
            "text": df["text"],
            "conf": df["conf"].astype(float),
            "block": df["block_num"],
            "par": df["par_num"],
            "line": df["line_num"],
            "x": df["left"] * scale,
            "y": df["top"] * scale,
            "width": df["width"] * scale,
            "height": df["height"] * scale,
        }
    ).reset_index(drop=True)


def ocr_pdf(pdf_path: Path, settings: Settings) -> pd.DataFrame:
    """OCR de TODAS las paginas (incluida la 0), una fila por palabra."""
    with pymupdf.open(pdf_path) as doc:
        n_pages = doc.page_count
    frames = []
    for page_number in range(n_pages):
        img, scale = render_page(pdf_path, page_number, settings.ocr_dpi)
        words = ocr_page(img, scale, settings)
        frames.append(words.assign(pdf=pdf_path.name, page=page_number))
    return pd.concat(frames, ignore_index=True)


def add_offsets(words: pd.DataFrame) -> tuple[pd.DataFrame, dict[int, str]]:
    """Texto por pagina y start/end de cada palabra en ese texto (un solo PDF).

    Palabras unidas con " " dentro de una linea y con "\\n" entre lineas.
    Con estos offsets, los spans de spaCy caen en palabras OCR exactas.
    """
    words = words.copy()
    texts: dict[int, str] = {}
    for page, group in words.groupby("page"):
        parts: list[str] = []
        pos = 0
        prev_line = None
        for row in group.itertuples():
            line = (row.block, row.par, row.line)
            if prev_line is not None:
                parts.append(" " if line == prev_line else "\n")
                pos += 1
            words.loc[row.Index, ["start", "end"]] = [pos, pos + len(row.text)]
            parts.append(row.text)
            pos += len(row.text)
            prev_line = line
        texts[page] = "".join(parts)
    words[["start", "end"]] = words[["start", "end"]].astype(int)
    return words, texts


def add_offsets_all(words: pd.DataFrame) -> tuple[pd.DataFrame, dict[tuple, str]]:
    """`add_offsets` PDF por PDF: palabras con start/end y texto por (pdf, pagina)."""
    frames, texts = [], {}
    for pdf, pdf_words in words.groupby("pdf", sort=False):
        pdf_words, page_texts = add_offsets(pdf_words)
        frames.append(pdf_words)
        texts.update({(pdf, page): text for page, text in page_texts.items()})
    return pd.concat(frames), texts


def add_lines(words: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Numera los renglones de arriba abajo por pagina (`line`; el de Tesseract pasa
    a `tess_line`). Devuelve las palabras con su renglon y una fila por renglon."""
    words = words.rename(columns={"line": "tess_line"}).assign(
        right=lambda w: w["x"] + w["width"], bottom=lambda w: w["y"] + w["height"]
    )
    key = ["pdf", "page", "block", "par", "tess_line"]
    lines = words.groupby(key, as_index=False).agg(
        text=("text", " ".join),
        x=("x", "min"),
        y=("y", "min"),
        right=("right", "max"),
        bottom=("bottom", "max"),
    )
    lines["line"] = lines.groupby(["pdf", "page"])["y"].rank(method="first").astype(int)
    lines = lines.assign(
        width=lines["right"] - lines["x"], height=lines["bottom"] - lines["y"]
    )
    return words.merge(lines[key + ["line"]], on=key), lines
