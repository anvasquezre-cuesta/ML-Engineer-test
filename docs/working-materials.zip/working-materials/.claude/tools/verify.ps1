# Lint + formato + tests. Si un paso falla imprime sus primeras 25 lineas y las ultimas 5; sale con 1.
Set-Location (Join-Path (Split-Path -Parent (Split-Path -Parent $PSScriptRoot)) "ML-Engineer-test")
$steps = [ordered]@{
    'ruff check'  = { uv run ruff check . }
    'ruff format' = { uv run ruff format --check . }
    'pytest'      = { uv run pytest -q }
}
$failed = @()
foreach ($name in $steps.Keys) {
    $out = & $steps[$name] 2>&1 | ForEach-Object { "$_" }
    if ($LASTEXITCODE -ne 0) {
        $failed += $name
        "== $name FALLO"
        $out | Select-Object -First 25
        if ($out.Count -gt 30) { '...'; $out | Select-Object -Last 5 }
    } else {
        "== $name ok"
    }
}
if ($failed) { exit 1 }
