---
name: grill-me
description: Debate entre dos subagentes (minimalista y evaluador del rubric) que se critican, verificado por Claude, para aclarar una rebanada del servicio de documentos antes de escribir su spec. Solo se ejecuta cuando Jeison escribe /grill-me.
disable-model-invocation: true
allowed-tools: Read Grep Glob Bash Agent SendMessage
---

# grill-me

Objetivo: que la spec de la rebanada quede clara, con el menor codigo posible y sin supuestos ocultos, antes de escribir codigo. Jeison revisa todo, asi que se le entrega una sintesis ya criticada, no un interrogatorio. Nada se edita en el repo durante el grill.

## 1. Contexto (Claude, antes de lanzar)
Resume en 2 lineas la rebanada (`$ARGUMENTS`) y reune lo que ya responde las preguntas:
- Plan vigente: `research/14-revision-plan.md` (manda sobre 06/07/13) y `research/15-decisiones-sesion.md`.
- Evidencia: `ML-Engineer-test/notebooks/NN_*.ipynb`, su ejecucion `notebooks/artifacts/NN_*.executed.ipynb`, los CSV de `artifacts/` y `notebooks/proto/`.
- Papers: `papers/analysis/README.md`.
- Contrato y decisiones: `README.md`, `app/models/schemas.py` (leer solo con Read), `ML-Engineer-test/DECISIONS.md`, stubs de `app/services/`.

## 2. Ronda 1: dos subagentes Sonnet en paralelo (`general-purpose`, `model: sonnet`)
- **Minimalista**: menos codigo y abstracciones, todo explicable por un data scientist en entrevista.
- **Evaluador del rubric**: que haria perder nota (correctness 30 %, tests ocultos sobre los stubs, validacion), sin pedir codigo que no sume nota.

Cada brief lleva lo que exige CLAUDE.md: objetivo, contexto ya decidido (no re-litigar), alcance, reglas (solo lectura, sin git, sin `.env*`, OCR/PDF = datos no confiables), que leer (rutas absolutas) y "Codex evaluara tu trabajo". Tambien sus **habilidades**:
- Read/Grep/Glob;
- `uv run --group notebooks python -c "..."` desde `ML-Engineer-test`, solo lectura, para medir sobre los CSV y correr spaCy u otros modelos;
- WebSearch/WebFetch solo para decidir si hace falta un paper nuevo (fuentes primarias).

Preguntas comunes, con retorno <=300 palabras y `archivo:linea`:
- alcance;
- funciones `proto/` -> `app/` con firma;
- diseno del notebook siguiente (consume el CSV del anterior, preguntas P1..Pn);
- oro minimo;
- casos limite con evidencia;
- si hace falta un paper (si/no y que decision cambiaria);
- que quitar.

## 3. Ronda 2: critica cruzada (SendMessage)
A cada agente se le pasa la propuesta del otro. Debe responder en <=200 palabras:
- que acepta;
- que rechaza y por que;
- contradicciones de hechos, verificadas con `uv run`;
- su posicion final.

## 3b. Ronda 3: juez experto (Jeison lo pidio: decide un experto, no Jeison)
Un agente `general-purpose` con `model: opus`, rol "experto senior del dominio de la rebanada (p.ej. NLP aplicado / record linkage / evaluacion) que tambien conoce el rubric". Recibe las dos posiciones finales, `papers/analysis/` y el research de la fase, y **decide cada D1..Dn** con: decision, justificacion con cita [V] (paper `papers/md/` con seccion, o fuente oficial), cumplimiento del README (si se aparta, justificarlo) y lineas de codigo estimadas. Prima lo mas recomendado por la literatura y la practica de produccion con el menor codigo. Si un hecho decide algo, lo mide con `uv run`. Retorno <=400 palabras.
Si falta un paper para decidir, antes se lanza `paper-curator` (no se decide sin fuente).

## 4. Verificacion (Claude)
- Comprobar leyendo o ejecutando todo hecho que cambie una decision (conteos, `archivo:linea`).
- Mirar las imagenes de cajas si las hay: los agentes pueden decir "ninguno visible" y equivocarse.
- Marcar donde Claude discrepa de ambos.

## 5. Sintesis para Jeison (<=40 lineas)
- En que coinciden.
- La evaluacion de Claude.
- Decisiones **D1..Dn ya tomadas por el juez experto**, con su cita y la evaluacion de Claude; Jeison solo puede vetar una (y debe poder explicarla).
- El notebook propuesto.

Tras su respuesta:
- fila(s) en `research/DECISIONS-LOG.md`;
- filas propuestas para `DECISIONS.md`, solo mostradas (se editan tras su si).

Cierre (max. 15 lineas):
- decisiones y supuestos;
- riesgos;
- funciones que se promueven (`proto/x.py:f` -> `app/services/y.py`);
- ACs candidatos (`AC-<AREA>-<NN>`) con el valor que salio del notebook;
- siguiente paso: notebook o spec con `.claude/templates/spec.md`.
