---
name: commit-handoff
description: Prepara el bloque de comandos de git para que Jeison lo ejecute (add, escaneo de secretos, commit) cuando una rebanada esta verificada. Claude nunca ejecuta add, commit ni push.
allowed-tools: Read Grep Glob
---

# commit-handoff

1. Comprueba (solo lectura) repo y rama: `git rev-parse --show-toplevel` debe ser `C:\Users\Jeikosd\Documents\jeikosd\parterns_test_ML\ML-Engineer-test` y `git branch --show-current` debe ser `feat/jeison-mesa-document-intelligence`.
2. Lee `git status --short` y `git diff --stat`. Agrupa en commits **pequenos y atomicos**, una idea por commit, solo archivos de esta tarea.
3. Entrega el bloque para pegar en PowerShell (rutas completas, sin `git add -A`):

```powershell
$r = "C:\Users\Jeikosd\Documents\jeikosd\parterns_test_ML\ML-Engineer-test"
git -C $r status --short
git -C $r diff --stat
git -C $r add -- "$r\<ruta1>" "$r\<ruta2>"
git -C $r diff --cached --stat
git -C $r commit -m "tipo(scope): resumen en imperativo, max. 72 caracteres"
```

El hook `pre-commit` ya corre gitleaks sobre lo staged; no se repite.
4. Mensaje Conventional Commits (`feat|fix|test|refactor|docs|chore|ci`) de **una sola linea, sin cuerpo** (regla de Jeison; el por que va en `DECISIONS.md`). Sin `Co-Authored-By` ni mencion a Claude: el hook `commit-msg` lo rechaza. El uso de IA se declara en `DECISIONS.md`.
5. Cierra con 2 o 3 preguntas de entrevistador sobre ese commit, con respuesta corta.
