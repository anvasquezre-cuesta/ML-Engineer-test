# NN - <rebanada>

**Objetivo:** una frase. **Fuera de alcance:** lo que NO entra.
**Contrato:** endpoint o funcion y su forma (no cambiar `schemas.py`).
**Datos de prueba:** PDF o fixture, y el resultado esperado conocido.

## Criterios de aceptacion
Cada uno se prueba con `test_ac_<area>_<nn>_*` (ej. `AC-OCR-01` -> `test_ac_ocr_01_px_to_pt`).

- **AC-XXX-01** Given <estado>, When <accion>, Then <resultado observable>. _Test: unitario | integracion | e2e_
- **AC-XXX-02** ...

## Tareas (max. 6)
1. ...

## Explicacion (JM)
Por cada AC, en 3 a 5 lineas: que lineas lo cumplen y por que. Respuestas a 3 preguntas de entrevistador.
Firmada solo cuando Jeison puede explicarlo sin mirar.
