# NN-slug · <titulo>

**Alcance:** ...
**Spec:** `ML-Engineer-test/docs/specs/NN-slug.md`
**Estado:** research · evaluacion · spec · plan (JM) · impl · commit

| Etapa | Archivo |
|---|---|
| Research | [research.md](research.md) |
| Evaluacion | [evaluation.md](evaluation.md) |
| Plan (JM) | [plan.md](plan.md) |
| Reviews | [reviews/](reviews/) |
