# NN-slug · Evaluacion

| Que | Como | Esperado |
|---|---|---|
| ACs | ... | ... |
| Calidad | `verify.ps1` + code-critic | verde; APPROVE |

Gates comunes: `research/19-plan-implementacion.md`.
