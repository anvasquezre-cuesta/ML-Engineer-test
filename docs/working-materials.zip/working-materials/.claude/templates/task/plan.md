# NN-slug · Plan de implementación (JM)

_Lo escribe Jeison cuando research, evaluación y spec están cerrados. Claude lo revisa contra la spec y no lanza el implementer hasta que exista._

## Orden
1. ...

## Archivos y funciones
| Archivo | Función / cambio | Por qué existe (qué AC cubre) |
|---|---|---|

## Tests (rojo primero)
| Test | AC | Qué falla antes del código |
|---|---|---|

## Líneas esperadas y qué no voy a escribir
- ...

## Riesgos y cómo los verifico
- ...
