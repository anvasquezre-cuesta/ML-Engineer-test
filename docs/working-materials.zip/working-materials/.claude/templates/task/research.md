# NN-slug · Research

## Fuentes y decisiones tomadas
- [V] ...

## Huecos (falta investigar)
- ...

## Decisiones abiertas
- D-XXX-1: ...
