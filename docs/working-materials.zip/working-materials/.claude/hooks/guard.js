// PreToolUse: bloquea (exit 2) git/gh de escritura y secretos.
// Red de seguridad, no frontera: Jeison revisa y ejecuta git.
// schemas.py ya no se bloquea (Jeison, 2026-10-29): solo se le añaden campos opcionales justificados en DECISIONS.md.
const fs = require('node:fs');
const input = JSON.parse(fs.readFileSync(0, 'utf8'));
const tool = input.tool_name;
const ti = input.tool_input || {};

function block(why) {
  process.stderr.write(`guard: BLOQUEADO. ${why}\n`);
  process.exit(2);
}

// .env y variantes (no .env.example), claves y credenciales.
const SECRET = /(^|[\s\\/'"=])(\.env(\.(?!example\b)[\w.-]+)?|[\w.-]+\.(pem|key|pfx|p12)|id_(rsa|ed25519)|\.git-credentials)(?=$|[\s\\/'";|&)])/i;
// "git ... <verbo>" en el mismo segmento: cubre git -C ruta, git -c x=y, & git, cmd /c git.
const GIT_WRITE = /\bgit\b[^|;&\n]*\s(add|commit|push|reset|clean|rebase|merge|tag|stash|checkout|switch|restore|rm|mv|cherry-pick|revert|apply|am)\b/i;
const GH_WRITE = /\bgh\b[^|;&\n]*\s(create|merge|close|edit|comment|review|delete|fork|token|-X\s*(POST|PUT|PATCH|DELETE))\b/i;

if (tool === 'Bash' || tool === 'PowerShell') {
  const cmd = String(ti.command || '').replace(/['"`]/g, ' ');
  if (GIT_WRITE.test(cmd) || GH_WRITE.test(cmd)) block('git/gh de escritura: lo ejecuta Jeison.');
  if (SECRET.test(cmd)) block('el comando menciona un archivo de secretos.');
} else {
  const p = String(ti.file_path || ti.notebook_path || ti.path || '');
  if (SECRET.test(p)) block(`${tool} sobre un archivo de secretos.`);
}
