---
paths:
  - "ML-Engineer-test/tests/**"
---

- Nombre del test = criterio de la spec: `AC-OCR-01` -> `test_ac_ocr_01_<que_prueba>`.
- Unitarios sin red, sin modelos reales y sin LLM: usar fakes de `tests/fakes.py` y `httpx.MockTransport`.
- E2E con `skipif` si no existe Tesseract (`shutil.which("tesseract")` es `None`).
- Fixtures con rutas de Windows: crearlos con la herramienta Write, no con heredocs de shell (colapsan `\\`).
- Un test por comportamiento; assertions con valores que el notebook ya valido.
- Primero rojo por la razon correcta, despues verde con el codigo minimo.
